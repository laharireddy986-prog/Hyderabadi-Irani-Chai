import os
import json
import time
import subprocess
import argparse
from io import BytesIO
from PIL import Image
from google import genai
from google.genai import types

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"

MENU_ITEMS_FILE = r"c:\Hyderabadi Irani\scripts\menu_items.json"
PROGRESS_FILE = r"c:\Hyderabadi Irani\scripts\generation_progress.json"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"

os.makedirs(OUTPUT_DIR, exist_ok=True)

def load_data():
    with open(MENU_ITEMS_FILE, "r", encoding="utf-8") as f:
        items = json.load(f)
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
            progress = json.load(f)
    else:
        progress = {}
    return items, progress

def save_progress(progress):
    with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
        json.dump(progress, f, indent=2)

def generate_and_upload_item(client, item, progress, max_retries=5):
    slug = item["slug"]
    name = item["name"]
    prompt = item.get("prompt", "")
    
    if not prompt or len(prompt.strip()) < 10:
        prompt = f"A professional close-up food photo of authentic Indian dish {name}, served hot in restaurant tableware, garnished with fresh herbs, appetizing colors, natural lighting, 45 degree angle, high resolution."

    print(f"\n[START] #{item['index']:03d}: {name} ({slug})", flush=True)
    
    for attempt in range(1, max_retries + 1):
        try:
            print(f" -> Generating image via Vertex AI (attempt {attempt})...", flush=True)
            response = client.models.generate_content(
                model="gemini-2.5-flash-image",
                contents=prompt
            )
            
            image_bytes = None
            for candidate in response.candidates:
                for part in candidate.content.parts:
                    if part.inline_data and part.inline_data.data:
                        image_bytes = part.inline_data.data
                        break
                if image_bytes:
                    break
                    
            if not image_bytes:
                raise ValueError("No inline image data returned by Vertex AI model")
                
            print(f" -> Raw image received ({len(image_bytes)/1024:.1f} KB). Optimizing to WebP...", flush=True)
            
            # Convert & Optimize
            img = Image.open(BytesIO(image_bytes))
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            img = img.resize((600, 600), Image.Resampling.LANCZOS)
            
            webp_path = os.path.join(OUTPUT_DIR, f"{slug}.webp")
            img.save(webp_path, "WEBP", quality=82, method=6)
            size_kb = os.path.getsize(webp_path) / 1024
            
            print(f" -> WebP created: {size_kb:.1f} KB. Uploading to GCS...", flush=True)
            gcs_dest = f"gs://{BUCKET_NAME}/menu/{slug}.webp"
            cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", webp_path, gcs_dest]
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            
            if res.returncode == 0:
                public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"
                progress[slug] = {
                    "status": "uploaded",
                    "size_kb": round(size_kb, 1),
                    "url": public_url
                }
                save_progress(progress)
                print(f"[DONE] Uploaded: {public_url}", flush=True)
                return True
            else:
                print(f" -> GCS Upload failed: {res.stderr}", flush=True)
                raise RuntimeError(f"GCS error: {res.stderr}")

        except Exception as e:
            err_str = str(e)
            print(f" -> Error on attempt {attempt}: {err_str}", flush=True)
            if attempt < max_retries:
                if "RESOURCE_EXHAUSTED" in err_str or "429" in err_str:
                    sleep_time = 15 + (attempt * 15)  # 30s, 45s, 60s, 75s
                else:
                    sleep_time = attempt * 5
                print(f" -> Waiting {sleep_time}s before retry...", flush=True)
                time.sleep(sleep_time)
            else:
                print(f"[FAILED] Could not process {slug} after {max_retries} attempts.", flush=True)
                return False

def main():
    parser = argparse.ArgumentParser(description="Generate and upload menu images via Vertex AI")
    parser.add_argument("--batch-size", type=int, default=0, help="Number of items to generate (0 for all)")
    parser.add_argument("--delay", type=float, default=4.0, help="Delay between requests in seconds")
    parser.add_argument("--single", type=str, default="", help="Specific slug to generate")
    args = parser.parse_args()

    items, progress = load_data()
    
    client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    
    if args.single:
        target_items = [it for it in items if it["slug"] == args.single]
        if not target_items:
            print(f"Item with slug {args.single} not found!", flush=True)
            return
    else:
        target_items = [it for it in items if it["slug"] not in progress or progress[it["slug"]].get("status") != "uploaded"]

    total_remaining = len(target_items)
    print(f"Found {total_remaining} items needing image generation.", flush=True)
    
    if args.batch_size > 0:
        target_items = target_items[:args.batch_size]
        print(f"Running batch of {len(target_items)} items...", flush=True)

    success_count = 0
    fail_count = 0
    
    for i, item in enumerate(target_items, 1):
        print(f"\n[{i}/{len(target_items)}] Processing #{item['index']} - {item['name']}", flush=True)
        ok = generate_and_upload_item(client, item, progress)
        if ok:
            success_count += 1
        else:
            fail_count += 1
            
        if i < len(target_items):
            print(f"Sleeping {args.delay}s to avoid rate limits...", flush=True)
            time.sleep(args.delay)

    print(f"\n==========================================", flush=True)
    print(f"Batch completed: {success_count} succeeded, {fail_count} failed.", flush=True)
    print(f"Total uploaded in progress file: {len([k for k, v in progress.items() if v.get('status') == 'uploaded'])} / {len(items)}", flush=True)
    print(f"==========================================", flush=True)

if __name__ == "__main__":
    main()
