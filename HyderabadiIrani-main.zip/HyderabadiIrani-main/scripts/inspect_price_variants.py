import json

with open('scripts/menu_items.json', 'r', encoding='utf-8') as f:
    items = json.load(f)

both = []
half_only = []
full_only = []

for it in items:
    h = it.get('price_half')
    f = it.get('price_full')
    if h is not None and f is not None:
        both.append(it)
    elif h is not None:
        half_only.append(it)
    elif f is not None:
        full_only.append(it)

print(f"Total items: {len(items)}")
print(f"Both half/single and full: {len(both)}")
print(f"Half/single only: {len(half_only)}")
print(f"Full only: {len(full_only)}")

print("\n--- Samples with Both Prices ---")
for it in both[:15]:
    sec = it.get('section')
    label_single = "Single" if sec in ["BIRYANIS", "BIRYANI", "COMBO PACK"] else "Half"
    print(f"#{it['index']:03d} [{sec}] {it['name']}: {label_single}=Rs.{it['price_half']}, Full=Rs.{it['price_full']}")

print("\n--- Samples with Single Price ---")
for it in (half_only + full_only)[:10]:
    val = it.get('price_half') or it.get('price_full')
    print(f"#{it['index']:03d} [{it.get('section')}] {it['name']}: Rs.{val}")
