import json

with open("scripts/menu_items.json", "r", encoding="utf-8") as f:
    items = json.load(f)

for it in items[:15]:
    print(f"#{it['index']:03d} {it['name']} ({it['section']}) -> {it['slug']}")
    print(f"   Prompt: {it['prompt']}\n")
