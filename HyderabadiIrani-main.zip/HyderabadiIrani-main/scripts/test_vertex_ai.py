import os
from google import genai
from google.genai import types

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"

print(f"Testing Vertex AI Imagen on project {PROJECT_ID}...")

try:
    client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    
    result = client.models.generate_images(
        model="imagen-3.0-generate-002",
        prompt="A professional photo of authentic Indian Veg Clear Soup served in a ceramic bowl, steaming hot with fresh herbs",
        config=types.GenerateImagesConfig(
            number_of_images=1,
            output_mime_type="image/jpeg",
            aspect_ratio="1:1",
        )
    )
    
    if result.generated_images:
        for idx, generated_image in enumerate(result.generated_images):
            image_bytes = generated_image.image.image_bytes
            with open("scripts/test_vertex_image.jpg", "wb") as f:
                f.write(image_bytes)
            print(f"[SUCCESS] Vertex AI generated image saved! Size: {len(image_bytes)} bytes")
    else:
        print("[FAIL] No images returned in result")

except Exception as e:
    print(f"[ERROR] Vertex AI test failed: {e}")
