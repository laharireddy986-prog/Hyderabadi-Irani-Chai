import os
import json
import time
import subprocess
import asyncio
from io import BytesIO
from PIL import Image
from google import genai
from motor.motor_asyncio import AsyncIOMotorClient

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

os.makedirs(OUTPUT_DIR, exist_ok=True)

ITEMS_TO_ADD = [
    # Sweets
    {
        "slug": "apricot_delight",
        "name": "Apricot Delight",
        "category": "Sweets",
        "price": 100.0,
        "veg": True,
        "station": "kitchen",
        "description": "Signature rich Hyderabadi Apricot Delight layered with pure apricot pulp, custard cream, and chopped dry fruits.",
        "prompt": "A professional close-up food photo of authentic Hyderabadi sweet Apricot Delight, served cold in a dessert cup layered with pure apricot pulp, rich custard cream, garnished with chopped pistachios and almonds, appetizing, 45 degree angle, restaurant lighting."
    },
    {
        "slug": "kaddu_ki_kheer",
        "name": "Kaddu Ka Kheer",
        "category": "Sweets",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Traditional Hyderabadi wedding dessert made with grated bottle gourd, creamy condensed milk, sago pearls, and crunchy cashews.",
        "prompt": "A professional close-up food photography of authentic Hyderabadi Kaddu Ki Kheer (bottle gourd sweet pudding), rich creamy texture, garnished with cashews, almonds, and silver vark, served in a traditional bowl, appetizing, shallow depth of field."
    },
    {
        "slug": "gulab_jamun",
        "name": "Gulab Jamun",
        "category": "Sweets",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Soft, golden-brown melt-in-mouth milk solid dumplings soaked in aromatic cardamom & saffron rose sugar syrup.",
        "prompt": "A professional close-up photo of hot juicy Gulab Jamun balls soaked in glossy cardamom rose sugar syrup, garnished with sliced pistachios and saffron strands, served in a ceramic bowl, steaming hot, high quality food photography."
    },
    {
        "slug": "double_ka_meetha",
        "name": "Double Ka Meetha",
        "category": "Sweets",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Royal Hyderabadi Shahi Tukda dessert made from crisp ghee-fried bread soaked in rich saffron infused rabdi and topped with roasted nuts.",
        "prompt": "A gourmet close-up food photo of authentic Hyderabadi Double Ka Meetha (Shahi Tukra), golden fried bread triangles steeped in saffron thickened rabdi milk, loaded with toasted cashews and almonds, rich royal Mughlai presentation."
    },

    # Snacks
    {
        "slug": "aloo_samosa",
        "name": "Aloo Samosa (1 Pc)",
        "category": "Snacks",
        "price": 20.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy golden fried triangle pastry filled with spiced mashed potato, green peas, and fragrant herbs (1 Piece).",
        "prompt": "A mouthwatering food photo of a freshly fried crispy golden North Indian Aloo Samosa with flaky crust, served hot with mint green chutney and tamarind sauce, steam rising, high detail food shot."
    },
    {
        "slug": "onion_samosa",
        "name": "Onion Samosa (6 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Irani cafe style crispy mini crunchy samosas stuffed with savory spiced onion, poha, and green chillies (Plate of 6 Pcs).",
        "prompt": "A plate of 6 freshly fried crispy Irani style mini Onion Samosas (Hyderabadi cafe snack), golden crunchy thin crust, served on a street food plate with fried green chillies, appetizing lighting."
    },
    {
        "slug": "osmania_biscuits_pack",
        "name": "Osmania Biscuits (10 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "tea",
        "description": "Classic melt-in-mouth sweet & salty butter baked Hyderabadi Osmania biscuits (Pack of 10 Pcs).",
        "prompt": "A stack of authentic round Hyderabadi Osmania Biscuits with a cup of hot steaming Irani Chai in background, golden baked texture, classic Hyderabad tea stall setting, warm cozy lighting."
    },
    {
        "slug": "khara_biscuits_pack",
        "name": "Khara Biscuits (10 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "tea",
        "description": "Crispy savory spiced Irani tea biscuits baked with cumin, curry leaves, and green chillies (Pack of 10 Pcs).",
        "prompt": "A neat plate of authentic savory spiced Khara biscuits with cumin seeds and curry leaf flecks, crisp bakery texture, paired with a glass of Irani tea, warm cafe backdrop."
    },
    {
        "slug": "egg_puff",
        "name": "Egg Puff",
        "category": "Snacks",
        "price": 20.0,
        "veg": False,
        "station": "kitchen",
        "description": "Flaky golden bakery puff pastry filled with spiced onion masala and seasoned boiled egg.",
        "prompt": "A close-up shot of a freshly baked golden brown flaky Egg Puff, cut to reveal savory onion masala and boiled egg inside, crispy pastry layers, bakery counter display."
    },
    {
        "slug": "veg_puff",
        "name": "Veg Puff",
        "category": "Snacks",
        "price": 20.0,
        "veg": True,
        "station": "kitchen",
        "description": "Layers of crispy golden puff pastry loaded with spiced mixed vegetable masala.",
        "prompt": "A close-up of a crispy golden laminated Veg Puff pastry, flaky golden brown layers, vegetable potato filling peeking through, appetizing bakery snack shot."
    },
    {
        "slug": "chicken_puff",
        "name": "Chicken Puff",
        "category": "Snacks",
        "price": 30.0,
        "veg": False,
        "station": "kitchen",
        "description": "Golden crisp layered puff stuffed with succulent minced chicken cooked in Hyderabadi spices.",
        "prompt": "A gourmet food photo of a freshly baked Indian Chicken Puff pastry, golden brown buttery crust, spiced minced chicken filling visible, served with tomato ketchup."
    },
    {
        "slug": "paneer_puff",
        "name": "Paneer Puff",
        "category": "Snacks",
        "price": 30.0,
        "veg": True,
        "station": "kitchen",
        "description": "Flaky crispy oven-baked puff loaded with savory marinated paneer cubes and herbs.",
        "prompt": "A close-up of a warm flaky Paneer Puff pastry with golden crispy layers, filled with spiced diced cottage cheese paneer masala, clean food photography."
    },
    {
        "slug": "onion_pakoda",
        "name": "Onion Pakoda (100g)",
        "category": "Snacks",
        "price": 30.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crunchy, spicy sliced onion fritters deep fried with chickpea batter, curry leaves, and green chillies (100 grams).",
        "prompt": "A fresh hot bowl of crunchy golden-brown Onion Pakoda (Ulli Vada / Onion Fritters), crispy tangled onion strands with curry leaves and green chillies, served with chai, vibrant colors."
    },
    {
        "slug": "mirchi_bajji",
        "name": "Mirchi Bajji (4 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy batter-fried whole green bhavnagri chillies stuffed with tangy ajwain and lemon masala (Plate of 4 Pcs).",
        "prompt": "A plate of 4 large golden-fried Andhra Mirchi Bajjis (chilli fritters), slit and stuffed with chopped onions, fresh coriander and lime juice, street food style, crisp batter."
    },
    {
        "slug": "punugulu",
        "name": "Punugulu",
        "category": "Snacks",
        "price": 40.0,
        "veg": True,
        "station": "kitchen",
        "description": "Golden crisp outside and fluffy soft inside deep-fried rice & urad dal snack balls served with spicy coconut chutney.",
        "prompt": "A plate of hot golden-fried Andhra Punugulu (bonda fritters), crispy round dumplings served with spicy red peanut chutney and coconut chutney, authentic street food shot."
    },
    {
        "slug": "masala_vada",
        "name": "Masala Vada (4 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crunchy South Indian chana dal patties infused with onions, coriander, curry leaves, and ginger (Plate of 4 Pcs).",
        "prompt": "A plate of 4 crispy crunchy South Indian Masala Vadas (Parippu Vada), coarse chana dal texture with visible curry leaves and chopped onions, golden brown, appetizing lighting."
    },
    {
        "slug": "cut_mirchi",
        "name": "Cut Mirchi (2 Pcs)",
        "category": "Snacks",
        "price": 30.0,
        "veg": True,
        "station": "kitchen",
        "description": "Double-fried crispy bite-sized sliced mirchi bajjis tossed with roasted peanut powder, onions, and lemon (2 pieces cut).",
        "prompt": "A bowl of Hyderabadi street style Cut Mirchi Bajji, double fried crunchy chilli pieces topped with finely chopped onions, roasted peanut powder, fresh coriander and lemon juice."
    },
    {
        "slug": "egg_bonda",
        "name": "Egg Bonda (1 Pc)",
        "category": "Snacks",
        "price": 20.0,
        "veg": False,
        "station": "kitchen",
        "description": "Whole boiled egg dipped in spiced gram flour batter and deep fried to golden perfection (1 Piece).",
        "prompt": "A plate with a golden deep-fried Egg Bonda cut in half to show the whole boiled egg with spiced masala inside, crispy golden batter, served with spicy onion salad."
    },
]

def generate_and_upload(client, item):
    slug = item["slug"]
    name = item["name"]
    prompt = item["prompt"]
    webp_path = os.path.join(OUTPUT_DIR, f"{slug}.webp")
    gcs_dest = f"gs://{BUCKET_NAME}/menu/{slug}.webp"
    public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"

    print(f"\n[IMAGE] Generating image for '{name}'...", flush=True)
    for attempt in range(1, 4):
        try:
            res = client.models.generate_content(
                model="gemini-2.5-flash-image",
                contents=prompt
            )
            image_bytes = None
            for candidate in res.candidates:
                for part in candidate.content.parts:
                    if part.inline_data and part.inline_data.data:
                        image_bytes = part.inline_data.data
                        break
                if image_bytes:
                    break

            if not image_bytes:
                raise ValueError("No image bytes returned")

            # Optimize with PIL
            img = Image.open(BytesIO(image_bytes))
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            img = img.resize((600, 600), Image.Resampling.LANCZOS)
            img.save(webp_path, "WEBP", quality=82, method=6)
            size_kb = os.path.getsize(webp_path) / 1024
            print(f" -> Optimized WebP: {size_kb:.1f} KB. Uploading to GCS...", flush=True)

            # Upload to GCS
            cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", webp_path, gcs_dest]
            proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if proc.returncode == 0:
                print(f" -> Uploaded: {public_url}", flush=True)
                return public_url
            else:
                print(f" -> GCS Upload error: {proc.stderr}", flush=True)
        except Exception as e:
            print(f" -> Error on attempt {attempt}: {e}", flush=True)
            time.sleep(3)

    return public_url

async def sync_mongodb(items_with_urls):
    print("\n[DB] Connecting to MongoDB to insert/update menu items...", flush=True)
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    for itm in items_with_urls:
        doc = {
            "name": itm["name"],
            "category": itm["category"],
            "price": float(itm["price"]),
            "price_half": None,
            "price_full": None,
            "has_variants": False,
            "variants": [],
            "veg": itm["veg"],
            "station": itm["station"],
            "available": True,
            "description": itm["description"],
            "image_url": f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{itm['slug']}.webp",
        }
        await db.menu.update_one(
            {"name": itm["name"]},
            {"$set": doc},
            upsert=True
        )
        print(f" -> Synced DB: {itm['name']} ({itm['category']} - Rs.{itm['price']})", flush=True)

    count = await db.menu.count_documents({})
    cats = await db.menu.distinct("category")
    print(f"\n[SUCCESS] MongoDB now has {count} total menu items across categories: {cats}", flush=True)

def main():
    asyncio.run(sync_mongodb(ITEMS_TO_ADD))

if __name__ == "__main__":
    main()
