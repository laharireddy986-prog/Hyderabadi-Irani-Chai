import os
import json
import time
from io import BytesIO
from PIL import Image
from google import genai
from google.cloud import storage
import pymongo

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

os.makedirs(OUTPUT_DIR, exist_ok=True)

REMAINING_ITEMS = [
    {
        "name": "Chicken Puff.",
        "slug": "crispy_chicken_puff_pastry",
        "prompt": "A golden-brown flaky Chicken Puff pastry, multi-layered crisp puff crust filled with spicy savory minced chicken filling, garnished with herbs on a restaurant plate."
    },
    {
        "name": "onion Pakoda(100grms)",
        "slug": "hyderabadi_onion_pakoda_kanda_bhajji",
        "prompt": "A generous portion of ultra-crispy golden-brown Hyderabadi Onion Pakoda (Kanda Bhajji), crunchy sliced onion fritters seasoned with ajwain and curry leaves, served with fried green chilies on rustic paper."
    },
    {
        "name": "Water Bottle",
        "slug": "packaged_drinking_water_1l",
        "prompt": "A sealed chilled 1-litre clear mineral water bottle with natural condensation water droplets on the bottle surface, clean refreshing pure blue and white background."
    },
    {
        "name": "Water Bottle(Half)",
        "slug": "packaged_drinking_water_500ml",
        "prompt": "A compact chilled 500ml mineral packaged drinking water bottle with cool water droplets, clean refreshing studio beverage photography."
    }
]

def main():
    print(f"=== Generating Remaining {len(REMAINING_ITEMS)} Items ===", flush=True)

    genai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    storage_client = storage.Client(project=PROJECT_ID)
    gcs_bucket = storage_client.bucket(BUCKET_NAME)
    mongo_client = pymongo.MongoClient(MONGO_URL)
    db = mongo_client[DB_NAME]

    for idx, item in enumerate(REMAINING_ITEMS, 1):
        slug = item["slug"]
        name = item["name"]
        prompt = item["prompt"]
        webp_path = os.path.join(OUTPUT_DIR, f"{slug}.webp")
        public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"

        print(f"\n[{idx}/{len(REMAINING_ITEMS)}] Processing '{name}' ({slug})...", flush=True)

        success = False
        for attempt in range(1, 5):
            try:
                t0 = time.time()
                res = genai_client.models.generate_content(
                    model="gemini-2.5-flash-image",
                    contents=prompt
                )
                image_bytes = None
                for candidate in res.candidates:
                    for part in candidate.content.parts:
                        if part.inline_data and part.inline_data.data:
                            image_bytes = part.inline_data.data
                            break
                    if image_bytes:
                        break

                if not image_bytes:
                    raise ValueError("No image bytes returned")

                img = Image.open(BytesIO(image_bytes))
                if img.mode in ("RGBA", "P"):
                    img = img.convert("RGB")
                img = img.resize((600, 600), Image.Resampling.LANCZOS)
                img.save(webp_path, "WEBP", quality=82, method=6)
                size_kb = os.path.getsize(webp_path) / 1024

                blob = gcs_bucket.blob(f"menu/{slug}.webp")
                blob.upload_from_filename(webp_path, content_type="image/webp")

                res_db = db.menu_items.update_one(
                    {"name": name},
                    {
                        "$set": {
                            "image_url": public_url,
                            "category": "Tea",
                            "counter_only": True,
                            "order_type": "counter",
                            "dine_in_instruction": "Order & Collect at Live Tea Counter"
                        }
                    }
                )

                print(f" -> SUCCESS in {time.time()-t0:.1f}s ({size_kb:.1f}KB) | DB matched: {res_db.matched_count} | URL: {public_url}", flush=True)
                success = True
                break
            except Exception as e:
                err_str = str(e)
                wait_time = 15 if "429" in err_str or "RESOURCE_EXHAUSTED" in err_str else 5
                print(f" -> Attempt {attempt} error: {e}. Sleeping {wait_time}s...", flush=True)
                time.sleep(wait_time)

        if not success:
            print(f" -> FAILED to generate: '{name}'", flush=True)

        time.sleep(4)

    print("\n=======================================================")
    print("ALL REMAINING ITEMS COMPLETE!")
    print("=======================================================")

if __name__ == "__main__":
    main()
