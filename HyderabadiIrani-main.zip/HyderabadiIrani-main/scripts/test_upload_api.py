import urllib.request
import json
import base64
from PIL import Image
import io

# 1. Login as admin
login_req = urllib.request.Request(
    'http://localhost:8000/api/auth/login',
    data=json.dumps({"email": "admin@hyderabadiirani.com", "password": "admin123"}).encode('utf-8'),
    headers={'Content-Type': 'application/json'}
)

try:
    with urllib.request.urlopen(login_req) as lres:
        auth_data = json.loads(lres.read())
        token = auth_data.get('token') or auth_data.get('access_token')
        csrf = auth_data.get('csrf_token', '')
        print("Logged in as admin successfully!")
except Exception as e:
    # Try default admin PIN or credentials
    print("Login error, testing with fallback login:", e)
    token = None
    csrf = ""

# Create sample test image
img = Image.new('RGB', (1000, 1000), color=(180, 50, 50))
buf = io.BytesIO()
img.save(buf, format='JPEG', quality=95)
img_b64 = base64.b64encode(buf.getvalue()).decode('utf-8')

payload = {
    "image_base64": img_b64,
    "filename": "test_api_upload_dish",
    "item_name": "Test Api Upload Dish"
}

headers = {'Content-Type': 'application/json'}
if token:
    headers['Authorization'] = f'Bearer {token}'
if csrf:
    headers['X-CSRF-Token'] = csrf

req = urllib.request.Request(
    'http://localhost:8000/api/menu/upload-image',
    data=json.dumps(payload).encode('utf-8'),
    headers=headers
)

try:
    with urllib.request.urlopen(req) as res:
        data = json.loads(res.read())
        print("Upload Response:", json.dumps(data, indent=2))
        print(f"Size: {data.get('size_kb')} KB (Under 50 KB: {data.get('size_kb', 100) < 50})")
except Exception as e:
    if hasattr(e, 'read'):
        print("Error details:", e.read().decode('utf-8'))
    else:
        print("Error:", e)

