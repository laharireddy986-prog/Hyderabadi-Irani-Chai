import asyncio
from motor.motor_asyncio import AsyncIOMotorClient

async def check():
    client = AsyncIOMotorClient("mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
    db = client["hyderabadi_irani"]
    count = await db.menu_items.count_documents({})
    print(f"Total items in DB menu_items: {count}")
    
    categories = ["Soups", "Fried Rice", "Noodles", "Starters", "Currys", "Sea Food", "Biryani", "Tandoori Kebabs", "Rotis", "Shawarma", "Tea"]
    print("\n--- Sample Items with Live Image URLs ---")
    for cat in categories:
        item = await db.menu_items.find_one({"category": cat})
        if item:
            print(f"[{cat:15s}] {item['name'][:25]:25s} (Rs.{item['price']:3.0f}) -> {item['image_url']}")

if __name__ == "__main__":
    asyncio.run(check())
