import os
from PIL import Image, ImageDraw, ImageFont

OUTPUT_DIR = r"c:\Hyderabadi Irani\mobile-delivery-app\store_assets"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def create_screenshot(title, subtitle, badge, content_renderer, filename):
    width, height = 1080, 2400
    img = Image.new("RGB", (width, height), "#1c0a00")
    draw = ImageDraw.Draw(img)

    try:
        font_badge = ImageFont.truetype("arialbd.ttf", 36)
        font_title = ImageFont.truetype("arialbd.ttf", 64)
        font_sub = ImageFont.truetype("arial.ttf", 40)
        font_bold = ImageFont.truetype("arialbd.ttf", 44)
        font_reg = ImageFont.truetype("arial.ttf", 36)
        font_mono = ImageFont.truetype("consola.ttf", 42)
    except:
        font_badge = ImageFont.load_default()
        font_title = ImageFont.load_default()
        font_sub = ImageFont.load_default()
        font_bold = ImageFont.load_default()
        font_reg = ImageFont.load_default()
        font_mono = ImageFont.load_default()

    # Top Header Banner
    draw.rounded_rectangle([60, 100, 420, 160], radius=30, fill="#78350f", outline="#fbbf24", width=2)
    draw.text((240, 130), badge, fill="#fbbf24", font=font_badge, anchor="mm")

    draw.text((60, 240), title, fill="#ffffff", font=font_title)
    draw.text((60, 320), subtitle, fill="#fcd34d", font=font_sub)

    # Phone mock container
    phone_box = [60, 420, 1020, 2300]
    draw.rounded_rectangle(phone_box, radius=60, fill="#f5f5f4", outline="#78350f", width=6)

    # Status Bar
    draw.text((120, 480), "9:41", fill="#1c1917", font=font_bold)
    draw.text((900, 480), "5G  100%", fill="#1c1917", font=font_reg, anchor="rm")

    content_renderer(draw, phone_box, font_bold, font_reg, font_mono)

    out_path = os.path.join(OUTPUT_DIR, filename)
    img.save(out_path, "PNG")
    print(f"Created screenshot: {out_path}")

# 1. Login Screen
def render_login(draw, box, font_bold, font_reg, font_mono):
    draw.rounded_rectangle([box[0], 540, box[1], 700], fill="#451a03")
    draw.text((540, 620), "Hyderabadi Irani Delivery", fill="#ffffff", font=font_bold, anchor="mm")

    # Center Logo
    draw.ellipse([440, 800, 640, 1000], fill="#fbbf24")
    draw.text((540, 900), "🛵", fill="#451a03", font=font_bold, anchor="mm")

    draw.text((540, 1060), "Partner Sign In", fill="#1c1917", font=font_bold, anchor="mm")
    draw.text((540, 1120), "Enter your registered driver details", fill="#78716c", font=font_reg, anchor="mm")

    # Input fields
    draw.rounded_rectangle([140, 1200, 940, 1320], radius=24, fill="#ffffff", outline="#d6d3d1", width=3)
    draw.text((200, 1260), "driver@hyderabadiirani.com", fill="#1c1917", font=font_reg, anchor="lm")

    draw.rounded_rectangle([140, 1360, 940, 1480], radius=24, fill="#ffffff", outline="#d6d3d1", width=3)
    draw.text((200, 1420), "••••••••••••", fill="#1c1917", font=font_reg, anchor="lm")

    # Sign In button
    draw.rounded_rectangle([140, 1540, 940, 1660], radius=24, fill="#fbbf24", outline="#d97706", width=2)
    draw.text((540, 1600), "SIGN IN 🛵", fill="#451a03", font=font_bold, anchor="mm")

# 2. Orders Screen
def render_orders(draw, box, font_bold, font_reg, font_mono):
    draw.rounded_rectangle([box[0], 540, box[1], 700], fill="#451a03")
    draw.text((120, 620), "🛵 My Active Deliveries", fill="#ffffff", font=font_bold, anchor="lm")

    # Order Card 1
    card1 = [100, 750, 980, 1350]
    draw.rounded_rectangle(card1, radius=32, fill="#ffffff", outline="#e7e5e4", width=3)
    draw.text((140, 810), "#HI-9842", fill="#451a03", font=font_mono)
    draw.rounded_rectangle([720, 780, 940, 840], radius=20, fill="#fef3c7")
    draw.text((830, 810), "ON THE WAY", fill="#92400e", font=font_reg, anchor="mm")

    draw.text((140, 880), "Customer: Rajesh Varma", fill="#1c1917", font=font_bold)
    draw.text((140, 940), "📍 Plot 42, Jubilee Hills Road No 36", fill="#44403c", font=font_reg)
    draw.text((140, 1000), "📦 2x Hyderabadi Mutton Biryani, 1x Apricot Delight", fill="#78716c", font=font_reg)
    draw.text((140, 1070), "Total: ₹670  (Cash on Delivery)", fill="#047857", font=font_bold)

    # Actions
    draw.rounded_rectangle([130, 1140, 440, 1240], radius=20, fill="#f5f5f4", outline="#d6d3d1", width=2)
    draw.text((285, 1190), "🗺️ Navigate", fill="#451a03", font=font_bold, anchor="mm")

    draw.rounded_rectangle([470, 1140, 670, 1240], radius=20, fill="#f5f5f4", outline="#d6d3d1", width=2)
    draw.text((570, 1190), "📞 Call", fill="#451a03", font=font_bold, anchor="mm")

    draw.rounded_rectangle([700, 1140, 950, 1240], radius=20, fill="#047857")
    draw.text((825, 1190), "Delivered ✅", fill="#ffffff", font=font_bold, anchor="mm")

    # Order Card 2
    card2 = [100, 1400, 980, 1950]
    draw.rounded_rectangle(card2, radius=32, fill="#ffffff", outline="#e7e5e4", width=3)
    draw.text((140, 1460), "#HI-9843", fill="#451a03", font=font_mono)
    draw.rounded_rectangle([720, 1430, 940, 1490], radius=20, fill="#d1fae5")
    draw.text((830, 1460), "READY PICKUP", fill="#065f46", font=font_reg, anchor="mm")

    draw.text((140, 1530), "Customer: Priya Sharma", fill="#1c1917", font=font_bold)
    draw.text((140, 1590), "📍 Cyber Towers, Hitec City", fill="#44403c", font=font_reg)
    draw.text((140, 1650), "📦 4x Irani Chai, 1x Osmania Biscuits (10 Pcs)", fill="#78716c", font=font_reg)
    draw.text((140, 1720), "Total: ₹130  (Prepaid Online)", fill="#1d4ed8", font=font_bold)

    draw.rounded_rectangle([130, 1800, 950, 1900], radius=20, fill="#451a03")
    draw.text((540, 1850), "Accept Delivery 🛵", fill="#ffffff", font=font_bold, anchor="mm")

# 3. Calendar & Stats
def render_stats(draw, box, font_bold, font_reg, font_mono):
    draw.rounded_rectangle([box[0], 540, box[1], 700], fill="#451a03")
    draw.text((120, 620), "📊 Daily Ride Analytics", fill="#ffffff", font=font_bold, anchor="lm")

    # Stat grid (4 cards)
    stats = [
        ("18", "RIDES COMPLETED", "#047857", "#d1fae5"),
        ("42.8 km", "DISTANCE TRAVELLED", "#b45309", "#fef3c7"),
        ("₹2,450", "CASH COLLECTED", "#047857", "#ecfdf5"),
        ("₹6,890", "TOTAL ORDER VALUE", "#4338ca", "#e0e7ff"),
    ]
    coords = [
        [100, 750, 520, 1020],
        [560, 750, 980, 1020],
        [100, 1060, 520, 1330],
        [560, 1060, 980, 1330],
    ]
    for (val, lbl, txt_col, bg_col), c in zip(stats, coords):
        draw.rounded_rectangle(c, radius=28, fill=bg_col, outline="#e5e7eb", width=2)
        draw.text(((c[0]+c[2])//2, c[1]+90), val, fill=txt_col, font=font_bold, anchor="mm")
        draw.text(((c[0]+c[2])//2, c[1]+180), lbl, fill="#374151", font=font_reg, anchor="mm")

    # History List
    draw.text((120, 1400), "Today's Delivery Log", fill="#1c1917", font=font_bold)
    draw.rounded_rectangle([100, 1470, 980, 2150], radius=28, fill="#ffffff", outline="#e5e7eb", width=2)
    draw.text((140, 1540), "✓ #HI-9839 · ₹450 Cash · 12:45 PM", fill="#047857", font=font_bold)
    draw.text((140, 1600), "Plot 12, Banjara Hills Rd 10", fill="#78716c", font=font_reg)

    draw.line([(140, 1680), (940, 1680)], fill="#e5e7eb", width=2)

    draw.text((140, 1760), "✓ #HI-9838 · ₹820 Online · 01:15 PM", fill="#1d4ed8", font=font_bold)
    draw.text((140, 1820), "Flat 402, Madhapur Main Road", fill="#78716c", font=font_reg)

    draw.line([(140, 1900), (940, 1900)], fill="#e5e7eb", width=2)

    draw.text((140, 1980), "✓ #HI-9837 · ₹210 Cash · 02:00 PM", fill="#047857", font=font_bold)
    draw.text((140, 2040), "Gachibowli Flyover Jn", fill="#78716c", font=font_reg)

if __name__ == "__main__":
    create_screenshot("Rider Sign In", "Instant access for verified fleet", "SECURITY", render_login, "screenshot_1_login.png")
    create_screenshot("Live Orders & Navigation", "Turn-by-turn Google Maps & calling", "NAVIGATION", render_orders, "screenshot_2_orders.png")
    create_screenshot("Daily Earnings & Analytics", "Rides, distance & cash tracking", "INSIGHTS", render_stats, "screenshot_3_stats.png")
