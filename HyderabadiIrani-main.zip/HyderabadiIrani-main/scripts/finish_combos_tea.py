import os
import time
import subprocess
import asyncio
from io import BytesIO
from PIL import Image
from google import genai
from motor.motor_asyncio import AsyncIOMotorClient

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
OUT = r"c:\Hyderabadi Irani\scripts\optimized_images"

client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)

items = [
    {
        "name": "CHICKEN FRY PIECE BIRYANI(FAMILY / JUMBO)",
        "slug": "combo_chicken_fry_piece_biryani_jumbo",
        "prompt": "A grand platter of Hyderabadi Special Chicken Fry Piece Biryani Family Jumbo Pack, richly topped with crispy spicy red Andhra-style fried chicken pieces, roasted cashews, curry leaves, layered over fragrant ghee bagara biryani rice, served with lemon wedges, onions, and gravy."
    },
    {
        "name": "Special Irani Chai (Khada Chammach)",
        "slug": "special_irani_chai_khada_chammach",
        "prompt": "Authentic Hyderabadi Khada Chammach Irani Chai, served in a glass where a steel spoon stands perfectly upright supported by thick rabdi condensed milk at the bottom, rich golden aromatic tea layered on top, traditional Hyderabad cafe presentation, 45 degree angle."
    },
    {
        "name": "Bun Maska",
        "slug": "bun_maska_authentic",
        "prompt": "Authentic Irani cafe Bun Maska, a fresh soft round sweet bakery bun sliced open and generously loaded with thick melting white Amul butter (maska) and sweet mixed fruit jam, served on a vintage plate with Irani Chai in the background."
    },
    {
        "name": "Lemon Tea",
        "slug": "sulaimani_lemon_tea_fresh",
        "prompt": "A clear transparent glass cup of aromatic Hyderabadi Sulaimani Lemon Tea with beautiful golden amber color, garnished with fresh green mint leaves and a floating sliced yellow lemon wheel, refreshing cafe drink."
    }
]

def generate_images():
    for itm in items:
        name = itm["name"]
        slug = itm["slug"]
        prompt = itm["prompt"]
        print(f"\nGenerating '{name}'...", flush=True)
        for attempt in range(1, 5):
            time.sleep(6)
            try:
                res = client.models.generate_content(model="gemini-2.5-flash-image", contents=prompt)
                img_data = None
                for c in res.candidates:
                    for p in c.content.parts:
                        if p.inline_data and p.inline_data.data:
                            img_data = p.inline_data.data
                            break
                    if img_data:
                        break
                if not img_data:
                    raise ValueError("No image data returned")
                img = Image.open(BytesIO(img_data)).convert("RGB").resize((600, 600), Image.Resampling.LANCZOS)
                webp_p = os.path.join(OUT, f"{slug}.webp")
                img.save(webp_p, "WEBP", quality=82)
                cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", webp_p, f"gs://{BUCKET}/menu/{slug}.webp"]
                subprocess.run(cmd, shell=True)
                print(f" -> Successfully generated & uploaded {slug}.webp", flush=True)
                break
            except Exception as e:
                print(f" -> Attempt {attempt} failed: {e}", flush=True)

async def update_db():
    c = AsyncIOMotorClient("mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
    db = c["hyderabadi_irani"]
    for itm in items:
        url = f"https://storage.googleapis.com/{BUCKET}/menu/{itm['slug']}.webp"
        res = await db.menu_items.update_one({"name": itm["name"]}, {"$set": {"image_url": url}})
        print(f" -> Updated DB for {itm['name']} (matched: {res.matched_count}, modified: {res.modified_count})", flush=True)

if __name__ == "__main__":
    generate_images()
    asyncio.run(update_db())
