#!/usr/bin/env python3
"""
Hyderabadi Irani - Automated MongoDB Database Backup Script
Exports all collections into a timestamped JSON archive in the 'backups/' folder.

Usage:
  python scripts/backup_db.py
"""

import os
import sys
import json
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(ROOT_DIR / "backend" / ".env")
load_dotenv(ROOT_DIR / ".env")

COLLECTIONS = [
    "users",
    "menu_items",
    "categories",
    "orders",
    "customers",
    "tables",
    "loyalty_transactions",
    "coupons",
    "settings",
    "counters",
    "device_tokens",
    "expense_categories",
    "expenses",
]

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    if hasattr(obj, "__str__"):
        return str(obj)
    raise TypeError(f"Type {type(obj)} not serializable")

async def run_backup():
    try:
        from motor.motor_asyncio import AsyncIOMotorClient
    except ImportError:
        print("[ERROR] Motor / pymongo not installed. Run: pip install motor pymongo")
        sys.exit(1)

    mongo_url = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
    db_name = os.environ.get("DB_NAME", "hyderabadi_irani")

    print(f"==================================================")
    print(f"📦 HYDERABADI IRANI - DATABASE BACKUP")
    print(f"Target DB:   {db_name}")
    print(f"Target Host: {mongo_url.split('@')[-1] if '@' in mongo_url else mongo_url}")
    print(f"==================================================")

    client = AsyncIOMotorClient(mongo_url, serverSelectionTimeoutMS=5000)
    db = client[db_name]

    # Create timestamped backup folder
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = ROOT_DIR / "backups" / f"backup_{timestamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)

    summary = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "database": db_name,
        "collections": {},
        "total_documents": 0,
    }

    for col_name in COLLECTIONS:
        try:
            cursor = db[col_name].find()
            docs = await cursor.to_list(length=100000)
            doc_count = len(docs)

            out_file = backup_dir / f"{col_name}.json"
            with open(out_file, "w", encoding="utf-8") as f:
                json.dump(docs, f, default=json_serial, indent=2, ensure_ascii=False)

            summary["collections"][col_name] = doc_count
            summary["total_documents"] += doc_count
            print(f"  ✓ {col_name.ljust(22)} -> {doc_count} documents exported")
        except Exception as e:
            print(f"  ✗ {col_name.ljust(22)} -> ERROR: {e}")
            summary["collections"][col_name] = f"ERROR: {e}"

    # Write summary metadata
    with open(backup_dir / "_metadata.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(f"==================================================")
    print(f"🎉 Backup successfully created at:")
    print(f"   {backup_dir}")
    print(f"   Total documents backed up: {summary['total_documents']}")
    print(f"==================================================")

if __name__ == "__main__":
    asyncio.run(run_backup())
