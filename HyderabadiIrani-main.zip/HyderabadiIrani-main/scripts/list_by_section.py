import json

with open("scripts/menu_items.json", "r", encoding="utf-8") as f:
    items = json.load(f)

by_section = {}
for it in items:
    s = it["section"]
    by_section.setdefault(s, []).append(it)

print("=== Menu Breakdown ===")
for sec, itms in by_section.items():
    print(f"\n[{sec}] ({len(itms)} items):")
    for it in itms:
        print(f"  - #{it['index']:03d} {it['name']} ({it['category']}) | Half: {it['price_half']}, Full: {it['price_full']} | Slug: {it['slug']}")
