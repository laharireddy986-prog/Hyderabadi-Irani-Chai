import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

async def check():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    cats = await db.menu_items.distinct("category")
    print(f"All categories in DB: {cats}\n")
    
    for c in sorted(cats, key=lambda x: str(x)):
        items = await db.menu_items.find({"category": c}).to_list(length=100)
        print(f"=== Category: '{c}' ({len(items)} items) ===")
        for it in items:
            name = it.get("name")
            img = it.get("image_url") or it.get("image")
            price = it.get("price")
            is_veg = it.get("is_veg")
            dine_in = it.get("available_dine_in")
            order_type = it.get("order_type")
            counter_only = it.get("counter_only")
            print(f"  * {name} | price: {price} | img: {img} | dine_in: {dine_in} | order_type: {order_type} | counter_only: {counter_only}")

if __name__ == "__main__":
    asyncio.run(check())
