import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

async def check():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    items = await db.menu_items.find({}).to_list(length=2000)
    
    missing_images = []
    has_images = []
    
    for it in items:
        img = it.get("image_url") or it.get("image")
        if not img or "placeholder" in str(img).lower():
            missing_images.append(it)
        else:
            has_images.append(it)
            
    print(f"Total items in DB: {len(items)}")
    print(f"Items with images: {len(has_images)}")
    print(f"Items MISSING images: {len(missing_images)}")
    
    print("\n--- Missing Images List ---")
    for it in missing_images:
        print(f"Category: [{it.get('category')}] | Name: '{it.get('name')}' | Price: {it.get('price')}")

if __name__ == "__main__":
    asyncio.run(check())
