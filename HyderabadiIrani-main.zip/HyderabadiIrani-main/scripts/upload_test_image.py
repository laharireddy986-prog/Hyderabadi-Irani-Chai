import os
from PIL import Image
import subprocess

src_jpg = r"C:\Users\lokes\.gemini\antigravity-ide\brain\aa261f9b-d0c7-43cd-b8a6-794f82b46113\hyderabadi_biryani_test_1787042701435.jpg"
out_webp = r"c:\Hyderabadi Irani\scripts\test_biryani.webp"

img = Image.open(src_jpg)
# Resize to optimal standard 600x600 for high DPI crispness with minimal file size
img = img.resize((600, 600), Image.Resampling.LANCZOS)
img.save(out_webp, "WEBP", quality=82, method=6)

orig_size = os.path.getsize(src_jpg) / 1024
webp_size = os.path.getsize(out_webp) / 1024

print(f"Original size: {orig_size:.1f} KB -> Compressed WebP: {webp_size:.1f} KB")

# Upload to GCS
cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", out_webp, "gs://hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/hyderabadi_chicken_biryani.webp"]
res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
print("Upload status:", res.returncode)
print("STDOUT:", res.stdout)
print("STDERR:", res.stderr)
print("Public CDN URL: https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/hyderabadi_chicken_biryani.webp")
