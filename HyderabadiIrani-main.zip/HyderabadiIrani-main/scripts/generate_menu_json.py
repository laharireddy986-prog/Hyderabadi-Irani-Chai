import pandas as pd
import json
import re

def slugify(text):
    text = str(text).lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '_', text)
    return text.strip('_')

df = pd.read_excel('menu_sheet.xlsx')
items = []

for idx, row in df.iterrows():
    name = str(row.get('Item Name', '')).strip()
    if not name or name == 'nan':
        continue
    
    section = str(row.get('Section', '')).strip()
    raw_cat = str(row.get('Category', '')).strip()
    
    # Fill in categories for sections where it was missing
    if section.upper() == 'TANDOORI KEBABS':
        category = 'NON-VEG'
    elif section.upper() == 'ROTIS':
        category = 'VEG'
    elif section.upper() == 'SHAWARMA':
        if 'PANNER' in name.upper() or 'PANEER' in name.upper():
            category = 'VEG'
        else:
            category = 'NON-VEG'
    else:
        category = raw_cat if raw_cat and raw_cat != 'nan' else ('VEG' if 'VEG' in name.upper() else 'NON-VEG')
    
    # Update df row category
    df.at[idx, 'Category'] = category
    
    half_price = row.get('Price (Half/Single)')
    full_price = row.get('Price (Full)')
    
    half_val = None if pd.isna(half_price) else float(half_price)
    full_val = None if pd.isna(full_price) else float(full_price)
    
    # Determine section variants: Single vs Half
    is_biryani_or_combo = section.upper() in ['BIRYANIS', 'BIRYANI', 'COMBO PACK']
    half_or_single_label = 'Single' if is_biryani_or_combo else 'Half'
    
    has_variants = bool(half_val is not None and full_val is not None)
    variants = []
    
    if has_variants:
        variants = [
            {"name": half_or_single_label, "label": half_or_single_label, "price": half_val, "is_default": True},
            {"name": "Full", "label": "Full", "price": full_val, "is_default": False}
        ]
        base_price = half_val
    elif half_val is not None:
        base_price = half_val
    elif full_val is not None:
        base_price = full_val
    else:
        base_price = 0.0
        
    prompt = str(row.get('AI Image Generation Prompt', '')).strip()
    slug = f"{idx+1:03d}_{slugify(name)}"
    img_filename = f"{slug}.webp"
    gcs_url = f"https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/{img_filename}"
    
    # Veg status
    is_veg = True if ('VEG' in category.upper() and 'NON' not in category.upper()) or ('PANEER' in name.upper() or 'PANNER' in name.upper() or 'MUSHROOM' in name.upper() or 'ALOO' in name.upper()) else False
    if 'CHICKEN' in name.upper() or 'MUTTON' in name.upper() or 'FISH' in name.upper() or 'PRAWN' in name.upper() or 'EGG' in name.upper():
        is_veg = False
    
    item_obj = {
        "index": idx + 1,
        "name": name,
        "slug": slug,
        "section": section,
        "category": category,
        "is_veg": is_veg,
        "price_half": half_val,
        "price_full": full_val,
        "price": base_price,
        "has_variants": has_variants,
        "variants": variants,
        "prompt": prompt,
        "image_filename": img_filename,
        "image_url": gcs_url
    }
    items.append(item_obj)

# Save updated excel with categories filled
df.to_excel('menu_sheet.xlsx', index=False)
df.to_csv('menu_sheet.csv', index=False)

with open('scripts/menu_items.json', 'w', encoding='utf-8') as f:
    json.dump(items, f, indent=2, ensure_ascii=False)

print(f"Exported {len(items)} structured menu items to scripts/menu_items.json")
print(f"Items with multiple portion variants: {sum(1 for i in items if i['has_variants'])}")
print(f"Items with single fixed price: {sum(1 for i in items if not i['has_variants'])}")
