import urllib.request
import json

res = urllib.request.urlopen("http://localhost:8000/api/menu")
data = json.loads(res.read().decode())
print(f"Total items returned: {len(data)}")
for i, it in enumerate(data[:30]):
    print(f"[{i+1}] Name: {it.get('name')} | Category: {it.get('category')} | Image: {it.get('image_url')}")
