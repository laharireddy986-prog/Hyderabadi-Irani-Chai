import urllib.request
import json

def test_menu_endpoint():
    url = "http://localhost:8000/api/menu"
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req) as resp:
        assert resp.status == 200, f"Expected 200, got {resp.status}"
        data = json.loads(resp.read().decode('utf-8'))
        
    print(f"Total menu items returned from API: {len(data)}")
    
    # Verify categories
    categories = set(i.get("category") for i in data)
    print(f"Categories found: {sorted(list(categories))}")
    
    # Check Tandoori Kebabs
    tandoori_items = [i for i in data if i.get("category", "").lower() == "tandoori kebabs"]
    print(f"Tandoori Kebabs items: {len(tandoori_items)} (Non-Veg: {all(not i.get('veg') for i in tandoori_items)})")
    
    # Check Rotis
    roti_items = [i for i in data if i.get("category", "").lower() == "rotis"]
    print(f"Rotis items: {len(roti_items)} (Veg: {all(i.get('veg') for i in roti_items)})")
    
    # Check Shawarma
    shawarma_items = [i for i in data if i.get("category", "").lower() == "shawarma"]
    print(f"Shawarma items: {len(shawarma_items)} ({[i.get('name') for i in shawarma_items]})")
    
    # Check items with variants
    variant_items = [i for i in data if i.get("has_variants")]
    print(f"Dishes with Portion Variants (Single/Half & Full): {len(variant_items)}")
    
    # Print sample biryani item with variants
    biryani = next((i for i in data if "Chicken Dum Biryani" in i.get("name", "")), None)
    if biryani:
        print("\nSample Biryani Data:")
        print(json.dumps(biryani, indent=2))
        
    # Print sample starter item with variants
    starter = next((i for i in data if i.get("category") == "STARTERS" and i.get("has_variants")), None)
    if starter:
        print("\nSample Starter with Variants:")
        print(json.dumps(starter, indent=2))

if __name__ == "__main__":
    test_menu_endpoint()
