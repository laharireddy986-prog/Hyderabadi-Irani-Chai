import pandas as pd

df = pd.read_excel('menu_sheet.xlsx')
print("Columns:", df.columns.tolist())
print(f"Total Rows: {len(df)}")

for sec in ['TANDOORI KEBABS', 'ROTIS', 'SHAWARMA']:
    sub = df[df['Section'].astype(str).str.upper().str.contains(sec)]
    print(f"\n--- Section: {sec} ({len(sub)} rows) ---")
    for idx, row in sub.iterrows():
        print(f"Row {idx+1}: Section='{row.get('Section')}', Category='{row.get('Category')}', Item='{row.get('Item Name')}', Half/Single={row.get('Price (Half/Single)')}, Full={row.get('Price (Full)')}")
