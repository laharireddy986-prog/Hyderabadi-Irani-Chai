from google import genai
from google.genai import types
import os

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"

print("Testing generate_content with image models on Vertex AI...")
client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)

for m in ["gemini-2.5-flash-image", "gemini-3.1-flash-image-preview", "gemini-3-pro-image"]:
    try:
        print(f"\n--- Testing model: {m} ---")
        response = client.models.generate_content(
            model=m,
            contents="A professional close-up photo of authentic Veg Clear Soup in a ceramic bowl, steaming hot, restaurant photography, 1:1 aspect ratio",
        )
        print(f"Response received for {m}!")
        # Check candidates and parts
        for candidate in response.candidates:
            for part in candidate.content.parts:
                if part.inline_data:
                    print(f"Found inline_data mime_type: {part.inline_data.mime_type}, length: {len(part.inline_data.data)}")
                    with open("scripts/test_gemini_image.png", "wb") as f:
                        f.write(part.inline_data.data)
                    print("Successfully saved scripts/test_gemini_image.png!")
                if part.text:
                    print(f"Text part: {part.text[:100]}")
    except Exception as e:
        print(f"Error testing {m}: {e}")
