import sys, os, io
sys.path.insert(0, os.path.abspath('.'))
from PIL import Image
from backend.server import compress_image_under_50kb, upload_bytes_to_gcs

# Create a test high-res image
img = Image.new('RGB', (1200, 1200), color=(220, 80, 20))
buf = io.BytesIO()
img.save(buf, format='JPEG', quality=95)
raw_bytes = buf.getvalue()
print(f"Raw image size: {len(raw_bytes)/1024:.1f} KB")

# Test compression
webp_bytes, size_kb, width, height = compress_image_under_50kb(raw_bytes, max_dim=600)
print(f"Compressed WebP size: {size_kb} KB ({width}x{height} px) - Under 50 KB: {size_kb < 50}")

# Test GCS upload
public_url = upload_bytes_to_gcs(webp_bytes, "test_admin_upload.webp", content_type="image/webp")
print(f"Uploaded to GCS: {public_url}")
