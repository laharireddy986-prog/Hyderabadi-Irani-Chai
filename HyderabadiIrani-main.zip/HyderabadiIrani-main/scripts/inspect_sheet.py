import pandas as pd

df = pd.read_excel('menu_sheet.xlsx')
print(f"Total Rows: {len(df)}")
print("\nBreakdown by Section:")
print(df['Section'].value_counts())

print("\nBreakdown by Category:")
print(df['Category'].value_counts())

print("\nSample of all columns for item #15:")
print(df.iloc[15].to_dict())
