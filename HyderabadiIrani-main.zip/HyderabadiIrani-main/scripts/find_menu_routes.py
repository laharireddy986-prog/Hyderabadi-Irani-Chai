with open("backend/server.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if "@api." in line or "@app." in line:
        if "menu" in line.lower() or idx > 3000:
            print(f"Line {idx+1}: {line.strip()}")
