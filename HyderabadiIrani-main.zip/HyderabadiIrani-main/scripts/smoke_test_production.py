import requests

API = 'https://hyderabadi-irani-api-826716276634.asia-south1.run.app/api'

def main():
    print("--- SMOKE TEST: Live Cloud Run API ---")
    
    # 1. Health check
    res = requests.get(f"{API}/store/status")
    print(f"1. Store status: {res.status_code} -> {res.json()}")
    
    # 2. Fetch menu
    menu_res = requests.get(f"{API}/menu")
    menu = menu_res.json()
    first_item = menu[0]
    print(f"2. Menu items count: {len(menu)} (Sample dish: {first_item.get('name')})")
    
    # 3. Test Dine-in COD rejection rule (Commit 1ae5874)
    cod_payload = {
        "customer_name": "Smoke Test Guest",
        "phone": "9876543210",
        "table_no": "T-01",
        "order_type": "dine-in",
        "payment_mode": "cash",
        "items": [{
            "item_id": first_item["id"],
            "name": first_item["name"],
            "price": first_item["price"],
            "qty": 1,
            "station": "kitchen"
        }]
    }
    r_cod = requests.post(f"{API}/public/orders", json=cod_payload)
    print(f"3. Dine-in COD attempt status: {r_cod.status_code} -> {r_cod.json().get('detail')}")
    assert r_cod.status_code == 400, f"Expected 400 for dine-in COD, got {r_cod.status_code}"
    
    # 4. Test Dine-in Online Payment acceptance (Commit 1ae5874)
    online_payload = {
        "customer_name": "Smoke Test Guest",
        "phone": "9876543210",
        "table_no": "T-01",
        "order_type": "dine-in",
        "payment_mode": "razorpay",
        "items": [{
            "item_id": first_item["id"],
            "name": first_item["name"],
            "price": first_item["price"],
            "qty": 1,
            "station": "kitchen"
        }]
    }
    r_online = requests.post(f"{API}/public/orders", json=online_payload)
    print(f"4. Dine-in Online attempt status: {r_online.status_code} -> Order #{r_online.json().get('order_no')}, Razorpay Order ID: {r_online.json().get('razorpay_order_id')}")
    assert r_online.status_code == 200, f"Expected 200 for dine-in online order, got {r_online.status_code}"
    
    print("\n✅ ALL LIVE PRODUCTION SMOKE TESTS PASSED!")

if __name__ == "__main__":
    main()
