import os
from PIL import Image, ImageDraw, ImageFont

OUTPUT_DIR = r"c:\Hyderabadi Irani\mobile-delivery-app\store_assets"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def create_icon_512():
    # 512x512 App Icon
    img = Image.new("RGBA", (512, 512), "#451a03") # Rich dark amber/brown
    draw = ImageDraw.Draw(img)

    # Draw rounded golden gradient-like card in center
    draw.rounded_rectangle([24, 24, 488, 488], radius=80, fill="#78350f", outline="#fbbf24", width=6)
    draw.rounded_rectangle([48, 48, 464, 464], radius=60, fill="#fbbf24")

    # Center circle
    draw.ellipse([100, 100, 412, 412], fill="#451a03", outline="#d97706", width=4)

    # Text
    try:
        font_lg = ImageFont.truetype("arialbd.ttf", 100)
        font_sm = ImageFont.truetype("arialbd.ttf", 36)
        font_xs = ImageFont.truetype("arialbd.ttf", 28)
    except:
        font_lg = ImageFont.load_default()
        font_sm = ImageFont.load_default()
        font_xs = ImageFont.load_default()

    # Draw Bike symbol / Text
    draw.text((256, 200), "🛵", fill="#fbbf24", font=font_lg, anchor="mm")
    draw.text((256, 285), "HYDERABADI", fill="#ffffff", font=font_sm, anchor="mm")
    draw.text((256, 325), "IRANI", fill="#fde68a", font=font_sm, anchor="mm")
    draw.text((256, 365), "DELIVERY", fill="#34d399", font=font_xs, anchor="mm")

    out_path = os.path.join(OUTPUT_DIR, "delivery_icon_512x512.png")
    img.save(out_path, "PNG")
    print(f"Created 512x512 icon at: {out_path}")

def create_feature_graphic_1024x500():
    # 1024x500 Feature Graphic
    img = Image.new("RGBA", (1024, 500), "#451a03")
    draw = ImageDraw.Draw(img)

    # Background pattern/stripes
    for i in range(0, 1024, 40):
        draw.line([(i, 0), (i + 200, 500)], fill="#78350f", width=12)

    # Dark overlay gradient card
    draw.rounded_rectangle([40, 40, 984, 460], radius=32, fill="#1c0a00", outline="#fbbf24", width=4)

    try:
        font_title = ImageFont.truetype("arialbd.ttf", 52)
        font_sub = ImageFont.truetype("arialbd.ttf", 30)
        font_pill = ImageFont.truetype("arialbd.ttf", 20)
        font_emoji = ImageFont.truetype("arialbd.ttf", 80)
    except:
        font_title = ImageFont.load_default()
        font_sub = ImageFont.load_default()
        font_pill = ImageFont.load_default()
        font_emoji = ImageFont.load_default()

    # Left content
    draw.text((512, 120), "🛵", fill="#fbbf24", font=font_emoji, anchor="mm")
    draw.text((512, 210), "HYDERABADI IRANI", fill="#fbbf24", font=font_title, anchor="mm")
    draw.text((512, 275), "DELIVERY PARTNER APP", fill="#ffffff", font=font_sub, anchor="mm")
    draw.text((512, 330), "Fast Pickups · Live GPS Navigation · Cash Collection", fill="#d1d5db", font=font_pill, anchor="mm")

    # Feature badges
    draw.rounded_rectangle([180, 380, 380, 425], radius=20, fill="#78350f", outline="#fbbf24", width=2)
    draw.text((280, 402), "📍 Turn-by-Turn GPS", fill="#ffffff", font=font_pill, anchor="mm")

    draw.rounded_rectangle([410, 380, 610, 425], radius=20, fill="#78350f", outline="#fbbf24", width=2)
    draw.text((510, 402), "⚡ Instant Orders", fill="#ffffff", font=font_pill, anchor="mm")

    draw.rounded_rectangle([640, 380, 840, 425], radius=20, fill="#78350f", outline="#fbbf24", width=2)
    draw.text((740, 402), "💰 Daily Earnings", fill="#ffffff", font=font_pill, anchor="mm")

    out_path = os.path.join(OUTPUT_DIR, "delivery_feature_graphic_1024x500.png")
    img.save(out_path, "PNG")
    print(f"Created 1024x500 feature graphic at: {out_path}")

if __name__ == "__main__":
    create_icon_512()
    create_feature_graphic_1024x500()
