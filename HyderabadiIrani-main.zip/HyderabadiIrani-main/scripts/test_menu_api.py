import urllib.request
import json

try:
    with urllib.request.urlopen('http://localhost:8000/api/menu') as res:
        data = json.loads(res.read())
        print(f"API menu returned {len(data)} items")
        variants_items = [i for i in data if i.get('has_variants')]
        print(f"Items with variants: {len(variants_items)}")
        for item in data[:5]:
            print(f"- {item['name']}: has_variants={item.get('has_variants')}, price={item.get('price')}, variants={item.get('variants')}")
except Exception as e:
    print("Error:", e)
