import os
import glob
import json
import subprocess
from PIL import Image

BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
ARTIFACTS_DIR = r"C:\Users\lokes\.gemini\antigravity-ide\brain\aa261f9b-d0c7-43cd-b8a6-794f82b46113"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"
PROGRESS_FILE = r"c:\Hyderabadi Irani\scripts\generation_progress.json"

os.makedirs(OUTPUT_DIR, exist_ok=True)

with open(r"c:\Hyderabadi Irani\scripts\menu_items.json", "r", encoding="utf-8") as f:
    menu_items = json.load(f)

if os.path.exists(PROGRESS_FILE):
    with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
        progress = json.load(f)
else:
    progress = {}

def optimize_and_upload(slug, raw_image_path):
    out_webp = os.path.join(OUTPUT_DIR, f"{slug}.webp")
    
    img = Image.open(raw_image_path)
    img = img.resize((600, 600), Image.Resampling.LANCZOS)
    img.save(out_webp, "WEBP", quality=82, method=6)
    
    size_kb = os.path.getsize(out_webp) / 1024
    
    gcs_dest = f"gs://{BUCKET_NAME}/menu/{slug}.webp"
    cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", out_webp, gcs_dest]
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    if res.returncode == 0:
        public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"
        progress[slug] = {
            "status": "uploaded",
            "size_kb": round(size_kb, 1),
            "url": public_url
        }
        with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
            json.dump(progress, f, indent=2)
        print(f"[SUCCESS] {slug} -> {size_kb:.1f} KB -> {public_url}")
        return public_url
    else:
        print(f"[ERROR] Failed uploading {slug}: {res.stderr}")
        return None

def scan_and_process_all():
    # List all raw images in artifacts dir
    raw_files = [f for f in glob.glob(os.path.join(ARTIFACTS_DIR, "*")) if f.lower().endswith(('.jpg', '.png', '.jpeg')) and not f.endswith('.webp')]
    
    for item in menu_items:
        slug = item["slug"]
        if slug in progress and progress[slug].get("status") == "uploaded":
            continue
        
        clean_name = slug.split("_", 1)[1] if "_" in slug else slug
        
        # Match against raw files
        matched_file = None
        for rf in raw_files:
            fname = os.path.basename(rf).lower()
            if clean_name in fname or slug in fname or fname.startswith(clean_name[:12]):
                matched_file = rf
                break
        
        if matched_file:
            print(f"Processing found image for {slug}: {matched_file}")
            optimize_and_upload(slug, matched_file)

if __name__ == "__main__":
    scan_and_process_all()
    print(f"Progress: {len(progress)} / {len(menu_items)} items uploaded.")
