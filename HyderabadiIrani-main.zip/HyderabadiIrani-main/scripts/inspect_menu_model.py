with open("backend/server.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if "class MenuItem" in line or "class MenuItemIn" in line:
        print(f"Line {idx+1}:")
        for j in range(idx, min(idx + 25, len(lines))):
            print(f"  {lines[j].rstrip()}")
        print("\n")
