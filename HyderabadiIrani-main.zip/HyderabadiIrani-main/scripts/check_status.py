import json

with open('scripts/menu_items.json', 'r', encoding='utf-8') as f:
    items = json.load(f)

with open('scripts/generation_progress.json', 'r', encoding='utf-8') as f:
    progress = json.load(f)

print(f"Total menu items: {len(items)}")
print(f"Total in progress file: {len(progress)}")
uploaded = [k for k, v in progress.items() if v.get('status') == 'uploaded']
print(f"Uploaded items count: {len(uploaded)}")
remaining = [item for item in items if item['slug'] not in progress]
print(f"Remaining items count: {len(remaining)}")

print("\n--- Summary by Section ---")
sections = {}
for item in items:
    sec = item.get('section', 'Unknown')
    if sec not in sections:
        sections[sec] = {'total': 0, 'uploaded': 0}
    sections[sec]['total'] += 1
    if item['slug'] in progress and progress[item['slug']].get('status') == 'uploaded':
        sections[sec]['uploaded'] += 1

for sec, stats in sections.items():
    print(f"  {sec:25s}: {stats['uploaded']:2d} / {stats['total']:2d} done")

print("\n--- First 15 Remaining Items ---")
for item in remaining[:15]:
    print(f"  #{item['index']:03d} | {item['slug']} | {item['name']} ({item['section']} / {item['category']})")
