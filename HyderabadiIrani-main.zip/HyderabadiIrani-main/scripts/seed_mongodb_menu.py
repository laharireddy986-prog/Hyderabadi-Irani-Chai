import os
import json
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = os.environ.get("DB_NAME", "hyderabadi_irani")

# Category fallback images from GCS or curated food assets
CATEGORY_DEFAULT_IMAGES = {
    "SOUPS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/001_veg_hot_sour_soup.webp",
    "FRIED RICE": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/023_chicken_fried_rice.webp",
    "NOODLES": "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=800&auto=format&fit=crop&q=80",
    "STARTERS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/068_chicken_65.webp",
    "CURRYS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/103_butter_chicken_boneless.webp",
    "SEA FOOD": "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?w=800&auto=format&fit=crop&q=80",
    "BIRYANIS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/130_chicken_dum_biryani.webp",
    "BIRYANI": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/130_chicken_dum_biryani.webp",
    "COMBO PACK": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/130_chicken_dum_biryani.webp",
    "TANDOORI KEBABS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/149_tandoori_chicken.webp",
    "ROTIS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/162_butter_naan.webp",
    "SHAWARMA": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/166_chicken_shawarma.webp",
    "TEA": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
}

TEA_ITEMS = [
    {
        "name": "Hyderabadi Irani Chai",
        "category": "Tea",
        "price": 20.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Authentic slow-dum brewed rich Hyderabadi Irani Chai with thick condensed milk.",
        "image_url": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Special Irani Chai (Khada Chammach)",
        "category": "Tea",
        "price": 25.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Extra rich cream & sweetened special Irani Chai with sugar-heavy authentic Nizami base.",
        "image_url": "https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Osmania Biscuits (Plate)",
        "category": "Tea",
        "price": 20.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Traditional melt-in-mouth sweet & salty Osmania biscuits baked fresh.",
        "image_url": "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Bun Maska",
        "category": "Tea",
        "price": 35.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Freshly toasted soft Irani bun loaded with generous homemade maska butter.",
        "image_url": "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Ginger Irani Chai",
        "category": "Tea",
        "price": 25.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Fresh crushed ginger infused aromatic Irani dum milk tea.",
        "image_url": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Lemon Tea",
        "category": "Tea",
        "price": 20.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Refreshing hot brewed black tea with fresh lemon & honey.",
        "image_url": "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Filter Coffee",
        "category": "Tea",
        "price": 30.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Authentic South Indian chicory-infused aromatic filter coffee with frothy hot milk.",
        "image_url": "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80"
    },
    {
        "name": "Badam Milk (Hot / Cold)",
        "category": "Tea",
        "price": 40.0,
        "price_half": None,
        "price_full": None,
        "has_variants": False,
        "variants": [],
        "veg": True,
        "station": "tea",
        "available": True,
        "description": "Rich almond & saffron infused thick creamy milk topped with roasted nuts.",
        "image_url": "https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop&q=80"
    },
]

async def seed_all_menu():
    print(f"Connecting to MongoDB at {MONGO_URL[:35]}...")
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    with open("scripts/menu_items.json", "r", encoding="utf-8") as f:
        sheet_items = json.load(f)
        
    progress = {}
    if os.path.exists("scripts/generation_progress.json"):
        with open("scripts/generation_progress.json", "r", encoding="utf-8") as f:
            progress = json.load(f)
            
    final_menu = []
    
    # 1. Add Chai & Tea
    for t in TEA_ITEMS:
        final_menu.append(t)
        
    # 2. Add all Sheet Items
    for it in sheet_items:
        slug = it["slug"]
        section = it["section"]
        
        # Check if custom generated GCS image exists
        if slug in progress and progress[slug].get("status") == "uploaded":
            img_url = progress[slug]["url"]
        else:
            img_url = CATEGORY_DEFAULT_IMAGES.get(section.upper(), CATEGORY_DEFAULT_IMAGES["STARTERS"])
            
        category_name = it["section"].title() if it["section"] else "Main Menu"
        # Standardize category names
        if category_name.upper() == "BIRYANIS":
            category_name = "Biryani"
        elif category_name.upper() == "COMBO PACK":
            category_name = "Biryani"
            
        half_val = it.get("price_half")
        full_val = it.get("price_full")
        has_vars = it.get("has_variants", False)
        variants = it.get("variants", [])
        
        base_price = it.get("price", 0.0)
        
        desc = f"Authentic {it['name']} prepared fresh with signature Hyderabadi spices and herbs."
        if has_vars and len(variants) >= 2:
            desc += f" ({variants[0]['name']}: ₹{int(variants[0]['price'])} / {variants[1]['name']}: ₹{int(variants[1]['price'])})"
        
        item_doc = {
            "name": it["name"].title(),
            "category": category_name,
            "price": float(base_price),
            "price_half": float(half_val) if half_val is not None else None,
            "price_full": float(full_val) if full_val is not None else None,
            "has_variants": bool(has_vars),
            "variants": variants,
            "veg": bool(it["is_veg"]),
            "station": "kitchen",
            "available": True,
            "description": desc,
            "image_url": img_url
        }
        final_menu.append(item_doc)
        
    print(f"Prepared {len(final_menu)} total menu items with images and portion variants.")
    
    # Seed both `menu_items` (used by backend) and `menu`
    await db.menu_items.delete_many({})
    res1 = await db.menu_items.insert_many(final_menu)
    print(f"Successfully inserted {len(res1.inserted_ids)} items into MongoDB `menu_items` collection!")
    
    await db.menu.delete_many({})
    res2 = await db.menu.insert_many(final_menu)
    print(f"Successfully inserted {len(res2.inserted_ids)} items into MongoDB `menu` collection!")
    
    # Verify count
    count = await db.menu_items.count_documents({})
    var_count = await db.menu_items.count_documents({"has_variants": True})
    print(f"Verified `menu_items` collection: {count} total items, {var_count} items with portion variants.")

if __name__ == "__main__":
    asyncio.run(seed_all_menu())
