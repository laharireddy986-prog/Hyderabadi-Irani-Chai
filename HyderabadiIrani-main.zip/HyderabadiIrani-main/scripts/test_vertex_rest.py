import subprocess
import requests
import json

res = subprocess.run(["gcloud", "auth", "print-access-token"], shell=True, capture_output=True, text=True)
token = res.stdout.strip()
print("Got access token length:", len(token))

# Test Vertex AI Imagen REST API endpoint
project_id = "metal-density-504117-k9"
locations = ["us-central1", "asia-south1"]

for loc in locations:
    url = f"https://{loc}-aiplatform.googleapis.com/v1/projects/{project_id}/locations/{loc}/publishers/google/models/imagen-3.0-generate-002:predict"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    payload = {
        "instances": [
            {"prompt": "A close up photo of authentic hyderabadi biryani, professional food photo"}
        ],
        "parameters": {
            "sampleCount": 1,
            "aspectRatio": "1:1"
        }
    }
    print(f"Testing {loc}...")
    r = requests.post(url, headers=headers, json=payload)
    print(f"Status in {loc}: {r.status_code}")
    print(f"Response snippet: {r.text[:300]}")
