import os
import json
import time
import subprocess
import asyncio
from io import BytesIO
from PIL import Image
from google import genai
from motor.motor_asyncio import AsyncIOMotorClient

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

os.makedirs(OUTPUT_DIR, exist_ok=True)

TIFFIN_ITEMS = [
    {
        "slug": "idly",
        "name": "Idly",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Steaming hot soft and fluffy South Indian rice & lentil cakes served with traditional sambar and fresh coconut chutney.",
        "prompt": "A hot steaming plate of 3 soft fluffy South Indian white Idlis garnished with ghee, served on a banana leaf plate with fresh coconut chutney, spicy tomato chutney, and authentic vegetable sambar in a brass bowl, high resolution food photography."
    },
    {
        "slug": "bonda",
        "name": "Bonda",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy golden Mysore Bajjis (Bonda), crisp on the outside and soft fluffy inside, served with spicy peanut and ginger chutney.",
        "prompt": "A plate of 4 golden brown crispy round Mysore Bajji Bonda snacks, served with spicy red ginger peanut chutney and coconut chutney, street food style, crisp outside fluffy soft inside."
    },
    {
        "slug": "vada",
        "name": "Vada",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy golden fried Medu Vada made with seasoned urad dal, black pepper, and curry leaves, served with piping hot sambar.",
        "prompt": "A plate of 3 crispy golden brown Medu Vada donuts with visible black pepper and curry leaves, crispy crunchy crust, served with hot sambar and fresh coconut chutney."
    },
    {
        "slug": "poori",
        "name": "Poori",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Fluffy puffed golden deep-fried Pooris served with homestyle spiced potato masala bhaji and coconut chutney.",
        "prompt": "A plate of 2 puffed golden hot Pooris served with traditional yellow potato kurma masala bhaji, coconut chutney, and pickled green chilli, South Indian restaurant presentation."
    },
    {
        "slug": "plain_dosa",
        "name": "Plain Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy thin golden crepe made from fermented rice and lentil batter, roasted to perfection and served with chutneys and sambar.",
        "prompt": "A large crispy thin golden-brown South Indian Plain Dosa rolled neatly, served on a banana leaf with three varieties of chutneys (coconut, red chutney, green chutney) and hot sambar."
    },
    {
        "slug": "single_egg_dosa",
        "name": "Single Egg Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": False,
        "station": "kitchen",
        "description": "Crispy golden dosa topped with a spiced egg layer, seasoned with black pepper, roasted cumin, and fresh coriander.",
        "prompt": "A delicious South Indian Egg Dosa with a seasoned spiced egg spread across the golden crispy crepe, sprinkled with black pepper and fresh coriander, served hot with chutneys."
    },
    {
        "slug": "double_egg_dosa",
        "name": "Double Egg Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": False,
        "station": "kitchen",
        "description": "Hyderabadi street style double egg layered dosa loaded with onions, green chillies, and special spices.",
        "prompt": "A rich and thick Hyderabadi street style Double Egg Dosa, lavishly spread with double spiced egg omelette, chopped onions, green chillies, and roasted spices, golden crispy."
    },
    {
        "slug": "upma_dosa",
        "name": "Upma Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Iconic Hyderabadi MLA Upma Dosa, a crisp golden dosa stuffed with delicious hot semolina upma, ghee, and cashews.",
        "prompt": "Authentic Hyderabadi MLA Upma Dosa, a large crispy golden roasted dosa stuffed generously with fragrant hot semolina rava upma, ghee, and roasted cashew nuts, served with peanut chutney."
    },
    {
        "slug": "masala_dosa",
        "name": "Masala Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy golden dosa smeared with red garlic chutney and stuffed with spiced mashed potato onion masala.",
        "prompt": "A classic crispy golden roasted Mysore Masala Dosa, smeared inside with red spicy garlic chutney and filled with flavorful spiced mashed potato masala, served with sambar and fresh coconut chutney."
    },
    {
        "slug": "paneer_dosa",
        "name": "Paneer Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy crepe stuffed with savory seasoned cottage cheese (paneer) filling, herbs, and spices.",
        "prompt": "A gourmet crispy golden Dosa stuffed with savory shredded paneer (cottage cheese) cooked with mild spices, herbs, and sweet bell peppers, garnished with coriander."
    },
    {
        "slug": "butter_paneer_dosa",
        "name": "Butter Paneer Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Extra rich dosa roasted with generous butter and filled with succulent spiced paneer masala.",
        "prompt": "A decadent crispy Dosa dripping with melting yellow Amul butter, loaded with rich creamy paneer masala filling, garnished with fresh herbs, appetizing food photography."
    },
    {
        "slug": "onion_dosa",
        "name": "Onion Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Thin crispy dosa cooked with crunchy caramelized onions, green chillies, and fresh coriander.",
        "prompt": "A crispy South Indian Onion Dosa embedded with finely chopped caramelized onions, green chillies, cumin seeds, and cilantro on a thin golden batter, served with chutneys."
    },
    {
        "slug": "onion_uthappam",
        "name": "Onion Uthappam",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Thick soft and spongy pancake topped generously with chopped onions, green chillies, and curry leaves.",
        "prompt": "A thick and soft South Indian Onion Uthappam pancake, topped with generous chopped onions, tomatoes, green chillies, and curry leaves, golden roasted, served on banana leaf with sambar."
    },
    {
        "slug": "set_dosa",
        "name": "Set Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Set of 3 soft, spongy, thick dosas with honeycomb pores, served with mixed vegetable sagu and chutney.",
        "prompt": "A stack of 3 soft, spongy, thick golden-yellow Set Dosas with porous honeycomb texture, topped with a dollop of butter, served with vegetable sagu and coconut chutney."
    },
    {
        "slug": "tawa_idly",
        "name": "Tawa Idly",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Hyderabadi street style idli cubes pan-tossed in butter, spicy gun powder (podi), chopped onions, and lemon.",
        "prompt": "Hyderabadi street style spicy Tawa Idly, bite-sized idli pieces tossed on a smoking tawa with butter, gun powder podi, chopped onions, curry leaves, and tomatoes, steaming hot."
    },
    {
        "slug": "tawa_bonda",
        "name": "Tawa Bonda",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Mysore bondas sliced and tossed on a hot tawa with spicy karam podi, rich butter, onions, and coriander.",
        "prompt": "Hyderabadi street food special Tawa Bonda, crispy Mysore bondas sliced and tossed on a hot buttered tawa with spicy karam podi, onions, lemon juice, and coriander."
    },
    {
        "slug": "tawa_vada",
        "name": "Tawa Vada",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Medu vadas tossed on a smoking buttered tawa with fiery spice blend, onions, and curry leaves.",
        "prompt": "Crispy Medu Vadas cut and tossed on a hot tawa with rich butter, special spice masala mix, chopped onions, and curry leaves, fragrant and spicy street snack."
    },
    {
        "slug": "ghee_karam_dosa",
        "name": "Ghee Karam Dosa",
        "category": "Tiffins",
        "price": 0.0,
        "veg": True,
        "station": "kitchen",
        "description": "Extra crispy golden dosa smeared with authentic red garlic chilli chutney (karam) and roasted in pure desi ghee.",
        "prompt": "Authentic Rayalaseema style Ghee Karam Dosa (Nalla Karam Podi Dosa), extra crispy golden crepe generously smeared with fiery red garlic karam paste, drenched in pure desi ghee, served with chutneys."
    },
]

def generate_and_upload(client, item):
    slug = item["slug"]
    name = item["name"]
    prompt = item["prompt"]
    webp_path = os.path.join(OUTPUT_DIR, f"{slug}.webp")
    gcs_dest = f"gs://{BUCKET_NAME}/menu/{slug}.webp"
    public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"

    print(f"\n[IMAGE] Generating image for '{name}'...", flush=True)
    for attempt in range(1, 4):
        try:
            res = client.models.generate_content(
                model="gemini-2.5-flash-image",
                contents=prompt
            )
            image_bytes = None
            for candidate in res.candidates:
                for part in candidate.content.parts:
                    if part.inline_data and part.inline_data.data:
                        image_bytes = part.inline_data.data
                        break
                if image_bytes:
                    break

            if not image_bytes:
                raise ValueError("No image bytes returned")

            # Optimize with PIL
            img = Image.open(BytesIO(image_bytes))
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            img = img.resize((600, 600), Image.Resampling.LANCZOS)
            img.save(webp_path, "WEBP", quality=82, method=6)
            size_kb = os.path.getsize(webp_path) / 1024
            print(f" -> Optimized WebP: {size_kb:.1f} KB. Uploading to GCS...", flush=True)

            # Upload to GCS
            cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", webp_path, gcs_dest]
            proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if proc.returncode == 0:
                print(f" -> Uploaded: {public_url}", flush=True)
                return public_url
            else:
                print(f" -> GCS Upload error: {proc.stderr}", flush=True)
        except Exception as e:
            print(f" -> Error on attempt {attempt}: {e}", flush=True)
            time.sleep(3)

    return public_url

async def sync_mongodb(items):
    print("\n[DB] Connecting to MongoDB to insert/update Tiffin items...", flush=True)
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    for itm in items:
        doc = {
            "name": itm["name"],
            "category": itm["category"],
            "price": float(itm["price"]),
            "price_half": None,
            "price_full": None,
            "has_variants": False,
            "variants": [],
            "veg": itm["veg"],
            "station": itm["station"],
            "available": True,
            "description": itm["description"],
            "image_url": f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{itm['slug']}.webp"
        }
        await db.menu_items.update_one(
            {"name": itm["name"]},
            {"$set": doc},
            upsert=True
        )
        print(f" -> Synced DB: {itm['name']} (Category: {itm['category']} - Price: Rs.{itm['price']})", flush=True)

    total = await db.menu_items.count_documents({})
    cats = await db.menu_items.distinct("category")
    print(f"\n[DONE] Total items in db.menu_items: {total}", flush=True)
    print(f"Categories: {cats}", flush=True)

def main():
    print(f"Starting Tiffins generation for {len(TIFFIN_ITEMS)} items...", flush=True)
    genai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)

    for item in TIFFIN_ITEMS:
        url = generate_and_upload(genai_client, item)
        item["image_url"] = url
        time.sleep(1)

    asyncio.run(sync_mongodb(TIFFIN_ITEMS))

if __name__ == "__main__":
    main()
