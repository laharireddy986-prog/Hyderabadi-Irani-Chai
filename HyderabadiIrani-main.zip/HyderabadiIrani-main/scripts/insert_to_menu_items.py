import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"

ITEMS = [
    # Sweets
    {
        "slug": "apricot_delight",
        "name": "Apricot Delight",
        "category": "Sweets",
        "price": 100.0,
        "veg": True,
        "station": "kitchen",
        "description": "Signature rich Hyderabadi Apricot Delight layered with pure apricot pulp, custard cream, and chopped dry fruits."
    },
    {
        "slug": "kaddu_ki_kheer",
        "name": "Kaddu Ka Kheer",
        "category": "Sweets",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Traditional Hyderabadi wedding dessert made with grated bottle gourd, creamy condensed milk, sago pearls, and crunchy cashews."
    },
    {
        "slug": "gulab_jamun",
        "name": "Gulab Jamun",
        "category": "Sweets",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Soft, golden-brown melt-in-mouth milk solid dumplings soaked in aromatic cardamom & saffron rose sugar syrup."
    },
    {
        "slug": "double_ka_meetha",
        "name": "Double Ka Meetha",
        "category": "Sweets",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Royal Hyderabadi Shahi Tukda dessert made from crisp ghee-fried bread soaked in rich saffron infused rabdi and topped with roasted nuts."
    },

    # Snacks
    {
        "slug": "aloo_samosa",
        "name": "Aloo Samosa (1 Pc)",
        "category": "Snacks",
        "price": 20.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy golden fried triangle pastry filled with spiced mashed potato, green peas, and fragrant herbs (1 Piece)."
    },
    {
        "slug": "onion_samosa",
        "name": "Onion Samosa (6 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Irani cafe style crispy mini crunchy samosas stuffed with savory spiced onion, poha, and green chillies (Plate of 6 Pcs)."
    },
    {
        "slug": "osmania_biscuits_pack",
        "name": "Osmania Biscuits (10 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "tea",
        "description": "Classic melt-in-mouth sweet & salty butter baked Hyderabadi Osmania biscuits (Pack of 10 Pcs)."
    },
    {
        "slug": "khara_biscuits_pack",
        "name": "Khara Biscuits (10 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "tea",
        "description": "Crispy savory spiced Irani tea biscuits baked with cumin, curry leaves, and green chillies (Pack of 10 Pcs)."
    },
    {
        "slug": "egg_puff",
        "name": "Egg Puff",
        "category": "Snacks",
        "price": 20.0,
        "veg": False,
        "station": "kitchen",
        "description": "Flaky golden bakery puff pastry filled with spiced onion masala and seasoned boiled egg."
    },
    {
        "slug": "veg_puff",
        "name": "Veg Puff",
        "category": "Snacks",
        "price": 20.0,
        "veg": True,
        "station": "kitchen",
        "description": "Layers of crispy golden puff pastry loaded with spiced mixed vegetable masala."
    },
    {
        "slug": "chicken_puff",
        "name": "Chicken Puff",
        "category": "Snacks",
        "price": 30.0,
        "veg": False,
        "station": "kitchen",
        "description": "Golden crisp layered puff stuffed with succulent minced chicken cooked in Hyderabadi spices."
    },
    {
        "slug": "paneer_puff",
        "name": "Paneer Puff",
        "category": "Snacks",
        "price": 30.0,
        "veg": True,
        "station": "kitchen",
        "description": "Flaky crispy oven-baked puff loaded with savory marinated paneer cubes and herbs."
    },
    {
        "slug": "onion_pakoda",
        "name": "Onion Pakoda (100g)",
        "category": "Snacks",
        "price": 30.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crunchy, spicy sliced onion fritters deep fried with chickpea batter, curry leaves, and green chillies (100 grams)."
    },
    {
        "slug": "mirchi_bajji",
        "name": "Mirchi Bajji (4 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crispy batter-fried whole green bhavnagri chillies stuffed with tangy ajwain and lemon masala (Plate of 4 Pcs)."
    },
    {
        "slug": "punugulu",
        "name": "Punugulu",
        "category": "Snacks",
        "price": 40.0,
        "veg": True,
        "station": "kitchen",
        "description": "Golden crisp outside and fluffy soft inside deep-fried rice & urad dal snack balls served with spicy coconut chutney."
    },
    {
        "slug": "masala_vada",
        "name": "Masala Vada (4 Pcs)",
        "category": "Snacks",
        "price": 50.0,
        "veg": True,
        "station": "kitchen",
        "description": "Crunchy South Indian chana dal patties infused with onions, coriander, curry leaves, and ginger (Plate of 4 Pcs)."
    },
    {
        "slug": "cut_mirchi",
        "name": "Cut Mirchi (2 Pcs)",
        "category": "Snacks",
        "price": 30.0,
        "veg": True,
        "station": "kitchen",
        "description": "Double-fried crispy bite-sized sliced mirchi bajjis tossed with roasted peanut powder, onions, and lemon (2 pieces cut)."
    },
    {
        "slug": "egg_bonda",
        "name": "Egg Bonda (1 Pc)",
        "category": "Snacks",
        "price": 20.0,
        "veg": False,
        "station": "kitchen",
        "description": "Whole boiled egg dipped in spiced gram flour batter and deep fried to golden perfection (1 Piece)."
    },
]

async def main():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    print("Inserting 18 items into db.menu_items...")
    for itm in ITEMS:
        doc = {
            "name": itm["name"],
            "category": itm["category"],
            "price": float(itm["price"]),
            "price_half": None,
            "price_full": None,
            "has_variants": False,
            "variants": [],
            "veg": itm["veg"],
            "station": itm["station"],
            "available": True,
            "description": itm["description"],
            "image_url": f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{itm['slug']}.webp"
        }
        await db.menu_items.update_one(
            {"name": itm["name"]},
            {"$set": doc},
            upsert=True
        )
        print(f" -> Synced: {itm['name']} ({itm['category']} - Rs.{itm['price']})")

    total = await db.menu_items.count_documents({})
    cats = await db.menu_items.distinct("category")
    print(f"\n[DONE] Total items in db.menu_items: {total}")
    print(f"Categories: {cats}")

if __name__ == "__main__":
    asyncio.run(main())
