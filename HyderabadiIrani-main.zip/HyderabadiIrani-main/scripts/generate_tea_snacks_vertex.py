import os
import json
import time
import asyncio
from io import BytesIO
from PIL import Image
from google import genai
from google.cloud import storage
from motor.motor_asyncio import AsyncIOMotorClient

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

os.makedirs(OUTPUT_DIR, exist_ok=True)

TEA_SNACKS_ITEMS = [
    {
        "name": "Hyderabadi Irani Chai",
        "slug": "hyderabadi_irani_chai_authentic",
        "prompt": "A close-up photograph of authentic hot Hyderabadi Irani Chai served in a classic transparent fluted Irani cafe glass with a thick rich creamy golden-white malai layer and froth on top, steaming hot, placed on a saucer with two crisp Osmania biscuits on the side, authentic Hyderabadi Irani cafe marble tabletop ambiance, warm morning lighting."
    },
    {
        "name": "Hydi Irani With Malai",
        "slug": "hydi_irani_chai_with_malai",
        "prompt": "Authentic Hyderabadi Irani Chai served in a traditional classic tea glass with a generous spoonful of thick rich clotted cream malai floating on top, steaming hot with deep golden caramel tea color, authentic old Hyderabad tea stall ambiance."
    },
    {
        "name": "Hydi Irani Chai Parcel",
        "slug": "hydi_irani_chai_parcel",
        "prompt": "Hyderabadi Irani Chai takeaway parcel packaging, a thermal silver dispenser flask container alongside small paper cups and packaged Osmania biscuits on a tea stall wooden counter, fresh hot tea pouring."
    },
    {
        "name": "Hydi Irani With Malai Parcel",
        "slug": "hydi_irani_with_malai_parcel",
        "prompt": "Authentic Hyderabadi Irani Chai with Extra Malai takeaway parcel, thermal insulated container with separate small container of thick rich clotted malai and biscuits, neat restaurant takeaway presentation."
    },
    {
        "name": "Black Tea",
        "slug": "black_tea_fresh",
        "prompt": "A crystal clear transparent glass cup of freshly brewed hot aromatic Black Tea with golden amber liquor, fresh mint sprig garnish, lemon slice on side, warm rustic cafe lighting, steam rising."
    },
    {
        "name": "coffee",
        "slug": "south_indian_filter_coffee",
        "prompt": "Authentic South Indian Filter Coffee served frothing hot in a traditional shiny brass Dabarah and Tumbler set, rich creamy brown foam spilling over, authentic South Indian hotel cafe setting."
    },
    {
        "name": "Boost",
        "slug": "boost_hot_malt_drink",
        "prompt": "A steaming hot glass cup of rich chocolate malt Boost drink, creamy frothy bubbles on top with a light dusting of cocoa powder, served in a glass mug on a cafe table."
    },
    {
        "name": "Horlicks",
        "slug": "horlicks_hot_malt_drink",
        "prompt": "A warm soothing glass of creamy golden malt Horlicks drink with rich thick froth, served in a classic glass tumbler with steam gently rising, cozy cafe setting."
    },
    {
        "name": "MILK",
        "slug": "fresh_hot_milk",
        "prompt": "A fresh hot glass of pure whole buffalo milk with natural creamy froth on top, served in a traditional Indian glass tumbler, steam rising, clean marble background."
    },
    {
        "name": "Milk With Malai",
        "slug": "milk_with_fresh_malai",
        "prompt": "A traditional glass tumbler of steaming hot rich whole milk generously topped with a thick dollop of clotted cream malai, rich creamy texture, authentic dairy stall setup."
    },
    {
        "name": "Boost/Horlicks/coffee/Milk Parcel",
        "slug": "hot_beverage_parcel_combo",
        "prompt": "Hot beverage takeaway packaging setup, thermal takeaway flask containers with carry handle and disposable cups neatly packed for delivery from a tea cafe."
    },
    {
        "name": "Milk With Malai Parcel",
        "slug": "milk_with_malai_parcel_pack",
        "prompt": "Hot Milk with fresh Malai in a secure thermal takeaway container with cups and lid, neatly packed for delivery on a cafe counter."
    },
    {
        "name": "Osmania Biscuits",
        "slug": "osmania_biscuits_plate_fresh",
        "prompt": "A plate of 6 freshly baked authentic round Hyderabadi Osmania Biscuits with glazed sweet and salty golden-brown tops, served next to a steaming glass of hot Irani Dum Chai, cozy Indian cafe lighting."
    },
    {
        "name": "Big samosa",
        "slug": "hyderabadi_big_samosa",
        "prompt": "A large crispy golden-brown Hyderabadi Big Samosa, crunchy flaky crust slightly broken open showing hot spicy potato, green peas and onion filling, served with green mint chutney and fried salted green chilies on a steel plate."
    },
    {
        "name": "Small Samosa(4pcs)",
        "slug": "small_onion_samosa_4pcs",
        "prompt": "A plate of 4 crispy golden-brown Hyderabadi Irani cafe style small onion samosas (patti samosas), ultra-crispy thin pastry triangles served with fried green chilies and sliced raw onions on a classic cafe plate."
    },
    {
        "name": "Small samosa (1pcs)",
        "slug": "small_onion_samosa_single",
        "prompt": "A single crispy golden-brown Hyderabadi Irani cafe style onion samosa with fried spicy green chili, gourmet street food close-up photography, crunchy flaky texture."
    },
    {
        "name": "Dilkush/Dilpasand/creambun",
        "slug": "hyderabadi_dilkush_dilpasand",
        "prompt": "Authentic Hyderabadi bakery Dilkush / Dilpasand pastry, golden baked flaky puff crust stuffed generously with colorful sweet tutti-frutti, grated coconut, dry fruits, and cherries, sliced into quarters showing mouthwatering colorful filling."
    },
    {
        "name": "Malai Bun/Maska Bun",
        "slug": "hyderabadi_malai_maska_bun",
        "prompt": "Authentic Hyderabadi Irani cafe Malai Bun / Bun Maska, fresh soft round sweet bakery bun sliced and generously loaded with thick melting white butter and clotted cream malai, served on a vintage plate next to a glass of Irani Chai."
    },
    {
        "name": "Plain Bun",
        "slug": "fresh_plain_bakery_bun",
        "prompt": "Freshly baked golden round plain bakery buns with glossy brown crust, soft and fluffy, served on a wooden bakery board with warm ambient light."
    },
    {
        "name": "Egg Bonda",
        "slug": "hyderabadi_egg_bonda",
        "prompt": "Two crispy deep-golden Hyderabadi Egg Bondas (boiled eggs coated in spiced chickpea besan batter and deep-fried), cut in half revealing yellow egg yolk, garnished with chopped onions, chaat masala, and curry leaves on a plate."
    },
    {
        "name": "Mirchi Bajji",
        "slug": "hyderabadi_mirchi_bajji_platter",
        "prompt": "A platter of authentic Hyderabadi Mirchi Bajjis, large deep-fried spicy green peppers in golden crispy gram flour batter, slit open and stuffed with seasoned diced onions, crushed roasted peanuts, cilantro, and lemon juice."
    },
    {
        "name": "Mirchi(1pc)",
        "slug": "hyderabadi_mirchi_bajji_single",
        "prompt": "A single piping hot crispy Hyderabadi Mirchi Bajji, golden besan coating, slit open with spicy onion and peanut filling, garnished with lemon slice and coriander."
    },
    {
        "name": "Cut Mirchi/Onion Mirchi (2pcs)",
        "slug": "hyderabadi_cut_mirchi_onion",
        "prompt": "Authentic Hyderabadi Cut Mirchi (twice-fried crispy sliced chili fritters) tossed in a bowl with crunchy diced onions, roasted peanuts, chat masala, fresh cilantro, and a wedge of juicy lime."
    },
    {
        "name": "Punugulu.",
        "slug": "hyderabadi_street_punugulu",
        "prompt": "A bowl of hot crispy golden-brown Andhra/Hyderabadi Punugulu (crispy batter fritters), served with spicy peanut chutney and tangy ginger (allam) chutney on a traditional banana leaf plate."
    },
    {
        "name": "Punugulu(Single)",
        "slug": "punugulu_single_portion",
        "prompt": "A plate of crispy bite-sized golden Punugulu street food snacks garnished with onions and coriander, served with coconut chutney and red chili chutney."
    },
    {
        "name": "Paneer Puff.",
        "slug": "crispy_paneer_puff_pastry",
        "prompt": "A freshly baked crispy golden-brown bakery Paneer Puff pastry with flaky buttery layers, filled with spicy paneer masala, served with tomato ketchup on a cafe plate."
    },
    {
        "name": "Veg puff.",
        "slug": "crispy_veg_puff_pastry",
        "prompt": "An authentic Indian bakery Veg Puff pastry with rich golden flaky puff layers, filled with spiced potato and green peas filling, steaming hot on a bakery tray."
    },
    {
        "name": "Chicken Puff.",
        "slug": "crispy_chicken_puff_pastry",
        "prompt": "A golden-brown flaky Chicken Puff pastry, multi-layered crisp puff crust filled with spicy savory minced chicken filling, garnished with herbs on a restaurant plate."
    },
    {
        "name": "onion Pakoda(100grms)",
        "slug": "hyderabadi_onion_pakoda_kanda_bhajji",
        "prompt": "A generous portion of ultra-crispy golden-brown Hyderabadi Onion Pakoda (Kanda Bhajji), crunchy sliced onion fritters seasoned with ajwain and curry leaves, served with fried green chilies on rustic paper."
    },
    {
        "name": "Water Bottle",
        "slug": "packaged_drinking_water_1l",
        "prompt": "A sealed chilled 1-litre clear mineral water bottle with natural condensation water droplets on the bottle surface, clean refreshing pure blue and white background."
    },
    {
        "name": "Water Bottle(Half)",
        "slug": "packaged_drinking_water_500ml",
        "prompt": "A compact chilled 500ml mineral packaged drinking water bottle with cool water droplets, clean refreshing studio beverage photography."
    }
]

def generate_and_upload(genai_client, gcs_bucket, item):
    slug = item["slug"]
    name = item["name"]
    prompt = item["prompt"]
    webp_path = os.path.join(OUTPUT_DIR, f"{slug}.webp")
    public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"

    print(f"\n[GEN] Generating image for '{name}' ({slug})...", flush=True)
    for attempt in range(1, 4):
        try:
            res = genai_client.models.generate_content(
                model="gemini-2.5-flash-image",
                contents=prompt
            )
            image_bytes = None
            for candidate in res.candidates:
                for part in candidate.content.parts:
                    if part.inline_data and part.inline_data.data:
                        image_bytes = part.inline_data.data
                        break
                if image_bytes:
                    break

            if not image_bytes:
                raise ValueError("No image bytes returned in candidate parts")

            # Optimize with PIL
            img = Image.open(BytesIO(image_bytes))
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            img = img.resize((600, 600), Image.Resampling.LANCZOS)
            img.save(webp_path, "WEBP", quality=82, method=6)
            size_kb = os.path.getsize(webp_path) / 1024
            print(f" -> Optimized WebP saved ({size_kb:.1f} KB). Uploading via google-cloud-storage...", flush=True)

            blob = gcs_bucket.blob(f"menu/{slug}.webp")
            blob.upload_from_filename(webp_path, content_type="image/webp")
            print(f" -> Uploaded: {public_url}", flush=True)
            return public_url
        except Exception as e:
            print(f" -> Error on attempt {attempt} for '{name}': {e}", flush=True)
            time.sleep(3)

    return public_url

async def update_single_db_item(mongo_db, name, url):
    res = await mongo_db.menu_items.update_one(
        {"name": name},
        {
            "$set": {
                "image_url": url,
                "category": "Tea",
                "counter_only": True,
                "order_type": "counter",
                "dine_in_instruction": "Order & Collect at Live Tea Counter"
            }
        }
    )
    print(f" -> DB Updated: '{name}' (matched={res.matched_count}, modified={res.modified_count})", flush=True)

async def main():
    print(f"Starting Vertex AI image generation & GCS upload for {len(TEA_SNACKS_ITEMS)} items...", flush=True)
    genai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    storage_client = storage.Client(project=PROJECT_ID)
    gcs_bucket = storage_client.bucket(BUCKET_NAME)

    mongo_client = AsyncIOMotorClient(MONGO_URL)
    mongo_db = mongo_client[DB_NAME]

    for idx, item in enumerate(TEA_SNACKS_ITEMS, 1):
        print(f"\n--- Item {idx}/{len(TEA_SNACKS_ITEMS)}: {item['name']} ---")
        url = generate_and_upload(genai_client, gcs_bucket, item)
        item["image_url"] = url
        await update_single_db_item(mongo_db, item["name"], url)
        time.sleep(1)

    print("\n=======================================================")
    print("ALL TEA & SNACKS IMAGES GENERATED, UPLOADED & DB UPDATED!")
    print("=======================================================")

if __name__ == "__main__":
    asyncio.run(main())
