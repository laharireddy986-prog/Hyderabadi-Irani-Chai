import vertexai
from vertexai.preview.vision_models import ImageGenerationModel
from PIL import Image
import os
import subprocess

PROJECT_ID = "metal-density-504117-k9"
vertexai.init(project=PROJECT_ID, location="us-central1")

for model_name in ["imagegeneration@006", "imagegeneration@005", "imagen-3.0-generate-002"]:
    try:
        print(f"Trying model {model_name}...")
        model = ImageGenerationModel.from_pretrained(model_name)
        images = model.generate_images(
            prompt="A professional close-up photo of authentic Hyderabadi Chicken Biryani garnished with fried onions, fresh mint, restaurant food photography, 45 degree angle.",
            number_of_images=1,
            aspect_ratio="1:1"
        )
        os.makedirs("scratch_images", exist_ok=True)
        raw_path = "scratch_images/test_raw.png"
        images[0].save(location=raw_path, include_generation_parameters=False)
        print(f"SUCCESS with {model_name}! Saved to {raw_path}")
        
        # Compress
        img = Image.open(raw_path)
        img = img.resize((700, 700), Image.Resampling.LANCZOS)
        webp_path = "scratch_images/test_compressed.webp"
        img.save(webp_path, "WEBP", quality=82, method=6)
        
        raw_size = os.path.getsize(raw_path) / 1024
        webp_size = os.path.getsize(webp_path) / 1024
        print(f"Original size: {raw_size:.1f} KB -> Compressed WebP: {webp_size:.1f} KB")
        
        # Test upload to GCS
        res = subprocess.run(["gcloud", "storage", "cp", webp_path, "gs://hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/test.webp"], capture_output=True, text=True)
        print("GCS Upload:", res.stdout, res.stderr)
        print("Public URL: https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/test.webp")
        break
    except Exception as e:
        print(f"Failed {model_name}: {e}")
