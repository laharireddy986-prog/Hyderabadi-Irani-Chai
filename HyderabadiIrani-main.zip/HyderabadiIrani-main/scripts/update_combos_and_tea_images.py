import os
import json
import time
import subprocess
import asyncio
from io import BytesIO
from PIL import Image
from google import genai
from motor.motor_asyncio import AsyncIOMotorClient

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"
BUCKET_NAME = "hyderabadi-irani-menu-assets-metal-density-504117-k9"
OUTPUT_DIR = r"c:\Hyderabadi Irani\scripts\optimized_images"
MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

os.makedirs(OUTPUT_DIR, exist_ok=True)

ITEMS_TO_UPDATE = [
    # --- COMBOS CATEGORY ---
    {
        "name": "VEG BIRYANI(FAMILY / JUMBO)",
        "slug": "combo_veg_biryani_jumbo",
        "prompt": "A lavish grand feast of Hyderabadi Veg Biryani Family Jumbo Pack served in a large royal brass handi, fragrant long-grain basmati rice with paneer cubes, fresh green vegetables, saffron strands, fried golden onions (birista), served with bowls of creamy raita, spicy mirchi ka salan, and sliced boiled eggs, restaurant table feast lighting."
    },
    {
        "name": "MUTTON BIRYANI(FAMILY / JUMBO)",
        "slug": "combo_mutton_biryani_jumbo",
        "prompt": "An authentic royal Hyderabadi Mutton Dum Biryani Family Jumbo Pack feast, large traditional copper handi loaded with tender juicy mutton pieces, aromatic saffron basmati rice, caramelized onions, fresh mint, garnished with 4 boiled eggs, served with authentic Mirchi Ka Salan and onion raita, gourmet food photography."
    },
    {
        "name": "CHICKEN DUM BIRYANI(FAMILY / JUMBO)",
        "slug": "combo_chicken_dum_biryani_jumbo",
        "prompt": "A huge steaming Hyderabadi Chicken Dum Biryani Family Pack served in a grand ceramic party platter, loaded with succulent juicy chicken pieces, aromatic yellow-orange long basmati rice, fried cashews, fresh cilantro, boiled eggs, surrounded by bowls of rich spicy salan and cold raita, festive family dinner setting."
    },
    {
        "name": "CHICKEN FRY PIECE BIRYANI(FAMILY / JUMBO)",
        "slug": "combo_chicken_fry_piece_biryani_jumbo",
        "prompt": "A grand platter of Hyderabadi Special Chicken Fry Piece Biryani Family Jumbo Pack, richly topped with crispy spicy red Andhra-style fried chicken pieces, roasted cashews, curry leaves, layered over fragrant ghee bagara biryani rice, served with lemon wedges, onions, and gravy."
    },

    # --- TEA & CAFE CATEGORY ---
    {
        "name": "Hyderabadi Irani Chai",
        "slug": "hyderabadi_irani_chai_authentic",
        "prompt": "A close-up of authentic hot Hyderabadi Irani Chai served in a classic transparent vintage tea glass with thick rich creamy malai layer on top, placed on a saucer with 2 Osmania biscuits on the side, steam gently rising, warm nostalgic Irani cafe marble tabletop ambiance."
    },
    {
        "name": "Special Irani Chai (Khada Chammach)",
        "slug": "special_irani_chai_khada_chammach",
        "prompt": "Authentic Hyderabadi Khada Chammach Irani Chai, served in a glass where a steel spoon stands perfectly upright supported by thick rabdi condensed milk at the bottom, rich golden aromatic tea layered on top, traditional Hyderabad cafe presentation, 45 degree angle."
    },
    {
        "name": "Osmania Biscuits (Plate)",
        "slug": "osmania_biscuits_plate_fresh",
        "prompt": "A fresh plate of 4 golden-brown authentic round Hyderabadi Osmania Biscuits with glazed sweet and salty browned tops, served next to a steaming glass of hot Irani Dum Chai, cozy Indian cafe lighting."
    },
    {
        "name": "Bun Maska",
        "slug": "bun_maska_authentic",
        "prompt": "Authentic Irani cafe Bun Maska, a fresh soft round sweet bakery bun sliced open and generously loaded with thick melting white Amul butter (maska) and sweet mixed fruit jam, served on a vintage plate with Irani Chai in the background."
    },
    {
        "name": "Ginger Irani Chai",
        "slug": "ginger_irani_chai_fresh",
        "prompt": "A hot glass of freshly brewed Hyderabadi Ginger (Adrak) Irani Chai with crushed ginger and crushed green cardamom, rich frothy creamy texture, steam rising, traditional tea stall setting."
    },
    {
        "name": "Lemon Tea",
        "slug": "sulaimani_lemon_tea_fresh",
        "prompt": "A clear transparent glass cup of aromatic Hyderabadi Sulaimani Lemon Tea with beautiful golden amber color, garnished with fresh green mint leaves and a floating sliced yellow lemon wheel, refreshing cafe drink."
    },
    {
        "name": "Filter Coffee",
        "slug": "south_indian_filter_coffee_authentic",
        "prompt": "Authentic South Indian Filter Coffee served frothing hot in a traditional traditional brass Dabarah and Tumbler set, rich brown coffee with creamy froth spilling over, authentic South Indian cafe background."
    },
    {
        "name": "Badam Milk (Hot / Cold)",
        "slug": "kesar_badam_milk_rich",
        "prompt": "A rich and thick royal Kesar Badam Milk served in a traditional earthen clay kulhad cup, vibrant golden saffron yellow color, lavishly garnished with slivered almonds, crushed pistachios, and real saffron strands."
    }
]

def generate_and_upload(client, item):
    slug = item["slug"]
    name = item["name"]
    prompt = item["prompt"]
    webp_path = os.path.join(OUTPUT_DIR, f"{slug}.webp")
    gcs_dest = f"gs://{BUCKET_NAME}/menu/{slug}.webp"
    public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/menu/{slug}.webp"

    print(f"\n[GEN] Generating image for '{name}'...", flush=True)
    for attempt in range(1, 4):
        try:
            res = client.models.generate_content(
                model="gemini-2.5-flash-image",
                contents=prompt
            )
            image_bytes = None
            for candidate in res.candidates:
                for part in candidate.content.parts:
                    if part.inline_data and part.inline_data.data:
                        image_bytes = part.inline_data.data
                        break
                if image_bytes:
                    break

            if not image_bytes:
                raise ValueError("No image bytes returned")

            # Optimize with PIL
            img = Image.open(BytesIO(image_bytes))
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            img = img.resize((600, 600), Image.Resampling.LANCZOS)
            img.save(webp_path, "WEBP", quality=82, method=6)
            size_kb = os.path.getsize(webp_path) / 1024
            print(f" -> Optimized WebP: {size_kb:.1f} KB. Uploading to GCS...", flush=True)

            # Upload to GCS
            cmd = ["gcloud", "storage", "cp", "--content-type=image/webp", webp_path, gcs_dest]
            proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if proc.returncode == 0:
                print(f" -> Uploaded: {public_url}", flush=True)
                return public_url
            else:
                print(f" -> GCS Upload error: {proc.stderr}", flush=True)
        except Exception as e:
            print(f" -> Error on attempt {attempt}: {e}", flush=True)
            time.sleep(4)

    return public_url

async def update_db_images(items_with_urls):
    print("\n[DB] Updating image_url for Combos and Tea items...", flush=True)
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    for itm in items_with_urls:
        res = await db.menu_items.update_one(
            {"name": itm["name"]},
            {"$set": {"image_url": itm["image_url"]}}
        )
        print(f" -> Updated DB image: {itm['name']} (matched: {res.matched_count}, modified: {res.modified_count})", flush=True)

    print("\n[DONE] All Combos and Tea images updated in MongoDB!", flush=True)

def main():
    print(f"Starting Combos & Tea image update for {len(ITEMS_TO_UPDATE)} items...", flush=True)
    genai_client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)

    for item in ITEMS_TO_UPDATE:
        url = generate_and_upload(genai_client, item)
        item["image_url"] = url
        time.sleep(2)

    asyncio.run(update_db_images(ITEMS_TO_UPDATE))

if __name__ == "__main__":
    main()
