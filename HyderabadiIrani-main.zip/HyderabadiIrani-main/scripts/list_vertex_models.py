from google import genai

PROJECT_ID = "metal-density-504117-k9"
LOCATION = "us-central1"

try:
    client = genai.Client(vertexai=True, project=PROJECT_ID, location=LOCATION)
    models = client.models.list()
    print("Available Vertex models in project:")
    for m in models:
        print(" -", m.name)
except Exception as e:
    print("Error listing models:", e)
