import os
import subprocess

# Let's test different approaches with Vertex AI in python

# 1. Test google.genai with gemini-2.5-flash-image or imagen-3.0-generate-002 or gemini-3.1-flash-image
print("Testing GenAI client with Vertex AI...")
try:
    from google import genai
    from google.genai import types
    
    client = genai.Client(vertexai=True, project="metal-density-504117-k9", location="us-central1")
    
    # Try models
    models_to_try = [
        "imagen-3.0-generate-002",
        "imagegeneration@006",
        "gemini-2.5-flash-image",
        "gemini-3.1-flash-image"
    ]
    
    for m in models_to_try:
        try:
            print(f"Trying {m}...")
            res = client.models.generate_images(
                model=m,
                prompt="A delicious bowl of hot and sour soup, food photography",
                config=types.GenerateImagesConfig(
                    number_of_images=1,
                    aspect_ratio="1:1"
                )
            )
            print(f"SUCCESS with {m}! Got {len(res.generated_images)} images")
            with open("scripts/test_out.png", "wb") as f:
                f.write(res.generated_images[0].image.image_bytes)
            print("Saved scripts/test_out.png successfully!")
            break
        except Exception as e:
            print(f"Failed {m}: {e}")

except Exception as e:
    print(f"GenAI SDK error: {e}")

# 2. Also check if vertexai SDK is available
try:
    import vertexai
    from vertexai.preview.vision_models import ImageGenerationModel
    vertexai.init(project="metal-density-504117-k9", location="us-central1")
    for m in ["imagen-3.0-generate-002", "imagegeneration@006"]:
        try:
            print(f"Trying VertexAI vision_models {m}...")
            model = ImageGenerationModel.from_pretrained(m)
            imgs = model.generate_images(
                prompt="A delicious bowl of soup, professional food photography",
                number_of_images=1,
                aspect_ratio="1:1"
            )
            imgs[0].save("scripts/test_vertex_vision.png")
            print(f"SUCCESS with VertexAI vision_models {m}!")
            break
        except Exception as e:
            print(f"Failed {m}: {e}")
except Exception as e:
    print(f"VertexAI vision_models error: {e}")
