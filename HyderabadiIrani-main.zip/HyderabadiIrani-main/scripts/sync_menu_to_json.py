import os
import json
import pymongo

MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = "hyderabadi_irani"

def sync():
    client = pymongo.MongoClient(MONGO_URL)
    db = client[DB_NAME]
    items = list(db.menu_items.find({}, {"_id": 0}))
    
    # Save to scripts/menu_items.json
    target_path = r"c:\Hyderabadi Irani\scripts\menu_items.json"
    with open(target_path, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2, ensure_ascii=False)
        
    print(f"Successfully exported {len(items)} full menu items to {target_path}!")

if __name__ == "__main__":
    sync()
