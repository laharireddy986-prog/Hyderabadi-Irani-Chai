import React from "react";
import { MapPin, Phone, Package, CheckCircle2, Navigation, Loader2, ChevronRight } from "lucide-react";
import { money } from "../lib/api";

function openNavigation(order) {
  const url =
    order.lat && order.lng
      ? `https://www.google.com/maps/dir/?api=1&destination=${order.lat},${order.lng}&travelmode=driving`
      : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(order.address || "")}`;
  window.open(url, "_system");
}

export default function OrderCard({ order, isMine, onAccept, onMarkDelivered, busy }) {
  const itemsSummary = (order.items || []).map((i) => `${i.qty}x ${i.name}`).join(", ");
  // Accepting sets driver_id + status=out_for_delivery together server-side,
  // but older/manually-assigned orders can have driver_id set while status
  // is still 'ready' — mark_order_delivered doesn't require a specific
  // prior status, so once it's mine, always give a way to close it out
  // rather than leaving the driver with no action at all.
  const showAccept = !isMine && !order.driver_id;
  const showMineActions = isMine;

  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-card overflow-hidden">
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="font-mono font-bold text-sm text-brand-950">#{order.order_no}</p>
            <p className="text-xs text-stone-500 mt-0.5">{order.customer_name}</p>
          </div>
          <span
            className={`text-[10px] font-bold uppercase px-2 py-1 rounded-full flex-shrink-0 ${
              order.status === "out_for_delivery"
                ? "bg-amber-100 text-amber-800"
                : order.status === "completed"
                ? "bg-stone-200 text-stone-600"
                : "bg-emerald-100 text-emerald-800"
            }`}
          >
            {order.status === "out_for_delivery"
              ? "🛵 On the way"
              : order.status === "completed"
              ? "Delivered"
              : "Ready for pickup"}
          </span>
        </div>

        <button
          type="button"
          onClick={() => openNavigation(order)}
          className="w-full flex items-start gap-2 text-xs text-stone-700 text-left bg-stone-50 hover:bg-stone-100 rounded-xl p-2.5 transition"
        >
          <MapPin size={14} className="text-brand-700 flex-shrink-0 mt-0.5" />
          <span className="flex-1">{order.address || "No address provided"}</span>
          <ChevronRight size={14} className="text-stone-400 flex-shrink-0" />
        </button>

        <div className="flex items-start gap-2 text-xs text-stone-500">
          <Package size={14} className="flex-shrink-0 mt-0.5" />
          <span className="line-clamp-2">{itemsSummary}</span>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-stone-100">
          <span className="font-mono font-extrabold text-sm text-brand-950">{money(order.total)}</span>
          <span className="text-[11px] font-bold text-stone-500 uppercase">
            {order.payment_mode === "cash" ? "💰 Collect Cash" : "✅ Prepaid"}
          </span>
        </div>
      </div>

      {/* Action row — Zomato-style: navigate + call always available once
          assigned, primary action (Accept / Mark Delivered) alongside. */}
      {(showAccept || showMineActions) && order.status !== "completed" && (
        <div className="flex border-t border-stone-100">
          {showMineActions && (
            <button
              type="button"
              onClick={() => openNavigation(order)}
              className="active-press flex-1 py-3 flex items-center justify-center gap-1.5 text-xs font-bold text-brand-900 border-r border-stone-100 hover:bg-stone-50"
            >
              <Navigation size={14} />
              <span>Navigate</span>
            </button>
          )}
          {showMineActions && order.phone && (
            <a
              href={`tel:${order.phone}`}
              className="active-press flex-1 py-3 flex items-center justify-center gap-1.5 text-xs font-bold text-brand-900 border-r border-stone-100 hover:bg-stone-50"
            >
              <Phone size={14} />
              <span>Call</span>
            </a>
          )}

          {showAccept ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => onAccept(order)}
              className="active-press flex-[1.4] py-3 bg-brand-900 hover:bg-brand-950 text-white font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {busy ? <Loader2 size={14} className="animate-spin" /> : <Navigation size={14} />}
              <span>{busy ? "Accepting…" : "Accept Delivery"}</span>
            </button>
          ) : showMineActions ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => onMarkDelivered(order)}
              className="active-press flex-[1.4] py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {busy ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
              <span>{busy ? "Confirming…" : "Mark Delivered"}</span>
            </button>
          ) : null}
        </div>
      )}
    </div>
  );
}
