import React from "react";
import { Banknote, X, Loader2, CheckCircle2 } from "lucide-react";
import { money } from "../lib/api";

export default function ConfirmCashModal({ order, onConfirm, onClose, busy }) {
  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 space-y-4">
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center">
            <Banknote size={22} />
          </div>
          <button type="button" onClick={onClose} className="text-stone-400">
            <X size={18} />
          </button>
        </div>

        <div>
          <h3 className="font-bold text-base text-brand-950">Confirm Cash Collected</h3>
          <p className="text-xs text-stone-500 mt-1">
            Order #{order.order_no} is Cash on Delivery. Please collect the payment from the customer
            before marking this order as delivered.
          </p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
          <span className="text-xs font-bold text-amber-900 uppercase">Amount to Collect</span>
          <span className="font-mono font-extrabold text-lg text-amber-950">{money(order.total)}</span>
        </div>

        <button
          type="button"
          disabled={busy}
          onClick={() => onConfirm(order)}
          className="active-press w-full bg-emerald-700 hover:bg-emerald-800 text-white py-3.5 rounded-2xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {busy ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
          <span>{busy ? "Confirming…" : `I Collected ${money(order.total)} — Mark Delivered`}</span>
        </button>

        <button type="button" onClick={onClose} className="w-full py-2 text-xs font-bold text-stone-500">
          Cancel
        </button>
      </div>
    </div>
  );
}
