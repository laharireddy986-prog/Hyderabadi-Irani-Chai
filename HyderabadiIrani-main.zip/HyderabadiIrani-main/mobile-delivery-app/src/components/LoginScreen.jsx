import React, { useState } from "react";
import { Bike, Loader2, Lock, Mail } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function LoginScreen() {
  const { login, signingIn } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) return;
    login(email.trim(), password);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 bg-brand-950 text-white">
      <div className="w-16 h-16 rounded-2xl bg-amber-400 text-brand-950 flex items-center justify-center shadow-lg mb-4">
        <Bike size={30} />
      </div>
      <h1 className="font-serif text-xl font-bold mb-1">Hyderabadi Irani</h1>
      <p className="text-xs text-amber-200 mb-8">Delivery Partner App</p>

      <form onSubmit={handleSubmit} className="w-full max-w-xs space-y-3">
        <div className="relative">
          <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400" />
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full bg-white text-stone-900 rounded-xl pl-9 pr-3 py-3 text-sm outline-none"
            autoCapitalize="none"
          />
        </div>
        <div className="relative">
          <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400" />
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full bg-white text-stone-900 rounded-xl pl-9 pr-3 py-3 text-sm outline-none"
          />
        </div>
        <button
          type="submit"
          disabled={signingIn}
          className="active-press w-full bg-amber-400 hover:bg-amber-300 text-brand-950 py-3 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {signingIn ? <Loader2 size={15} className="animate-spin" /> : null}
          <span>{signingIn ? "Signing in…" : "Sign In"}</span>
        </button>
      </form>

      <p className="text-[11px] text-brand-400 mt-8 text-center">
        Delivery partner accounts are created by the restaurant admin.
        <br />Contact the restaurant if you don't have login details.
      </p>
    </div>
  );
}
