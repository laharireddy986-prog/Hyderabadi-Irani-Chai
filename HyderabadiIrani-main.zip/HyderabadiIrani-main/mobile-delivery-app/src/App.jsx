import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  LogOut,
  Bike,
  RefreshCw,
  Loader2,
  ClipboardList,
  User,
  TrendingUp,
  MapPinned,
  CheckCircle2,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Filter,
  Banknote,
  PackageCheck,
  Navigation
} from "lucide-react";
import { useAuth } from "./context/AuthContext";
import { api, errMsg, money } from "./lib/api";
import { toast } from "sonner";
import LoginScreen from "./components/LoginScreen";
import OrderCard from "./components/OrderCard";
import ConfirmCashModal from "./components/ConfirmCashModal";
import { initializeDriverPushNotifications } from "./lib/notifications";

const POLL_INTERVAL_MS = 15000;
const LOCATION_UPDATE_INTERVAL_MS = 20000;

// Helper to convert Date/ISO string to local "YYYY-MM-DD"
const toLocalDateStr = (dInput) => {
  if (!dInput) return "";
  const d = dInput instanceof Date ? dInput : new Date(dInput);
  if (isNaN(d.getTime())) return "";
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const getTodayStr = () => toLocalDateStr(new Date());

const getYesterdayStr = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return toLocalDateStr(d);
};

export default function App() {
  const { user, isLoggedIn, loading, logout } = useAuth();
  const [orders, setOrders] = useState([]);
  const [fetching, setFetching] = useState(true);
  const [busyOrderId, setBusyOrderId] = useState(null);
  const [activeTab, setActiveTab] = useState("orders"); // "orders" | "profile"
  const [pendingCashOrder, setPendingCashOrder] = useState(null);

  // Calendar / Date Filter State for Profile / Earnings
  const [dateFilter, setDateFilter] = useState("today"); // "today" | "yesterday" | "last7" | "thisMonth" | "custom" | "all"
  const [selectedDate, setSelectedDate] = useState(getTodayStr());

  const loadOrders = useCallback(async () => {
    try {
      const res = await api.get("/delivery/orders");
      setOrders(res.data || []);
    } catch (err) {
      console.warn("[ORDERS] fetch error:", errMsg(err));
    } finally {
      setFetching(false);
    }
  }, []);

  // Poll for new/updated orders while logged in.
  useEffect(() => {
    if (!isLoggedIn) return;
    loadOrders();
    const interval = setInterval(loadOrders, POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [isLoggedIn, loadOrders]);

  // Register for push notifications once logged in
  useEffect(() => {
    if (!isLoggedIn) return;
    initializeDriverPushNotifications({ onNewOrder: loadOrders });
  }, [isLoggedIn, loadOrders]);

  const handleAccept = async (order) => {
    setBusyOrderId(order.id);
    try {
      await api.put(`/delivery/orders/${order.id}/accept`);
      toast.success(`Order #${order.order_no} accepted! 🛵`);
      await loadOrders();
    } catch (err) {
      toast.error(errMsg(err) || "Could not accept this order.");
    } finally {
      setBusyOrderId(null);
    }
  };

  const submitMarkDelivered = async (order) => {
    setBusyOrderId(order.id);
    try {
      await api.put(`/delivery/orders/${order.id}/delivered`);
      toast.success(`Order #${order.order_no} marked as delivered! ✅`);
      setPendingCashOrder(null);
      await loadOrders();
    } catch (err) {
      toast.error(errMsg(err) || "Could not update this order.");
    } finally {
      setBusyOrderId(null);
    }
  };

  const handleMarkDelivered = (order) => {
    if (order.payment_mode === "cash") {
      setPendingCashOrder(order);
    } else {
      submitMarkDelivered(order);
    }
  };

  // Live location broadcast
  const activeDeliveries = orders.filter((o) => o.driver_id === user?.id && o.status === "out_for_delivery");
  const activeIdsKey = activeDeliveries.map((o) => o.id).join(",");

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const pushLocation = async () => {
      try {
        let position = null;
        if (window.Capacitor?.isPluginAvailable("Geolocation")) {
          try {
            const { Geolocation } = await import("@capacitor/geolocation");
            position = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10000 });
          } catch {}
        }
        if (!position && navigator.geolocation) {
          position = await new Promise((resolve, reject) =>
            navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 })
          );
        }
        if (!position || cancelled) return;

        const { latitude: lat, longitude: lng, speed, heading } = position.coords;
        let batteryLevel = null;
        if (navigator.getBattery) {
          try {
            const b = await navigator.getBattery();
            batteryLevel = Math.round(b.level * 100);
          } catch {}
        }

        const payload = {
          lat,
          lng,
          speed: speed ? Math.round(speed * 3.6) : 0, // km/h
          heading: heading || 0,
          battery: batteryLevel,
          status: activeDeliveries.length ? "out_for_delivery" : "online",
        };

        // Broadcast driver live location to admin
        await api.put("/delivery/location", payload).catch(() => {});

        // Update active delivery orders
        if (activeDeliveries.length) {
          await Promise.all(
            activeDeliveries.map((o) =>
              api.put(`/delivery/orders/${o.id}/location`, payload).catch(() => {})
            )
          );
        }
      } catch {
        // Best-effort silent location sync
      }
    };

    pushLocation();
    const interval = setInterval(pushLocation, 10000); // 10s live pulse
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, activeIdsKey]);

  const mine = useMemo(() => orders.filter((o) => o.driver_id === user?.id), [orders, user]);
  const readyForPickup = useMemo(() => orders.filter((o) => !o.driver_id && o.status === "ready"), [orders]);

  // All completed orders for this driver
  const deliveredOrders = useMemo(() => mine.filter((o) => o.status === "completed"), [mine]);

  // Filtered completed deliveries based on calendar/date selection
  const filteredDeliveredOrders = useMemo(() => {
    const today = getTodayStr();
    const yesterday = getYesterdayStr();
    const now = new Date();

    return deliveredOrders.filter((o) => {
      const oDateStr = toLocalDateStr(o.created_at);
      if (!oDateStr) return dateFilter === "all";

      if (dateFilter === "today") {
        return oDateStr === today;
      }
      if (dateFilter === "yesterday") {
        return oDateStr === yesterday;
      }
      if (dateFilter === "last7") {
        const oDate = new Date(o.created_at);
        const diffMs = now.getTime() - oDate.getTime();
        const diffDays = diffMs / (1000 * 60 * 60 * 24);
        return diffDays >= 0 && diffDays <= 7;
      }
      if (dateFilter === "thisMonth") {
        const oDate = new Date(o.created_at);
        return oDate.getFullYear() === now.getFullYear() && oDate.getMonth() === now.getMonth();
      }
      if (dateFilter === "custom") {
        return oDateStr === selectedDate;
      }
      return true; // "all"
    });
  }, [deliveredOrders, dateFilter, selectedDate]);

  // Recalculated metrics for the selected period
  const filteredDistanceKm = useMemo(
    () => filteredDeliveredOrders.reduce((sum, o) => sum + (Number(o.distance_km) || 0), 0),
    [filteredDeliveredOrders]
  );

  const filteredCashCollected = useMemo(
    () =>
      filteredDeliveredOrders
        .filter((o) => o.payment_mode === "cash")
        .reduce((sum, o) => sum + (Number(o.total) || 0), 0),
    [filteredDeliveredOrders]
  );

  const filteredTotalValue = useMemo(
    () => filteredDeliveredOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0),
    [filteredDeliveredOrders]
  );

  // Friendly label for current filter
  const filterSummaryLabel = useMemo(() => {
    if (dateFilter === "today") {
      const d = new Date();
      return `Today (${d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })})`;
    }
    if (dateFilter === "yesterday") {
      const d = new Date();
      d.setDate(d.getDate() - 1);
      return `Yesterday (${d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })})`;
    }
    if (dateFilter === "last7") {
      return "Last 7 Days";
    }
    if (dateFilter === "thisMonth") {
      return new Date().toLocaleDateString("en-IN", { month: "long", year: "numeric" });
    }
    if (dateFilter === "custom") {
      if (selectedDate) {
        const parts = selectedDate.split("-");
        if (parts.length === 3) {
          const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
          return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
        }
      }
      return selectedDate;
    }
    return "All Time (Lifetime)";
  }, [dateFilter, selectedDate]);

  // Step single day back/forward
  const stepDate = (delta) => {
    let base = new Date();
    if (dateFilter === "custom" && selectedDate) {
      const parts = selectedDate.split("-");
      if (parts.length === 3) {
        base = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      }
    } else if (dateFilter === "yesterday") {
      base.setDate(base.getDate() - 1);
    }
    base.setDate(base.getDate() + delta);
    const newDateStr = toLocalDateStr(base);
    setSelectedDate(newDateStr);
    setDateFilter("custom");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-950">
        <Loader2 size={28} className="animate-spin text-amber-400" />
      </div>
    );
  }

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  return (
    <div className="min-h-screen bg-surface-subtle pb-24">
      {/* Header */}
      <header className="bg-brand-950 text-white px-4 py-4 flex items-center justify-between sticky top-0 z-10 pt-safe">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-400 text-brand-950 flex items-center justify-center shadow-sm">
            <Bike size={18} />
          </div>
          <div>
            <p className="font-bold text-sm leading-tight">{user?.name || "Hyderabadi Irani Delivery Partner"}</p>
            <p className="text-[11px] text-amber-200">
              {mine.filter((o) => o.status !== "completed").length} active {mine.filter((o) => o.status !== "completed").length === 1 ? "delivery" : "deliveries"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadOrders}
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition active:scale-95"
            title="Refresh"
          >
            <RefreshCw size={14} className={fetching ? "animate-spin" : ""} />
          </button>
          <button
            type="button"
            onClick={logout}
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition active:scale-95 text-red-300"
            title="Log Out"
          >
            <LogOut size={14} />
          </button>
        </div>
      </header>

      <main className="px-4 pt-4 space-y-5 max-w-md mx-auto">
        {activeTab === "orders" ? (
          fetching && orders.length === 0 ? (
            <div className="flex justify-center py-12">
              <Loader2 size={24} className="animate-spin text-brand-700" />
            </div>
          ) : (
            <>
              {/* Active Assigned Deliveries */}
              {mine.filter((o) => o.status !== "completed").length > 0 && (
                <section className="space-y-2.5">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                    My Deliveries ({mine.filter((o) => o.status !== "completed").length})
                  </h2>
                  {mine
                    .filter((o) => o.status !== "completed")
                    .map((o) => (
                      <OrderCard
                        key={o.id}
                        order={o}
                        isMine
                        busy={busyOrderId === o.id}
                        onAccept={handleAccept}
                        onMarkDelivered={handleMarkDelivered}
                      />
                    ))}
                </section>
              )}

              {/* Ready for Pickup */}
              <section className="space-y-2.5">
                <h2 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                  Ready for Pickup ({readyForPickup.length})
                </h2>
                {readyForPickup.length === 0 ? (
                  <div className="text-center py-10 text-stone-400 text-xs bg-white rounded-2xl border border-stone-200/70 p-6">
                    No new orders waiting for pickup right now. This screen refreshes automatically.
                  </div>
                ) : (
                  readyForPickup.map((o) => (
                    <OrderCard
                      key={o.id}
                      order={o}
                      isMine={false}
                      busy={busyOrderId === o.id}
                      onAccept={handleAccept}
                      onMarkDelivered={handleMarkDelivered}
                    />
                  ))
                )}
              </section>

              {/* Recent Completed Deliveries */}
              {deliveredOrders.length > 0 && (
                <section className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                      Recent Deliveries ({deliveredOrders.length})
                    </h2>
                    <button
                      type="button"
                      onClick={() => setActiveTab("profile")}
                      className="text-xs font-bold text-brand-900 flex items-center gap-1 hover:underline"
                    >
                      <span>Calendar Stats</span>
                      <ChevronRight size={14} />
                    </button>
                  </div>
                  {deliveredOrders.slice(0, 3).map((o) => (
                    <OrderCard key={o.id} order={o} isMine busy={false} onAccept={() => {}} onMarkDelivered={() => {}} />
                  ))}
                </section>
              )}
            </>
          )
        ) : (
          /* ===================== PROFILE / CALENDAR / STATS TAB ===================== */
          <div className="space-y-4">
            {/* Driver Profile Card */}
            <div className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 flex items-center gap-3.5">
              <div className="w-13 h-13 rounded-full bg-brand-900 text-white flex items-center justify-center font-bold text-lg shadow-sm">
                {(user?.name || "H")[0].toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <p className="font-bold text-base text-brand-950 truncate">{user?.name || "Hyderabadi Irani Delivery Partner"}</p>
                </div>
                <p className="text-xs text-stone-500 truncate">{user?.email || "driver@hyderabadiirani.com"}</p>
                <span className="inline-block mt-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200">
                  🛵 Delivery Partner
                </span>
              </div>
            </div>

            {/* Calendar & Date Filter Section */}
            <div className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-stone-700">
                  <Calendar size={15} className="text-brand-900" />
                  <span>Calendar & Ride Stats</span>
                </div>
                <span className="text-[11px] font-semibold text-brand-900 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-100">
                  {filterSummaryLabel}
                </span>
              </div>

              {/* Quick Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
                {[
                  { id: "today", label: "Today" },
                  { id: "yesterday", label: "Yesterday" },
                  { id: "last7", label: "Last 7 Days" },
                  { id: "thisMonth", label: "This Month" },
                  { id: "all", label: "All Time" }
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setDateFilter(f.id)}
                    className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition text-xs ${
                      dateFilter === f.id
                        ? "bg-brand-900 text-white shadow-sm"
                        : "bg-stone-100 text-stone-600 hover:bg-stone-200"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              {/* Day-by-Day Stepper & Exact Date Picker */}
              <div className="bg-stone-50 rounded-xl p-2 flex items-center justify-between border border-stone-200/80 gap-2">
                <button
                  type="button"
                  onClick={() => stepDate(-1)}
                  className="p-1.5 rounded-lg bg-white border border-stone-200 text-stone-700 hover:bg-stone-100 active:scale-95 transition"
                  title="Previous Day"
                >
                  <ChevronLeft size={16} />
                </button>

                <div className="flex-1 flex items-center justify-center gap-2">
                  <label htmlFor="delivery-date-picker" className="text-xs font-bold text-stone-700 flex items-center gap-1.5 cursor-pointer">
                    <Filter size={13} className="text-brand-900" />
                    <span>Pick Date:</span>
                  </label>
                  <input
                    id="delivery-date-picker"
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      setDateFilter("custom");
                    }}
                    className="text-xs font-semibold bg-white border border-stone-300 rounded-lg px-2.5 py-1 text-stone-800 focus:outline-none focus:ring-1 focus:ring-brand-900"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => stepDate(1)}
                  className="p-1.5 rounded-lg bg-white border border-stone-200 text-stone-700 hover:bg-stone-100 active:scale-95 transition"
                  title="Next Day"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>

            {/* Dynamically Recalculated Metric Cards */}
            <div className="grid grid-cols-2 gap-3">
              {/* Completed Orders / Rides */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 space-y-1">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <CheckCircle2 size={16} />
                </div>
                <p className="font-mono font-extrabold text-2xl text-brand-950">{filteredDeliveredOrders.length}</p>
                <p className="text-[11px] text-stone-500 font-bold uppercase">Rides / Orders</p>
                <p className="text-[10px] text-stone-400">Delivered successfully</p>
              </div>

              {/* Distance Travelled */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 space-y-1">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <MapPinned size={16} />
                </div>
                <p className="font-mono font-extrabold text-2xl text-brand-950">{filteredDistanceKm.toFixed(1)} km</p>
                <p className="text-[11px] text-stone-500 font-bold uppercase">Distance Covered</p>
                <p className="text-[10px] text-stone-400">Total ride distance</p>
              </div>

              {/* Cash Collected */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 space-y-1">
                <div className="w-8 h-8 rounded-xl bg-green-100 text-green-800 flex items-center justify-center">
                  <Banknote size={16} />
                </div>
                <p className="font-mono font-extrabold text-2xl text-emerald-900">{money(filteredCashCollected)}</p>
                <p className="text-[11px] text-stone-500 font-bold uppercase">Cash Collected</p>
                <p className="text-[10px] text-stone-400">
                  {filteredDeliveredOrders.filter((o) => o.payment_mode === "cash").length} cash orders
                </p>
              </div>

              {/* Total Deliveries Value */}
              <div className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 space-y-1">
                <div className="w-8 h-8 rounded-xl bg-brand-100 text-brand-900 flex items-center justify-center">
                  <TrendingUp size={16} />
                </div>
                <p className="font-mono font-extrabold text-2xl text-brand-950">{money(filteredTotalValue)}</p>
                <p className="text-[11px] text-stone-500 font-bold uppercase">Total Order Value</p>
                <p className="text-[10px] text-stone-400">All payment modes</p>
              </div>
            </div>

            {/* Filtered Order History */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                  Delivery History ({filteredDeliveredOrders.length})
                </h2>
                <span className="text-[11px] text-stone-400">{filterSummaryLabel}</span>
              </div>

              {filteredDeliveredOrders.length === 0 ? (
                <div className="text-center py-10 bg-white rounded-2xl border border-stone-200 p-6 space-y-2">
                  <PackageCheck size={32} className="mx-auto text-stone-300" />
                  <p className="text-xs font-semibold text-stone-600">
                    No completed deliveries found for {filterSummaryLabel}.
                  </p>
                  <p className="text-[11px] text-stone-400">
                    Try picking another date from the calendar or view all-time history.
                  </p>
                  <button
                    type="button"
                    onClick={() => setDateFilter("all")}
                    className="mt-2 inline-block px-3 py-1.5 rounded-lg bg-stone-100 text-stone-700 hover:bg-stone-200 text-xs font-bold transition"
                  >
                    View All Time History
                  </button>
                </div>
              ) : (
                filteredDeliveredOrders.map((o) => {
                  const d = o.created_at ? new Date(o.created_at) : null;
                  const timeFormatted = d && !isNaN(d.getTime())
                    ? d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })
                    : "";
                  const dateFormatted = d && !isNaN(d.getTime())
                    ? d.toLocaleDateString("en-IN", { day: "numeric", month: "short" })
                    : "";

                  return (
                    <div key={o.id} className="bg-white rounded-2xl border border-stone-200 shadow-card p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <p className="font-mono font-bold text-xs text-brand-950">#{o.order_no}</p>
                          {timeFormatted && (
                            <span className="text-[10px] text-stone-400 font-medium">
                              {dateFormatted} {timeFormatted}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          Delivered ✅
                        </span>
                      </div>

                      <p className="text-xs text-stone-600 font-medium">{o.customer_name} · {o.address || "Customer Address"}</p>

                      {o.items && o.items.length > 0 && (
                        <p className="text-[11px] text-stone-400 line-clamp-1">
                          {o.items.map((i) => `${i.qty}x ${i.name}`).join(", ")}
                        </p>
                      )}

                      <div className="flex items-center justify-between text-xs pt-1.5 border-t border-stone-100">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-extrabold text-brand-950">{money(o.total)}</span>
                          <span
                            className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                              o.payment_mode === "cash"
                                ? "bg-amber-100 text-amber-900"
                                : "bg-blue-100 text-blue-900"
                            }`}
                          >
                            {o.payment_mode === "cash" ? "Cash Collected" : "Prepaid Online"}
                          </span>
                        </div>
                        {o.distance_km ? (
                          <span className="text-stone-500 font-semibold text-[11px]">{o.distance_km} km</span>
                        ) : null}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Logout Button */}
            <button
              type="button"
              onClick={logout}
              className="active-press w-full text-red-700 bg-red-50 hover:bg-red-100 py-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition border border-red-200"
            >
              <LogOut size={14} />
              <span>Log Out</span>
            </button>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-white border-t border-stone-200 flex pb-safe">
        <button
          type="button"
          onClick={() => setActiveTab("orders")}
          className={`flex-1 py-3 flex flex-col items-center gap-1 text-[11px] font-bold transition ${
            activeTab === "orders" ? "text-brand-900 border-t-2 border-brand-900" : "text-stone-400"
          }`}
        >
          <ClipboardList size={18} />
          <span>Orders</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("profile")}
          className={`flex-1 py-3 flex flex-col items-center gap-1 text-[11px] font-bold transition ${
            activeTab === "profile" ? "text-brand-900 border-t-2 border-brand-900" : "text-stone-400"
          }`}
        >
          <User size={18} />
          <span>Calendar & Stats</span>
        </button>
      </nav>

      <ConfirmCashModal
        order={pendingCashOrder}
        busy={busyOrderId === pendingCashOrder?.id}
        onConfirm={submitMarkDelivered}
        onClose={() => setPendingCashOrder(null)}
      />
    </div>
  );
}

