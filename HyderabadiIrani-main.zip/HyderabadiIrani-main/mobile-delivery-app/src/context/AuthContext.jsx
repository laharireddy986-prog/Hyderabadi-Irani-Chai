import { createContext, useContext, useState, useEffect } from "react";
import { api, errMsg } from "../lib/api";
import { setSecureItem, getSecureItem, removeSecureItem } from "../lib/storage";
import { toast } from "sonner";

const AuthContext = createContext(null);

const TOKEN_KEY = "hi_driver_token";
const USER_KEY = "hi_driver_profile";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [signingIn, setSigningIn] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const savedToken = await getSecureItem(TOKEN_KEY);
        const savedUserStr = await getSecureItem(USER_KEY);
        if (savedToken) setToken(savedToken);
        if (savedUserStr) {
          try {
            setUser(JSON.parse(savedUserStr));
          } catch {}
        }
        if (savedToken) {
          try {
            const res = await api.get("/auth/me");
            setUser(res.data);
            await setSecureItem(USER_KEY, JSON.stringify(res.data));
          } catch {
            // Token invalid/expired — fall through, login screen will show.
          }
        }
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const login = async (email, password) => {
    setSigningIn(true);
    try {
      const res = await api.post("/auth/login", { email, password });
      const { access_token, user: loggedInUser } = res.data;
      if (!["delivery", "admin"].includes(loggedInUser.role)) {
        toast.error("This account isn't set up as a delivery partner. Contact the restaurant.");
        return { ok: false };
      }
      setToken(access_token);
      setUser(loggedInUser);
      await setSecureItem(TOKEN_KEY, access_token);
      await setSecureItem(USER_KEY, JSON.stringify(loggedInUser));
      toast.success(`Welcome, ${loggedInUser.name || "Partner"}! 🛵`);
      return { ok: true };
    } catch (err) {
      toast.error(errMsg(err) || "Login failed");
      return { ok: false };
    } finally {
      setSigningIn(false);
    }
  };

  const logout = async () => {
    setUser(null);
    setToken(null);
    await removeSecureItem(TOKEN_KEY);
    await removeSecureItem(USER_KEY);
    try {
      await api.post("/auth/logout");
    } catch {}
  };

  return (
    <AuthContext.Provider
      value={{ user, token, isLoggedIn: Boolean(user && token), loading, signingIn, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
