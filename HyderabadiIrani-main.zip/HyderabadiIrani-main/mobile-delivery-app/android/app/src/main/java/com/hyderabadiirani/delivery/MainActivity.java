package com.hyderabadiirani.delivery;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
