# The Grand Hotel — Billing Suite + Online Ordering

## Original problem statement
"i need to bulid a billind sofetware for hotals along with online orring wesites for them for that can you give me the the good coller them ui degibne for this project"

## User choices (June 2026)
- Scope: Both hotel billing/POS and customer online ordering website
- Auth: JWT login with Admin + Cashier/Staff roles
- Payments: Cash on Delivery now, Razorpay later
- Invoices: Printable / downloadable PDF
- Theme: agent-chosen ("Warm Brutalism" — cream #F7F5F0, terracotta #D45D48, forest #2A4736, Cormorant Garamond + IBM Plex Sans, hard 1px borders, offset shadows)

## Architecture
- Backend: FastAPI (`/app/backend/server.py`), MongoDB via motor, all routes under `/api`
- Auth: bcrypt + PyJWT (12h access token), Bearer header, roles admin/staff
- PDF: reportlab, `GET /api/invoice/{order_no}`
- Frontend: React 19 + React Router, Tailwind, sonner toasts, recharts
- Contexts: `AuthContext` (localStorage `gh_token`), `CartContext` (localStorage `gh_cart`)

## Personas
- Admin/Owner: menu catalogue, revenue dashboard, all orders
- Cashier/Staff: POS billing terminal + order queue only
- Guest/Customer: public storefront, cart, COD checkout, order tracking

## Implemented (2026-06)
- Public storefront `/` — hero, marquee, category filter, search, cart
- Checkout `/checkout` — COD order, 5% GST math, success screen + invoice PDF
- Track order `/track` — status timeline, items, invoice download
- Staff login `/login` — admin & cashier seeded, role-gated nav/routes
- POS `/admin/pos` — tap-to-bill, qty edit, customer/table/type/payment, generate bill, print/download invoice
- Orders `/admin/orders` — filters, status flow placed→preparing→ready→completed, cancel, invoice
- Dashboard `/admin/dashboard` — 6 KPI cards, 7-day revenue chart, best sellers
- Menu admin `/admin/menu` — create/edit/delete items, veg + availability flags
- Concurrency-safe order numbers (counters collection + retry), mobile responsive at 390px
- Verified: 18/18 backend pytest, 24/24 UI checks

## Implemented (iteration 2, 2026-06)
- Kitchen Order Ticket: 80mm KOT PDF `GET /api/kot/{order_no}` (staff auth), auto-printed on bill save (toggle in POS) + reprint from POS and each Orders card
- Day-End Report: `GET /api/reports/day-end` + `/api/reports/day-end.pdf` (admin only) — orders, cancellations, net sales, GST, gross, AOV, split by payment mode and channel, top 10 items; date picker + view/download panel on Dashboard
- Razorpay: full flow coded per playbook (`/api/payments/config`, `/api/payments/razorpay/order`, `/api/payments/razorpay/verify` with signature check) but DISABLED — `RAZORPAY_KEY_ID`/`RAZORPAY_KEY_SECRET` are empty in backend/.env, so checkout shows Card/UPI greyed out and COD stays default
- Verified: 30/30 backend pytest, all UI flows, no 390px overflow

## Implemented (iteration 3, 2026-06)
- Kitchen Display Screen `/kitchen` (any logged-in staff, bare full-screen layout): three live columns New → Cooking → Ready, 7s auto-polling, elapsed-minute badge that turns terracotta past 15 min, one-tap status advance; backed by `GET /api/kitchen/queue`
- Monthly GST Statement (admin only): `GET /api/reports/gst-monthly` + `/reports/gst-monthly.pdf` — month totals (orders, taxable value, GST payable, gross) plus a day-wise table, paginated in the PDF; panel with month picker on the Dashboard
- Razorpay left DISABLED at the user's request (keys skipped); COD is the default and Card/UPI is greyed out

## Implemented (iteration 4, 2026-06 — code quality)
- Memoized `AuthContext` / `CartContext` provider values (useCallback + useMemo), memoized `AdminLayout` role-filtered nav links
- Extracted `_pdf_head` / `_pdf_footer` / `_gst_monthly` helpers in server.py to remove duplicated PDF chrome
- Wired the Kitchen double-advance guard (`disabled={moving === o.id}` + early return) and linked all login/checkout labels to inputs via htmlFor/id/name
- Restored the "Payment: CASH ON DELIVERY" row on the order success card
- Note: auth tokens intentionally remain Bearer-in-localStorage (CORS is open with allow_credentials=False); moving to httpOnly cookies is deferred
- Verified: 40/40 backend pytest across iterations 4 and 5, PDF contents re-rendered and checked, rapid triple-click kitchen guard proven

## Backlog
- P0: Activate Razorpay by pasting Key ID + Key Secret into backend/.env (code already in place); consider webhook endpoint for async capture
- P1: Room-service billing tied to room numbers; table/floor map; KOT printing per kitchen station
- P1: Staff user management UI (create/disable cashiers)
- P2: Discounts/coupons, split bills, day-end Z-report export (CSV/PDF), delivery zone charges

## Next tasks
1. Razorpay checkout once keys are provided
2. Room-service / room-charge posting
3. Day-end sales report export
