# Auth Testing Playbook (cookie-based JWT)

Staff sign-in uses **httpOnly cookies** (`access_token` 15 min, `refresh_token` 7 days),
with an `Authorization: Bearer <token>` fallback still accepted for API/pytest clients.

## Step 1: MongoDB verification
```
mongosh
use test_database
db.users.find({}, {email:1, role:1}).pretty()
db.users.findOne({role: "admin"}, {password_hash: 1})
```
Expect: bcrypt hash starting with `$2b$`; unique index on `users.email`;
index on `login_attempts.identifier`.

## Step 2: Cookie flow with curl
```
API=$(grep REACT_APP_BACKEND_URL /app/frontend/.env | cut -d= -f2)
curl -c /tmp/cookies.txt -X POST "$API/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@grandhotel.com","password":"admin123"}'
cat /tmp/cookies.txt          # must contain access_token AND refresh_token, HttpOnly
curl -b /tmp/cookies.txt "$API/api/auth/me"
curl -b /tmp/cookies.txt -X POST "$API/api/auth/refresh"
curl -b /tmp/cookies.txt -X POST "$API/api/auth/logout" -i   # clears both cookies
```
- `/auth/login` returns `{ access_token, user }` and sets both cookies.
- `/auth/me` works with cookies only (no Authorization header).
- `/auth/me` also still works with `-H "Authorization: Bearer <access_token>"`.
- After logout, `/auth/me` with the same cookie jar returns 401.

## Step 3: Brute force protection
6 consecutive wrong passwords for the same email+IP must return 429 with a
"Too many failed attempts" message; a correct login clears the counter.

## Step 4: Roles
- `admin@grandhotel.com / admin123` → role `admin` (all routes)
- `cashier@grandhotel.com / cashier123` → role `staff` (403 on menu writes, day-end, gst-monthly)

## Step 5: Browser
The React app sends `withCredentials: true` on every request and stores **no token**
in localStorage — verify `localStorage.getItem('gh_token')` is null after login and
that a page reload keeps the session (cookie-based `/auth/me` restore).
