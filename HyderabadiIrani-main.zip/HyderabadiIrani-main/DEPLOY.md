# Deploying Hyderabadi Irani to Google Cloud Run

This app is two separate services — a FastAPI backend and a React frontend —
each deployed as its own Cloud Run service, plus a MongoDB database that
Cloud Run does not host for you.

## 0. One-time setup

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud services enable run.googleapis.com artifactregistry.googleapis.com \
    secretmanager.googleapis.com cloudbuild.googleapis.com
```

## 1. Database — MongoDB Atlas

Cloud Run is stateless; it does not include a database. The simplest option
is a free/shared **MongoDB Atlas** cluster (Atlas has a GCP-hosted region
option so latency to Cloud Run stays low):

1. Create a cluster at https://cloud.mongodb.com
2. Create a database user + password
3. Under Network Access, allow access from anywhere (`0.0.0.0/0`) — Cloud Run
   has no fixed outbound IP on the default network, so IP allow-listing isn't
   practical without a VPC connector + Cloud NAT (a later hardening step).
4. Copy the connection string, e.g.
   `mongodb+srv://user:pass@cluster0.xxxxx.mongodb.net`

## 2. Secrets

Create each secret once:

```bash
echo -n "mongodb+srv://user:pass@cluster0.xxxxx.mongodb.net" | gcloud secrets create MONGO_URL --data-file=-
echo -n "hyderabadi_irani" | gcloud secrets create DB_NAME --data-file=-
echo -n "$(openssl rand -hex 32)" | gcloud secrets create JWT_SECRET --data-file=-
echo -n "https://YOUR-FRONTEND-URL.a.run.app" | gcloud secrets create FRONTEND_URL --data-file=-
echo -n "admin@yourdomain.com" | gcloud secrets create ADMIN_EMAIL --data-file=-
echo -n "$(openssl rand -base64 18)" | gcloud secrets create ADMIN_PASSWORD --data-file=-
echo -n "staff@yourdomain.com" | gcloud secrets create STAFF_EMAIL --data-file=-
echo -n "$(openssl rand -base64 18)" | gcloud secrets create STAFF_PASSWORD --data-file=-
# Optional — leave unset (Razorpay disabled, COD-only) until you have real keys:
echo -n "rzp_live_xxxxxxxx" | gcloud secrets create RAZORPAY_KEY_ID --data-file=-
echo -n "your_key_secret" | gcloud secrets create RAZORPAY_KEY_SECRET --data-file=-
```

`FRONTEND_URL` must exactly match the deployed frontend's URL (or your custom
domain) — the backend's CORS check rejects requests from anything else.

**Save the generated `ADMIN_PASSWORD` / `STAFF_PASSWORD` somewhere safe** —
these are the login credentials for the site's staff/admin pages, created
automatically on first backend startup.

## 3. Deploy the backend

From `backend/`:

```bash
cd backend
gcloud run deploy hyderabadi-irani-api \
  --source . \
  --region asia-south1 \
  --allow-unauthenticated \
  --set-secrets MONGO_URL=MONGO_URL:latest,DB_NAME=DB_NAME:latest,JWT_SECRET=JWT_SECRET:latest,FRONTEND_URL=FRONTEND_URL:latest,ADMIN_EMAIL=ADMIN_EMAIL:latest,ADMIN_PASSWORD=ADMIN_PASSWORD:latest,STAFF_EMAIL=STAFF_EMAIL:latest,STAFF_PASSWORD=STAFF_PASSWORD:latest,RAZORPAY_KEY_ID=RAZORPAY_KEY_ID:latest,RAZORPAY_KEY_SECRET=RAZORPAY_KEY_SECRET:latest
```

Note the service URL it prints (e.g. `https://hyderabadi-irani-api-xxxxx.a.run.app`).
`--source .` builds the Dockerfile in this folder via Cloud Build automatically
— no local Docker required.

## 4. Deploy the frontend

The frontend needs the backend's URL baked in **at build time**
(`REACT_APP_API_URL` / `REACT_APP_BACKEND_URL` is a compile-time React env var, not something the
container reads at runtime). From `frontend/`:

```bash
cd ../frontend
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/hyderabadi-irani-web \
  --substitutions=_API_URL=https://hyderabadi-irani-api-826716276634.asia-south1.run.app \
  --config <(cat <<'EOF'
steps:
  - name: gcr.io/cloud-builders/docker
    args: ['build', '--build-arg', 'REACT_APP_API_URL=${_API_URL}', '--build-arg', 'REACT_APP_BACKEND_URL=${_API_URL}', '-t', 'gcr.io/$PROJECT_ID/hyderabadi-irani-web', '.']
images: ['gcr.io/$PROJECT_ID/hyderabadi-irani-web']
EOF
)

gcloud run deploy hyderabadi-irani-web \
  --image gcr.io/YOUR_PROJECT_ID/hyderabadi-irani-web \
  --region asia-south1 \
  --allow-unauthenticated
```

Note the frontend's URL it prints, then go back and update the `FRONTEND_URL`
secret to match it exactly, and redeploy the backend so CORS picks it up:

```bash
echo -n "https://hyderabadi-irani-web-xxxxx.a.run.app" | gcloud secrets versions add FRONTEND_URL --data-file=-
gcloud run services update hyderabadi-irani-api --region asia-south1
```

## 5. First login

Visit `https://your-frontend-url/login` and sign in with the `ADMIN_EMAIL`
/ `ADMIN_PASSWORD` you generated in step 2. The menu seeds itself with sample
dishes on first backend startup — edit/replace them from **Admin → Menu**.

## 6. Custom domain (optional)

```bash
gcloud run domain-mappings create --service hyderabadi-irani-web --domain www.yourdomain.com --region asia-south1
```
Follow the DNS records it gives you, then update `FRONTEND_URL` to the
custom domain and redeploy the backend again (step 4's last two commands).

## Notes / things to revisit later

- **Razorpay**: leave the two Razorpay secrets unset to launch cash-on-delivery-only;
  add real keys later and redeploy the backend to turn on online payment.
- **Scaling**: Cloud Run scales to zero by default — the first request after
  idle time will be slower (cold start, plus a MongoDB reconnect). If that's
  noticeable, set `--min-instances 1` on the backend service.
- **Reports at scale**: the dashboard/GST report endpoints currently cap at
  2,000–20,000 orders per query; fine at launch, revisit if order volume
  grows past that.
