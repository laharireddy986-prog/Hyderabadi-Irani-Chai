import asyncio
import random
from datetime import datetime, timedelta, timezone
from motor.motor_asyncio import AsyncIOMotorClient

# Connect to MongoDB
MONGO_URI = "mongodb://127.0.0.1:27017/hyderabadi_irani"

NAMES = [
  "Ramesh Kumar", "Priya Sharma", "Mohammed Ali", "Vikram Reddy", "Sneha Patel",
  "Anand Rao", "Kavitha Reddy", "Rajesh Verma", "Deepika Padukone", "Suresh Goud",
  "Lakshmi Narayana", "Venkatesh Rao", "Fatima Begum", "Syed Ahmed", "Rahul Verma",
  "Divya Spandana", "Arjun Reddy", "Manish Pandey", "Sravanthi Naidu", "Pradeep Kumar"
]

PHONES = [f"9876{random.randint(10000, 99999)}" for _ in range(20)]

STATUSES = ["placed", "preparing", "ready", "served", "completed", "completed", "completed", "cancelled"]
TYPES = ["dine-in", "dine-in", "takeaway", "delivery"]
PAYMENTS = ["cod", "upi", "razorpay"]
COUPONS = ["", "", "", "IRANI10", "FLAT50", "WELCOME20", "FREEJAMUN"]

async def seed():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client.get_default_database()
    
    # Get menu items
    menu_items = await db.menu.find({}).to_list(100)
    if not menu_items:
        print("No menu items found! Run uvicorn server first.")
        return

    print(f"Loaded {len(menu_items)} menu items. Seeding 100 mock orders...")
    
    orders_to_insert = []
    now = datetime.now(timezone.utc)
    
    for i in range(1, 101):
        order_no = f"GH260814-{i:04d}"
        cust_name = random.choice(NAMES)
        phone = random.choice(PHONES)
        order_type = random.choice(TYPES)
        table_no = f"T-{random.randint(1, 50):02d}" if order_type == "dine-in" else ""
        payment_mode = random.choice(PAYMENTS)
        status = random.choice(STATUSES)
        discount_code = random.choice(COUPONS)

        # 1 to 4 random menu items
        selected_items = random.sample(menu_items, random.randint(1, 4))
        line_items = []
        subtotal = 0.0
        
        for item in selected_items:
            qty = random.randint(1, 3)
            price = float(item["price"])
            subtotal += price * qty
            line_items.append({
                "item_id": str(item.get("_id", item.get("id"))),
                "name": item["name"],
                "price": price,
                "qty": qty
            })
            
        discount = 0.0
        if discount_code == "IRANI10":
            discount = round(subtotal * 0.10, 2)
        elif discount_code == "FLAT50" and subtotal >= 300:
            discount = 50.0
        elif discount_code == "WELCOME20":
            discount = round(subtotal * 0.20, 2)

        tax = round((subtotal - discount) * 0.05, 2)
        total = round(subtotal - discount + tax, 2)

        # Random timestamp over past 3 days
        time_offset_minutes = random.randint(0, 4320)
        created_at = (now - timedelta(minutes=time_offset_minutes)).isoformat()

        order_doc = {
            "order_no": order_no,
            "customer_name": cust_name,
            "phone": phone,
            "address": f"Table {table_no}" if table_no else "H.No 12-4, Rampally Main Road, Hyderabad",
            "order_type": order_type,
            "table_no": table_no,
            "payment_mode": payment_mode,
            "status": status,
            "notes": "Less spicy please" if random.random() > 0.7 else "",
            "items": line_items,
            "subtotal": subtotal,
            "discount_code": discount_code,
            "discount": discount,
            "tax": tax,
            "total": total,
            "created_at": created_at,
            "source": "online" if order_type == "delivery" else "pos"
        }
        orders_to_insert.append(order_doc)

    await db.orders.delete_many({}) # Clear previous mock
    await db.orders.insert_many(orders_to_insert)
    print(f"Successfully inserted {len(orders_to_insert)} mock orders into MongoDB!")

if __name__ == "__main__":
    asyncio.run(seed())
