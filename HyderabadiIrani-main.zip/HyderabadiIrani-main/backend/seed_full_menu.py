import os
import json
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ.get("MONGO_URL", "mongodb+srv://digitalfoxagencycare_db_user:9701463241@cluster0.7rbuevx.mongodb.net/?appName=Cluster0")
DB_NAME = os.environ.get("DB_NAME", "hyderabadi_irani")

# Category fallback images from GCS or curated food assets
CATEGORY_DEFAULT_IMAGES = {
    "SOUPS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/001_veg_hot_sour_soup.webp",
    "FRIED RICE": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/023_chicken_fried_rice.webp",
    "NOODLES": "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=800&auto=format&fit=crop&q=80",
    "STARTERS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/068_chicken_65.webp",
    "CURRYS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/103_butter_chicken_boneless.webp",
    "SEA FOOD": "https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?w=800&auto=format&fit=crop&q=80",
    "BIRYANIS": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/130_chicken_dum_biryani.webp",
    "COMBO PACK": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/130_chicken_dum_biryani.webp",
    "TANDOORI KEBABS": "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
    "ROTIS": "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=800&auto=format&fit=crop&q=80",
    "SHAWARMA": "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/166_chicken_shawarma.webp",
    "TEA": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
}

TEA_ITEMS = [
    {"name": "Hyderabadi Irani Chai", "category": "Tea", "section": "TEA", "price": 20.0, "veg": True, "station": "tea", "available": True, "description": "Authentic slow-dum brewed rich Hyderabadi Irani Chai.", "image_url": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80"},
    {"name": "Special Irani Chai (Khada Chammach)", "category": "Tea", "section": "TEA", "price": 25.0, "veg": True, "station": "tea", "available": True, "description": "Extra rich cream & sweetened special Irani Chai.", "image_url": "https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop&q=80"},
    {"name": "Osmania Biscuits (Plate)", "category": "Tea", "section": "TEA", "price": 20.0, "veg": True, "station": "tea", "available": True, "description": "Traditional melt-in-mouth sweet & salty Osmania biscuits.", "image_url": "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&auto=format&fit=crop&q=80"},
    {"name": "Bun Maska", "category": "Tea", "section": "TEA", "price": 35.0, "veg": True, "station": "tea", "available": True, "description": "Fresh soft bun loaded with maska butter.", "image_url": "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=80"},
    {"name": "Ginger Irani Chai", "category": "Tea", "section": "TEA", "price": 25.0, "veg": True, "station": "tea", "available": True, "description": "Fresh crushed ginger infused Irani milk tea.", "image_url": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80"},
    {"name": "Lemon Tea", "category": "Tea", "section": "TEA", "price": 20.0, "veg": True, "station": "tea", "available": True, "description": "Refreshing hot brewed black tea with fresh lemon & honey.", "image_url": "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=800&auto=format&fit=crop&q=80"},
    {"name": "Filter Coffee", "category": "Tea", "section": "TEA", "price": 30.0, "veg": True, "station": "tea", "available": True, "description": "Authentic South Indian aromatic filter coffee.", "image_url": "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80"},
    {"name": "Badam Milk (Hot / Cold)", "category": "Tea", "section": "TEA", "price": 40.0, "veg": True, "station": "tea", "available": True, "description": "Rich saffron badam infused thick milk.", "image_url": "https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop&q=80"},
]

async def seed_all_menu():
    print(f"Connecting to MongoDB at {MONGO_URL[:30]}...")
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    script_dir = os.path.dirname(__file__)
    json_path = os.path.join(script_dir, "..", "scripts", "menu_items.json")
    prog_path = os.path.join(script_dir, "..", "scripts", "generation_progress.json")
    
    with open(json_path, "r", encoding="utf-8") as f:
        sheet_items = json.load(f)
        
    progress = {}
    if os.path.exists(prog_path):
        with open(prog_path, "r", encoding="utf-8") as f:
            progress = json.load(f)
            
    final_menu = []
    
    for t in TEA_ITEMS:
        final_menu.append(t)
        
    for it in sheet_items:
        slug = it["slug"]
        section = it["section"]
        
        if slug in progress and progress[slug].get("status") == "uploaded":
            img_url = progress[slug]["url"]
        else:
            img_url = CATEGORY_DEFAULT_IMAGES.get(section, CATEGORY_DEFAULT_IMAGES["STARTERS"])
            
        category_name = it["section"].title() if it["section"] else "Main Menu"
        
        item_doc = {
            "name": it["name"],
            "slug": slug,
            "section": it["section"],
            "category": category_name,
            "sub_category": it["category"],
            "price": it["price"],
            "price_half": it["price_half"],
            "price_full": it["price_full"],
            "veg": it["is_veg"],
            "station": "kitchen",
            "available": True,
            "description": f"Authentic {it['name']} prepared fresh with premium ingredients & rich traditional spices.",
            "image_url": img_url
        }
        final_menu.append(item_doc)
        
    print(f"Prepared {len(final_menu)} total menu items.")
    await db.menu.delete_many({})
    res = await db.menu.insert_many(final_menu)
    print(f"Successfully inserted {len(res.inserted_ids)} items into MongoDB `menu` collection!")

if __name__ == "__main__":
    asyncio.run(seed_all_menu())
