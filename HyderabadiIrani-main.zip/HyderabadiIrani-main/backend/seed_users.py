"""
Seed and initialize database users, menu items, and coupons in MongoDB.
Can be executed locally or in container environment.

Usage:
    python seed_users.py
"""

import os
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv
import bcrypt
from motor.motor_asyncio import AsyncIOMotorClient

# Load environment variables
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.environ.get("DB_NAME", "hyderabadi_irani")

ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@hyderabadiirani.com").lower().strip()
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123").strip()

STAFF_EMAIL = os.environ.get("STAFF_EMAIL", "staff@hyderabadiirani.com").lower().strip()
STAFF_PASSWORD = os.environ.get("STAFF_PASSWORD", "9701463241").strip()

DRIVER_EMAIL = os.environ.get("DRIVER_EMAIL", "driver@hyderabadiirani.com").lower().strip()
DRIVER_PASSWORD = os.environ.get("DRIVER_PASSWORD", "9701463241").strip()


def hash_password(pwd: str) -> str:
    return bcrypt.hashpw(pwd.encode(), bcrypt.gensalt()).decode()


SEED_MENU = [
    ("Butter Chicken", "Slow-cooked tandoori chicken in a silky tomato-cashew gravy", 480, "Main Course", False,
     "https://images.unsplash.com/photo-1514326640560-7d063ef2aed5?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"),
    ("Paneer Tikka Masala", "Char-grilled cottage cheese in spiced onion gravy", 420, "Main Course", True,
     "https://images.pexels.com/photos/1327393/pexels-photo-1327393.jpeg?auto=compress&cs=tinysrgb&w=800"),
    ("Grand Signature Burger", "Double patty, aged cheddar, house pickles, brioche bun", 360, "Fast Food", False,
     "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"),
    ("Truffle Mushroom Burger", "Portobello, truffle aioli, rocket leaves", 340, "Fast Food", True,
     "https://images.pexels.com/photos/15010285/pexels-photo-15010285.jpeg?auto=compress&cs=tinysrgb&w=800"),
    ("Dal Makhani", "Black lentils simmered overnight with butter and cream", 290, "Main Course", True, ""),
    ("Tandoori Roti", "Whole wheat bread from the clay oven", 45, "Breads", True, ""),
    ("Garlic Naan", "Leavened bread with roasted garlic and coriander", 70, "Breads", True, ""),
    ("Hyderabadi Biryani", "Aged basmati, saffron, slow-dum cooked", 520, "Rice", False, ""),
    ("Jeera Rice", "Basmati tempered with cumin and ghee", 220, "Rice", True, ""),
    ("Masala Papad", "Crisp papad, onion, tomato, chaat masala", 90, "Starters", True, ""),
    ("Chicken 65", "Fiery South-Indian fried chicken", 380, "Starters", False, ""),
    ("Gulab Jamun", "Warm milk dumplings in cardamom syrup", 160, "Desserts", True, ""),
    ("Tiramisu", "Espresso-soaked ladyfingers, mascarpone cream", 260, "Desserts", True, ""),
    ("Masala Chai", "Brewed with ginger, cardamom and fresh milk", 80, "Beverages", True, ""),
    ("Fresh Lime Soda", "Sweet, salted or mixed", 110, "Beverages", True, ""),
]

SEED_COUPONS = [
    {"code": "IRANI10", "discount_type": "percent", "discount_value": 10.0, "min_order": 200.0, "active": True},
    {"code": "FLAT50", "discount_type": "fixed", "discount_value": 50.0, "min_order": 300.0, "active": True},
    {"code": "WELCOME20", "discount_type": "percent", "discount_value": 20.0, "min_order": 500.0, "active": True},
]


async def seed():
    print(f"Connecting to MongoDB at {MONGO_URL} (Database: {DB_NAME})...")
    client = AsyncIOMotorClient(MONGO_URL, serverSelectionTimeoutMS=5000)
    db = client[DB_NAME]

    # Clear previous lockout attempts
    await db.login_attempts.delete_many({})
    print("Cleared login lockout records.")

    # Create Indexes
    try:
        await db.users.create_index("email", unique=True)
        await db.orders.create_index("order_no", unique=True)
    except Exception as e:
        print(f"Index creation notice: {e}")

    # Seed Admin User
    admin_user = await db.users.find_one({"email": ADMIN_EMAIL})
    admin_hash = hash_password(ADMIN_PASSWORD)
    if admin_user:
        await db.users.update_one(
            {"_id": admin_user["_id"]},
            {"$set": {"password_hash": admin_hash, "role": "admin", "active": True}}
        )
        print(f"✓ Updated existing Admin user: {ADMIN_EMAIL} (Password: {ADMIN_PASSWORD})")
    else:
        await db.users.insert_one({
            "email": ADMIN_EMAIL,
            "password_hash": admin_hash,
            "name": "Hotel Admin",
            "role": "admin",
            "active": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        print(f"✓ Created Admin user: {ADMIN_EMAIL} (Password: {ADMIN_PASSWORD})")

    # Seed Staff User
    staff_user = await db.users.find_one({"email": STAFF_EMAIL})
    staff_hash = hash_password(STAFF_PASSWORD)
    if staff_user:
        await db.users.update_one(
            {"_id": staff_user["_id"]},
            {"$set": {"password_hash": staff_hash, "role": "staff", "active": True}}
        )
        print(f"✓ Updated Staff user: {STAFF_EMAIL} (Password: {STAFF_PASSWORD})")
    else:
        await db.users.insert_one({
            "email": STAFF_EMAIL,
            "password_hash": staff_hash,
            "name": "Front Desk Cashier",
            "role": "staff",
            "active": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        print(f"✓ Created Staff user: {STAFF_EMAIL} (Password: {STAFF_PASSWORD})")

    # Seed Driver User
    driver_user = await db.users.find_one({"email": DRIVER_EMAIL})
    driver_hash = hash_password(DRIVER_PASSWORD)
    if driver_user:
        await db.users.update_one(
            {"_id": driver_user["_id"]},
            {"$set": {"password_hash": driver_hash, "role": "delivery", "name": "Hyderabadi Irani Delivery Partner", "active": True}}
        )
        print(f"✓ Updated Driver user: {DRIVER_EMAIL} (Password: {DRIVER_PASSWORD})")
    else:
        await db.users.insert_one({
            "email": DRIVER_EMAIL,
            "password_hash": driver_hash,
            "name": "Hyderabadi Irani Delivery Partner",
            "role": "delivery",
            "active": True,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        print(f"✓ Created Driver user: {DRIVER_EMAIL} (Password: {DRIVER_PASSWORD})")

    # Seed Menu Items
    menu_count = await db.menu_items.count_documents({})
    if menu_count == 0:
        await db.menu_items.insert_many([
            {"name": n, "description": d, "price": float(p), "category": c, "veg": v,
             "image_url": img, "available": True, "station": "beverage" if c == "Beverages" else "kitchen"}
            for n, d, p, c, v, img in SEED_MENU
        ])
        print(f"✓ Seeded {len(SEED_MENU)} menu items.")
    else:
        print(f"✓ Menu items already present ({menu_count} items).")

    # Seed Coupons
    coupon_count = await db.coupons.count_documents({})
    if coupon_count == 0:
        await db.coupons.insert_many(SEED_COUPONS)
        print(f"✓ Seeded {len(SEED_COUPONS)} coupons.")
    else:
        print(f"✓ Coupons already present ({coupon_count} coupons).")

    print("\n=======================================================")
    print("Database seeding completed successfully!")
    print(f"Admin Login   : {ADMIN_EMAIL} / {ADMIN_PASSWORD} (or admin123)")
    print(f"Cashier Login : {STAFF_EMAIL} / {STAFF_PASSWORD}")
    print(f"Driver Login  : {DRIVER_EMAIL} / {DRIVER_PASSWORD}")
    print("=======================================================\n")

    client.close()


if __name__ == "__main__":
    asyncio.run(seed())
