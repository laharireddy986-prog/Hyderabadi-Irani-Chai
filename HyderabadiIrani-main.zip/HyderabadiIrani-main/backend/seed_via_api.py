import requests
import random
from datetime import datetime, timedelta, timezone

API_BASE = "http://127.0.0.1:8000/api"

NAMES = [
  "Ramesh Kumar", "Priya Sharma", "Mohammed Ali", "Vikram Reddy", "Sneha Patel",
  "Anand Rao", "Kavitha Reddy", "Rajesh Verma", "Deepika Padukone", "Suresh Goud",
  "Lakshmi Narayana", "Venkatesh Rao", "Fatima Begum", "Syed Ahmed", "Rahul Verma",
  "Divya Spandana", "Arjun Reddy", "Manish Pandey", "Sravanthi Naidu", "Pradeep Kumar"
]

PHONES = [f"9876{random.randint(10000, 99999)}" for _ in range(20)]
STATUSES = ["placed", "preparing", "ready", "served", "completed", "completed", "completed"]
TYPES = ["dine-in", "dine-in", "takeaway", "delivery"]
PAYMENTS = ["cod", "upi", "razorpay"]
COUPONS = ["", "", "", "IRANI10", "FLAT50", "WELCOME20", "FREEJAMUN"]

def main():
    r_menu = requests.get(f"{API_BASE}/menu")
    if r_menu.status_code != 200:
        print("Backend server not responding properly.")
        return
    
    menu = r_menu.json()
    print(f"Loaded {len(menu)} menu items from server. Generating 100 mock orders...")
    
    r_login = requests.post(f"{API_BASE}/auth/login", json={'email': 'admin@hyderabadiirani.com', 'password': '9701463241'}).json()
    token = r_login.get('access_token')
    headers = {'Authorization': f'Bearer {token}'}

    success_count = 0
    now = datetime.now(timezone.utc)

    for i in range(1, 101):
        cust_name = random.choice(NAMES)
        phone = random.choice(PHONES)
        order_type = random.choice(TYPES)
        table_no = f"T-{random.randint(1, 50):02d}" if order_type == "dine-in" else ""
        payment_mode = random.choice(PAYMENTS)
        status = random.choice(STATUSES)
        discount_code = random.choice(COUPONS)

        selected_items = random.sample(menu, random.randint(1, 4))
        line_items = []
        subtotal = 0.0
        
        for item in selected_items:
            qty = random.randint(1, 3)
            price = float(item["price"])
            subtotal += price * qty
            line_items.append({
                "item_id": item["id"],
                "name": item["name"],
                "price": price,
                "qty": qty
            })

        order_payload = {
            "customer_name": cust_name,
            "phone": phone,
            "address": f"Table {table_no}" if table_no else "H.No 12-4, Rampally Main Road, Hyderabad",
            "order_type": order_type,
            "table_no": table_no,
            "payment_mode": payment_mode,
            "discount_code": discount_code,
            "items": line_items
        }

        r_create = requests.post(f"{API_BASE}/public/orders", json=order_payload)
        if r_create.status_code == 200:
            order_data = r_create.json()
            order_no = order_data["order_no"]
            
            # If status needs update
            if status != "placed":
                requests.put(f"{API_BASE}/orders/{order_data['id']}/status", json={"status": status}, headers=headers)

            success_count += 1

    print(f"DONE! Successfully generated and seeded {success_count} mock orders into the backend server!")

if __name__ == "__main__":
    main()
