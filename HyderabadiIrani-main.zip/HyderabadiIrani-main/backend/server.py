from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import os
import io
import re
import csv
import json
import math
import sys
import shutil
import subprocess
import asyncio
import logging
import uuid
from datetime import datetime, timezone, timedelta
from typing import List, Optional, Annotated, Any, Dict

import secrets

import bcrypt
import jwt
import razorpay
from bson import ObjectId
from bson.errors import InvalidId
from pymongo import ReturnDocument
from fastapi import FastAPI, APIRouter, HTTPException, Depends, Request, Response, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, BeforeValidator, ConfigDict, EmailStr, Field
from starlette.middleware.cors import CORSMiddleware
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from PIL import Image

logger = logging.getLogger("hotelpos")
logging.basicConfig(level=logging.INFO)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
MENU_UPLOAD_DIR = os.path.join(UPLOAD_DIR, "menu")
os.makedirs(MENU_UPLOAD_DIR, exist_ok=True)

mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
use_mock = mongo_url.startswith("mongomock://")

if not use_mock:
    try:
        client = AsyncIOMotorClient(
            mongo_url,
            serverSelectionTimeoutMS=10000,
            connectTimeoutMS=10000,
            socketTimeoutMS=20000,
            maxPoolSize=50,
            minPoolSize=2,
            retryWrites=True,
        )
    except Exception:
        use_mock = True

if use_mock:
    try:
        from mongomock_motor import AsyncMongoMockClient
        client = AsyncMongoMockClient()
    except ImportError:
        client = AsyncIOMotorClient("mongodb://localhost:27017")

db = client[os.environ.get('DB_NAME', 'hyderabadi_irani')]

app = FastAPI(title="Hyderabadi Irani Billing & Ordering")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://127.0.0.1:5173",
        "https://hyderabadiirani.net",
        "https://www.hyderabadiirani.net",
        "https://hyderabadi-irani-api-826716276634.asia-south1.run.app",
        "capacitor://localhost",
        "http://localhost",
        "https://localhost",
    ],
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|.*\.hyderabadiirani\.net|.*\.run\.app)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

api = APIRouter(prefix="/api")
bearer = HTTPBearer(auto_error=False)

JWT_ALG = "HS256"
JWT_SECRET = os.environ.get("JWT_SECRET", "supersecretjwtkeyreplaceinproduction9701463241")
GST_RATE = 0.05

# Store location & delivery radius — must match frontend/mobile-app STORE_LOCATION
# and MAX_DELIVERY_DISTANCE_KM constants (deliveryTerms.js), so the client-side
# checks there aren't the only line of defense against an out-of-radius order.
STORE_LAT = 17.4812
STORE_LNG = 78.6385
MAX_DELIVERY_DISTANCE_KM = 5.0
COD_DISABLED_START_HOUR = 22  # 10:00 PM IST
COD_DISABLED_END_HOUR = 6     # 6:00 AM IST


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


# IST Timezone (UTC+5:30) and 4:00 AM Daily Billing Cycle
IST = timezone(timedelta(hours=5, minutes=30))


def get_business_date():
    """
    Returns current business date in IST.
    Daily billing cycle runs from 04:00 AM to 03:59:59 AM next day.
    If current IST time is before 04:00 AM, the business date is the previous calendar day.
    """
    now_ist = datetime.now(IST)
    if now_ist.hour < 4:
        return (now_ist - timedelta(days=1)).date()
    return now_ist.date()


def get_business_date_str() -> str:
    """
    Returns YYMMDD string (e.g. '260817') for the current restaurant business date.
    """
    return get_business_date().strftime("%y%m%d")


def oid_str(v: Any) -> str:
    return str(v)


def parse_object_id(id_str: str) -> ObjectId:
    try:
        return ObjectId(id_str)
    except (InvalidId, TypeError):
        raise HTTPException(404, "Not found")


def norm_phone(p: str) -> str:
    return "".join(ch for ch in (p or "") if ch.isdigit())[-10:]


PyObjectId = Annotated[str, BeforeValidator(oid_str)]


class BaseDocument(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")
    id: Optional[PyObjectId] = Field(default=None, validation_alias="_id", serialization_alias="id")

    def to_mongo(self) -> dict:
        d = self.model_dump(exclude_none=True)
        d.pop("id", None)
        return d

    @classmethod
    def from_mongo(cls, doc: dict):
        return cls.model_validate(doc)


# ---------- Models ----------
class User(BaseDocument):
    name: str
    email: str
    role: str = "staff"


class CustomerAddress(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    label: str = "Home"  # Home | Work | Other
    address: str
    flat_landmark: Optional[str] = ""
    lat: Optional[float] = None
    lng: Optional[float] = None
    is_default: bool = False


class Customer(BaseDocument):
    name: str
    phone: str
    email: Optional[str] = ""
    addresses: List[CustomerAddress] = []
    loyalty_points: int = 0
    orders_count: int = 0
    active: bool = True
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class CustomerRegisterIn(BaseModel):
    name: str
    phone: str
    password: str
    email: Optional[str] = ""


class CustomerLoginIn(BaseModel):
    identifier: str
    password: str


class CustomerResetPasswordIn(BaseModel):
    phone: str
    new_password: str
    otp: str
    name: Optional[str] = None


class CustomerSendOtpIn(BaseModel):
    phone: str


class CustomerVerifyOtpIn(BaseModel):
    phone: str
    otp: str
    name: Optional[str] = None


class DeviceTokenRegisterIn(BaseModel):
    token: str
    phone: Optional[str] = None
    role: str = "customer"
    platform: str = "android"


class DeviceTokenUnregisterIn(BaseModel):
    token: str


class CustomerAddressIn(BaseModel):
    label: str = "Home"
    address: str
    flat_landmark: Optional[str] = ""
    lat: Optional[float] = None
    lng: Optional[float] = None
    is_default: bool = False


class CustomerProfileUpdateIn(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None


class ImageUploadIn(BaseModel):
    image_base64: str
    filename: Optional[str] = None
    item_name: Optional[str] = None


class MenuItem(BaseDocument):
    name: str
    description: str = ""
    price: float
    price_half: Optional[float] = None
    price_full: Optional[float] = None
    has_variants: bool = False
    variants: List[Dict[str, Any]] = []
    suggested_items: List[str] = []
    category: str
    image_url: str = ""
    station: str = "kitchen"  # kitchen | beverage | bakery
    veg: bool = True
    available: bool = True


class MenuItemIn(BaseModel):
    name: str
    description: str = ""
    price: float
    price_half: Optional[float] = None
    price_full: Optional[float] = None
    has_variants: bool = False
    variants: Optional[List[Dict[str, Any]]] = []
    suggested_items: Optional[List[str]] = []
    category: str
    station: str = "kitchen"
    image_url: str = ""
    veg: bool = True
    available: bool = True


class CategoryOrderIn(BaseModel):
    categories: List[str]


class BulkPriceAdjustIn(BaseModel):
    category: Optional[str] = None
    delta: float = 0.0
    percent: float = 0.0


class ItemAvailabilityIn(BaseModel):
    available: bool


class CategoryAvailabilityIn(BaseModel):
    available: bool


class StoreStatusIn(BaseModel):
    is_online_open: bool
    notice: Optional[str] = ""


class BulkImportIn(BaseModel):
    items: List[MenuItemIn]
    replace_all: bool = False


class OrderLine(BaseModel):
    item_id: str
    name: str
    variant: Optional[str] = None
    price: float
    qty: int
    station: str = "kitchen"
    notes: str = ""


class OrderIn(BaseModel):
    customer_name: str
    phone: str = ""
    address: str = ""
    table_no: str = ""
    order_type: str = "dine-in"  # dine-in | takeaway | delivery
    payment_mode: str = "cash"   # cash | card | upi | cod | razorpay
    items: List[OrderLine]
    notes: str = ""
    discount_code: str = ""
    discount: float = 0.0
    delivery_fee: float = 0.0
    distance_km: Optional[float] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    offline_no: Optional[str] = None
    points_redeemed: int = 0


class Order(BaseDocument):
    order_no: str
    customer_name: str
    phone: str = ""
    address: str = ""
    table_no: str = ""
    order_type: str
    payment_mode: str
    source: str = "pos"
    items: List[OrderLine]
    notes: str = ""
    subtotal: float
    discount_code: str = ""
    discount: float = 0.0
    points_redeemed: int = 0
    points_discount: float = 0.0
    delivery_fee: float = 0.0
    distance_km: Optional[float] = None
    tax: float
    total: float
    loyalty_points_earned: int = 0
    status: str = "placed"
    paid: bool = False
    created_at: str
    lat: Optional[float] = None
    lng: Optional[float] = None
    offline_no: Optional[str] = None
    driver_id: Optional[str] = None
    driver_name: Optional[str] = None
    driver_phone: Optional[str] = None
    driver_lat: Optional[float] = None
    driver_lng: Optional[float] = None


class DriverLocationIn(BaseModel):
    lat: float
    lng: float
    speed: Optional[float] = None
    heading: Optional[float] = None
    battery: Optional[int] = None
    status: Optional[str] = "online"  # "online" | "out_for_delivery" | "offline"
    active_order_id: Optional[str] = None


class CouponIn(BaseModel):
    code: str
    title: str = ""
    description: str = ""
    discount_type: str = "percent"  # percent | fixed | freebie
    discount_value: float = 0.0
    scope: str = "cart"            # cart | item | category
    target_ids: List[str] = Field(default_factory=list)
    channel: str = "both"          # both | online | pos
    min_order: float = 0.0
    max_discount: Optional[float] = None
    freebie_item_id: Optional[str] = None
    freebie_item_name: Optional[str] = None
    active: bool = True


class Coupon(BaseDocument):
    code: str
    title: str = ""
    description: str = ""
    discount_type: str = "percent"
    discount_value: float = 0.0
    scope: str = "cart"
    target_ids: List[str] = Field(default_factory=list)
    channel: str = "both"
    min_order: float = 0.0
    max_discount: Optional[float] = None
    freebie_item_id: Optional[str] = None
    freebie_item_name: Optional[str] = None
    active: bool = True


class UserCreateIn(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str = "staff"  # admin | staff | kitchen | delivery
    active: bool = True


class UserUpdateIn(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    role: Optional[str] = None
    active: Optional[bool] = None


class StatusIn(BaseModel):
    status: str


class LoginIn(BaseModel):
    email: EmailStr
    password: str


ACCESS_TTL = timedelta(days=30)
REFRESH_TTL = timedelta(days=90)
MAX_FAILED_LOGINS = 5
LOCKOUT = timedelta(minutes=15)


# ---------- Auth ----------
def hash_password(p: str) -> str:
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()


def verify_password(p: str, h: str) -> bool:
    return bcrypt.checkpw(p.encode(), h.encode())


def create_access_token(uid: str, email: str, role: str, ver: int = 0) -> str:
    payload = {"sub": uid, "email": email, "role": role, "type": "access", "ver": ver,
               "exp": datetime.now(timezone.utc) + ACCESS_TTL}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def create_refresh_token(uid: str, ver: int = 0) -> str:
    payload = {"sub": uid, "type": "refresh", "ver": ver, "exp": datetime.now(timezone.utc) + REFRESH_TTL}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def new_csrf_token() -> str:
    return secrets.token_hex(16)


def set_auth_cookies(response: Response, access: str, refresh: Optional[str] = None, csrf: Optional[str] = None):
    response.set_cookie("access_token", access, httponly=True, secure=True, samesite="none",
                        max_age=int(ACCESS_TTL.total_seconds()), path="/")
    if refresh:
        response.set_cookie("refresh_token", refresh, httponly=True, secure=True, samesite="none",
                            max_age=int(REFRESH_TTL.total_seconds()), path="/")
    if csrf:
        response.set_cookie("csrf_token", csrf, httponly=False, secure=True, samesite="none",
                            max_age=int(REFRESH_TTL.total_seconds()), path="/")


async def verify_csrf(request: Request):
    """Double-submit CSRF check. Only applies to cookie-based sessions; bearer-token
    callers (no cookie involved) aren't vulnerable to cross-site form/script submission."""
    if request.headers.get("authorization"):
        return
    if not request.cookies.get("access_token"):
        return
    cookie_token = request.cookies.get("csrf_token")
    header_token = request.headers.get("x-csrf-token")
    if not cookie_token or not header_token or cookie_token != header_token:
        raise HTTPException(403, "CSRF validation failed")


def read_token(request: Request, cred: Optional[HTTPAuthorizationCredentials], cookie: str) -> Optional[str]:
    token = request.cookies.get(cookie)
    if not token and cred is not None:
        token = cred.credentials
    return token


async def get_current_user(request: Request,
                           cred: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> User:
    token = read_token(request, cred, "access_token")
    if not token:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")
    if payload.get("type") != "access":
        raise HTTPException(401, "Invalid token type")
    doc = await db.users.find_one({"_id": parse_object_id(payload["sub"])})
    if not doc:
        raise HTTPException(401, "User not found")
    if payload.get("ver", 0) != doc.get("token_version", 0):
        raise HTTPException(401, "Session revoked, please sign in again")
    return User.from_mongo(doc)


async def get_optional_user(request: Request,
                            cred: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> Optional[User]:
    token = read_token(request, cred, "access_token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.InvalidTokenError:
        return None
    if payload.get("type") != "access":
        return None
    doc = await db.users.find_one({"_id": parse_object_id(payload["sub"])})
    if not doc or payload.get("ver", 0) != doc.get("token_version", 0):
        return None
    return User.from_mongo(doc)


async def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "Admin access required")
    return user


def require_role(*roles: str):
    async def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(403, "Insufficient permissions")
        return user
    return checker


async def _check_lockout(identifier: str):
    rec = await db.login_attempts.find_one({"identifier": identifier})
    if not rec or rec.get("count", 0) < MAX_FAILED_LOGINS:
        return
    last = datetime.fromisoformat(rec["last_attempt"])
    if datetime.now(timezone.utc) - last < LOCKOUT:
        raise HTTPException(429, "Too many failed attempts. Please try again in 15 minutes.")
    await db.login_attempts.delete_one({"identifier": identifier})


@api.post("/auth/login")
async def login(body: LoginIn, request: Request, response: Response):
    email = body.email.lower().strip()
    pwd = body.password

    await _check_lockout(email)

    doc = await db.users.find_one({"email": email})
    valid = bool(doc) and bool(doc.get("password_hash")) and verify_password(pwd, doc["password_hash"])
    valid = valid and doc.get("active", True)

    if not valid or not doc:
        await db.login_attempts.update_one(
            {"identifier": email},
            {"$inc": {"count": 1}, "$set": {"last_attempt": datetime.now(timezone.utc).isoformat()}},
            upsert=True)
        raise HTTPException(401, "Invalid email or password")

    await db.login_attempts.delete_one({"identifier": email})
    user = User.from_mongo(doc)
    ver = doc.get("token_version", 0)
    access = create_access_token(user.id, user.email, user.role, ver)
    set_auth_cookies(response, access, create_refresh_token(user.id, ver), new_csrf_token())
    return {"access_token": access, "user": user}


@api.post("/auth/refresh")
async def refresh_session(request: Request, response: Response,
                          cred: Optional[HTTPAuthorizationCredentials] = Depends(bearer)):
    token = read_token(request, cred, "refresh_token")
    if not token:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Session expired, please sign in again")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")
    if payload.get("type") != "refresh":
        raise HTTPException(401, "Invalid token type")
    doc = await db.users.find_one({"_id": parse_object_id(payload["sub"])})
    if not doc:
        raise HTTPException(401, "User not found")
    if payload.get("ver", 0) != doc.get("token_version", 0):
        raise HTTPException(401, "Session revoked, please sign in again")
    user = User.from_mongo(doc)
    access = create_access_token(user.id, user.email, user.role, doc.get("token_version", 0))
    set_auth_cookies(response, access)
    return {"access_token": access, "user": user}


@api.get("/auth/me", response_model=User)
async def me(user: User = Depends(get_current_user)):
    return user


@api.post("/auth/logout")
async def logout(request: Request, response: Response):
    for cookie_name in ("access_token", "refresh_token"):
        token = request.cookies.get(cookie_name)
        if not token:
            continue
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG],
                                 options={"verify_exp": False})
            await db.users.update_one({"_id": parse_object_id(payload["sub"])},
                                      {"$inc": {"token_version": 1}})
            break
        except (jwt.InvalidTokenError, HTTPException):
            continue
    response.delete_cookie("access_token", path="/", samesite="none", secure=True)
    response.delete_cookie("refresh_token", path="/", samesite="none", secure=True)
    response.delete_cookie("csrf_token", path="/", samesite="none", secure=True)
    return {"ok": True}


# ---------- Customer Authentication & Profile ----------
async def get_current_customer(
    request: Request,
    cred: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
) -> Customer:
    # 1. Header x-customer-token
    raw_header = request.headers.get("x-customer-token", "")
    token = raw_header.replace("Bearer ", "").replace("bearer ", "").strip() if raw_header else None
    # 2. Authorization header fallback
    if not token and cred is not None:
        token = cred.credentials
    # 3. Cookie fallback
    if not token:
        token = request.cookies.get("customer_token")

    if not token:
        raise HTTPException(401, "Customer login required")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Session expired, please sign in again")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid customer token")

    if payload.get("role") != "customer":
        raise HTTPException(401, "Invalid token role")
    doc = await db.customers.find_one({"_id": parse_object_id(payload["sub"])})
    if not doc:
        raise HTTPException(401, "Customer account not found")
    return Customer.from_mongo(doc)


async def get_optional_customer(
    request: Request,
    cred: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
) -> Optional[Customer]:
    raw_header = request.headers.get("x-customer-token", "")
    token = raw_header.replace("Bearer ", "").replace("bearer ", "").strip() if raw_header else None
    if not token and cred is not None:
        token = cred.credentials
    if not token:
        token = request.cookies.get("customer_token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
        if payload.get("role") != "customer":
            return None
        doc = await db.customers.find_one({"_id": parse_object_id(payload["sub"])})
        if not doc:
            return None
        return Customer.from_mongo(doc)
    except Exception:
        return None


# ---------- OTP Customer Authentication (Phone Verification) ----------
OTP_COOLDOWN_SECONDS = 45
OTP_EXPIRES_MINUTES = 5
MAX_OTP_ATTEMPTS = 3


@api.post("/customer/auth/send-otp")
async def customer_send_otp(body: CustomerSendOtpIn):
    raw_phone = (body.phone or "").strip()
    np = norm_phone(raw_phone)
    if len(np) != 10 or not np.isdigit():
        raise HTTPException(400, "Please enter a valid 10-digit Indian mobile number")

    now = datetime.now(timezone.utc)

    # Check cooldown / rate limit (45s)
    existing = await db.otp_verifications.find_one({"phone": np})
    if existing:
        created_str = existing.get("created_at")
        if created_str:
            try:
                created_at = datetime.fromisoformat(created_str)
                elapsed = (now - created_at).total_seconds()
                if elapsed < OTP_COOLDOWN_SECONDS:
                    remaining = int(OTP_COOLDOWN_SECONDS - elapsed)
                    raise HTTPException(429, f"Please wait {remaining} seconds before requesting a new OTP")
            except (ValueError, TypeError):
                pass

    # Generate 6-digit random numeric OTP code
    otp_code = f"{secrets.randbelow(900000) + 100000}"
    expires_at = (now + timedelta(minutes=OTP_EXPIRES_MINUTES)).isoformat()

    otp_doc = {
        "phone": np,
        "otp": otp_code,
        "attempts": 0,
        "created_at": now.isoformat(),
        "expires_at": expires_at,
    }
    await db.otp_verifications.update_one({"phone": np}, {"$set": otp_doc}, upsert=True)
    logger.info(f"[OTP] Generated verification OTP for +91{np}: {otp_code}")

    # SMS Gateway Integration (Fast2SMS / Webhook if configured in environment)
    sms_api_key = os.environ.get("FAST2SMS_API_KEY") or os.environ.get("SMS_API_KEY")
    if sms_api_key:
        try:
            import urllib.request
            import json

            sms_url = "https://www.fast2sms.com/dev/bulkV2"
            sms_data = json.dumps({
                "route": "q",
                "message": f"Your Hyderabadi Irani OTP is {otp_code}. Valid for 5 mins.",
                "language": "english",
                "numbers": np,
            }).encode("utf-8")

            req = urllib.request.Request(
                sms_url,
                data=sms_data,
                headers={
                    "authorization": sms_api_key,
                    "Content-Type": "application/json",
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                resp_body = resp.read().decode("utf-8")
                logger.info(f"[OTP] SMS Gateway dispatched for {np}: {resp_body[:100]}")
        except Exception as e:
            logger.warning(f"[OTP] SMS dispatch error for {np}: {e}")

    resp_data = {
        "ok": True,
        "message": f"Verification code sent to +91 {np}",
        "phone": np,
        "cooldown_seconds": OTP_COOLDOWN_SECONDS,
        "expires_in_seconds": OTP_EXPIRES_MINUTES * 60,
    }
    # Only ever echo the OTP back when explicitly opted in (e.g. local dev without
    # an SMS gateway configured) — never by default, since that defeats the point
    # of phone verification for anyone who can see the API response.
    if os.environ.get("DEBUG_OTP", "false").lower() == "true":
        resp_data["debug_otp"] = otp_code
    return resp_data


@api.post("/customer/auth/verify-otp")
async def customer_verify_otp(body: CustomerVerifyOtpIn, response: Response):
    np = norm_phone(body.phone)
    if len(np) != 10 or not np.isdigit():
        raise HTTPException(400, "Please enter a valid 10-digit Indian mobile number")

    typed_otp = (body.otp or "").strip()
    if len(typed_otp) != 6 or not typed_otp.isdigit():
        raise HTTPException(400, "Please enter a valid 6-digit OTP code")

    now = datetime.now(timezone.utc)
    rec = await db.otp_verifications.find_one({"phone": np})

    if not rec:
        raise HTTPException(400, "No active verification request found. Please tap 'Get OTP'.")

    expires_str = rec.get("expires_at")
    if expires_str:
        try:
            expires_at = datetime.fromisoformat(expires_str)
            if now > expires_at:
                await db.otp_verifications.delete_one({"phone": np})
                raise HTTPException(400, "OTP has expired. Please request a new verification code.")
        except (ValueError, TypeError):
            pass

    attempts = rec.get("attempts", 0)
    if attempts >= MAX_OTP_ATTEMPTS:
        await db.otp_verifications.delete_one({"phone": np})
        raise HTTPException(400, "Too many incorrect attempts. Please request a fresh OTP.")

    stored_otp = str(rec.get("otp", ""))

    # Validate OTP. The universal "123456" test code only works when explicitly
    # opted in (e.g. local dev) — never by default, since that's a bypass for
    # every phone number's verification.
    is_valid = (typed_otp == stored_otp) or (
        typed_otp == "123456" and os.environ.get("ALLOW_TEST_OTP", "false").lower() == "true"
    )

    if not is_valid:
        new_attempts = attempts + 1
        remaining = MAX_OTP_ATTEMPTS - new_attempts
        if remaining > 0:
            await db.otp_verifications.update_one({"phone": np}, {"$set": {"attempts": new_attempts}})
            raise HTTPException(400, f"Incorrect OTP code. {remaining} attempt{'s' if remaining > 1 else ''} remaining.")
        else:
            await db.otp_verifications.delete_one({"phone": np})
            raise HTTPException(400, "Too many failed attempts. Please request a new OTP code.")

    # Invalidate OTP on successful verification
    await db.otp_verifications.delete_one({"phone": np})

    # Find or Create Customer
    now_iso = now.isoformat()
    existing_cust = await db.customers.find_one({"phone": np})

    if existing_cust:
        doc = existing_cust
        if body.name and body.name.strip() and (not doc.get("name") or doc.get("name") in ["Customer", "Irani Guest", "Irani Food Lover"]):
            await db.customers.update_one({"_id": doc["_id"]}, {"$set": {"name": body.name.strip()}})
            doc["name"] = body.name.strip()
        logger.info(f"[CUSTOMER-OTP] Verified existing customer {np} ({doc.get('name')})")
    else:
        new_name = (body.name or "Irani Food Lover").strip()
        new_doc = {
            "name": new_name,
            "phone": np,
            "email": "",
            "password_hash": "",
            "addresses": [],
            "loyalty_points": 100,
            "active": True,
            "created_at": now_iso,
        }
        res = await db.customers.insert_one(new_doc)
        new_doc["_id"] = res.inserted_id
        doc = new_doc
        logger.info(f"[CUSTOMER-OTP] Registered new verified customer {np} with 100 welcome points")
        
        # Log initial welcome bonus passbook entry
        tx = {
            "phone": np,
            "customer_id": str(res.inserted_id),
            "type": "welcome_bonus",
            "points": 100,
            "balance_after": 100,
            "order_no": None,
            "description": "Welcome Joining Bonus (100 Irani Royalty Coins - ₹25 off first 4 orders > ₹249)",
            "created_at": now_iso,
        }
        try:
            await db.loyalty_transactions.insert_one(tx)
        except Exception as e:
            logger.warning(f"[LOYALTY] Could not log welcome bonus tx: {e}")

    customer = Customer.from_mongo(doc)
    customer.orders_count = await db.orders.count_documents({
        "phone": np,
        "status": {"$nin": ["cancelled", "failed"]}
    })
    access_token = create_access_token(customer.id, customer.phone, "customer")
    response.set_cookie("customer_token", access_token, httponly=True, secure=True, samesite="none",
                        max_age=int(ACCESS_TTL.total_seconds()), path="/")

    return {
        "ok": True,
        "access_token": access_token,
        "customer": customer,
        "message": "Mobile number verified successfully! 100 Welcome Coins added 👑",
    }


@api.get("/customer/auth/me", response_model=Customer)
async def customer_auth_me(customer: Customer = Depends(get_current_customer)):
    doc = await db.customers.find_one({"_id": parse_object_id(customer.id)})
    if not doc:
        raise HTTPException(404, "Customer account not found")
    c = Customer.from_mongo(doc)
    c.orders_count = await db.orders.count_documents({
        "phone": norm_phone(c.phone),
        "status": {"$nin": ["cancelled", "failed"]}
    })
    return c


# ---------- Push Notifications (FCM v1 / CRM Alerts) ----------
# The legacy "key=<server key>" FCM HTTP API this used to call was
# discontinued by Google in 2024 — it silently fails now. FCM v1 requires a
# Firebase service account and an OAuth2 access token per request instead.
_FCM_TOKEN_CACHE = {"token": None, "expiry": 0.0}


def _get_fcm_access_token_sync() -> Optional[str]:
    """Blocking (RSA-signs a JWT and does a network round trip) — always call
    this via asyncio.to_thread, never directly from an async function."""
    import time as _time
    now = _time.time()
    if _FCM_TOKEN_CACHE["token"] and _FCM_TOKEN_CACHE["expiry"] > now + 60:
        return _FCM_TOKEN_CACHE["token"]

    sa_json = os.environ.get("FIREBASE_SERVICE_ACCOUNT_JSON")
    scopes = ["https://www.googleapis.com/auth/firebase.messaging"]
    try:
        from google.auth.transport.requests import Request as GoogleAuthRequest

        if sa_json:
            from google.oauth2 import service_account
            info = json.loads(sa_json)
            creds = service_account.Credentials.from_service_account_info(info, scopes=scopes)
        else:
            # No downloaded key configured (e.g. blocked by an org policy on
            # service-account key creation) — fall back to the identity Cloud
            # Run already runs as (Application Default Credentials). This
            # needs the "Firebase Cloud Messaging API Admin" role granted to
            # the Cloud Run service's service account; no key file needed.
            import google.auth
            creds, _ = google.auth.default(scopes=scopes)

        creds.refresh(GoogleAuthRequest())
        _FCM_TOKEN_CACHE["token"] = creds.token
        _FCM_TOKEN_CACHE["expiry"] = creds.expiry.timestamp() if creds.expiry else now + 3000
        return creds.token
    except Exception as e:
        logger.warning(f"[PUSH] Failed to get FCM v1 access token: {e}")
        return None


def _send_one_fcm_v1_sync(access_token: str, project_id: str, token: str,
                          title: str, body: str, data: Optional[dict]) -> str:
    """Blocking HTTP call — always call via asyncio.to_thread."""
    import urllib.request
    import urllib.error

    url = f"https://fcm.googleapis.com/v1/projects/{project_id}/messages:send"
    message = {
        "message": {
            "token": token,
            "notification": {"title": title, "body": body},
            "data": {str(k): str(v) for k, v in (data or {}).items()},
            "android": {"priority": "high", "notification": {"sound": "default"}},
        }
    }
    req = urllib.request.Request(
        url,
        data=json.dumps(message).encode("utf-8"),
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            return response.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return f"HTTP {e.code}: {e.read().decode('utf-8', 'ignore')[:200]}"


async def send_push_notification(title: str, body: str, target_phone: Optional[str] = None, target_role: Optional[str] = None, data: Optional[dict] = None):
    """Dispatches an FCM v1 push notification to every device registered for
    the given phone or role. Requires FIREBASE_SERVICE_ACCOUNT_JSON (the full
    service account key JSON) and FIREBASE_PROJECT_ID to be configured;
    otherwise this just logs and returns (e.g. local dev without FCM set up)."""
    try:
        q: dict = {}
        if target_phone:
            np = norm_phone(target_phone)
            if np:
                q["phone"] = np
        elif target_role:
            q["role"] = target_role

        tokens_cursor = db.device_tokens.find(q)
        tokens = [d["token"] async for d in tokens_cursor if d.get("token")]

        if not tokens:
            logger.info(f"[PUSH] Target (phone={target_phone}, role={target_role}) - Notification '{title}': '{body}' (No device tokens registered)")
            return

        project_id = os.environ.get("FIREBASE_PROJECT_ID")
        access_token = await asyncio.to_thread(_get_fcm_access_token_sync)
        if not access_token or not project_id:
            logger.info(f"[PUSH] FCM not configured (FIREBASE_SERVICE_ACCOUNT_JSON/FIREBASE_PROJECT_ID) — "
                       f"would have sent to {len(tokens)} device(s): '{title}' - '{body}'")
            return

        logger.info(f"[PUSH] Dispatching to {len(tokens)} device(s): '{title}' - '{body}'")
        for tok in tokens:
            result = await asyncio.to_thread(_send_one_fcm_v1_sync, access_token, project_id, tok, title, body, data)
            logger.info(f"[PUSH] FCM v1 response for token ...{tok[-8:]}: {result[:150]}")
    except Exception as e:
        logger.warning(f"[PUSH] Error sending push notification: {e}")


@api.post("/notifications/register-token")
async def register_device_token(body: DeviceTokenRegisterIn,
                                customer: Optional[Customer] = Depends(get_optional_customer)):
    tok = (body.token or "").strip()
    if not tok:
        raise HTTPException(400, "Device token is required")
    # Only ever associate this device with the phone number of the customer
    # who is actually logged in — otherwise anyone could register their own
    # device against someone else's phone and start receiving that person's
    # order-status push notifications.
    np = norm_phone(customer.phone) if customer else None

    doc = {
        "token": tok,
        "phone": np,
        "role": body.role,
        "platform": body.platform,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.device_tokens.update_one({"token": tok}, {"$set": doc}, upsert=True)
    logger.info(f"[NOTIF] Registered device token for {body.role} (phone: {np})")
    return {"ok": True, "token": tok}


@api.post("/notifications/unregister-token")
async def unregister_device_token(body: DeviceTokenUnregisterIn):
    tok = (body.token or "").strip()
    if tok:
        await db.device_tokens.delete_one({"token": tok})
    return {"ok": True}


# ---------- Loyalty Points Engine (Audit Ledger & Rules) ----------
LOYALTY_EARN_RATIO = 100.0  # ₹100 spent = 1 Coin
LOYALTY_COIN_VALUE = 1.0    # 1 Coin = ₹1 discount
LOYALTY_WELCOME_BONUS = 100 # 100 Coins Joining Bonus
LOYALTY_JOINING_DISCOUNT_PER_ORDER = 25 # ₹25 off per order
LOYALTY_JOINING_ORDERS_LIMIT = 4        # Applicable on first 4 orders
LOYALTY_MIN_SUBTOTAL = 249.0            # Minimum food subtotal > ₹249 (i.e. ₹250+)
LOYALTY_MIN_REDEEM = 20                 # Minimum 20 coins to redeem
LOYALTY_MAX_ORDER_PCT = 0.50            # Max 50% of food subtotal payable via coins


async def log_loyalty_transaction(phone: str, t_type: str, points: int, order_no: Optional[str] = None, description: str = "") -> int:
    """
    Applies points delta to customer balance and logs immutable entry into db.loyalty_transactions.
    """
    np = norm_phone(phone)
    if not np or points == 0:
        return 0
    c_doc = await db.customers.find_one({"phone": np})
    if not c_doc:
        return 0

    current_pts = int(c_doc.get("loyalty_points", 0))
    new_pts = max(0, current_pts + points)
    await db.customers.update_one({"_id": c_doc["_id"]}, {"$set": {"loyalty_points": new_pts}})

    tx = {
        "phone": np,
        "customer_id": str(c_doc["_id"]),
        "type": t_type,  # earn | redeem | welcome_bonus | refund | admin_adjustment
        "points": points,
        "balance_after": new_pts,
        "order_no": order_no,
        "description": description or f"{t_type.replace('_', ' ').title()} on Order #{order_no}",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.loyalty_transactions.insert_one(tx)
    logger.info(f"[LOYALTY] Customer {np}: {t_type} {points:+d} pts (New Balance: {new_pts}) - {description}")
    return new_pts


@api.get("/loyalty/rules")
async def get_loyalty_rules():
    return {
        "earn_ratio": LOYALTY_EARN_RATIO,
        "coin_value": LOYALTY_COIN_VALUE,
        "welcome_coins": LOYALTY_WELCOME_BONUS,
        "joining_discount_per_order": LOYALTY_JOINING_DISCOUNT_PER_ORDER,
        "joining_orders_limit": LOYALTY_JOINING_ORDERS_LIMIT,
        "min_subtotal": LOYALTY_MIN_SUBTOTAL,
        "min_redeem": LOYALTY_MIN_REDEEM,
        "max_order_percent": int(LOYALTY_MAX_ORDER_PCT * 100),
        "currency": "INR",
        "description": f"Get 100 Royalty Coins on signup! Claim ₹25 OFF on each of your first 4 orders above ₹249. Earn 1 Coin per ₹{int(LOYALTY_EARN_RATIO)} spent.",
    }


@api.get("/customer/loyalty/transactions")
async def get_customer_loyalty_transactions(customer: Customer = Depends(get_current_customer)):
    np = norm_phone(customer.phone)
    if not np:
        return []
    docs = await db.loyalty_transactions.find({"phone": np}).sort("created_at", -1).to_list(100)
    for d in docs:
        d["id"] = str(d.pop("_id"))
    return docs


@api.post("/customer/register")
async def customer_register(body: CustomerRegisterIn, response: Response):
    np = norm_phone(body.phone)
    if len(np) < 10:
        raise HTTPException(400, "Please enter a valid 10-digit mobile number")
    if not body.name.strip():
        raise HTTPException(400, "Name is required")
    if len(body.password) < 4:
        raise HTTPException(400, "Password must be at least 4 characters")

    email_clean = (body.email or "").strip().lower()
    pwd_hash = hash_password(body.password)
    now_iso = datetime.now(timezone.utc).isoformat()

    # Check if customer already exists
    existing = await db.customers.find_one({"phone": np})
    if existing:
        # If user re-registers or updates credentials, update their profile smoothly
        update_data = {
            "name": body.name.strip(),
            "password_hash": pwd_hash,
        }
        if email_clean:
            update_data["email"] = email_clean
        await db.customers.update_one({"_id": existing["_id"]}, {"$set": update_data})
        doc = await db.customers.find_one({"_id": existing["_id"]})
        logger.info(f"[CUSTOMER] Updated credentials on re-registration for phone {np}")
    else:
        if email_clean:
            existing_email = await db.customers.find_one({"email": email_clean})
            if existing_email:
                raise HTTPException(400, "An account with this email address already exists.")

        new_doc = {
            "name": body.name.strip(),
            "phone": np,
            "email": email_clean,
            "password_hash": pwd_hash,
            "addresses": [],
            "loyalty_points": 100,
            "active": True,
            "created_at": now_iso,
        }
        res = await db.customers.insert_one(new_doc)
        new_doc["_id"] = res.inserted_id
        doc = new_doc
        logger.info(f"[CUSTOMER] Registered new account for phone {np} with 100 welcome coins")

    customer = Customer.from_mongo(doc)
    access_token = create_access_token(customer.id, customer.email or customer.phone, "customer")
    response.set_cookie("customer_token", access_token, httponly=True, secure=True, samesite="none",
                        max_age=int(ACCESS_TTL.total_seconds()), path="/")
    return {"access_token": access_token, "customer": customer}


@api.post("/customer/login")
async def customer_login(body: CustomerLoginIn, response: Response):
    raw_ident = body.identifier.strip()
    np = norm_phone(raw_ident)
    ident_lower = raw_ident.lower()
    pwd = body.password.strip()
    logger.info(f"[CUSTOMER] Sign-in attempt for identifier: '{raw_ident}'")

    query_cond = []
    if len(np) >= 10:
        query_cond.append({"phone": np})
    query_cond.append({"email": ident_lower})

    doc = await db.customers.find_one({"$or": query_cond})
    if not doc:
        # If user logs in with 10 digit number and password >= 4 chars, auto-provision
        if len(np) >= 10 and len(pwd) >= 4:
            logger.info(f"[CUSTOMER] Auto-provisioning customer for {np} on first sign-in")
            pwd_hash = hash_password(pwd)
            new_doc = {
                "name": "Customer",
                "phone": np,
                "email": ident_lower if "@" in ident_lower else "",
                "password_hash": pwd_hash,
                "addresses": [],
                "loyalty_points": 100,
                "active": True,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            res = await db.customers.insert_one(new_doc)
            new_doc["_id"] = res.inserted_id
            doc = new_doc
        else:
            logger.warning(f"[CUSTOMER] Account not found for '{raw_ident}'")
            raise HTTPException(401, "Invalid mobile number or password")

    stored_hash = doc.get("password_hash", "")
    valid = bool(stored_hash) and verify_password(pwd, stored_hash)

    if not valid:
        logger.warning(f"[CUSTOMER] Password verification failed for {raw_ident}")
        raise HTTPException(401, "Invalid mobile number or password")

    customer = Customer.from_mongo(doc)
    access_token = create_access_token(customer.id, customer.email or customer.phone, "customer")
    response.set_cookie("customer_token", access_token, httponly=True, secure=True, samesite="none",
                        max_age=int(ACCESS_TTL.total_seconds()), path="/")
    logger.info(f"[CUSTOMER] Sign-in successful for {customer.phone} ({customer.name})")
    return {"access_token": access_token, "customer": customer}


@api.post("/customer/reset-password")
async def customer_reset_password(body: CustomerResetPasswordIn, response: Response):
    np = norm_phone(body.phone)
    if len(np) < 10:
        raise HTTPException(400, "Please enter a valid 10-digit mobile number")
    if len(body.new_password) < 4:
        raise HTTPException(400, "New password must be at least 4 characters")

    # Require a freshly-verified OTP for this phone before allowing a password
    # reset — otherwise anyone who knows a customer's phone number could take
    # over their account by just calling this endpoint directly.
    typed_otp = (body.otp or "").strip()
    if len(typed_otp) != 6 or not typed_otp.isdigit():
        raise HTTPException(400, "Please enter a valid 6-digit OTP code")
    rec = await db.otp_verifications.find_one({"phone": np})
    if not rec:
        raise HTTPException(400, "No active verification request found. Please tap 'Get OTP'.")
    expires_str = rec.get("expires_at")
    if expires_str:
        try:
            if datetime.now(timezone.utc) > datetime.fromisoformat(expires_str):
                await db.otp_verifications.delete_one({"phone": np})
                raise HTTPException(400, "OTP has expired. Please request a new verification code.")
        except (ValueError, TypeError):
            pass
    if typed_otp != str(rec.get("otp", "")):
        raise HTTPException(400, "Incorrect OTP code.")
    await db.otp_verifications.delete_one({"phone": np})

    pwd_hash = hash_password(body.new_password)
    now_iso = datetime.now(timezone.utc).isoformat()

    doc = await db.customers.find_one({"phone": np})
    if doc:
        update_fields = {"password_hash": pwd_hash}
        if body.name and body.name.strip():
            update_fields["name"] = body.name.strip()
        await db.customers.update_one({"_id": doc["_id"]}, {"$set": update_fields})
        doc = await db.customers.find_one({"_id": doc["_id"]})
        logger.info(f"[CUSTOMER] Password reset successfully for {np}")
    else:
        new_doc = {
            "name": (body.name or "Customer").strip(),
            "phone": np,
            "email": "",
            "password_hash": pwd_hash,
            "addresses": [],
            "loyalty_points": 0,
            "active": True,
            "created_at": now_iso,
        }
        res = await db.customers.insert_one(new_doc)
        new_doc["_id"] = res.inserted_id
        doc = new_doc
        logger.info(f"[CUSTOMER] Account created via reset password for {np}")

    customer = Customer.from_mongo(doc)
    access_token = create_access_token(customer.id, customer.email or customer.phone, "customer")
    response.set_cookie("customer_token", access_token, httponly=True, secure=True, samesite="none",
                        max_age=int(ACCESS_TTL.total_seconds()), path="/")
    return {"access_token": access_token, "customer": customer}


@api.get("/customer/profile", response_model=Customer)
async def get_customer_profile(customer: Customer = Depends(get_current_customer)):
    # Refresh customer from db
    doc = await db.customers.find_one({"_id": parse_object_id(customer.id)})
    if not doc:
        raise HTTPException(404, "Customer not found")
    return Customer.from_mongo(doc)


@api.put("/customer/profile", response_model=Customer)
async def update_customer_profile(body: CustomerProfileUpdateIn, customer: Customer = Depends(get_current_customer)):
    updates = {}
    if body.name is not None:
        updates["name"] = body.name.strip()
    if body.email is not None:
        updates["email"] = body.email.strip().lower()

    if updates:
        await db.customers.update_one({"_id": parse_object_id(customer.id)}, {"$set": updates})

    doc = await db.customers.find_one({"_id": parse_object_id(customer.id)})
    return Customer.from_mongo(doc)


@api.post("/customer/addresses", response_model=List[CustomerAddress])
async def add_customer_address(body: CustomerAddressIn, customer: Customer = Depends(get_current_customer)):
    new_addr = CustomerAddress(
        id=str(uuid.uuid4())[:8],
        label=body.label or "Home",
        address=body.address.strip(),
        flat_landmark=body.flat_landmark.strip() if body.flat_landmark else "",
        lat=body.lat,
        lng=body.lng,
        is_default=body.is_default,
    )

    doc = await db.customers.find_one({"_id": parse_object_id(customer.id)})
    addresses = doc.get("addresses", []) if doc else []

    if body.is_default:
        for a in addresses:
            a["is_default"] = False

    addresses.append(new_addr.model_dump())
    await db.customers.update_one({"_id": parse_object_id(customer.id)}, {"$set": {"addresses": addresses}})
    return [CustomerAddress(**a) for a in addresses]


@api.delete("/customer/addresses/{address_id}", response_model=List[CustomerAddress])
async def delete_customer_address(address_id: str, customer: Customer = Depends(get_current_customer)):
    doc = await db.customers.find_one({"_id": parse_object_id(customer.id)})
    addresses = doc.get("addresses", []) if doc else []
    addresses = [a for a in addresses if a.get("id") != address_id]
    await db.customers.update_one({"_id": parse_object_id(customer.id)}, {"$set": {"addresses": addresses}})
    return [CustomerAddress(**a) for a in addresses]


@api.get("/customer/orders", response_model=List[Order])
async def get_customer_orders(customer: Customer = Depends(get_current_customer)):
    np = norm_phone(customer.phone)
    query = {"$or": [{"phone": np}, {"phone": customer.phone}]}
    docs = await db.orders.find(query).sort("created_at", -1).to_list(100)
    return [Order.from_mongo(d) for d in docs]


@api.get("/admin/customers")
async def get_admin_customers(q: Optional[str] = None, _: User = Depends(require_admin)):
    registered_docs = await db.customers.find({}).to_list(1000)
    all_orders = await db.orders.find({}).sort("created_at", -1).to_list(5000)

    orders_by_phone: dict = {}
    for ord in all_orders:
        raw_p = ord.get("phone", "")
        clean_p = norm_phone(raw_p)
        if not clean_p:
            continue
        if clean_p not in orders_by_phone:
            orders_by_phone[clean_p] = []
        orders_by_phone[clean_p].append(ord)

    cust_map = {}

    for c in registered_docs:
        raw_p = c.get("phone", "")
        clean_p = norm_phone(raw_p)
        if not clean_p:
            continue
        ords = orders_by_phone.get(clean_p, [])
        tot_spend = sum(float(o.get("total", 0)) for o in ords)
        last_ord = ords[0]["created_at"] if ords else c.get("created_at", "")

        item_counts: dict = {}
        for o in ords:
            for it in o.get("items", []):
                inm = it.get("name", "")
                if inm:
                    item_counts[inm] = item_counts.get(inm, 0) + int(it.get("qty", 1))
        fav_item = max(item_counts, key=item_counts.get) if item_counts else "—"

        cust_map[clean_p] = {
            "id": str(c.get("_id")),
            "name": c.get("name") or "Customer",
            "phone": clean_p,
            "email": c.get("email", ""),
            "loyalty_points": int(c.get("loyalty_points", 0)),
            "total_orders": len(ords),
            "total_spend": round(tot_spend, 2),
            "last_order_at": last_ord,
            "favorite_item": fav_item,
            "addresses": c.get("addresses", []),
            "registered": True,
            "created_at": c.get("created_at", "")
        }

    for clean_p, ords in orders_by_phone.items():
        if clean_p not in cust_map:
            latest_ord = ords[0]
            tot_spend = sum(float(o.get("total", 0)) for o in ords)
            item_counts = {}
            for o in ords:
                for it in o.get("items", []):
                    inm = it.get("name", "")
                    if inm:
                        item_counts[inm] = item_counts.get(inm, 0) + int(it.get("qty", 1))
            fav_item = max(item_counts, key=item_counts.get) if item_counts else "—"

            cname = latest_ord.get("customer_name") or "Walk-in Customer"
            if cname == "Walk-in Guest":
                cname = f"Customer ({clean_p[-4:]})"

            cust_map[clean_p] = {
                "id": f"guest_{clean_p}",
                "name": cname,
                "phone": clean_p,
                "email": "",
                "loyalty_points": int(tot_spend // 100),
                "total_orders": len(ords),
                "total_spend": round(tot_spend, 2),
                "last_order_at": latest_ord.get("created_at", ""),
                "favorite_item": fav_item,
                "addresses": [{"address": latest_ord.get("address")}] if latest_ord.get("address") else [],
                "registered": False,
                "created_at": ords[-1].get("created_at", "")
            }

    res_list = list(cust_map.values())

    if q and q.strip():
        search_term = q.strip().lower()
        res_list = [
            c for c in res_list
            if search_term in c["name"].lower()
            or search_term in c["phone"]
            or search_term in c["email"].lower()
        ]

    res_list.sort(key=lambda x: (x["total_spend"], x["total_orders"]), reverse=True)
    return res_list


# ---------- Menu ----------
@api.get("/menu", response_model=List[MenuItem])
async def list_menu(category: Optional[str] = None, only_available: bool = False):
    q: dict = {}
    if category and category != "All":
        q["category"] = category
    if only_available:
        q["available"] = {"$ne": False}
    docs = await db.menu_items.find(q).sort("name", 1).to_list(500)
    return [MenuItem.from_mongo(d) for d in docs]


@api.post("/menu", response_model=MenuItem)
async def create_menu_item(body: MenuItemIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    name_clean = body.name.strip()
    if not name_clean:
        raise HTTPException(400, "Item name cannot be empty")

    # Prevent duplicate menu item names (case-insensitive & trimmed)
    existing = await db.menu_items.find_one({
        "name": {"$regex": f"^{re.escape(name_clean)}$", "$options": "i"}
    })
    if existing:
        raise HTTPException(
            400,
            f"Item '{existing.get('name', name_clean)}' already exists in the menu. Please edit the existing item or choose a distinct name."
        )

    item_dict = body.model_dump()
    item_dict["name"] = name_clean
    if item_dict.get("suggested_items") is None:
        item_dict["suggested_items"] = []
    item = MenuItem(**item_dict)
    res = await db.menu_items.insert_one(item.to_mongo())
    item.id = str(res.inserted_id)
    return item


@api.put("/menu/{item_id}", response_model=MenuItem)
async def update_menu_item(item_id: str, body: MenuItemIn, _: User = Depends(require_admin),
                           __: None = Depends(verify_csrf)):
    name_clean = body.name.strip()
    if not name_clean:
        raise HTTPException(400, "Item name cannot be empty")

    obj_id = parse_object_id(item_id)

    # Prevent duplicate item names with other items
    existing = await db.menu_items.find_one({
        "_id": {"$ne": obj_id},
        "name": {"$regex": f"^{re.escape(name_clean)}$", "$options": "i"}
    })
    if existing:
        raise HTTPException(
            400,
            f"Another item named '{existing.get('name', name_clean)}' already exists in the menu."
        )

    update_payload = body.model_dump()
    update_payload["name"] = name_clean
    if update_payload.get("suggested_items") is None:
        update_payload["suggested_items"] = []
    res = await db.menu_items.find_one_and_update(
        {"_id": obj_id}, {"$set": update_payload}, return_document=True)
    if not res:
        raise HTTPException(404, "Item not found")
    return MenuItem.from_mongo(res)


@api.delete("/menu/{item_id}")
async def delete_menu_item(item_id: str, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    res = await db.menu_items.delete_one({"_id": parse_object_id(item_id)})
    if res.deleted_count == 0:
        raise HTTPException(404, "Item not found")
    return {"ok": True}


@api.put("/menu/{item_id}/availability")
async def toggle_item_availability(item_id: str, body: ItemAvailabilityIn, _: User = Depends(require_admin),
                                   __: None = Depends(verify_csrf)):
    res = await db.menu_items.find_one_and_update(
        {"_id": parse_object_id(item_id)},
        {"$set": {"available": body.available}},
        return_document=True
    )
    if not res:
        raise HTTPException(404, "Item not found")
    return {"ok": True, "id": str(res["_id"]), "available": res.get("available", True)}


@api.put("/menu/category/{category_name}/availability")
async def toggle_category_availability(category_name: str, body: CategoryAvailabilityIn, _: User = Depends(require_admin),
                                       __: None = Depends(verify_csrf)):
    res = await db.menu_items.update_many(
        {"category": {"$regex": f"^{category_name}$", "$options": "i"}},
        {"$set": {"available": body.available}}
    )
    return {"ok": True, "category": category_name, "available": body.available, "modified_count": res.modified_count}


@api.get("/store/status")
async def get_store_status():
    doc = await db.settings.find_one({"key": "store_status"})
    if not doc:
        return {"is_online_open": True, "notice": ""}
    return {
        "is_online_open": doc.get("is_online_open", True),
        "notice": doc.get("notice", "")
    }


@api.put("/store/status")
async def update_store_status(body: StoreStatusIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    await db.settings.update_one(
        {"key": "store_status"},
        {"$set": {"key": "store_status", "is_online_open": body.is_online_open, "notice": body.notice or ""}},
        upsert=True
    )
    return {"ok": True, "is_online_open": body.is_online_open, "notice": body.notice}


@api.get("/menu/categories")
async def get_menu_categories():
    raw_cats = await db.menu_items.distinct("category")
    clean_cats = [c for c in raw_cats if c and str(c).strip()]
    
    order_doc = await db.settings.find_one({"key": "category_order"})
    if order_doc and "categories" in order_doc:
        saved_order = order_doc["categories"]
        ordered = [c for c in saved_order if c in clean_cats]
        for c in clean_cats:
            if c not in ordered:
                ordered.append(c)
        return {"categories": ordered}
    
    default_priority = ["Tea", "Tiffins", "Snacks", "Biryani", "Starters", "Tandoori Kebabs", "Currys", "Rotis", "Shawarma", "Sweets", "Fried Rice", "Noodles", "Soups", "Sea Food"]
    ordered = [c for c in default_priority if c in clean_cats]
    for c in clean_cats:
        if c not in ordered:
            ordered.append(c)
    return {"categories": ordered}


@api.put("/menu/categories/order")
async def update_category_order(body: CategoryOrderIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    await db.settings.update_one(
        {"key": "category_order"},
        {"$set": {"key": "category_order", "categories": body.categories}},
        upsert=True
    )
    return {"ok": True, "categories": body.categories}


@api.post("/menu/bulk-price-adjust")
async def bulk_price_adjust(body: BulkPriceAdjustIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    q: dict = {}
    if body.category and body.category != "All":
        q["category"] = body.category
    
    cursor = db.menu_items.find(q)
    updated_count = 0
    async for item in cursor:
        old_price = float(item.get("price", 0.0))
        hike = float(body.delta) + (old_price * float(body.percent) / 100.0)
        new_price = max(1.0, round(old_price + hike, 2))
        await db.menu_items.update_one({"_id": item["_id"]}, {"$set": {"price": new_price}})
        updated_count += 1
    return {"ok": True, "updated_count": updated_count}


@api.post("/menu/bulk-import")
async def bulk_import_menu(body: BulkImportIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    if not body.items:
        raise HTTPException(400, "No items provided")
    
    if body.replace_all:
        await db.menu_items.delete_many({})
    
    docs = [MenuItem(**item.model_dump()).to_mongo() for item in body.items]
    res = await db.menu_items.insert_many(docs)
    return {"ok": True, "inserted_count": len(res.inserted_ids)}


@api.delete("/menu/clear-all")
async def clear_all_menu(_: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    res = await db.menu_items.delete_many({})
    return {"ok": True, "deleted_count": res.deleted_count}


# ---------- Image Upload & WebP Optimization under 50 KB ----------
GCS_MENU_BUCKET = os.environ.get("GCS_BUCKET_NAME", "hyderabadi-irani-menu-assets-metal-density-504117-k9")


def compress_image_under_50kb(image_bytes: bytes, max_dim: int = 600) -> tuple[bytes, float, int, int]:
    """Compress and convert image to WebP strictly under 50 KB with crisp visual clarity."""
    img = Image.open(io.BytesIO(image_bytes))
    
    # Convert RGBA or P mode to RGB if needed, or preserve RGBA
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        img = img.convert("RGBA")
    else:
        img = img.convert("RGB")
        
    # Resize preserving aspect ratio (max 600x600)
    img.thumbnail((max_dim, max_dim), Image.Resampling.LANCZOS)
    width, height = img.size
    
    # Progressively compress to WebP ensuring file size is strictly < 50 KB
    quality = 82
    out_buf = io.BytesIO()
    while quality >= 25:
        out_buf.seek(0)
        out_buf.truncate(0)
        img.save(out_buf, format="WEBP", quality=quality, method=6)
        size_kb = out_buf.tell() / 1024.0
        if size_kb <= 48.0:  # Safely strictly under 50 KB
            break
        quality -= 7
        
    final_bytes = out_buf.getvalue()
    final_size_kb = round(len(final_bytes) / 1024.0, 1)
    return final_bytes, final_size_kb, width, height


def upload_bytes_to_gcs(data: bytes, filename: str, content_type: str = "image/webp") -> str:
    """Upload byte buffer directly to GCS bucket and return public URL with local fallback."""
    # 1. Always save a local copy in uploads/menu as reliable backup
    local_url = None
    local_path = None
    try:
        os.makedirs(MENU_UPLOAD_DIR, exist_ok=True)
        local_path = os.path.join(MENU_UPLOAD_DIR, filename)
        with open(local_path, "wb") as f:
            f.write(data)
        local_url = f"/uploads/menu/{filename}"
    except Exception as le:
        logger.warning(f"Could not save local upload backup: {le}")

    # 2. Try Google Cloud Storage Python Client
    try:
        from google.cloud import storage
        client = storage.Client()
        bucket = client.bucket(GCS_MENU_BUCKET)
        blob = bucket.blob(f"menu/{filename}")
        blob.upload_from_string(data, content_type=content_type)
        return f"https://storage.googleapis.com/{GCS_MENU_BUCKET}/menu/{filename}"
    except Exception as e:
        logger.warning(f"GCS Python client upload failed ({e}), checking gcloud CLI fallback...")

    # 3. Try gcloud CLI fallback safely if gcloud executable exists
    gcloud_bin = shutil.which("gcloud") or shutil.which("gcloud.cmd")
    if gcloud_bin and local_path and os.path.exists(local_path):
        try:
            gcs_dest = f"gs://{GCS_MENU_BUCKET}/menu/{filename}"
            res = subprocess.run(
                [gcloud_bin, "storage", "cp", f"--content-type={content_type}", local_path, gcs_dest],
                capture_output=True,
                text=True,
                timeout=15,
                shell=(sys.platform == "win32")
            )
            if res.returncode == 0:
                return f"https://storage.googleapis.com/{GCS_MENU_BUCKET}/menu/{filename}"
            else:
                logger.warning(f"gcloud storage cp returned non-zero code: {res.stderr}")
        except Exception as gcloud_err:
            logger.warning(f"gcloud CLI fallback execution error: {gcloud_err}")

    # 4. If GCS is unreachable (e.g. offline/local development), return the local static URL
    if local_url:
        logger.info(f"Using local static image URL: {local_url}")
        return local_url

    raise Exception("Failed to save image locally or upload to cloud storage.")


@api.post("/menu/upload-image")
async def upload_menu_image(
    req: Request,
    _: User = Depends(require_admin),
    __: None = Depends(verify_csrf)
):
    """
    Accepts multipart/form-data with file or JSON body with image_base64.
    Compresses image to WebP under 50 KB and uploads directly to Google Cloud Storage.
    """
    content_type = req.headers.get("content-type", "")
    raw_bytes = None
    original_filename = "menu_dish.jpg"

    if "application/json" in content_type:
        body = await req.json()
        b64 = body.get("image_base64", "")
        if not b64:
            raise HTTPException(400, "No image_base64 data provided")
        if "," in b64:
            b64 = b64.split(",", 1)[1]
        import base64
        try:
            raw_bytes = base64.b64decode(b64)
        except Exception as e:
            raise HTTPException(400, f"Invalid base64 image data: {e}")
        original_filename = body.get("filename") or body.get("item_name") or "menu_item"
    else:
        form = await req.form()
        file_obj = form.get("file")
        if not file_obj:
            raise HTTPException(400, "No file uploaded in form data")
        raw_bytes = await file_obj.read()
        original_filename = getattr(file_obj, "filename", "menu_item")

    if not raw_bytes:
        raise HTTPException(400, "Uploaded image is empty")

    try:
        # Sanitize filename slug
        slug = re.sub(r'[^a-zA-Z0-9_-]', '_', os.path.splitext(original_filename)[0]).lower()
        slug = re.sub(r'_+', '_', slug).strip('_') or "menu_item"
        unique_name = f"{slug}_{int(datetime.now(timezone.utc).timestamp())}.webp"

        # Compress to WebP strictly under 50 KB
        webp_bytes, size_kb, width, height = compress_image_under_50kb(raw_bytes, max_dim=600)

        # Upload to GCS
        public_url = upload_bytes_to_gcs(webp_bytes, unique_name, content_type="image/webp")

        return {
            "ok": True,
            "url": public_url,
            "filename": unique_name,
            "size_kb": size_kb,
            "width": width,
            "height": height,
            "format": "webp",
            "message": f"Image compressed to {size_kb} KB and uploaded to Cloud Storage successfully!"
        }
    except Exception as e:
        logger.error(f"Image upload/compression failed: {e}", exc_info=True)
        raise HTTPException(500, f"Failed to process and upload image: {str(e)}")


# ---------- Orders ----------
async def _build_order(body: OrderIn, source: str) -> Order:
    if not body.items:
        raise HTTPException(400, "Order must have at least one item")
    if body.offline_no:
        existing = await db.orders.find_one({"offline_no": body.offline_no})
        if existing:
            return Order.from_mongo(existing)

    # Server-Side Input Validations
    clean_phone = norm_phone(body.phone) if body.phone else ""
    if source == "online" or clean_phone:
        if not clean_phone or len(clean_phone) != 10 or not re.match(r"^[6-9]\d{9}$", clean_phone):
            raise HTTPException(400, "Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.")

    if body.order_type == "delivery":
        if len((body.address or "").strip()) < 6:
            raise HTTPException(400, "Please provide a complete delivery address (Flat/House No., Street, Area).")

        # 5 km delivery radius — enforced server-side so it can't be bypassed
        # by calling the API directly instead of going through the checkout UI.
        if body.lat is not None and body.lng is not None:
            dist = haversine_km(STORE_LAT, STORE_LNG, body.lat, body.lng)
            if dist > MAX_DELIVERY_DISTANCE_KM:
                raise HTTPException(
                    400,
                    f"We deliver up to {MAX_DELIVERY_DISTANCE_KM} km from our Secunderabad store. "
                    f"Your address is {dist:.1f} km away.",
                )

        # Late-night (10:00 PM - 6:00 AM IST) orders must be prepaid online —
        # cash on delivery is disabled during those hours.
        ist_hour = datetime.now(IST).hour
        is_late_night = ist_hour >= COD_DISABLED_START_HOUR or ist_hour < COD_DISABLED_END_HOUR
        if is_late_night and body.payment_mode not in ("razorpay", "online"):
            raise HTTPException(
                400,
                "Late Night orders (10:00 PM to 6:00 AM) must be prepaid online. Cash on delivery is disabled.",
            )

    if body.order_type in ["dinein", "dine-in"]:
        if not (body.table_no or "").strip():
            raise HTTPException(400, "Please specify a Table Number for Dine-In.")

        # In-house (dine-in) bookings placed by the customer themselves via
        # the app/website (table QR ordering) must be prepaid online — this
        # does NOT apply to source == "pos", where a staff member is taking
        # a walk-in dine-in order at the counter and cash is still fine.
        if source == "online" and body.payment_mode not in ("razorpay", "online"):
            raise HTTPException(
                400,
                "Dine-in bookings placed through the app/website must be prepaid online (UPI / Cards). "
                "Cash payment is available only when ordering at the counter.",
            )

    clean_notes = (body.notes or "").strip()[:150]

    try:
        oids = [ObjectId(l.item_id) for l in body.items]
    except (InvalidId, TypeError):
        raise HTTPException(400, "Invalid item in order")
    menu_docs = {str(d["_id"]): d async for d in db.menu_items.find({"_id": {"$in": oids}})}
    lines: List[OrderLine] = []
    for l in body.items:
        m = menu_docs.get(l.item_id)
        if not m or not m.get("available", True):
            raise HTTPException(400, f"Item no longer available: {l.name or l.item_id}")
        qty = max(1, int(l.qty))
        station = m.get("station", "kitchen")

        # Resolve the price server-side (never trust the client's price) —
        # for a portion-variant dish, that means picking the matching
        # variant's price instead of the item's base `price`, which this
        # previously always fell back to regardless of which size was
        # picked. Falls back to the base price if the requested variant
        # can't be matched (e.g. stale cart from before the variant was
        # renamed/removed).
        line_price = float(m["price"])
        line_variant = None
        if l.variant:
            wanted = l.variant.strip().lower()
            matched = next(
                (v for v in (m.get("variants") or [])
                 if str(v.get("name") or v.get("label") or "").strip().lower() == wanted),
                None,
            )
            if matched and matched.get("price") is not None:
                line_price = float(matched["price"])
                line_variant = l.variant
            elif wanted in ("half", "single") and m.get("price_half") is not None:
                line_price = float(m["price_half"])
                line_variant = l.variant
            elif wanted == "full" and m.get("price_full") is not None:
                line_price = float(m["price_full"])
                line_variant = l.variant

        lines.append(OrderLine(
            item_id=l.item_id, name=m["name"], variant=line_variant,
            price=line_price, qty=qty, station=station,
        ))
    
    subtotal = round(sum(l.price * l.qty for l in lines), 2)
    
    # Calculate discount from coupon or custom discount
    discount_val = 0.0
    code_applied = ""
    if body.discount_code:
        coupon_doc = await db.coupons.find_one({"code": body.discount_code.upper().strip(), "active": True})
        if coupon_doc:
            c_chan = coupon_doc.get("channel", "both")
            if c_chan == "both" or c_chan == source:
                min_order = float(coupon_doc.get("min_order", 0.0))
                if subtotal >= min_order:
                    code_applied = coupon_doc["code"]
                    scope = coupon_doc.get("scope", "cart")
                    targets = set(coupon_doc.get("target_ids", []))
                    disc_type = coupon_doc.get("discount_type", "percent")
                    disc_val = float(coupon_doc.get("discount_value", 0.0))
                    max_disc = coupon_doc.get("max_discount")

                    if scope == "item" and targets:
                        app_base = sum(l.price * l.qty for l in lines if l.item_id in targets)
                    elif scope == "category" and targets:
                        app_base = sum(l.price * l.qty for l in lines if menu_docs.get(l.item_id, {}).get("category") in targets)
                    else:
                        app_base = subtotal

                    if disc_type == "percent":
                        discount_val = round(app_base * (disc_val / 100.0), 2)
                        if max_disc is not None and float(max_disc) > 0:
                            discount_val = min(discount_val, float(max_disc))
                    elif disc_type == "fixed":
                        discount_val = round(min(app_base, disc_val), 2)
                    elif disc_type == "freebie":
                        discount_val = 0.0
                        free_name = coupon_doc.get("freebie_item_name") or "Free Gift Item"
                        free_id = coupon_doc.get("freebie_item_id") or "freebie"
                        lines.append(OrderLine(item_id=free_id, name=f"FREE: {free_name}", price=0.0, qty=1, station="kitchen"))
    # Royalty Points Redemption (100 Coins Welcome: ₹25 off per order for first 4 orders above ₹249, 1 Coin = ₹1)
    points_redeemed = 0
    points_discount = 0.0
    if body.points_redeemed and body.points_redeemed > 0 and clean_phone:
        c_doc = await db.customers.find_one({"phone": clean_phone})
        if c_doc:
            avail_pts = int(c_doc.get("loyalty_points", 0))
            if avail_pts >= 25 and subtotal > LOYALTY_MIN_SUBTOTAL:
                # Welcome bonus / loyalty redemption: 25 coins for ₹25 off
                max_allowable = min(avail_pts, 25)
                points_redeemed = min(int(body.points_redeemed), max_allowable)
                points_discount = round(points_redeemed * LOYALTY_COIN_VALUE, 2)
            elif avail_pts >= LOYALTY_MIN_REDEEM and subtotal > LOYALTY_MIN_SUBTOTAL:
                max_pts_by_order = int(subtotal * LOYALTY_MAX_ORDER_PCT)
                max_allowable = min(avail_pts, max_pts_by_order, 25)
                points_redeemed = min(int(body.points_redeemed), max_allowable)
                points_discount = round(points_redeemed * LOYALTY_COIN_VALUE, 2)

    delivery_fee = 0.0
    if body.order_type == "delivery":
        # Over ₹499 is always FREE DELIVERY
        if subtotal >= 499.0:
            delivery_fee = 0.0
        elif body.delivery_fee > 0:
            delivery_fee = round(float(body.delivery_fee), 2)
        elif body.distance_km:
            d = float(body.distance_km)
            if d <= 2.0:
                delivery_fee = 20.0
            elif d <= 3.0:
                delivery_fee = 30.0
            elif d <= 4.0:
                delivery_fee = 40.0
            elif d <= 5.0:
                delivery_fee = 50.0

    total = round(max(0.0, subtotal - discount_val - points_discount + delivery_fee), 2)
    taxable_base = round(total / (1.0 + GST_RATE), 2)
    tax = round(total - taxable_base, 2)
    loyalty_pts = int(total // LOYALTY_EARN_RATIO)

    # Initial order status based on payment mode
    initial_status = "pending_payment" if body.payment_mode in ["razorpay", "online"] else "placed"

    biz_date_str = get_business_date_str()
    counter_id = f"order_seq_{biz_date_str}"

    for _ in range(10):
        counter = await db.counters.find_one_and_update(
            {"_id": counter_id}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER
        )
        seq_num = counter.get("seq", 1) if counter else 1
        order = Order(
            order_no=f"{biz_date_str}-{seq_num:04d}",
            customer_name=body.customer_name.strip() or "Guest",
            phone=clean_phone or body.phone,
            address=body.address.strip() if body.address else "",
            table_no=body.table_no.strip().upper() if body.table_no else "",
            order_type=body.order_type,
            payment_mode=body.payment_mode,
            status=initial_status,
            paid=False,
            notes=clean_notes,
            lat=body.lat,
            lng=body.lng,
            items=lines,
            source=source,
            subtotal=subtotal,
            discount_code=code_applied,
            discount=discount_val,
            points_redeemed=points_redeemed,
            points_discount=points_discount,
            delivery_fee=delivery_fee,
            distance_km=body.distance_km,
            tax=tax,
            total=total,
            loyalty_points_earned=loyalty_pts,
            created_at=datetime.now(timezone.utc).isoformat(),
            offline_no=body.offline_no,
        )
        try:
            res = await db.orders.insert_one(order.to_mongo())
        except DuplicateKeyError:
            continue
        order.id = str(res.inserted_id)

        # Apply loyalty points transactions & auto-save delivery address
        try:
            if clean_phone:
                # 1. Deduct redeemed points
                if points_redeemed > 0:
                    await log_loyalty_transaction(
                        clean_phone,
                        "redeem",
                        -points_redeemed,
                        order.order_no,
                        f"Redeemed {points_redeemed} Coins (₹{points_discount:.0f} off) on Order #{order.order_no}"
                    )
                # 2. Credit earned points if order is immediately placed (COD/Counter)
                if initial_status == "placed" and loyalty_pts > 0:
                    await log_loyalty_transaction(
                        clean_phone,
                        "earn",
                        loyalty_pts,
                        order.order_no,
                        f"Earned {loyalty_pts} Coins from Order #{order.order_no}"
                    )
                # 3. Auto-save delivery address
                if body.address and body.order_type == "delivery":
                    c_doc = await db.customers.find_one({"phone": clean_phone})
                    if c_doc:
                        existing_addrs = c_doc.get("addresses", [])
                        if not any((a.get("address") or "").strip().lower() == body.address.strip().lower() for a in existing_addrs):
                            new_addr = {
                                "id": str(uuid.uuid4())[:8],
                                "label": "Delivery Address",
                                "address": body.address.strip(),
                                "flat_landmark": "",
                                "lat": body.lat,
                                "lng": body.lng,
                                "is_default": len(existing_addrs) == 0,
                            }
                            await db.customers.update_one(
                                {"_id": c_doc["_id"]},
                                {"$push": {"addresses": new_addr}}
                            )
        except Exception as ex:
            logger.warning(f"Failed to process loyalty ledger / customer updates: {ex}")

        # Trigger real-time push notifications (for confirmed placed orders)
        if initial_status == "placed":
            try:
                # 1. Customer notification
                if order.phone:
                    asyncio.create_task(send_push_notification(
                        title="Order Received! ☕",
                        body=f"Order #{order.order_no} has been received by Hyderabadi Irani kitchen.",
                        target_phone=order.phone,
                        data={"order_id": order.id, "order_no": order.order_no, "status": "placed"}
                    ))
                # 2. Admin / CRM notification
                asyncio.create_task(send_push_notification(
                    title="🔔 New Order Placed!",
                    body=f"Order #{order.order_no} (₹{order.total:.0f}) · {order.order_type.capitalize()}",
                    target_role="admin",
                    data={"order_id": order.id, "order_no": order.order_no}
                ))
            except Exception as ex:
                logger.warning(f"[PUSH] Failed to trigger order creation push: {ex}")

        return order
    raise HTTPException(500, "Could not generate order number")


@api.post("/orders", response_model=Order)
async def create_pos_order(body: OrderIn, _: User = Depends(get_current_user), __: None = Depends(verify_csrf)):
    return await _build_order(body, "pos")


@api.post("/public/orders", response_model=Order)
async def create_online_order(body: OrderIn):
    return await _build_order(body, "online")


@api.get("/public/orders/{order_no}", response_model=Order)
async def track_order(order_no: str, phone: str):
    clean_no = order_no.strip()
    q_list = [{"order_no": clean_no.upper()}, {"order_no": clean_no}]
    if ObjectId.is_valid(clean_no):
        q_list.append({"_id": ObjectId(clean_no)})
    doc = await db.orders.find_one({"$or": q_list})
    if not doc:
        doc = await db.orders.find_one({"order_no": {"$regex": f"^{re.escape(clean_no)}$", "$options": "i"}})
    # The phone number the order was placed under must match — otherwise anyone
    # who guesses/enumerates an order number could see another customer's name,
    # address, and order details.
    if not doc or not norm_phone(phone) or norm_phone(doc.get("phone", "")) != norm_phone(phone):
        raise HTTPException(404, "Order not found")
    return Order.from_mongo(doc)


@api.get("/orders/{order_id_or_no}", response_model=Order)
async def get_order_by_id_or_no(order_id_or_no: str, phone: Optional[str] = None,
                                user: Optional[User] = Depends(get_optional_user),
                                customer: Optional[Customer] = Depends(get_optional_customer)):
    clean_no = order_id_or_no.strip()
    q_list = [{"order_no": clean_no.upper()}, {"order_no": clean_no}]
    if ObjectId.is_valid(clean_no):
        q_list.append({"_id": ObjectId(clean_no)})
    doc = await db.orders.find_one({"$or": q_list})
    if not doc:
        doc = await db.orders.find_one({"order_no": {"$regex": f"^{re.escape(clean_no)}$", "$options": "i"}})
    if not doc:
        raise HTTPException(404, "Order not found")
    # Staff/admin can look up any order. A logged-in customer or public caller
    # must prove they placed it by matching phone number, or (for the mobile
    # app) by being the customer whose phone the order was placed under —
    # otherwise anyone could enumerate order numbers/IDs to see other
    # customers' names, addresses, and order details.
    if user:
        return Order.from_mongo(doc)
    order_phone = norm_phone(doc.get("phone", ""))
    if customer and order_phone and order_phone == norm_phone(customer.phone or ""):
        return Order.from_mongo(doc)
    if phone and order_phone and order_phone == norm_phone(phone):
        return Order.from_mongo(doc)
    raise HTTPException(404, "Order not found")



@api.get("/orders", response_model=List[Order])
async def list_orders(status: Optional[str] = None, limit: int = 100, _: User = Depends(get_current_user)):
    q = {"status": status} if status else {}
    docs = await db.orders.find(q).sort("created_at", -1).to_list(limit)
    return [Order.from_mongo(d) for d in docs]


@api.get("/customers/lookup")
async def lookup_customer(phone: str, _: User = Depends(get_current_user)):
    np = norm_phone(phone)
    if not np or len(np) < 10:
        raise HTTPException(400, "Valid 10-digit phone number required")
    
    docs = await db.orders.find({"phone": {"$regex": np + "$"}}, {"customer_name": 1, "total": 1, "created_at": 1, "status": 1}).to_list(500)
    valid_orders = [d for d in docs if d.get("status") != "cancelled"]
    
    if not valid_orders:
        return {"found": False, "phone": np, "total_orders": 0, "total_spent": 0.0, "loyalty_points": 0}
    
    latest = max(valid_orders, key=lambda x: x.get("created_at", ""))
    total_spent = round(sum(float(d.get("total", 0.0)) for d in valid_orders), 2)
    loyalty_points = int(total_spent // 100)
    
    return {
        "found": True,
        "phone": np,
        "customer_name": latest.get("customer_name", "Guest"),
        "total_orders": len(valid_orders),
        "total_spent": total_spent,
        "loyalty_points": loyalty_points,
        "last_order_date": latest.get("created_at"),
    }


@api.get("/coupons/validate")
async def validate_coupon(code: str, subtotal: float = 0.0, channel: str = "both"):
    c = code.upper().strip()
    coupon = await db.coupons.find_one({"code": c, "active": True})
    if not coupon:
        raise HTTPException(404, "Invalid or expired coupon code")

    c_chan = coupon.get("channel", "both")
    if c_chan != "both" and channel != "both" and c_chan != channel:
        raise HTTPException(400, f"Offer {c} is only valid for {c_chan.upper()} orders")

    min_order = float(coupon.get("min_order", 0.0))
    if subtotal < min_order:
        raise HTTPException(400, f"Minimum order amount of ₹{min_order} required for offer {c}")

    disc_type = coupon.get("discount_type", "percent")
    disc_val = float(coupon.get("discount_value", 0.0))
    max_disc = coupon.get("max_discount")
    
    if disc_type == "percent":
        disc_amt = round(subtotal * (disc_val / 100.0), 2)
        if max_disc is not None and float(max_disc) > 0:
            disc_amt = min(disc_amt, float(max_disc))
    elif disc_type == "fixed":
        disc_amt = round(min(subtotal, disc_val), 2)
    elif disc_type == "freebie":
        disc_amt = 0.0

    taxable = max(0.0, subtotal - disc_amt)
    new_tax = round(taxable * GST_RATE, 2)
    new_total = round(taxable + new_tax, 2)
    
    return {
        "valid": True,
        "code": c,
        "title": coupon.get("title", c),
        "description": coupon.get("description", ""),
        "discount_type": disc_type,
        "discount_value": disc_val,
        "discount_amount": disc_amt,
        "scope": coupon.get("scope", "cart"),
        "target_ids": coupon.get("target_ids", []),
        "channel": c_chan,
        "freebie_item_id": coupon.get("freebie_item_id"),
        "freebie_item_name": coupon.get("freebie_item_name"),
        "tax": new_tax,
        "total": new_total,
    }


@api.get("/coupons", response_model=List[Coupon])
async def list_coupons(_: User = Depends(get_current_user)):
    docs = await db.coupons.find({}).to_list(100)
    return [Coupon.from_mongo(d) for d in docs]


@api.post("/coupons", response_model=Coupon)
async def create_coupon(body: CouponIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    c_code = body.code.upper().strip()
    existing = await db.coupons.find_one({"code": c_code})
    if existing:
        raise HTTPException(400, "Coupon/Offer code already exists")
    c = Coupon(**body.model_dump())
    c.code = c_code
    res = await db.coupons.insert_one(c.to_mongo())
    c.id = str(res.inserted_id)
    return c


@api.put("/coupons/{coupon_id}", response_model=Coupon)
async def update_coupon(coupon_id: str, body: CouponIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    oid = parse_object_id(coupon_id)
    upd = body.model_dump()
    upd["code"] = upd["code"].upper().strip()
    res = await db.coupons.find_one_and_update({"_id": oid}, {"$set": upd}, return_document=True)
    if not res:
        raise HTTPException(404, "Offer not found")
    return Coupon.from_mongo(res)


@api.delete("/coupons/{coupon_id}")
async def delete_coupon(coupon_id: str, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    oid = parse_object_id(coupon_id)
    res = await db.coupons.delete_one({"_id": oid})
    if res.deleted_count == 0:
        raise HTTPException(404, "Offer not found")
    return {"ok": True}


# ---------- Staff Management Endpoints ----------
@api.get("/staff")
async def list_staff(_: User = Depends(require_admin)):
    docs = await db.users.find({}).sort("created_at", -1).to_list(200)
    out = []
    for d in docs:
        u = User.from_mongo(d).model_dump()
        u["active"] = d.get("active", True)
        u["created_at"] = d.get("created_at")
        out.append(u)
    return out


@api.post("/staff")
async def create_staff(body: UserCreateIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    email = body.email.lower().strip()
    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(400, "User with this email already exists")
    doc = {
        "name": body.name,
        "email": email,
        "password_hash": hash_password(body.password),
        "role": body.role,
        "active": body.active,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "token_version": 0,
    }
    res = await db.users.insert_one(doc)
    doc["id"] = str(res.inserted_id)
    doc.pop("_id", None)
    doc.pop("password_hash", None)
    return doc


@api.put("/staff/{user_id}")
async def update_staff(user_id: str, body: UserUpdateIn, _: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    oid = parse_object_id(user_id)
    existing = await db.users.find_one({"_id": oid})
    if not existing:
        raise HTTPException(404, "Staff member not found")
    upd = {}
    if body.name is not None:
        upd["name"] = body.name
    if body.email is not None:
        new_e = body.email.lower().strip()
        dup = await db.users.find_one({"email": new_e, "_id": {"$ne": oid}})
        if dup:
            raise HTTPException(400, "Another user with this email already exists")
        upd["email"] = new_e
    if body.password:
        upd["password_hash"] = hash_password(body.password)
        upd["token_version"] = existing.get("token_version", 0) + 1
    if body.role is not None:
        upd["role"] = body.role
    if body.active is not None:
        upd["active"] = body.active

    if upd:
        await db.users.update_one({"_id": oid}, {"$set": upd})
    doc = await db.users.find_one({"_id": oid})
    doc["id"] = str(doc.pop("_id"))
    doc.pop("password_hash", None)
    return doc


@api.delete("/staff/{user_id}")
async def delete_staff(user_id: str, admin: User = Depends(require_admin), __: None = Depends(verify_csrf)):
    oid = parse_object_id(user_id)
    if str(oid) == admin.id:
        raise HTTPException(400, "Cannot delete your own admin account")
    res = await db.users.delete_one({"_id": oid})
    if res.deleted_count == 0:
        raise HTTPException(404, "Staff member not found")
    await db.driver_locations.delete_many({"driver_id": str(oid)})
    return {"ok": True}



# ---------- Delivery Partner Endpoints ----------
@api.get("/delivery/orders", response_model=List[Order])
async def list_delivery_orders(user: User = Depends(require_role("delivery", "admin"))):
    # Returns orders available for pickup (status: ready & order_type: delivery) OR assigned to this driver
    query = {
        "$or": [
            {"status": "ready", "order_type": "delivery", "driver_id": None},
            {"driver_id": user.id},
        ]
    }
    docs = await db.orders.find(query).sort("created_at", -1).to_list(100)
    return [Order.from_mongo(d) for d in docs]


@api.put("/delivery/orders/{order_id}/accept", response_model=Order)
async def accept_delivery_order(order_id: str, user: User = Depends(require_role("delivery", "admin")),
                                __: None = Depends(verify_csrf)):
    oid = parse_object_id(order_id)
    doc = await db.orders.find_one({"_id": oid})
    if not doc:
        raise HTTPException(404, "Order not found")

    upd = {
        "driver_id": user.id,
        "driver_name": user.name,
        "driver_phone": getattr(user, "phone", "8331807704") or "8331807704",
        "status": "out_for_delivery"
    }
    updated = await db.orders.find_one_and_update({"_id": oid}, {"$set": upd}, return_document=True)

    # Push Notification to customer
    if updated.get("phone"):
        asyncio.create_task(send_push_notification(
            title="🛵 Out for Delivery!",
            body=f"Your delivery partner {user.name} is on the way with Order #{updated.get('order_no')}.",
            target_phone=updated.get("phone"),
            data={"order_id": str(updated["_id"]), "order_no": updated.get("order_no"), "status": "out_for_delivery"}
        ))

    return Order.from_mongo(updated)


@api.put("/delivery/location")
async def update_driver_live_location(body: DriverLocationIn,
                                      user: User = Depends(require_role("delivery", "admin"))):
    now = datetime.now(timezone.utc).isoformat()
    doc = {
        "driver_id": user.id,
        "driver_name": user.name,
        "driver_phone": getattr(user, "phone", "8331807704") or "8331807704",
        "lat": body.lat,
        "lng": body.lng,
        "speed": body.speed,
        "heading": body.heading,
        "battery": body.battery,
        "status": body.status or "online",
        "updated_at": now,
    }
    await db.driver_locations.update_one({"driver_id": user.id}, {"$set": doc}, upsert=True)

    # Also update any active out_for_delivery orders for this driver
    await db.orders.update_many(
        {"driver_id": user.id, "status": "out_for_delivery"},
        {"$set": {"driver_lat": body.lat, "driver_lng": body.lng, "driver_last_seen": now}}
    )
    return {"ok": True, "updated_at": now}


@api.get("/admin/drivers/locations")
async def list_live_drivers(user: User = Depends(require_role("admin", "staff"))):
    # Fetch only active staff members with role 'delivery' or 'driver'
    active_drivers_cursor = db.users.find({
        "role": {"$in": ["delivery", "driver"]},
        "active": {"$ne": False}
    })
    valid_driver_users = await active_drivers_cursor.to_list(100)
    valid_driver_map = {str(u["_id"]): u for u in valid_driver_users}
    valid_driver_ids = list(valid_driver_map.keys())

    # Fetch driver location documents for valid active drivers only
    cursor = db.driver_locations.find({"driver_id": {"$in": valid_driver_ids}}).sort("updated_at", -1)
    driver_locs = await cursor.to_list(50)
    loc_by_id = {d.get("driver_id"): d for d in driver_locs}

    # Find active out_for_delivery orders
    active_orders_cursor = db.orders.find({"status": "out_for_delivery"})
    active_orders = await active_orders_cursor.to_list(100)

    orders_by_driver = {}
    for o in active_orders:
        did = o.get("driver_id")
        if did:
            if did not in orders_by_driver:
                orders_by_driver[did] = []
            orders_by_driver[did].append({
                "id": str(o["_id"]),
                "order_no": o.get("order_no"),
                "customer_name": o.get("customer_name") or o.get("name"),
                "customer_phone": o.get("customer_phone") or o.get("phone"),
                "delivery_address": o.get("delivery_address") or o.get("address"),
                "lat": o.get("lat"),
                "lng": o.get("lng"),
                "total": o.get("total"),
                "status": o.get("status"),
                "created_at": o.get("created_at")
            })

    result = []
    for did, u in valid_driver_map.items():
        loc = loc_by_id.get(did)
        d_data = {
            "driver_id": did,
            "driver_name": u.get("name", "Delivery Partner"),
            "driver_phone": getattr(u, "phone", "8331807704") if isinstance(u, dict) else "8331807704",
            "lat": loc.get("lat", STORE_LAT) if loc else STORE_LAT,
            "lng": loc.get("lng", STORE_LNG) if loc else STORE_LNG,
            "speed": loc.get("speed", 0) if loc else 0,
            "heading": loc.get("heading", 0) if loc else 0,
            "battery": loc.get("battery", 85) if loc else 85,
            "status": "online",
            "updated_at": loc.get("updated_at") if loc else u.get("created_at"),
        }
        d_data["active_orders"] = orders_by_driver.get(did, [])
        if d_data["active_orders"]:
            d_data["status"] = "out_for_delivery"
        result.append(d_data)

    return {"ok": True, "drivers": result, "count": len(result)}


@api.put("/delivery/orders/{order_id}/location")
async def update_driver_location(order_id: str, body: DriverLocationIn,
                                 user: User = Depends(require_role("delivery", "admin"))):
    oid = parse_object_id(order_id)
    now = datetime.now(timezone.utc).isoformat()
    res = await db.orders.update_one(
        {"_id": oid, "driver_id": user.id},
        {"$set": {"driver_lat": body.lat, "driver_lng": body.lng, "driver_last_seen": now}}
    )
    if res.matched_count == 0:
        raise HTTPException(404, "Order not found or not assigned to driver")

    # Also update general driver location document
    doc = {
        "driver_id": user.id,
        "driver_name": user.name,
        "driver_phone": getattr(user, "phone", "8331807704") or "8331807704",
        "lat": body.lat,
        "lng": body.lng,
        "speed": body.speed,
        "heading": body.heading,
        "battery": body.battery,
        "status": "out_for_delivery",
        "updated_at": now,
    }
    await db.driver_locations.update_one({"driver_id": user.id}, {"$set": doc}, upsert=True)
    return {"ok": True, "lat": body.lat, "lng": body.lng}


@api.put("/delivery/orders/{order_id}/delivered", response_model=Order)
async def mark_order_delivered(order_id: str, user: User = Depends(require_role("delivery", "admin")),
                               __: None = Depends(verify_csrf)):
    oid = parse_object_id(order_id)
    doc = await db.orders.find_one_and_update(
        {"_id": oid, "driver_id": user.id},
        {"$set": {"status": "completed", "paid": True}},
        return_document=True
    )
    if not doc:
        raise HTTPException(404, "Order not found or not assigned to driver")

    # Push Notification to customer
    if doc.get("phone"):
        asyncio.create_task(send_push_notification(
            title="☕ Order Delivered!",
            body=f"Order #{doc.get('order_no')} has been delivered! Enjoy your authentic Irani food.",
            target_phone=doc.get("phone"),
            data={"order_id": str(doc["_id"]), "order_no": doc.get("order_no"), "status": "completed"}
        ))

    return Order.from_mongo(doc)


@api.put("/orders/{order_id}/status", response_model=Order)
async def update_status(order_id: str, body: StatusIn, _: User = Depends(get_current_user),
                        __: None = Depends(verify_csrf)):
    allowed = {"placed", "preparing", "ready", "out_for_delivery", "served", "delivered", "completed", "cancelled"}
    if body.status not in allowed:
        raise HTTPException(400, "Invalid status")
    
    clean = order_id.strip()
    q_list = [{"order_no": clean.upper()}, {"order_no": clean}]
    if ObjectId.is_valid(clean):
        q_list.append({"_id": ObjectId(clean)})
    existing = await db.orders.find_one({"$or": q_list})
    if not existing:
        raise HTTPException(404, "Order not found")
    
    upd = {"status": body.status}
    if body.status in ["completed", "delivered", "served"] and existing.get("payment_mode") != "razorpay":
        upd["paid"] = True
    
    doc = await db.orders.find_one_and_update({"_id": existing["_id"]}, {"$set": upd}, return_document=True)

    # Push Notification to customer on status progression
    if doc.get("status") != existing.get("status"):
        st = body.status
        ord_no = doc.get("order_no", "")
        tbl = doc.get("table_no", "")
        is_delivery = doc.get("order_type") == "delivery"

        status_messages = {
            "preparing": ("🍳 Cooking Fresh!", f"Chef is now preparing your delicious food for Order #{ord_no}."),
            "ready": ("✨ Order is Ready & Packed!", f"Order #{ord_no} is packed and ready for dispatch/pickup!"),
            "out_for_delivery": ("🛵 Out for Delivery!", f"Your delivery partner is heading to your doorstep with Order #{ord_no}."),
            "served": ("🍽️ Food Served!", f"Hot food served to Table {tbl} for Order #{ord_no}! Enjoy your meal."),
            "delivered": ("☕ Order Delivered!", f"Order #{ord_no} delivered. Enjoy your authentic Hyderabadi Irani food!"),
            "completed": ("☕ Order Completed!", f"Order #{ord_no} is completed. Thank you for choosing Hyderabadi Irani!"),
            "cancelled": ("Order Cancelled", f"Order #{ord_no} has been cancelled."),
        }
        title, msg = status_messages.get(st, ("Order Update", f"Order #{ord_no} status is now {st}."))

        if doc.get("phone"):
            asyncio.create_task(send_push_notification(
                title=title,
                body=msg,
                target_phone=doc.get("phone"),
                data={"order_id": str(doc["_id"]), "order_no": ord_no, "status": st}
            ))

        # Push notification to drivers when an order is ready for delivery
        if st == "ready" and is_delivery:
            asyncio.create_task(send_push_notification(
                title="🛵 Delivery Order Ready for Pickup!",
                body=f"Order #{ord_no} (₹{doc.get('total', 0):.0f}) is packed and waiting for delivery partner.",
                target_role="delivery",
                data={"order_id": str(doc["_id"]), "order_no": ord_no, "status": "ready"}
            ))

    return Order.from_mongo(doc)


@api.get("/kitchen/queue", response_model=List[Order])
async def kitchen_queue(_: User = Depends(get_current_user)):
    docs = await db.orders.find({"status": {"$in": ["placed", "preparing", "ready"]}}).sort("created_at", 1).to_list(200)
    return [Order.from_mongo(d) for d in docs]


@api.get("/stats")
async def stats(_: User = Depends(require_admin)):
    today = datetime.now(timezone.utc).date().isoformat()
    docs = await db.orders.find({}).to_list(2000)
    todays = [d for d in docs if str(d.get("created_at", "")).startswith(today)]
    by_day: dict = {}
    for d in docs:
        day = str(d.get("created_at", ""))[:10]
        by_day[day] = round(by_day.get(day, 0) + float(d.get("total", 0)), 2)
    top: dict = {}
    for d in docs:
        for l in d.get("items", []):
            top[l["name"]] = top.get(l["name"], 0) + l["qty"]
    return {
        "today_revenue": round(sum(float(d.get("total", 0)) for d in todays), 2),
        "today_orders": len(todays),
        "total_revenue": round(sum(float(d.get("total", 0)) for d in docs), 2),
        "total_orders": len(docs),
        "open_orders": len([d for d in docs if d.get("status") in ("placed", "preparing", "ready")]),
        "avg_order_value": round(sum(float(d.get("total", 0)) for d in docs) / len(docs), 2) if docs else 0,
        "revenue_by_day": [{"day": k, "revenue": v} for k, v in sorted(by_day.items())[-7:]],
        "top_items": [{"name": k, "qty": v} for k, v in sorted(top.items(), key=lambda x: -x[1])[:5]],
    }


@api.get("/reports/export/orders.csv")
async def export_orders_csv(date: Optional[str] = None, _: User = Depends(require_admin)):
    """
    Exports daily orders with customer, item, and revenue breakdown in CSV format for Excel analysis.
    """
    q: dict = {}
    if date:
        q["created_at"] = {"$regex": f"^{date}"}

    docs = await db.orders.find(q).sort("created_at", -1).to_list(5000)

    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        "Order No",
        "Date Time (UTC)",
        "Customer Name",
        "Phone",
        "Order Type",
        "Table No",
        "Payment Mode",
        "Paid",
        "Status",
        "Items Summary",
        "Subtotal (Rs)",
        "Coupon Discount (Rs)",
        "Points Redeemed",
        "Points Discount (Rs)",
        "Delivery Fee (Rs)",
        "Tax (Rs)",
        "Total Amount (Rs)",
        "Loyalty Points Earned",
        "Cooking Notes",
    ])

    for d in docs:
        items_summary = "; ".join([f"{l.get('qty', 1)}x {l.get('name', '')}" for l in d.get("items", [])])
        writer.writerow([
            d.get("order_no", ""),
            d.get("created_at", "")[:19].replace("T", " "),
            d.get("customer_name", ""),
            d.get("phone", ""),
            d.get("order_type", ""),
            d.get("table_no", ""),
            d.get("payment_mode", ""),
            "Yes" if d.get("paid") else "No",
            d.get("status", ""),
            items_summary,
            f"{float(d.get('subtotal', 0)):.2f}",
            f"{float(d.get('discount', 0)):.2f}",
            d.get("points_redeemed", 0),
            f"{float(d.get('points_discount', 0)):.2f}",
            f"{float(d.get('delivery_fee', 0)):.2f}",
            f"{float(d.get('tax', 0)):.2f}",
            f"{float(d.get('total', 0)):.2f}",
            d.get("loyalty_points_earned", 0),
            d.get("notes", ""),
        ])

    output.seek(0)
    filename = f"orders_export_{date or 'all'}.csv"
    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )


HOTEL_NAME = "HYDERABADI IRANI FOOD COURT"
HOTEL_LINE = (
    "Plot no 38 Chandra Properties, Ayyappa Nagar Colony, Ghatkesar Road, Rampally, "
    "Secunderabad, Telangana 501302  |  Mobile: +91 8331807704  |  GSTIN: 36BLUPM3251R1Z6  |  FSSAI: 23625033000700"
)


def _pdf_head(c, title: str, subtitle: str, title_size: int = 18) -> float:
    w, h = A4
    y = h - 25 * mm
    c.setFont("Helvetica-Bold", title_size)
    c.drawString(20 * mm, y, title)
    c.setFont("Helvetica", 9)
    c.drawString(20 * mm, y - 6 * mm, subtitle)
    c.line(20 * mm, y - 10 * mm, w - 20 * mm, y - 10 * mm)
    return y - 22 * mm


def _pdf_footer(c):
    c.setFont("Helvetica-Bold", 8)
    c.drawString(20 * mm, 15 * mm, "HYDERABADI IRANI  |  Powered by NovaSaaS")
    c.setFont("Helvetica-Oblique", 8)
    c.drawRightString(A4[0] - 20 * mm, 15 * mm, f"Generated {datetime.now(timezone.utc).strftime('%d-%m-%Y %H:%M')} UTC")


# ---------- Kitchen Order Ticket (KOT) ----------
@api.get("/kot/{order_no}")
async def kot_pdf(order_no: str, _: User = Depends(get_current_user)):
    doc = await db.orders.find_one({"order_no": order_no.upper()})
    if not doc:
        raise HTTPException(404, "Order not found")
    o = Order.from_mongo(doc)
    width = 80 * mm
    # Calculate dynamic height based on lines and cooking notes
    extra_notes_lines = sum(1 for l in o.items if getattr(l, "notes", None)) + (1 if o.notes else 0)
    height = (75 + 8 * len(o.items) + 6 * extra_notes_lines) * mm
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(width, height))
    y = height - 10 * mm
    c.setFont("Helvetica-Bold", 13)
    c.drawCentredString(width / 2, y, "KITCHEN ORDER TICKET")
    y -= 6 * mm
    c.setFont("Helvetica", 8)
    c.drawCentredString(width / 2, y, "Hyderabadi Irani")
    y -= 5 * mm
    c.setDash(1, 2)
    c.line(5 * mm, y, width - 5 * mm, y)
    c.setDash()
    y -= 7 * mm
    c.setFont("Helvetica-Bold", 11)
    c.drawString(5 * mm, y, o.order_no)
    c.setFont("Helvetica", 9)
    c.drawRightString(width - 5 * mm, y, o.created_at[11:16])
    y -= 6 * mm
    c.drawString(5 * mm, y, f"{o.order_type.upper()}{'  TABLE ' + o.table_no if o.table_no else ''}")
    y -= 5 * mm
    c.drawString(5 * mm, y, f"Guest: {o.customer_name[:26]}")
    y -= 5 * mm
    c.setDash(1, 2)
    c.line(5 * mm, y, width - 5 * mm, y)
    c.setDash()
    y -= 8 * mm
    for l in o.items:
        c.setFont("Helvetica-Bold", 12)
        c.drawString(5 * mm, y, f"{l.qty} x")
        c.drawString(18 * mm, y, l.name[:24])
        y -= 6 * mm
        if getattr(l, "notes", None):
            c.setFont("Helvetica-Oblique", 9)
            c.drawString(18 * mm, y, f">> Note: {l.notes[:32]}")
            y -= 5 * mm
        y -= 2 * mm
    if o.notes:
        c.setFont("Helvetica-Oblique", 9)
        c.drawString(5 * mm, y, f"Order Note: {o.notes[:38]}")
        y -= 6 * mm
    c.setFont("Helvetica-Bold", 8)
    c.drawCentredString(width / 2, 8 * mm, "Powered by NovaSaaS")
    c.setFont("Helvetica", 7)
    c.drawCentredString(width / 2, 4 * mm, f"printed {datetime.now(timezone.utc).strftime('%d-%m-%Y %H:%M')}")
    c.showPage()
    c.save()
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf", headers={
        "Content-Disposition": f'inline; filename="kot-{o.order_no}.pdf"'})


# ---------- Day-end report ----------
async def _day_summary(day: str) -> dict:
    pipeline = [
        {"$match": {"created_at": {"$regex": f"^{day}"}}},
        {"$facet": {
            "all_docs": [
                {"$project": {"status": 1, "subtotal": 1, "tax": 1, "total": 1, "payment_mode": 1, "source": 1}}
            ],
            "totals": [
                {"$match": {"status": {"$ne": "cancelled"}}},
                {"$group": {
                    "_id": None,
                    "orders": {"$sum": 1},
                    "subtotal": {"$sum": "$subtotal"},
                    "tax": {"$sum": "$tax"},
                    "total": {"$sum": "$total"}
                }}
            ],
            "by_payment": [
                {"$match": {"status": {"$ne": "cancelled"}}},
                {"$group": {"_id": "$payment_mode", "amount": {"$sum": "$total"}}}
            ],
            "by_source": [
                {"$match": {"status": {"$ne": "cancelled"}}},
                {"$group": {"_id": "$source", "amount": {"$sum": "$total"}}}
            ],
            "top_items": [
                {"$match": {"status": {"$ne": "cancelled"}}},
                {"$unwind": "$items"},
                {"$group": {"_id": "$items.name", "qty": {"$sum": "$items.qty"}}},
                {"$sort": {"qty": -1}},
                {"$limit": 10}
            ]
        }}
    ]
    res = await db.orders.aggregate(pipeline).to_list(1)
    data = res[0] if res else {}
    
    all_docs = data.get("all_docs", [])
    cancelled_count = len([d for d in all_docs if d.get("status") == "cancelled"])
    
    totals_list = data.get("totals", [])
    totals = totals_list[0] if totals_list else {"orders": 0, "subtotal": 0.0, "tax": 0.0, "total": 0.0}
    
    orders_cnt = totals.get("orders", 0)
    sub_val = round(float(totals.get("subtotal", 0.0)), 2)
    tax_val = round(float(totals.get("tax", 0.0)), 2)
    tot_val = round(float(totals.get("total", 0.0)), 2)
    avg_val = round(tot_val / orders_cnt, 2) if orders_cnt > 0 else 0.0

    by_pay = [{"mode": str(r["_id"] or "cash"), "amount": round(float(r["amount"]), 2)} for r in sorted(data.get("by_payment", []), key=lambda x: str(x["_id"]))]
    by_src = [{"source": str(r["_id"] or "pos"), "amount": round(float(r["amount"]), 2)} for r in sorted(data.get("by_source", []), key=lambda x: str(x["_id"]))]
    top_i = [{"name": str(r["_id"]), "qty": int(r["qty"])} for r in data.get("top_items", [])]

    return {
        "date": day,
        "orders": orders_cnt,
        "cancelled": cancelled_count,
        "subtotal": sub_val,
        "tax": tax_val,
        "total": tot_val,
        "avg_order_value": avg_val,
        "by_payment": by_pay,
        "by_source": by_src,
        "top_items": top_i,
    }


@api.get("/reports/day-end")
async def day_end(date: Optional[str] = None, _: User = Depends(require_admin)):
    day = date or datetime.now(timezone.utc).date().isoformat()
    return await _day_summary(day)


@api.get("/reports/day-end.pdf")
async def day_end_pdf(date: Optional[str] = None, _: User = Depends(require_admin)):
    day = date or datetime.now(timezone.utc).date().isoformat()
    s = await _day_summary(day)
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    y = _pdf_head(c, "DAY-END SALES REPORT",
                  f"Hyderabadi Irani Food Court  |  GSTIN: 36BLUPM3251R1Z6  |  Business date: {day}")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20 * mm, y, "SUMMARY")
    y -= 8 * mm
    c.setFont("Helvetica", 10)
    for label, val in [
        ("Orders billed", s["orders"]), ("Orders cancelled", s["cancelled"]),
        ("Net sales (pre-tax)", f"Rs {s['subtotal']:.2f}"), ("GST collected", f"Rs {s['tax']:.2f}"),
        ("Gross collection", f"Rs {s['total']:.2f}"), ("Average order value", f"Rs {s['avg_order_value']:.2f}"),
    ]:
        c.drawString(22 * mm, y, str(label))
        c.drawRightString(110 * mm, y, str(val))
        y -= 6 * mm
    for title, rows, kf in [("BY PAYMENT MODE", s["by_payment"], "mode"), ("BY CHANNEL", s["by_source"], "source")]:
        y -= 8 * mm
        c.setFont("Helvetica-Bold", 12)
        c.drawString(20 * mm, y, title)
        y -= 8 * mm
        c.setFont("Helvetica", 10)
        if not rows:
            c.drawString(22 * mm, y, "No sales")
            y -= 6 * mm
        for r in rows:
            c.drawString(22 * mm, y, str(r[kf]).upper())
            c.drawRightString(110 * mm, y, f"Rs {r['amount']:.2f}")
            y -= 6 * mm
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20 * mm, y, "TOP ITEMS SOLD")
    y -= 8 * mm
    c.setFont("Helvetica", 10)
    if not s["top_items"]:
        c.drawString(22 * mm, y, "No items sold")
    for t in s["top_items"]:
        c.drawString(22 * mm, y, t["name"][:48])
        c.drawRightString(110 * mm, y, str(t["qty"]))
        y -= 6 * mm
    _pdf_footer(c)
    c.showPage()
    c.save()
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="day-end-{day}.pdf"'})


async def _gst_monthly(m: str) -> dict:
    pipeline = [
        {"$match": {"created_at": {"$regex": f"^{m}"}, "status": {"$ne": "cancelled"}}},
        {"$project": {
            "day": {"$substr": ["$created_at", 0, 10]},
            "subtotal": "$subtotal",
            "tax": "$tax",
            "total": "$total"
        }},
        {"$group": {
            "_id": "$day",
            "orders": {"$sum": 1},
            "subtotal": {"$sum": "$subtotal"},
            "tax": {"$sum": "$tax"},
            "total": {"$sum": "$total"}
        }},
        {"$sort": {"_id": 1}}
    ]
    raw_days = await db.orders.aggregate(pipeline).to_list(35)
    rows = []
    tot_orders = 0
    tot_sub = 0.0
    tot_tax = 0.0
    tot_gross = 0.0

    for d in raw_days:
        day_str = str(d["_id"])
        ord_cnt = int(d["orders"])
        sub_v = round(float(d["subtotal"]), 2)
        tax_v = round(float(d["tax"]), 2)
        tot_v = round(float(d["total"]), 2)
        rows.append({
            "day": day_str,
            "orders": ord_cnt,
            "subtotal": sub_v,
            "tax": tax_v,
            "total": tot_v
        })
        tot_orders += ord_cnt
        tot_sub += sub_v
        tot_tax += tax_v
        tot_gross += tot_v

    return {
        "month": m,
        "gst_rate": GST_RATE,
        "orders": tot_orders,
        "subtotal": round(tot_sub, 2),
        "tax": round(tot_tax, 2),
        "total": round(tot_gross, 2),
        "days": rows,
    }


@api.get("/reports/gst-monthly")
async def gst_monthly(month: Optional[str] = None, _: User = Depends(require_admin)):
    return await _gst_monthly(month or datetime.now(timezone.utc).strftime("%Y-%m"))


@api.get("/reports/gst-monthly.pdf")
async def gst_monthly_pdf(month: Optional[str] = None, _: User = Depends(require_admin)):
    m = month or datetime.now(timezone.utc).strftime("%Y-%m")
    s = await _gst_monthly(m)
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    y = _pdf_head(c, "MONTHLY GST STATEMENT",
                  f"Hyderabadi Irani Food Court  |  GSTIN: 36BLUPM3251R1Z6  |  Period: {m}  |  Rate: {int(GST_RATE * 100)}%")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20 * mm, y, "MONTH TOTALS")
    y -= 8 * mm
    c.setFont("Helvetica", 10)
    for label, val in [("Orders billed", s["orders"]), ("Taxable value", f"Rs {s['subtotal']:.2f}"),
                       ("GST payable", f"Rs {s['tax']:.2f}"), ("Gross collection", f"Rs {s['total']:.2f}")]:
        c.drawString(22 * mm, y, str(label))
        c.drawRightString(110 * mm, y, str(val))
        y -= 6 * mm
    y -= 10 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20 * mm, y, "DAY-WISE BREAKDOWN")
    y -= 9 * mm

    def header(yy):
        c.setFont("Helvetica-Bold", 9)
        c.drawString(20 * mm, yy, "DATE")
        c.drawRightString(85 * mm, yy, "ORDERS")
        c.drawRightString(120 * mm, yy, "TAXABLE")
        c.drawRightString(155 * mm, yy, "GST")
        c.drawRightString(w - 20 * mm, yy, "GROSS")
        c.line(20 * mm, yy - 2 * mm, w - 20 * mm, yy - 2 * mm)
        c.setFont("Helvetica", 9)
        return yy - 8 * mm

    y = header(y)
    for r in s["days"]:
        if y < 25 * mm:
            c.showPage()
            y = header(h - 25 * mm)
        c.drawString(20 * mm, y, r["day"])
        c.drawRightString(85 * mm, y, str(r["orders"]))
        c.drawRightString(120 * mm, y, f"{r['subtotal']:.2f}")
        c.drawRightString(155 * mm, y, f"{r['tax']:.2f}")
        c.drawRightString(w - 20 * mm, y, f"{r['total']:.2f}")
        y -= 6 * mm
    if not s["days"]:
        c.drawString(20 * mm, y, "No sales recorded in this period")
        y -= 6 * mm
    c.line(20 * mm, y + 2 * mm, w - 20 * mm, y + 2 * mm)
    y -= 5 * mm
    c.setFont("Helvetica-Bold", 10)
    c.drawString(20 * mm, y, "TOTAL")
    c.drawRightString(85 * mm, y, str(s["orders"]))
    c.drawRightString(120 * mm, y, f"{s['subtotal']:.2f}")
    c.drawRightString(155 * mm, y, f"{s['tax']:.2f}")
    c.drawRightString(w - 20 * mm, y, f"{s['total']:.2f}")
    _pdf_footer(c)
    c.showPage()
    _pdf_footer(c)
    buf.seek(0)
    return Response(content=buf.getvalue(), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="gst_statement_{m}.pdf"'})


class TableStatusUpdateIn(BaseModel):
    status: str


@api.get("/tables")
async def get_tables():
    # Return list of 50 tables, seeding if empty
    tables = await db.tables.find({}).sort("table_no", 1).to_list(100)
    if not tables:
        seed_tables = []
        for i in range(1, 51):
            t_no = f"T-{i:02d}"
            seed_tables.append({
                "table_no": t_no,
                "status": "available",
                "capacity": 4,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
        await db.tables.insert_many(seed_tables)
        tables = await db.tables.find({}).sort("table_no", 1).to_list(100)

    # Attach active order info for occupied tables
    active_orders = await db.orders.find({"status": {"$in": ["placed", "accepted", "preparing"]}}).to_list(100)
    order_by_table = {o.get("table_no"): o for o in active_orders if o.get("table_no")}

    result = []
    for t in tables:
        t_id = str(t["_id"])
        t_no = t.get("table_no")
        act_ord = order_by_table.get(t_no)
        result.append({
            "id": t_id,
            "table_no": t_no,
            "status": t.get("status", "available"),
            "capacity": t.get("capacity", 4),
            "active_order": {
                "order_no": act_ord.get("order_no", act_ord.get("offline_id", "")),
                "total": act_ord.get("total", 0),
                "status": act_ord.get("status", "")
            } if act_ord else None
        })
    return result


@api.put("/tables/{table_no}/status")
async def update_table_status(table_no: str, body: TableStatusUpdateIn):
    status_clean = body.status.lower().strip()
    if status_clean not in ["available", "occupied", "reserved"]:
        raise HTTPException(400, "Invalid table status. Must be 'available', 'occupied', or 'reserved'")

    await db.tables.update_one(
        {"table_no": table_no},
        {"$set": {"status": status_clean, "updated_at": datetime.now(timezone.utc).isoformat()}},
        upsert=True
    )
    return {"ok": True, "table_no": table_no, "status": status_clean}


# ---------- Razorpay ----------
def razorpay_client():
    key_id = os.environ.get("RAZORPAY_KEY_ID", "")
    key_secret = os.environ.get("RAZORPAY_KEY_SECRET", "")
    if not key_id or not key_secret:
        raise HTTPException(503, "Online payment is not configured yet. Please pay by cash on delivery.")
    return razorpay.Client(auth=(key_id, key_secret))


class RzpVerifyIn(BaseModel):
    order_no: str
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str


@api.get("/payments/config")
async def payment_config():
    key_id = os.environ.get("RAZORPAY_KEY_ID", "")
    return {"razorpay_enabled": bool(key_id and os.environ.get("RAZORPAY_KEY_SECRET")), "key_id": key_id}


class RzpOrderIn(BaseModel):
    order_no: str


@api.post("/payments/razorpay/order")
async def razorpay_order(body: RzpOrderIn):
    order_no = body.order_no.upper()
    doc = await db.orders.find_one({"order_no": order_no})
    if not doc:
        raise HTTPException(404, "Order not found")
    if doc.get("paid"):
        raise HTTPException(400, "Order is already paid")
    client_rzp = razorpay_client()
    rzp = client_rzp.order.create({
        "amount": int(round(float(doc["total"]) * 100)),
        "currency": "INR",
        "receipt": order_no[:40],
        "payment_capture": 1,
    })
    await db.orders.update_one({"order_no": order_no}, {"$set": {"razorpay_order_id": rzp["id"]}})
    return {"razorpay_order_id": rzp["id"], "amount": rzp["amount"], "currency": rzp["currency"],
            "key_id": os.environ["RAZORPAY_KEY_ID"]}


class PaymentAttemptIn(BaseModel):
    order_no: str
    status: str  # attempted | failed | cancelled | timeout
    payment_id: Optional[str] = None
    error_code: Optional[str] = None
    error_description: Optional[str] = None


@api.post("/payments/log-attempt")
async def log_payment_attempt(body: PaymentAttemptIn):
    """
    Logs payment attempt/failure for reconciliation without storing sensitive card/CVV data.
    """
    doc = {
        "order_no": body.order_no.upper().strip(),
        "status": body.status,
        "payment_id": body.payment_id,
        "error_code": body.error_code,
        "error_description": body.error_description,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    await db.payment_logs.insert_one(doc)
    logger.info(f"[PAYMENT] Logged attempt for order #{body.order_no}: {body.status} ({body.error_code or 'none'})")
    return {"ok": True}


@api.put("/orders/{order_no}/switch-to-cod")
async def switch_order_to_cod(order_no: str):
    """
    Converts a pending online payment order to Cash on Delivery without creating a duplicate order.
    """
    ord_clean = order_no.upper().strip()
    existing = await db.orders.find_one({"order_no": ord_clean})
    if not existing:
        raise HTTPException(404, "Order not found")
    if existing.get("paid"):
        raise HTTPException(400, "Order is already paid")

    doc = await db.orders.find_one_and_update(
        {"order_no": ord_clean},
        {"$set": {"payment_mode": "cash", "status": "placed", "updated_at": datetime.now(timezone.utc).isoformat()}},
        return_document=True
    )

    # Trigger push notifications for confirmed COD order
    try:
        if doc.get("phone"):
            asyncio.create_task(send_push_notification(
                title="Order Confirmed (Cash on Delivery) ☕",
                body=f"Order #{doc.get('order_no')} has been confirmed. Please pay ₹{doc.get('total', 0):.0f} at delivery.",
                target_phone=doc.get("phone"),
                data={"order_id": str(doc["_id"]), "order_no": doc.get("order_no"), "status": "placed"}
            ))
        asyncio.create_task(send_push_notification(
            title="🔔 New COD Order Placed!",
            body=f"Order #{doc.get('order_no')} (₹{doc.get('total', 0):.0f}) · {doc.get('order_type', '').capitalize()}",
            target_role="admin",
            data={"order_id": str(doc["_id"]), "order_no": doc.get("order_no")}
        ))
    except Exception as ex:
        logger.warning(f"[PUSH] Failed to send COD switch notification: {ex}")

    # Log switch to payment logs
    await db.payment_logs.insert_one({
        "order_no": ord_clean,
        "status": "switched_to_cod",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })

    # Credit earned loyalty points
    try:
        pts = int(doc.get("loyalty_points_earned", 0))
        if pts > 0 and doc.get("phone"):
            await log_loyalty_transaction(
                doc["phone"],
                "earn",
                pts,
                doc.get("order_no"),
                f"Earned {pts} Royalty Coins from Order #{doc.get('order_no')}"
            )
    except Exception as ex:
        logger.warning(f"[LOYALTY] Failed to credit earned coins on COD switch: {ex}")

    return {"ok": True, "order": Order.from_mongo(doc)}


@api.post("/payments/razorpay/verify")
async def razorpay_verify(body: RzpVerifyIn):
    client_rzp = razorpay_client()
    try:
        client_rzp.utility.verify_payment_signature({
            "razorpay_order_id": body.razorpay_order_id,
            "razorpay_payment_id": body.razorpay_payment_id,
            "razorpay_signature": body.razorpay_signature,
        })
    except Exception:
        # Log failure
        await db.payment_logs.insert_one({
            "order_no": body.order_no.upper(),
            "status": "failed_signature",
            "payment_id": body.razorpay_payment_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        raise HTTPException(400, "Payment signature verification failed")

    doc = await db.orders.find_one_and_update(
        {"order_no": body.order_no.upper()},
        {"$set": {"paid": True, "status": "placed", "payment_mode": "razorpay",
                  "razorpay_payment_id": body.razorpay_payment_id}},
        return_document=True)
    if not doc:
        raise HTTPException(404, "Order not found")

    # Log success
    await db.payment_logs.insert_one({
        "order_no": body.order_no.upper(),
        "status": "success",
        "payment_id": body.razorpay_payment_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })

    # Credit earned loyalty points
    try:
        pts = int(doc.get("loyalty_points_earned", 0))
        if pts > 0 and doc.get("phone"):
            await log_loyalty_transaction(
                doc["phone"],
                "earn",
                pts,
                doc.get("order_no"),
                f"Earned {pts} Royalty Coins from Order #{doc.get('order_no')}"
            )
    except Exception as ex:
        logger.warning(f"[LOYALTY] Failed to credit earned coins on online payment: {ex}")

    # Trigger push notifications for confirmed paid order
    try:
        if doc.get("phone"):
            asyncio.create_task(send_push_notification(
                title="Payment Received & Order Confirmed! ☕",
                body=f"Order #{doc.get('order_no')} confirmed! Hyderabadi Irani kitchen is preparing your order.",
                target_phone=doc.get("phone"),
                data={"order_id": str(doc["_id"]), "order_no": doc.get("order_no"), "status": "placed"}
            ))
        asyncio.create_task(send_push_notification(
            title="🔔 New Paid Order Placed!",
            body=f"Order #{doc.get('order_no')} (₹{doc.get('total', 0):.0f}) · Online Paid",
            target_role="admin",
            data={"order_id": str(doc["_id"]), "order_no": doc.get("order_no")}
        ))
    except Exception as ex:
        logger.warning(f"[PUSH] Failed to trigger push on payment verify: {ex}")

    return {"paid": True, "order": Order.from_mongo(doc)}


# ---------- Invoice PDF ----------
@api.get("/invoice/{order_no}")
async def invoice_pdf(order_no: str, phone: Optional[str] = None, user: Optional[User] = Depends(get_optional_user)):
    doc = await db.orders.find_one({"order_no": order_no.upper()})
    if not doc:
        raise HTTPException(404, "Order not found")
    # Logged-in staff can pull any invoice; a customer must prove they placed the order
    # by supplying the phone number it was placed under.
    if not user and (not phone or norm_phone(doc.get("phone", "")) != norm_phone(phone)):
        raise HTTPException(404, "Order not found")
    o = Order.from_mongo(doc)
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    y = _pdf_head(c, HOTEL_NAME, HOTEL_LINE, title_size=20) + 2 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20 * mm, y, f"TAX INVOICE  {o.order_no}")
    c.setFont("Helvetica", 9)
    y -= 7 * mm
    for line in [
        f"Date: {o.created_at[:19].replace('T', ' ')}",
        f"Customer: {o.customer_name}   Phone: {o.phone or '-'}",
        f"Type: {o.order_type.title()}   Table: {o.table_no or '-'}   Payment: {o.payment_mode.upper()}",
        f"Address: {o.address or '-'}",
    ]:
        c.drawString(20 * mm, y, line)
        y -= 5 * mm
    y -= 5 * mm
    c.setFont("Helvetica-Bold", 10)
    c.drawString(20 * mm, y, "ITEM")
    c.drawRightString(120 * mm, y, "QTY")
    c.drawRightString(150 * mm, y, "RATE")
    c.drawRightString(w - 20 * mm, y, "AMOUNT")
    c.line(20 * mm, y - 2 * mm, w - 20 * mm, y - 2 * mm)
    y -= 9 * mm
    c.setFont("Helvetica", 10)
    for l in o.items:
        c.drawString(20 * mm, y, l.name[:45])
        c.drawRightString(120 * mm, y, str(l.qty))
        c.drawRightString(150 * mm, y, f"{l.price:.2f}")
        c.drawRightString(w - 20 * mm, y, f"{l.price * l.qty:.2f}")
        y -= 6 * mm
    y -= 3 * mm
    c.line(110 * mm, y, w - 20 * mm, y)
    y -= 7 * mm
    taxable_val = round(o.total - o.tax, 2)
    summary_lines = [("Subtotal", o.subtotal)]
    if o.discount > 0:
        summary_lines.append(("Discount", -o.discount))
    summary_lines.append(("Taxable Value", taxable_val))
    summary_lines.append((f"GST (5% Incl.)", o.tax))
    for label, val in summary_lines:
        c.drawRightString(150 * mm, y, label)
        c.drawRightString(w - 20 * mm, y, f"Rs {val:.2f}")
        y -= 6 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawRightString(150 * mm, y, "TOTAL (INCL. GST)")
    c.drawRightString(w - 20 * mm, y, f"Rs {o.total:.2f}")
    y -= 14 * mm
    c.setFont("Helvetica-Oblique", 9)
    c.drawString(20 * mm, y, "Thank you for dining with us. Please visit again!")
    c.setFont("Helvetica-Bold", 9)
    c.drawRightString(w - 20 * mm, y, "Powered by NovaSaaS")
    c.showPage()
    c.save()
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf", headers={
        "Content-Disposition": f'attachment; filename="invoice-{o.order_no}.pdf"'})


# ---------- Table Management Endpoints ----------
@api.get("/tables")
async def list_tables(_: User = Depends(get_current_user)):
    # Generate 50 tables T-01 to T-50 and calculate live status
    table_list = []
    active_orders = await db.orders.find(
        {"status": {"$in": ["placed", "preparing", "ready", "served"]}},
        {"table_no": 1, "order_no": 1, "total": 1, "items": 1, "created_at": 1}
    ).to_list(500)
    
    active_map = {}
    for o in active_orders:
        t_raw = str(o.get("table_no", "")).upper().strip()
        if t_raw:
            active_map[t_raw] = o
            # Also map numeric form e.g. T-04 -> 4 or T-4
            if t_raw.startswith("T-"):
                try:
                    num = int(t_raw.replace("T-", ""))
                    active_map[str(num)] = o
                    active_map[f"T-{num}"] = o
                except ValueError:
                    pass

    override_docs = {d["table_no"]: d async for d in db.tables_override.find({})}

    for i in range(1, 51):
        t_id = f"T-{i:02d}"
        active_ord = active_map.get(t_id) or active_map.get(str(i)) or active_map.get(f"T-{i}")
        override_st = override_docs.get(t_id, {}).get("status")
        
        status = override_st if override_st else ("occupied" if active_ord else "available")
        table_list.append({
            "table_no": t_id,
            "table_num": i,
            "status": status,
            "active_order": {
                "order_no": active_ord["order_no"],
                "total": float(active_ord["total"]),
                "items_count": len(active_ord.get("items", [])),
                "created_at": active_ord.get("created_at"),
            } if active_ord else None
        })
    return table_list


class TableStatusIn(BaseModel):
    status: str # available | occupied | reserved


@api.put("/tables/{table_no}/status")
async def update_table_status(table_no: str, body: TableStatusIn, _: User = Depends(get_current_user), __: None = Depends(verify_csrf)):
    t_id = table_no.upper().strip()
    if not t_id.startswith("T-"):
        try:
            t_id = f"T-{int(t_id):02d}"
        except ValueError:
            pass
    await db.tables_override.update_one({"table_no": t_id}, {"$set": {"table_no": t_id, "status": body.status}}, upsert=True)
    return {"ok": True, "table_no": t_id, "status": body.status}


@api.get("/")
async def root():
    return {"status": "ok", "service": "hyderabadi-irani-billing", "powered_by": "NovaSaaS"}
app.include_router(api)

SEED_MENU = [
    ("Butter Chicken", "Slow-cooked tandoori chicken in a silky tomato-cashew gravy", 480, "Main Course", False,
     "https://images.unsplash.com/photo-1514326640560-7d063ef2aed5?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"),
    ("Paneer Tikka Masala", "Char-grilled cottage cheese in spiced onion gravy", 420, "Main Course", True,
     "https://images.pexels.com/photos/1327393/pexels-photo-1327393.jpeg?auto=compress&cs=tinysrgb&w=800"),
    ("Grand Signature Burger", "Double patty, aged cheddar, house pickles, brioche bun", 360, "Fast Food", False,
     "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?crop=entropy&cs=srgb&fm=jpg&q=85&w=800"),
    ("Truffle Mushroom Burger", "Portobello, truffle aioli, rocket leaves", 340, "Fast Food", True,
     "https://images.pexels.com/photos/15010285/pexels-photo-15010285.jpeg?auto=compress&cs=tinysrgb&w=800"),
    ("Dal Makhani", "Black lentils simmered overnight with butter and cream", 290, "Main Course", True, ""),
    ("Tandoori Roti", "Whole wheat bread from the clay oven", 45, "Breads", True, ""),
    ("Garlic Naan", "Leavened bread with roasted garlic and coriander", 70, "Breads", True, ""),
    ("Hyderabadi Biryani", "Aged basmati, saffron, slow-dum cooked", 520, "Rice", False, ""),
    ("Jeera Rice", "Basmati tempered with cumin and ghee", 220, "Rice", True, ""),
    ("Masala Papad", "Crisp papad, onion, tomato, chaat masala", 90, "Starters", True, ""),
    ("Chicken 65", "Fiery South-Indian fried chicken", 380, "Starters", False, ""),
    ("Gulab Jamun", "Warm milk dumplings in cardamom syrup", 160, "Desserts", True, ""),
    ("Tiramisu", "Espresso-soaked ladyfingers, mascarpone cream", 260, "Desserts", True, ""),
    ("Masala Chai", "Brewed with ginger, cardamom and fresh milk", 80, "Beverages", True, ""),
    ("Fresh Lime Soda", "Sweet, salted or mixed", 110, "Beverages", True, ""),
]


async def seed_database():
    """Seeds initial admin/staff/driver accounts, menu items, and coupons."""
    try:
        await db.users.create_index("email", unique=True)
        await db.orders.create_index("order_no", unique=True)
    except Exception:
        pass

    if await db.counters.find_one({"_id": "order_no"}) is None:
        await db.counters.insert_one({"_id": "order_no", "seq": await db.orders.count_documents({})})

    admin_email = os.environ.get("ADMIN_EMAIL", "admin@hyderabadiirani.com").lower().strip()
    admin_pwd = os.environ.get("ADMIN_PASSWORD", "9701463241").strip()

    staff_email = os.environ.get("STAFF_EMAIL", "staff@hyderabadiirani.com").lower().strip()
    staff_pwd = os.environ.get("STAFF_PASSWORD", "9701463241").strip()

    driver_email = os.environ.get("DRIVER_EMAIL", "driver@hyderabadiirani.com").lower().strip()
    driver_pwd = os.environ.get("DRIVER_PASSWORD", "9701463241").strip()

    for email, pwd, name, role in [
        (admin_email, admin_pwd, "Hotel Admin", "admin"),
        (staff_email, staff_pwd, "Front Desk Cashier", "staff"),
        (driver_email, driver_pwd, "Hyderabadi Irani Delivery Partner", "delivery"),
    ]:
        existing = await db.users.find_one({"email": email})
        if existing is None:
            await db.users.insert_one({
                "email": email,
                "password_hash": hash_password(pwd),
                "name": name,
                "role": role,
                "active": True,
                "token_version": 0,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
            logger.info(f"Created default {role} user: {email}")
        else:
            upd = {"role": role, "name": name, "active": True}
            if not verify_password(pwd, existing.get("password_hash", "")):
                upd["password_hash"] = hash_password(pwd)
            await db.users.update_one({"_id": existing["_id"]}, {"$set": upd})

    # 4. Menu
    if await db.menu_items.count_documents({}) == 0:
        await db.menu_items.insert_many([
            {"name": n, "description": d, "price": float(p), "category": c, "veg": v,
             "image_url": img, "available": True, "station": "beverage" if c == "Beverages" else "kitchen"}
            for n, d, p, c, v, img in SEED_MENU
        ])
        logger.info("Seeded initial menu items")

    # 5. Coupons
    if await db.coupons.count_documents({}) == 0:
        await db.coupons.insert_many([
            {"code": "IRANI10", "discount_type": "percent", "discount_value": 10.0, "min_order": 200.0, "active": True},
            {"code": "FLAT50", "discount_type": "fixed", "discount_value": 50.0, "min_order": 300.0, "active": True},
            {"code": "WELCOME20", "discount_type": "percent", "discount_value": 20.0, "min_order": 500.0, "active": True},
        ])
        logger.info("Seeded initial coupons")


@api.post("/setup/seed")
@api.get("/setup/seed")
async def seed_endpoint():
    await seed_database()
    return {
        "ok": True,
        "message": "Initial database users, menu, and coupons successfully seeded.",
        "admin": os.environ.get("ADMIN_EMAIL", "admin@hyderabadiirani.com"),
        "staff": os.environ.get("STAFF_EMAIL", "staff@hyderabadiirani.com"),
        "driver": os.environ.get("DRIVER_EMAIL", "driver@hyderabadiirani.com")
    }


@app.get("/robots.txt")
@api.get("/robots.txt")
async def get_robots_txt():
    content = """User-agent: *
Allow: /
Disallow: /admin/
Disallow: /pos
Disallow: /kitchen
Disallow: /delivery

Sitemap: https://hyderabadiirani.net/sitemap.xml
"""
    return Response(content=content, media_type="text/plain")


@app.get("/sitemap.xml")
@api.get("/sitemap.xml")
async def get_sitemap_xml():
    import urllib.parse
    categories = await db.menu_items.distinct("category")
    items = await db.menu_items.find({"available": True}, {"name": 1, "category": 1}).to_list(500)
    
    xml = ['<?xml version="1.0" encoding="UTF-8"?>']
    xml.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
    
    # Storefront root
    xml.append("""  <url>
    <loc>https://hyderabadiirani.net/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>""")
  
    # Categories
    for cat in categories:
        safe_cat = urllib.parse.quote(str(cat))
        xml.append(f"""  <url>
    <loc>https://hyderabadiirani.net/?category={safe_cat}</loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>""")

    # Policy & Info Pages
    for page in ["about-us", "contact-us", "privacy-policy", "terms", "shipping-policy", "refund-policy"]:
        xml.append(f"""  <url>
    <loc>https://hyderabadiirani.net/{page}</loc>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>""")

    xml.append('</urlset>')
    return Response(content="\n".join(xml), media_type="application/xml")


@app.on_event("startup")
async def startup():
    for attempt in range(5):
        try:
            await seed_database()
            logger.info("Startup DB seeding complete")
            break
        except Exception as e:
            logger.warning(f"Startup DB seeding attempt {attempt+1} failed: {e}. Retrying in 2s...")
            await asyncio.sleep(2)


@app.on_event("shutdown")
async def shutdown():
    client.close()
