"""Cookie-based auth tests (iteration 6): httpOnly cookies, refresh, logout,
   brute-force lockout with X-Forwarded-For identifier, token-type confusion."""
import os
import time
import pytest
import requests

BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@hyderabadiirani.com", "password": "9701463241"}
STAFF = {"email": "staff@hyderabadiirani.com", "password": "9701463241"}


def _cleanup_lockout(email):
    # best effort via mongosh
    try:
        import subprocess
        subprocess.run(
            ["mongosh", "--quiet", "--eval",
             f'db.getSiblingDB("test_database").login_attempts.deleteMany({{identifier: /{email}/}})'],
            capture_output=True, timeout=10)
    except Exception:
        pass


# ---------- Cookie login ----------
def test_login_sets_httponly_cookies():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    body = r.json()
    assert "access_token" in body and body["user"]["role"] == "admin"

    # Both cookies must be set with HttpOnly
    set_cookie_hdrs = r.headers.get("set-cookie", "") + " ; ".join(
        [v for k, v in r.raw.headers.items() if k.lower() == "set-cookie"])
    # Requests merges multi headers - use raw list
    raw = [v for k, v in r.raw.headers.items() if k.lower() == "set-cookie"]
    joined = "\n".join(raw) if raw else set_cookie_hdrs
    assert "access_token=" in joined
    assert "refresh_token=" in joined
    assert "HttpOnly" in joined
    # Secure + SameSite=None required for cross-site cookies
    assert "Secure" in joined
    assert "SameSite=None" in joined or "SameSite=none" in joined.lower() or "samesite=none" in joined.lower()

    # cookie jar has cookies
    names = {c.name for c in s.cookies}
    assert "access_token" in names and "refresh_token" in names


def test_me_with_cookie_only():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200
    # No Authorization header
    r2 = s.get(f"{API}/auth/me", timeout=15)
    assert r2.status_code == 200
    assert r2.json()["email"] == ADMIN["email"]


def test_refresh_mints_new_access_token():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    old_access = s.cookies.get("access_token")
    time.sleep(1)
    r2 = s.post(f"{API}/auth/refresh", timeout=15)
    assert r2.status_code == 200
    body = r2.json()
    assert "access_token" in body and body["user"]["email"] == ADMIN["email"]
    new_access = s.cookies.get("access_token")
    assert new_access and new_access != old_access
    # Refresh cookie remains valid: /auth/me still works
    r3 = s.get(f"{API}/auth/me", timeout=15)
    assert r3.status_code == 200


def test_logout_clears_cookies():
    s = requests.Session()
    s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    r = s.post(f"{API}/auth/logout", timeout=15)
    assert r.status_code == 200
    raw = [v for k, v in r.raw.headers.items() if k.lower() == "set-cookie"]
    joined = "\n".join(raw)
    # Deletion headers for both cookies (Max-Age=0 or expires in the past)
    assert "access_token=" in joined and "refresh_token=" in joined
    # Requests removes the cookies from jar because server sends expired cookies
    # After the logout, /auth/me must return 401 (jar should not carry valid cookies)
    r2 = s.get(f"{API}/auth/me", timeout=15)
    assert r2.status_code == 401


def test_invalid_garbage_cookie():
    r = requests.get(f"{API}/auth/me",
                     cookies={"access_token": "garbage.not.a.jwt"}, timeout=15)
    assert r.status_code == 401


# ---------- Token-type confusion ----------
def test_refresh_token_rejected_on_me():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    refresh_tok = s.cookies.get("refresh_token")
    assert refresh_tok
    # Send refresh token where access token is expected (Bearer)
    r2 = requests.get(f"{API}/auth/me",
                      headers={"Authorization": f"Bearer {refresh_tok}"}, timeout=15)
    assert r2.status_code == 401
    assert "Invalid token type" in r2.text


def test_access_token_rejected_on_refresh():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    access = r.json()["access_token"]
    # Use access token as Bearer for /auth/refresh
    r2 = requests.post(f"{API}/auth/refresh",
                       headers={"Authorization": f"Bearer {access}"}, timeout=15)
    assert r2.status_code == 401
    assert "Invalid token type" in r2.text


# ---------- Bearer fallback still works ----------
def test_bearer_fallback_me():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    tok = r.json()["access_token"]
    r2 = requests.get(f"{API}/auth/me",
                      headers={"Authorization": f"Bearer {tok}"}, timeout=15)
    assert r2.status_code == 200


def test_bearer_fallback_protected():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    tok = r.json()["access_token"]
    h = {"Authorization": f"Bearer {tok}"}
    for path in ["/kitchen/queue", "/orders", "/reports/gst-monthly"]:
        rr = requests.get(f"{API}{path}", headers=h, timeout=15)
        assert rr.status_code == 200, f"{path} => {rr.status_code} {rr.text[:120]}"


# ---------- Roles over cookies ----------
def test_cashier_cookie_role_gating():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=STAFF, timeout=15)
    assert r.status_code == 200
    # allowed
    assert s.get(f"{API}/kitchen/queue", timeout=15).status_code == 200
    assert s.get(f"{API}/orders", timeout=15).status_code == 200
    # forbidden
    assert s.get(f"{API}/reports/day-end", timeout=15).status_code == 403
    assert s.get(f"{API}/reports/gst-monthly", timeout=15).status_code == 403
    rr = s.post(f"{API}/menu", json={"name": "TEST_x", "price": 1, "category": "T"}, timeout=15)
    assert rr.status_code == 403


def test_admin_cookie_role_all_ok():
    s = requests.Session()
    s.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert s.get(f"{API}/kitchen/queue", timeout=15).status_code == 200
    assert s.get(f"{API}/orders", timeout=15).status_code == 200
    assert s.get(f"{API}/reports/day-end", timeout=15).status_code == 200
    assert s.get(f"{API}/reports/gst-monthly", timeout=15).status_code == 200


# ---------- Brute force ----------
def test_brute_force_lockout_and_isolation():
    lock_email = "lockme_test@grandhotel.com"
    _cleanup_lockout(lock_email)
    # 5 failed logins with unknown account - each 401
    codes = []
    for i in range(5):
        r = requests.post(f"{API}/auth/login",
                          json={"email": lock_email, "password": "wrong"},
                          headers={"X-Forwarded-For": "203.0.113.9"},
                          timeout=15)
        codes.append(r.status_code)
    assert codes == [401, 401, 401, 401, 401], codes
    # 6th -> 429
    r = requests.post(f"{API}/auth/login",
                      json={"email": lock_email, "password": "wrong"},
                      headers={"X-Forwarded-For": "203.0.113.9"},
                      timeout=15)
    assert r.status_code == 429
    assert "Too many failed attempts" in r.text

    # Different account can still log in during that lockout
    r2 = requests.post(f"{API}/auth/login", json=ADMIN,
                       headers={"X-Forwarded-For": "203.0.113.9"}, timeout=15)
    assert r2.status_code == 200

    # cleanup
    _cleanup_lockout(lock_email)


def test_successful_login_clears_counter():
    email = ADMIN["email"]
    _cleanup_lockout(email)
    # 3 wrong attempts
    for _ in range(3):
        requests.post(f"{API}/auth/login",
                      json={"email": email, "password": "wrong"},
                      headers={"X-Forwarded-For": "203.0.113.10"},
                      timeout=15)
    # correct login clears counter
    r = requests.post(f"{API}/auth/login", json=ADMIN,
                     headers={"X-Forwarded-For": "203.0.113.10"}, timeout=15)
    assert r.status_code == 200
    # Now attempt 6 more wrongs -- should NOT trip early (counter reset)
    for i in range(5):
        rr = requests.post(f"{API}/auth/login",
                           json={"email": email, "password": "wrong"},
                           headers={"X-Forwarded-For": "203.0.113.10"},
                           timeout=15)
        assert rr.status_code == 401, f"attempt {i} => {rr.status_code}"
    _cleanup_lockout(email)
