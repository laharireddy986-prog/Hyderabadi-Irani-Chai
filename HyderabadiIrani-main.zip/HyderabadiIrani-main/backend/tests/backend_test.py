"""Backend API tests for Grand Hotel POS + Storefront."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://stay-charge-system.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@hyderabadiirani.com", "password": "9701463241"}
STAFF = {"email": "staff@hyderabadiirani.com", "password": "9701463241"}


@pytest.fixture(scope="session")
def admin_token():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def staff_token():
    r = requests.post(f"{API}/auth/login", json=STAFF, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


# ----- Auth -----
def test_login_admin_ok():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200
    data = r.json()
    assert "access_token" in data
    assert data["user"]["role"] == "admin"
    assert data["user"]["email"] == ADMIN["email"]


def test_login_staff_ok():
    r = requests.post(f"{API}/auth/login", json=STAFF, timeout=15)
    assert r.status_code == 200
    assert r.json()["user"]["role"] == "staff"


def test_login_bad_password():
    r = requests.post(f"{API}/auth/login", json={"email": ADMIN["email"], "password": "wrong"}, timeout=15)
    assert r.status_code == 401


def test_auth_me(admin_token):
    r = requests.get(f"{API}/auth/me", headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    assert r.json()["role"] == "admin"


def test_auth_me_no_token():
    r = requests.get(f"{API}/auth/me", timeout=15)
    assert r.status_code == 401


# ----- Menu -----
def test_menu_list_public():
    r = requests.get(f"{API}/menu?only_available=true", timeout=15)
    assert r.status_code == 200
    items = r.json()
    assert isinstance(items, list)
    assert len(items) > 0
    assert "id" in items[0] and "name" in items[0] and "price" in items[0]
    assert "_id" not in items[0]


def test_menu_category_filter():
    r = requests.get(f"{API}/menu?category=Beverages", timeout=15)
    assert r.status_code == 200
    for it in r.json():
        assert it["category"] == "Beverages"


def test_menu_write_requires_admin(staff_token):
    payload = {"name": "TEST_Staff", "price": 10, "category": "Test"}
    r = requests.post(f"{API}/menu", json=payload,
                      headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 403


def test_menu_crud_admin(admin_token):
    h = {"Authorization": f"Bearer {admin_token}"}
    # Create
    r = requests.post(f"{API}/menu", json={
        "name": "TEST_Item", "price": 99.5, "category": "TEST_Cat", "veg": True
    }, headers=h, timeout=15)
    assert r.status_code == 200, r.text
    item = r.json()
    assert item["name"] == "TEST_Item"
    assert item["price"] == 99.5
    iid = item["id"]

    # Update
    r = requests.put(f"{API}/menu/{iid}", json={
        "name": "TEST_Item_Upd", "price": 120, "category": "TEST_Cat"
    }, headers=h, timeout=15)
    assert r.status_code == 200
    assert r.json()["name"] == "TEST_Item_Upd"
    assert r.json()["price"] == 120

    # Verify via list
    r = requests.get(f"{API}/menu?category=TEST_Cat", timeout=15)
    assert any(x["id"] == iid and x["name"] == "TEST_Item_Upd" for x in r.json())

    # Delete
    r = requests.delete(f"{API}/menu/{iid}", headers=h, timeout=15)
    assert r.status_code == 200
    r = requests.delete(f"{API}/menu/{iid}", headers=h, timeout=15)
    assert r.status_code == 404


# ----- Public order (COD) + track + invoice -----
@pytest.fixture(scope="session")
def public_order():
    menu = requests.get(f"{API}/menu?only_available=true", timeout=15).json()
    it = menu[0]
    payload = {
        "customer_name": "TEST_Customer",
        "phone": "9999999999",
        "address": "Test Address",
        "order_type": "delivery",
        "payment_mode": "cod",
        "items": [{"item_id": it["id"], "name": it["name"], "price": it["price"], "qty": 2}],
    }
    r = requests.post(f"{API}/public/orders", json=payload, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()


def test_public_order_totals(public_order):
    o = public_order
    assert o["order_no"].startswith("GH")
    expected_sub = round(o["items"][0]["price"] * o["items"][0]["qty"], 2)
    assert o["subtotal"] == expected_sub
    assert o["tax"] == round(expected_sub * 0.05, 2)
    assert o["total"] == round(expected_sub + o["tax"], 2)
    assert o["source"] == "online"
    assert o["status"] == "placed"


def test_public_order_ignores_client_submitted_price():
    """The server must price orders from the menu, not from whatever the client sends."""
    menu = requests.get(f"{API}/menu?only_available=true", timeout=15).json()
    it = menu[0]
    payload = {
        "customer_name": "TEST_Tamper",
        "phone": "9999999998",
        "address": "Test Address",
        "order_type": "delivery",
        "payment_mode": "cod",
        "items": [{"item_id": it["id"], "name": it["name"], "price": 1, "qty": 1}],
    }
    r = requests.post(f"{API}/public/orders", json=payload, timeout=15)
    assert r.status_code == 200, r.text
    o = r.json()
    assert o["items"][0]["price"] == it["price"]
    assert o["subtotal"] == round(it["price"], 2)


def test_track_order_ok(public_order):
    r = requests.get(f"{API}/public/orders/{public_order['order_no']}",
                     params={"phone": public_order["phone"]}, timeout=15)
    assert r.status_code == 200
    assert r.json()["order_no"] == public_order["order_no"]


def test_track_order_wrong_phone(public_order):
    r = requests.get(f"{API}/public/orders/{public_order['order_no']}",
                     params={"phone": "0000000000"}, timeout=15)
    assert r.status_code == 404


def test_track_order_not_found():
    r = requests.get(f"{API}/public/orders/GH999999-9999", params={"phone": "9999999999"}, timeout=15)
    assert r.status_code == 404


def test_invoice_pdf(public_order):
    r = requests.get(f"{API}/invoice/{public_order['order_no']}",
                     params={"phone": public_order["phone"]}, timeout=15)
    assert r.status_code == 200
    assert r.headers.get("content-type", "").startswith("application/pdf")
    assert r.content[:4] == b"%PDF"


def test_invoice_pdf_requires_phone_or_auth(public_order):
    r = requests.get(f"{API}/invoice/{public_order['order_no']}", timeout=15)
    assert r.status_code == 404


def test_invoice_pdf_staff_bypasses_phone(public_order, admin_token):
    r = requests.get(f"{API}/invoice/{public_order['order_no']}",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200


def test_public_order_empty_items():
    r = requests.post(f"{API}/public/orders", json={
        "customer_name": "X", "items": []}, timeout=15)
    assert r.status_code == 400


# ----- POS order + status transitions -----
def test_pos_order_and_transitions(admin_token, staff_token):
    h = {"Authorization": f"Bearer {staff_token}"}
    menu = requests.get(f"{API}/menu?only_available=true", timeout=15).json()
    it = menu[1]
    payload = {
        "customer_name": "TEST_POS",
        "order_type": "dine-in",
        "payment_mode": "cash",
        "table_no": "5",
        "items": [{"item_id": it["id"], "name": it["name"], "price": it["price"], "qty": 1}],
    }
    r = requests.post(f"{API}/orders", json=payload, headers=h, timeout=15)
    assert r.status_code == 200, r.text
    o = r.json()
    assert o["source"] == "pos"
    oid = o["id"]

    for s in ["preparing", "ready", "completed"]:
        r = requests.put(f"{API}/orders/{oid}/status", json={"status": s}, headers=h, timeout=15)
        assert r.status_code == 200
        assert r.json()["status"] == s
    assert r.json()["paid"] is True

    # invalid status
    r = requests.put(f"{API}/orders/{oid}/status", json={"status": "bogus"}, headers=h, timeout=15)
    assert r.status_code == 400


def test_orders_list_requires_auth():
    r = requests.get(f"{API}/orders", timeout=15)
    assert r.status_code == 401


def test_orders_list_with_filter(admin_token):
    h = {"Authorization": f"Bearer {admin_token}"}
    r = requests.get(f"{API}/orders?status=placed", headers=h, timeout=15)
    assert r.status_code == 200
    for o in r.json():
        assert o["status"] == "placed"


# ----- Stats -----
def test_stats(admin_token):
    r = requests.get(f"{API}/stats", headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    d = r.json()
    for k in ["today_revenue", "today_orders", "total_revenue", "total_orders",
              "open_orders", "avg_order_value", "revenue_by_day", "top_items"]:
        assert k in d
    assert isinstance(d["revenue_by_day"], list)
    assert isinstance(d["top_items"], list)
