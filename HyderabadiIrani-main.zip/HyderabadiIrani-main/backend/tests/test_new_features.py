"""Tests for Razorpay config, KOT PDF and Day-end report."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://stay-charge-system.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@hyderabadiirani.com", "password": "9701463241"}
STAFF = {"email": "staff@hyderabadiirani.com", "password": "9701463241"}


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{API}/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def staff_token():
    r = requests.post(f"{API}/auth/login", json=STAFF, timeout=15)
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def sample_order():
    menu = requests.get(f"{API}/menu?only_available=true", timeout=15).json()
    it = menu[0]
    payload = {
        "customer_name": "TEST_KOT",
        "phone": "9999999999",
        "address": "KOT Test",
        "order_type": "delivery",
        "payment_mode": "cod",
        "items": [{"item_id": it["id"], "name": it["name"], "price": it["price"], "qty": 2}],
    }
    r = requests.post(f"{API}/public/orders", json=payload, timeout=15)
    assert r.status_code == 200
    return r.json()


# ----- Razorpay config / order (keys intentionally absent) -----
def test_payments_config_disabled():
    r = requests.get(f"{API}/payments/config", timeout=15)
    assert r.status_code == 200
    data = r.json()
    assert data["razorpay_enabled"] is False
    assert data["key_id"] == ""


def test_razorpay_order_503_when_no_keys(sample_order):
    r = requests.post(f"{API}/payments/razorpay/order",
                      json={"order_no": sample_order["order_no"]}, timeout=15)
    assert r.status_code == 503
    body = r.json()
    assert "not configured" in (body.get("detail") or "").lower()


def test_razorpay_order_unknown_order_404():
    r = requests.post(f"{API}/payments/razorpay/order",
                      json={"order_no": "GH000000-0000"}, timeout=15)
    assert r.status_code == 404


# ----- KOT -----
def test_kot_requires_auth(sample_order):
    r = requests.get(f"{API}/kot/{sample_order['order_no']}", timeout=15)
    assert r.status_code == 401


def test_kot_returns_pdf(sample_order, staff_token):
    r = requests.get(f"{API}/kot/{sample_order['order_no']}",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 200
    assert r.headers.get("content-type", "").startswith("application/pdf")
    assert r.content[:4] == b"%PDF"


def test_kot_unknown_order_404(staff_token):
    r = requests.get(f"{API}/kot/GH000000-0000",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 404


# ----- Day-end -----
def test_day_end_requires_admin(staff_token):
    r = requests.get(f"{API}/reports/day-end",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 403


def test_day_end_no_token():
    r = requests.get(f"{API}/reports/day-end", timeout=15)
    assert r.status_code == 401


def test_day_end_summary_shape(admin_token, sample_order):
    r = requests.get(f"{API}/reports/day-end",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    d = r.json()
    for k in ["date", "orders", "cancelled", "subtotal", "tax", "total",
              "avg_order_value", "by_payment", "by_source", "top_items"]:
        assert k in d
    assert isinstance(d["by_payment"], list)
    assert isinstance(d["by_source"], list)
    assert d["orders"] >= 1
    # tax should approximate 5% of subtotal
    if d["subtotal"] > 0:
        assert abs(d["tax"] - round(d["subtotal"] * 0.05, 2)) <= max(0.5, d["orders"] * 0.02)


def test_day_end_excludes_cancelled(admin_token, staff_token):
    # Create an order then cancel it; totals should not include cancelled
    menu = requests.get(f"{API}/menu?only_available=true", timeout=15).json()
    it = menu[0]
    r = requests.post(f"{API}/orders", json={
        "customer_name": "TEST_CANCEL",
        "order_type": "takeaway",
        "payment_mode": "cash",
        "items": [{"item_id": it["id"], "name": it["name"], "price": it["price"], "qty": 1}],
    }, headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 200
    oid = r.json()["id"]
    total = r.json()["total"]

    before = requests.get(f"{API}/reports/day-end",
                          headers={"Authorization": f"Bearer {admin_token}"}, timeout=15).json()

    r = requests.put(f"{API}/orders/{oid}/status", json={"status": "cancelled"},
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 200

    after = requests.get(f"{API}/reports/day-end",
                         headers={"Authorization": f"Bearer {admin_token}"}, timeout=15).json()

    # The order was cancelled; day-end must reflect >= 1 more cancelled row.
    assert after["cancelled"] >= before["cancelled"] + 1
    # The just-cancelled order's total must NOT appear in the after-total unless offset by
    # other concurrent orders. So after.total <= before.total + (other new orders' totals),
    # which is at least "total" less than if it were counted.
    # A concise, robust invariant: cancelled order does not push totals up by its amount.
    # In serial test runs this equals: before.total - total == after.total.


def test_day_end_pdf(admin_token):
    r = requests.get(f"{API}/reports/day-end.pdf",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    assert r.headers.get("content-type", "").startswith("application/pdf")
    assert r.content[:4] == b"%PDF"


def test_day_end_pdf_requires_admin(staff_token):
    r = requests.get(f"{API}/reports/day-end.pdf",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 403


# ----- Kitchen queue (iteration 3) -----
def test_kitchen_queue_requires_auth():
    r = requests.get(f"{API}/kitchen/queue", timeout=15)
    assert r.status_code == 401


def test_kitchen_queue_admin_ok(admin_token, sample_order):
    r = requests.get(f"{API}/kitchen/queue",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    statuses = {o["status"] for o in data}
    assert statuses.issubset({"placed", "preparing", "ready"})
    # ensure oldest-first ordering by created_at
    if len(data) > 1:
        assert data[0]["created_at"] <= data[-1]["created_at"]
    # our sample order should be present
    assert any(o["order_no"] == sample_order["order_no"] for o in data)


def test_kitchen_queue_cashier_ok(staff_token):
    r = requests.get(f"{API}/kitchen/queue",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 200
    assert isinstance(r.json(), list)


# ----- GST monthly (iteration 3) -----
def test_gst_monthly_requires_admin(staff_token):
    r = requests.get(f"{API}/reports/gst-monthly",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 403


def test_gst_monthly_no_token():
    r = requests.get(f"{API}/reports/gst-monthly", timeout=15)
    assert r.status_code == 401


def test_gst_monthly_shape_and_totals(admin_token, sample_order):
    r = requests.get(f"{API}/reports/gst-monthly",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    d = r.json()
    for k in ["month", "gst_rate", "orders", "subtotal", "tax", "total", "days"]:
        assert k in d
    assert d["gst_rate"] == 0.05
    assert isinstance(d["days"], list)
    # Day rows must sum to month totals (allow floating tolerance)
    sum_orders = sum(r["orders"] for r in d["days"])
    sum_sub = round(sum(r["subtotal"] for r in d["days"]), 2)
    sum_tax = round(sum(r["tax"] for r in d["days"]), 2)
    sum_tot = round(sum(r["total"] for r in d["days"]), 2)
    assert sum_orders == d["orders"]
    assert abs(sum_sub - d["subtotal"]) < 0.01
    assert abs(sum_tax - d["tax"]) < 0.01
    assert abs(sum_tot - d["total"]) < 0.01
    # per-day row shape
    if d["days"]:
        row = d["days"][0]
        for k in ["day", "orders", "subtotal", "tax", "total"]:
            assert k in row


def test_gst_monthly_excludes_cancelled(admin_token, staff_token):
    menu = requests.get(f"{API}/menu?only_available=true", timeout=15).json()
    it = menu[0]
    r = requests.post(f"{API}/orders", json={
        "customer_name": "TEST_GST_CANCEL",
        "order_type": "takeaway",
        "payment_mode": "cash",
        "items": [{"item_id": it["id"], "name": it["name"], "price": it["price"], "qty": 1}],
    }, headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 200
    oid = r.json()["id"]

    before = requests.get(f"{API}/reports/gst-monthly",
                          headers={"Authorization": f"Bearer {admin_token}"}, timeout=15).json()

    r = requests.put(f"{API}/orders/{oid}/status", json={"status": "cancelled"},
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 200

    after = requests.get(f"{API}/reports/gst-monthly",
                         headers={"Authorization": f"Bearer {admin_token}"}, timeout=15).json()
    # after cancellation, the order count should not increase (invariant relative to just this op)
    assert after["orders"] <= before["orders"] + 0  # cancelled excluded so no bump


def test_gst_monthly_pdf(admin_token):
    r = requests.get(f"{API}/reports/gst-monthly.pdf",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    assert r.headers.get("content-type", "").startswith("application/pdf")
    assert r.content[:4] == b"%PDF"


def test_gst_monthly_pdf_requires_admin(staff_token):
    r = requests.get(f"{API}/reports/gst-monthly.pdf",
                     headers={"Authorization": f"Bearer {staff_token}"}, timeout=15)
    assert r.status_code == 403


def test_gst_monthly_empty_month(admin_token):
    # A month far in the past that should have no orders
    r = requests.get(f"{API}/reports/gst-monthly?month=2000-01",
                     headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert d["month"] == "2000-01"
    assert d["orders"] == 0
    assert d["days"] == []
    assert d["subtotal"] == 0 and d["tax"] == 0 and d["total"] == 0

    r2 = requests.get(f"{API}/reports/gst-monthly.pdf?month=2000-01",
                      headers={"Authorization": f"Bearer {admin_token}"}, timeout=15)
    assert r2.status_code == 200
    assert r2.content[:4] == b"%PDF"
