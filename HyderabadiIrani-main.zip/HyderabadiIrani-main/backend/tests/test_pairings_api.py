import sys
from pathlib import Path

# Add backend directory to sys.path
backend_dir = Path(__file__).resolve().parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

try:
    from server import MenuItem, MenuItemIn
except ImportError:
    from backend.server import MenuItem, MenuItemIn

def test_menu_item_model_with_suggested_items():
    item_in = MenuItemIn(
        name="Chicken Dum Biryani",
        price=220.0,
        category="Biryani",
        suggested_items=["64aef123456789abcdef0001", "64aef123456789abcdef0002"],
        veg=False,
    )
    assert item_in.suggested_items == ["64aef123456789abcdef0001", "64aef123456789abcdef0002"]

    item = MenuItem(**item_in.model_dump())
    assert item.suggested_items == ["64aef123456789abcdef0001", "64aef123456789abcdef0002"]
    
    mongo_doc = item.to_mongo()
    assert "suggested_items" in mongo_doc
    assert mongo_doc["suggested_items"] == ["64aef123456789abcdef0001", "64aef123456789abcdef0002"]

def test_menu_item_model_defaults_empty_suggested_items():
    item_in = MenuItemIn(
        name="Irani Chai",
        price=20.0,
        category="Tea",
        veg=True,
    )
    assert item_in.suggested_items is None or item_in.suggested_items == []

    dumped = item_in.model_dump()
    if dumped.get("suggested_items") is None:
        dumped["suggested_items"] = []
    
    item = MenuItem(**dumped)
    assert item.suggested_items == []
