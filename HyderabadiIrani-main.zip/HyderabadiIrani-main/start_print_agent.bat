@echo off
title Hyderabadi Irani - Petpooja Print Agent
color 0A
echo =======================================================
echo   ☕ HYDERABADI IRANI - PETPOOJA THERMAL PRINT AGENT
echo   Direct Raw ESC/POS Spooler for TVS RP 3200 STAR AU
echo =======================================================
echo.
cd /d "%~dp0\print-agent"
if not exist "node_modules" (
    echo Installing dependencies...
    call npm install
)
echo Starting Local Print Agent on http://127.0.0.1:8989 ...
node server.js
pause
