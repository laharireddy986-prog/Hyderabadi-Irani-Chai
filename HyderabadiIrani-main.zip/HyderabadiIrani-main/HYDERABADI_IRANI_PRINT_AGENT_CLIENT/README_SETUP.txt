========================================================================
HYDERABADI IRANI - 1-CLICK THERMAL PRINT AGENT CLIENT SETUP GUIDE
========================================================================

WHAT THIS FOLDER CONTAINS:
------------------------------------------------------------------------
1. INSTALL_DESKTOP_SHORTCUTS.bat  -> Auto-installer (creates desktop & startup icons)
2. HYDERABADI_IRANI_POS.bat       -> 1-Click Cashier Launcher (Kiosk auto-print)
3. start_print_agent.bat          -> Background print spooler service (Port 8989)
4. print-agent/                   -> Lightweight Node.js print driver spooler

------------------------------------------------------------------------
QUICK 3-STEP SETUP ON CLIENT LAPTOP:
------------------------------------------------------------------------

STEP 1: INSTALL PREREQUISITES
  a) Node.js (LTS Version): Download from https://nodejs.org and install.
  b) Connect the Thermal Printer via USB (e.g. TVS RP 3200 STAR AU / POS-80)
     and turn ON the printer power.

STEP 2: RUN AUTOMATIC INSTALLER
  Double-click "INSTALL_DESKTOP_SHORTCUTS.bat".
  This will:
  - Verify Node.js
  - Prepare all required dependencies
  - Create the "Hyderabadi Irani POS" shortcut on your Desktop
  - Set the Print Agent to automatically start when Windows boots up!

STEP 3: START BILLING!
  Double-click the "Hyderabadi Irani POS" icon on your Desktop.
  The POS will open in silent printing mode. Every bill and KOT will
  now print instantly with zero popups and auto-cut!
========================================================================
