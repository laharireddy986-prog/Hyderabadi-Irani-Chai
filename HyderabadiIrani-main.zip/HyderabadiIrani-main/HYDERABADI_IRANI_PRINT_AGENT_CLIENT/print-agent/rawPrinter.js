const { exec, spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");

// PowerShell script template using Win32 winspool.drv with DataType="RAW"
const PS_RAW_HELPER = `
Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Runtime.InteropServices;

public class RawPrinterHelper {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    public class DOCINFOW {
        [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
    }

    [DllImport("winspool.Drv", EntryPoint="OpenPrinterW", SetLastError=true, CharSet=CharSet.Unicode, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPWStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);

    [DllImport("winspool.Drv", EntryPoint="ClosePrinter", SetLastError=true, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool ClosePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint="StartDocPrinterW", SetLastError=true, CharSet=CharSet.Unicode, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOW di);

    [DllImport("winspool.Drv", EntryPoint="EndDocPrinter", SetLastError=true, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool EndDocPrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint="StartPagePrinter", SetLastError=true, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool StartPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint="EndPagePrinter", SetLastError=true, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool EndPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.Drv", EntryPoint="WritePrinter", SetLastError=true, ExactSpelling=true, CallingConvention=CallingConvention.StdCall)]
    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);

    public static bool SendBytesToPrinter(string szPrinterName, byte[] pBytes) {
        IntPtr pUnmanagedBytes = Marshal.AllocCoTaskMem(pBytes.Length);
        Marshal.Copy(pBytes, 0, pUnmanagedBytes, pBytes.Length);
        IntPtr hPrinter = IntPtr.Zero;
        DOCINFOW di = new DOCINFOW();
        di.pDocName = "Thermal Receipt";
        di.pDataType = "RAW";
        bool bSuccess = false;
        try {
            if (OpenPrinter(szPrinterName, out hPrinter, IntPtr.Zero)) {
                if (StartDocPrinter(hPrinter, 1, di)) {
                    if (StartPagePrinter(hPrinter)) {
                        int dwWritten = 0;
                        bSuccess = WritePrinter(hPrinter, pUnmanagedBytes, pBytes.Length, out dwWritten);
                        EndPagePrinter(hPrinter);
                    }
                    EndDocPrinter(hPrinter);
                }
                ClosePrinter(hPrinter);
            }
        } catch (Exception ex) {
            Console.Error.WriteLine("WinSpool Error: " + ex.Message);
        } finally {
            Marshal.FreeCoTaskMem(pUnmanagedBytes);
        }
        return bSuccess;
    }
}
"@
`;

/**
 * Get all installed Windows printers
 */
function getInstalledPrinters() {
  return new Promise((resolve) => {
    const psCmd = `Get-Printer | Select-Object Name, DriverName, PortName, PrinterStatus | ConvertTo-Json -Compress`;
    exec(`powershell -NoProfile -Command "${psCmd}"`, { windowsHide: true }, (err, stdout) => {
      if (err) {
        console.warn("Failed to get printers via PowerShell:", err.message);
        return resolve([]);
      }
      try {
        const parsed = JSON.parse(stdout.trim());
        const list = Array.isArray(parsed) ? parsed : [parsed];
        resolve(list);
      } catch (e) {
        resolve([]);
      }
    });
  });
}

/**
 * Find best matching TVS or thermal printer
 */
async function findThermalPrinter() {
  const printers = await getInstalledPrinters();
  // 1. Exact match for TVS or RP 3200
  let matched = printers.find(p => /tvs|rp\s*3200|rp3200|pos/i.test(p.Name || ""));
  if (matched) return matched.Name;

  // 2. Generic / Text Only
  matched = printers.find(p => /generic/i.test(p.Name || "") || /generic/i.test(p.DriverName || ""));
  if (matched) return matched.Name;

  // 3. Fallback to first printer
  return printers[0]?.Name || "TVS RP 3200";
}

/**
 * Send raw binary buffer directly to Windows printer using RAW data type
 */
function printRawBytes(printerName, buffer) {
  return new Promise(async (resolve, reject) => {
    try {
      const targetPrinter = printerName || (await findThermalPrinter());
      const tempBin = path.join(os.tmpdir(), `receipt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}.bin`);
      const tempPs = path.join(os.tmpdir(), `print_${Date.now()}_${Math.random().toString(36).slice(2, 7)}.ps1`);

      fs.writeFileSync(tempBin, buffer);

      // Printer name and file path are passed via environment variables, not
      // interpolated into the script text — printerName comes straight from
      // an HTTP request body, and string-interpolating it into PowerShell
      // source (even quote-escaped) is a command-injection hole: PowerShell
      // still evaluates $(...) and other expressions inside a double-quoted
      // string. Env var values are never parsed as code.
      const psScript = `
${PS_RAW_HELPER}
$printer = $env:PRINT_AGENT_PRINTER_NAME
$binPath = $env:PRINT_AGENT_BIN_PATH
$bytes = [System.IO.File]::ReadAllBytes($binPath)
$success = [RawPrinterHelper]::SendBytesToPrinter($printer, $bytes)
if ($success) {
    Write-Output "PRINT_SUCCESS"
} else {
    Write-Error "Failed to write raw bytes to printer: $printer"
}
`;
      fs.writeFileSync(tempPs, psScript, "utf8");

      exec(`powershell -NoProfile -ExecutionPolicy Bypass -File "${tempPs}"`, {
        windowsHide: true,
        env: { ...process.env, PRINT_AGENT_PRINTER_NAME: targetPrinter, PRINT_AGENT_BIN_PATH: tempBin },
      }, (err, stdout, stderr) => {
        // Cleanup temp files
        try { fs.unlinkSync(tempBin); } catch (_) {}
        try { fs.unlinkSync(tempPs); } catch (_) {}

        if (err || stderr.includes("Failed to write")) {
          return reject(new Error(stderr || err?.message || "Print failed"));
        }
        resolve({ success: true, printer: targetPrinter });
      });
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = {
  getInstalledPrinters,
  findThermalPrinter,
  printRawBytes
};
