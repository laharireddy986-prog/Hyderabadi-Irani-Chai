const express = require("express");
const http = require("http");
const { WebSocketServer } = require("ws");
const { getInstalledPrinters, findThermalPrinter, printRawBytes } = require("./rawPrinter");

const app = express();
const PORT = 8989;

// Only the real POS site(s) may talk to this local agent. A wildcard origin
// here would let ANY website open in the cashier's browser — an ad, a
// phishing link, a compromised site in another tab — silently send print
// jobs (and, combined with the printer-name injection this app used to
// have, run arbitrary commands) to this machine.
const ALLOWED_ORIGINS = (process.env.PRINT_AGENT_ALLOWED_ORIGINS ||
  "https://hyderabadiirani.net,https://www.hyderabadiirani.net,https://hyderabadi-irani-web-826716276634.asia-south1.run.app,http://localhost:3000,http://127.0.0.1:3000"
).split(",").map((o) => o.trim()).filter(Boolean);

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
  // CRITICAL for Chrome HTTPS -> HTTP localhost (Private Network Access)
  res.setHeader("Access-Control-Allow-Private-Network", "true");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }
  next();
});

app.use(express.json({ limit: "10mb" }));
app.use(express.raw({ type: "application/octet-stream", limit: "10mb" }));

// 1. Health & Status
app.get("/status", async (req, res) => {
  try {
    const printers = await getInstalledPrinters();
    const defaultPrinter = await findThermalPrinter();
    res.json({
      status: "online",
      version: "1.1.0",
      printer: defaultPrinter,
      printers: printers.map(p => ({
        name: p.Name,
        port: p.PortName,
        driver: p.DriverName
      }))
    });
  } catch (err) {
    res.status(500).json({ status: "error", message: err.message });
  }
});

// 2. List Installed Printers
app.get("/printers", async (req, res) => {
  try {
    const printers = await getInstalledPrinters();
    res.json({ printers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Print Raw ESC/POS Buffer
app.post("/print-raw", async (req, res) => {
  try {
    let buffer;
    let targetPrinter = req.body?.printerName;

    if (Buffer.isBuffer(req.body)) {
      buffer = req.body;
    } else if (req.body?.data) {
      buffer = typeof req.body.data === "string" 
        ? Buffer.from(req.body.data, "base64")
        : Buffer.from(req.body.data);
    } else {
      return res.status(400).json({ error: "No print data provided (expected base64 'data' or raw bytes)" });
    }

    if (!buffer || buffer.length === 0) {
      return res.status(400).json({ error: "Empty print buffer" });
    }

    const result = await printRawBytes(targetPrinter, buffer);
    console.log(`[PRINT AGENT] Successfully sent ${buffer.length} bytes to ${result.printer}`);
    res.json({ success: true, message: `Printed to ${result.printer}`, bytes: buffer.length });
  } catch (err) {
    console.error("[PRINT AGENT] Print error:", err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Test Print Endpoint
app.post("/test", async (req, res) => {
  try {
    const targetPrinter = req.body?.printerName || (await findThermalPrinter());
    
    // ESC/POS Commands
    const ESC = 0x1B;
    const GS = 0x1D;
    
    const bytes = [];
    const add = (arr) => bytes.push(...arr);
    const addStr = (str) => {
      for (let i = 0; i < str.length; i++) {
        bytes.push(str.charCodeAt(i));
      }
    };

    // 1. Initialize
    add([ESC, 0x40]);
    // 2. Center Align
    add([ESC, 0x61, 0x01]);
    // Double height & width
    add([ESC, 0x21, 0x30]);
    addStr("HYDERABADI IRANI\n");
    // Normal text
    add([ESC, 0x21, 0x00]);
    addStr("------------------------------------------\n");
    addStr("Petpooja-Style 0-Click Local Agent: ACTIVE\n");
    addStr(`Date/Time: ${new Date().toLocaleString()}\n`);
    addStr(`Printer: ${targetPrinter}\n`);
    addStr("------------------------------------------\n");
    addStr("Item                 Qty    Price     Amount\n");
    addStr("------------------------------------------\n");
    addStr("Hydi Irani Tea         1    20.00      20.00\n");
    addStr("Osmania Biscuit        2    10.00      20.00\n");
    addStr("------------------------------------------\n");
    add([ESC, 0x21, 0x20]); // Bold Double-height
    addStr("Grand Total: Rs 40.00\n");
    add([ESC, 0x21, 0x00]);
    addStr("------------------------------------------\n");
    addStr("Thanks\n");
    addStr("Powered by NovaSaaS\n");
    addStr("\n\n\n\n");
    // Full Auto-Cut: GS V 65 0
    add([GS, 0x56, 0x41, 0x00]);

    const buf = Buffer.from(bytes);
    const result = await printRawBytes(targetPrinter, buf);
    res.json({ success: true, message: `Test slip sent to ${result.printer}` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

const server = http.createServer(app);

// 5. WebSocket Server (ws://127.0.0.1:8989)
// WebSockets from HTTPS websites to ws://127.0.0.1 are 100% permitted by modern browsers without mixed-content blocks!
// The WebSocket handshake isn't covered by the CORS middleware above, so
// enforce the same origin allowlist here — otherwise any page in the
// cashier's browser could open a socket and issue print jobs.
const wss = new WebSocketServer({
  server,
  verifyClient: (info) => ALLOWED_ORIGINS.includes(info.origin),
});

wss.on("connection", async (ws) => {
  console.log("[PRINT AGENT] WebSocket client connected from Web POS!");
  
  // Send immediate status greeting
  try {
    const defaultPrinter = await findThermalPrinter();
    ws.send(JSON.stringify({
      type: "STATUS",
      status: "online",
      version: "1.1.0",
      printer: defaultPrinter
    }));
  } catch (e) {
    ws.send(JSON.stringify({ type: "STATUS", status: "online", version: "1.1.0" }));
  }

  ws.on("message", async (message) => {
    try {
      const data = JSON.parse(message.toString());
      console.log(`[PRINT AGENT] Received WS message: ${data.action || data.type}`);

      if (data.action === "STATUS" || data.type === "STATUS") {
        const defaultPrinter = await findThermalPrinter();
        ws.send(JSON.stringify({
          type: "STATUS",
          status: "online",
          printer: defaultPrinter
        }));
      } else if (data.action === "PRINT_RAW" || data.action === "print_raw") {
        const targetPrinter = data.printerName;
        let buf = null;
        if (typeof data.data === "string") {
          buf = Buffer.from(data.data, "base64");
        } else if (Array.isArray(data.data)) {
          buf = Buffer.from(data.data);
        }
        if (buf) {
          const result = await printRawBytes(targetPrinter, buf);
          ws.send(JSON.stringify({
            type: "PRINT_RESULT",
            success: true,
            message: `Printed to ${result.printer}`,
            requestId: data.requestId
          }));
        } else {
          ws.send(JSON.stringify({
            type: "PRINT_RESULT",
            success: false,
            error: "No binary buffer provided",
            requestId: data.requestId
          }));
        }
      } else if (data.action === "TEST_PRINT" || data.action === "test") {
        const targetPrinter = data.printerName || (await findThermalPrinter());
        const ESC = 0x1B;
        const GS = 0x1D;
        const bytes = [];
        const add = (arr) => bytes.push(...arr);
        const addStr = (str) => {
          for (let i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i));
        };
        add([ESC, 0x40, ESC, 0x61, 0x01, ESC, 0x21, 0x30]);
        addStr("HYDERABADI IRANI\n");
        add([ESC, 0x21, 0x00]);
        addStr("TVS RP 3200 PRINT AGENT TEST\n");
        addStr("------------------------------------------\n");
        addStr("Petpooja-Style 0-Click Local Agent: ACTIVE\n");
        addStr(`Date/Time: ${new Date().toLocaleString()}\n`);
        addStr(`Printer: ${targetPrinter}\n`);
        addStr("------------------------------------------\n");
        addStr("Item                 Qty    Price     Amount\n");
        addStr("------------------------------------------\n");
        addStr("Hydi Irani Tea         1    20.00      20.00\n");
        addStr("Osmania Biscuit        2    10.00      20.00\n");
        addStr("------------------------------------------\n");
        add([ESC, 0x21, 0x20]);
        addStr("Grand Total: Rs 40.00\n");
        add([ESC, 0x21, 0x00]);
        addStr("------------------------------------------------\n");
        addStr("Thanks\n");
        addStr("Powered by NovaSaaS\n");
        addStr("\n\n\n\n");
        add([GS, 0x56, 0x41, 0x00]);
        const buf = Buffer.from(bytes);
        const result = await printRawBytes(targetPrinter, buf);
        ws.send(JSON.stringify({
          type: "PRINT_RESULT",
          success: true,
          message: `Test slip printed to ${result.printer}`,
          requestId: data.requestId
        }));
      }
    } catch (err) {
      console.error("[PRINT AGENT] WS Handler Error:", err.message);
      ws.send(JSON.stringify({
        type: "ERROR",
        error: err.message
      }));
    }
  });

  ws.on("close", () => {
    console.log("[PRINT AGENT] WebSocket client disconnected");
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`=======================================================`);
  console.log(`☕ Hyderabadi Irani - Petpooja-Style Local Print Agent`);
  console.log(`🟢 HTTP & WebSocket Server Running at: http://127.0.0.1:${PORT} & ws://127.0.0.1:${PORT}`);
  console.log(`⚡ Raw WinSpool Thermal Bridge for TVS RP 3200 STAR AU`);
  console.log(`=======================================================`);
});
