@echo off
title Hyderabadi Irani POS - 1-Click Installer
color 0B

echo ====================================================================
echo   HYDERABADI IRANI - AUTOMATIC CLIENT SETUP & SHORTCUT CREATOR
echo ====================================================================
echo.

:: 1. Check Node.js
echo [1/3] Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo [WARNING] Node.js is NOT found on this system!
    echo Please download and install Node.js (LTS) from: https://nodejs.org
    echo After installing Node.js, run this file again.
    echo.
    pause
    exit /b 1
) else (
    echo       Node.js is INSTALLED.
)

:: 2. Install dependencies if needed
echo [2/3] Checking Print Agent dependencies...
cd /d "%~dp0\print-agent"
if not exist "node_modules" (
    echo       Installing npm packages...
    call npm install
) else (
    echo       Dependencies already present.
)

:: 3. Create Desktop & Startup Shortcuts using PowerShell
echo [3/3] Creating Desktop and Windows Startup Shortcuts...
cd /d "%~dp0"
powershell -NoProfile -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$startup = [Environment]::GetFolderPath('Startup'); " ^
  "$s1 = $ws.CreateShortcut((Join-Path $desktop 'Hyderabadi Irani POS.lnk')); " ^
  "$s1.TargetPath = '%~dp0HYDERABADI_IRANI_POS.bat'; " ^
  "$s1.WorkingDirectory = '%~dp0'; " ^
  "$s1.Description = 'Launch Hyderabadi Irani POS with 0-Click Auto Print'; " ^
  "$s1.Save(); " ^
  "$s2 = $ws.CreateShortcut((Join-Path $startup 'Hyderabadi Irani Print Agent.lnk')); " ^
  "$s2.TargetPath = '%~dp0start_print_agent.bat'; " ^
  "$s2.WorkingDirectory = '%~dp0'; " ^
  "$s2.WindowStyle = 7; " ^
  "$s2.Description = 'Background Thermal Print Agent for Hyderabadi Irani POS'; " ^
  "$s2.Save();"

echo.
echo ====================================================================
echo   [SUCCESS] Setup Completed!
echo.
echo   1. Desktop Shortcut created: 'Hyderabadi Irani POS'
echo   2. Auto-Start on Windows boot configured in Startup folder!
echo.
echo   You can now double-click the 'Hyderabadi Irani POS' icon
echo   on your Desktop to start billing!
echo ====================================================================
echo.
pause
