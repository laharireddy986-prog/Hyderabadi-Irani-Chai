import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { Toaster } from "sonner";
import { CartProvider } from "./context/CartContext.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider>
      <CartProvider>
        <App />
        <Toaster
          position="top-center"
          richColors
          toastOptions={{
            duration: 2500,
            style: {
              borderRadius: "16px",
              padding: "12px 16px",
              fontSize: "13px",
              fontWeight: "600",
            },
          }}
        />
      </CartProvider>
    </AuthProvider>
  </React.StrictMode>
);
