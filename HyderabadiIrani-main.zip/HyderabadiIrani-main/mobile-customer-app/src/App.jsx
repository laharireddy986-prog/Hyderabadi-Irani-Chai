import React, { useState, useEffect, useMemo, useRef } from "react";
import Header from "./components/Header";
import HeroCarousel from "./components/HeroCarousel";
import QuickServiceSelector from "./components/QuickServiceSelector";
import CategoryStories from "./components/CategoryStories";
import DishCard from "./components/DishCard";
import DishDetailModal from "./components/DishDetailModal";
import FloatingCartBar from "./components/FloatingCartBar";
import CartModal from "./components/CartModal";
import OrderTrackingModal from "./components/OrderTrackingModal";
import LocationSelectDrawer from "./components/LocationSelectDrawer";
import LocationPickerModal from "./components/LocationPickerModal";
import TableQrScannerModal from "./components/TableQrScannerModal";
import AccountModal from "./components/AccountModal";
import BottomNavBar from "./components/BottomNavBar";
import NotificationPermissionPrompt from "./components/NotificationPermissionPrompt";
import { DishCardSkeleton } from "./components/Skeletons";
import { EmptySearchState, NetworkErrorState } from "./components/EmptyState";
import { api, errMsg } from "./lib/api";
import { initializePushNotifications } from "./lib/notifications";
import { useAuth } from "./context/AuthContext";
import { useCart } from "./context/CartContext";
import { Search, Sparkles, Mic, SlidersHorizontal, X } from "lucide-react";
import { toast } from "sonner";

export default function App() {
  const { customer } = useAuth();
  const { deliveryAddress, setDeliveryAddress } = useCart();

  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [storeStatus, setStoreStatus] = useState({ is_online_open: true, notice: "" });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedQuickFilter, setSelectedQuickFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isVegOnly, setIsVegOnly] = useState(false);
  const [activeTab, setActiveTab] = useState("menu"); // menu, search, account

  // Modals & Drawers
  const [detailItem, setDetailItem] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [trackingOrder, setTrackingOrder] = useState(null);
  const [trackingReturnToAccount, setTrackingReturnToAccount] = useState(false);
  const [tableScannerOpen, setTableScannerOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [locationSelectOpen, setLocationSelectOpen] = useState(false);
  const [mapPickerOpen, setMapPickerOpen] = useState(false);

  // Rotating placeholder keywords (Zomato style: "cake", "biryani", "irani chai", "shawarma")
  const searchPlaceholders = useMemo(
    () => ['Search "biryani"', 'Search "chai & osmania"', 'Search "kebabs"', 'Search "butter chicken"'],
    []
  );
  const [placeholderIndex, setPlaceholderIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setPlaceholderIndex((prev) => (prev + 1) % searchPlaceholders.length);
    }, 3000);
    return () => clearInterval(timer);
  }, [searchPlaceholders.length]);

  // Initialize push notification listeners & deep-linking
  useEffect(() => {
    initializePushNotifications({
      onOpenOrderTracking: (orderInfo) => {
        setTrackingOrder(orderInfo);
      },
    });
  }, []);

  // Android hardware Back button: close whichever modal/drawer is on top
  // instead of exiting the app (the default Capacitor behavior when no
  // listener is registered is to kill the app on every back press).
  // Registered exactly once (empty deps) and reads the latest modal state
  // via a ref — re-subscribing on every state change raced the async
  // addListener()/remove() pair and could leave the listener detached.
  const modalStateRef = useRef({});
  modalStateRef.current = {
    mapPickerOpen,
    locationSelectOpen,
    detailItem,
    trackingOrder,
    trackingReturnToAccount,
    tableScannerOpen,
    accountOpen,
    cartOpen,
  };

  useEffect(() => {
    if (!window.Capacitor?.isNativePlatform()) return;

    let handle;
    let cancelled = false;
    import("@capacitor/app").then(({ App: CapApp }) => {
      if (cancelled) return;
      CapApp.addListener("backButton", () => {
        const s = modalStateRef.current;
        if (s.mapPickerOpen) return setMapPickerOpen(false);
        if (s.locationSelectOpen) return setLocationSelectOpen(false);
        if (s.detailItem) return setDetailItem(null);
        if (s.trackingOrder) {
          if (s.trackingReturnToAccount) {
            setTrackingOrder(null);
            setAccountOpen(true);
            setTrackingReturnToAccount(false);
            return;
          }
          return setTrackingOrder(null);
        }
        if (s.tableScannerOpen) return setTableScannerOpen(false);
        if (s.accountOpen) return setAccountOpen(false);
        if (s.cartOpen) return setCartOpen(false);
        CapApp.minimizeApp();
      }).then((h) => {
        handle = h;
      });
    });

    return () => {
      cancelled = true;
      handle?.remove();
    };
  }, []);

  // Load menu & store status from live backend
  const loadMenu = async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const [menuRes, catsRes, statusRes] = await Promise.all([
        api.get("/menu"),
        api.get("/menu/categories").catch(() => ({ data: { categories: [] } })),
        api.get("/store/status").catch(() => ({ data: { is_online_open: true, notice: "" } })),
      ]);
      const rawItems = menuRes.data || [];
      setItems(rawItems);
      if (statusRes.data) {
        setStoreStatus(statusRes.data);
      }

      let fetchedCats = catsRes.data?.categories || [];
      if (!fetchedCats.length) {
        fetchedCats = Array.from(new Set(rawItems.map((i) => i.category).filter(Boolean)));
      }
      setCategories(fetchedCats);
    } catch (e) {
      const err = errMsg(e) || "Unable to load menu from kitchen.";
      setFetchError(err);
      toast.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Silent background sync
  const refreshMenuSilently = async () => {
    try {
      const [menuRes, statusRes] = await Promise.all([
        api.get("/menu"),
        api.get("/store/status").catch(() => null),
      ]);
      if (menuRes.data && Array.isArray(menuRes.data)) {
        setItems(menuRes.data);
      }
      if (statusRes?.data) {
        setStoreStatus(statusRes.data);
      }
    } catch {}
  };

  useEffect(() => {
    loadMenu();

    const interval = setInterval(refreshMenuSilently, 15000);
    const handleVisibility = () => {
      if (document.visibilityState === "visible") {
        refreshMenuSilently();
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, []);

  // Items count map for category chips
  const itemsCountMap = useMemo(() => {
    const map = { All: items.length };
    categories.forEach((cat) => {
      map[cat] = items.filter(
        (i) => i.category?.toLowerCase() === cat.toLowerCase()
      ).length;
    });
    return map;
  }, [items, categories]);

  // Filtered dishes
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchCat =
        selectedCategory === "All" ||
        item.category?.toLowerCase() === selectedCategory.toLowerCase();

      const matchVeg = !isVegOnly || item.veg === true;

      const matchSearch =
        !searchQuery ||
        item.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchQuery.toLowerCase());

      let matchQuick = true;
      if (selectedQuickFilter === "under200") {
        matchQuick = Number(item.price) <= 200;
      } else if (selectedQuickFilter === "under250") {
        matchQuick = Number(item.price) <= 250;
      } else if (selectedQuickFilter === "bestseller") {
        matchQuick =
          item.category?.toLowerCase() === "biryani" ||
          item.category?.toLowerCase() === "tea" ||
          item.category?.toLowerCase() === "chai" ||
          Number(item.price) >= 200;
      } else if (selectedQuickFilter === "spicy") {
        matchQuick =
          item.name?.toLowerCase().includes("biryani") ||
          item.name?.toLowerCase().includes("tikka") ||
          item.name?.toLowerCase().includes("chicken") ||
          item.name?.toLowerCase().includes("chilli");
      }

      return matchCat && matchVeg && matchSearch && matchQuick;
    });
  }, [items, selectedCategory, isVegOnly, searchQuery, selectedQuickFilter]);

  // Voice search helper
  const handleVoiceSearch = () => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.info("Voice search is not supported by your browser. Please type to search.");
      return;
    }
    try {
      const recognition = new SpeechRecognition();
      recognition.lang = "en-IN";
      recognition.onstart = () => {
        toast.info("Listening... Speak your dish name! 🎙️");
      };
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
        toast.success(`Searching for: "${transcript}"`);
      };
      recognition.onerror = () => {
        toast.error("Voice input cancelled or unavailable");
      };
      recognition.start();
    } catch {
      toast.info("Voice search unavailable.");
    }
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] text-stone-900 pb-32">
      {/* Top Header with Location Drawer Trigger, Wallet & Profile Avatar (Image 4) */}
      <Header
        onOpenLocation={() => setLocationSelectOpen(true)}
        onOpenSearch={() => {
          setActiveTab("search");
          window.scrollTo({ top: 150, behavior: "smooth" });
        }}
        onOpenTableScanner={() => setTableScannerOpen(true)}
        onOpenAccount={() => setAccountOpen(true)}
      />

      {/* Store Closed / Busy Live Notice Banner */}
      {!storeStatus.is_online_open && (
        <div className="bg-amber-950 text-amber-200 px-4 py-2.5 text-xs font-bold flex items-center justify-between shadow-md border-b border-amber-800 animate-in fade-in sticky top-14 z-30">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping flex-shrink-0" />
            <span>
              {storeStatus.notice ||
                "Online Ordering is currently paused by the kitchen. You can still browse the menu!"}
            </span>
          </div>
        </div>
      )}

      {/* Main Scrollable View */}
      <main className="max-w-md mx-auto">
        {/* Top Search Bar with Mic & VEG Toggle Switch (Exact Image 4 Style) */}
        <div className="px-4 pt-3 pb-1">
          <div className="flex items-center gap-2.5">
            {/* Search Input Box */}
            <div className="relative flex-1 flex items-center bg-white border border-stone-200/90 rounded-2xl shadow-2xs">
              <Search size={17} className="absolute left-3.5 text-red-500 stroke-[2.5]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={searchPlaceholders[placeholderIndex]}
                className="w-full bg-transparent pl-10 pr-16 py-3 text-xs sm:text-sm font-medium text-stone-900 outline-none placeholder:text-stone-400 placeholder:transition-all"
              />

              {/* Clear or Mic Icon */}
              <div className="absolute right-3 flex items-center gap-1.5">
                {searchQuery ? (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="text-stone-400 hover:text-stone-600 p-1"
                  >
                    <X size={15} />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleVoiceSearch}
                    className="text-red-500 hover:text-red-600 p-1 transition active-press"
                    title="Voice Search"
                  >
                    <Mic size={17} className="stroke-[2.2]" />
                  </button>
                )}
              </div>
            </div>

            {/* VEG Switch Toggle (Image 4 Style) */}
            <div className="flex flex-col items-center justify-center flex-shrink-0 bg-white border border-stone-200/90 rounded-2xl px-2.5 py-1.5 shadow-2xs">
              <span className="text-[9px] font-black tracking-wider text-emerald-800 uppercase leading-none">
                VEG
              </span>
              <button
                type="button"
                onClick={() => setIsVegOnly(!isVegOnly)}
                className={`mt-1 w-9 h-5 rounded-full transition-colors relative flex items-center p-0.5 ${
                  isVegOnly ? "bg-emerald-600" : "bg-stone-300"
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white shadow-xs transition-transform duration-200 ${
                    isVegOnly ? "translate-x-4" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Top Hero Slideable Banners / Promo Cards (Image 4 Style) */}
        <HeroCarousel
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            setSelectedQuickFilter("");
            window.scrollTo({ top: 380, behavior: "smooth" });
          }}
          onSelectFilter={(filt) => {
            setSelectedQuickFilter(filt);
            window.scrollTo({ top: 380, behavior: "smooth" });
          }}
          onOpenAccount={() => setAccountOpen(true)}
          onOpenTableScanner={() => setTableScannerOpen(true)}
        />

        {/* Quick Fulfillment Mode Picker (Delivery, Dine-in, Takeaway) */}
        <QuickServiceSelector onOpenTableScanner={() => setTableScannerOpen(true)} />

        {/* Category Horizontal Food Icon Carousel (Zomato Style from Image 4 & Image 1) */}
        <CategoryStories
          categories={categories}
          items={items}
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            setSelectedQuickFilter("");
          }}
          isVegOnly={isVegOnly}
          onToggleVegOnly={() => setIsVegOnly(!isVegOnly)}
          itemsCountMap={itemsCountMap}
          selectedQuickFilter={selectedQuickFilter}
          onSelectQuickFilter={setSelectedQuickFilter}
        />

        {/* Active Category Heading & Reset Pill */}
        <div className="px-4 pt-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-black text-stone-900">
            <Sparkles size={13} className="text-amber-500 fill-amber-400" />
            <span>
              {selectedQuickFilter === "under250"
                ? "Pocket Deals Under ₹250"
                : `${selectedCategory} Dishes`}{" "}
              ({filteredItems.length})
            </span>
            {selectedQuickFilter && (
              <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-md uppercase font-black">
                {selectedQuickFilter}
              </span>
            )}
          </div>

          {(isVegOnly || selectedQuickFilter || searchQuery || selectedCategory !== "All") && (
            <button
              type="button"
              onClick={() => {
                setIsVegOnly(false);
                setSelectedQuickFilter("");
                setSearchQuery("");
                setSelectedCategory("All");
              }}
              className="text-[11px] text-red-600 font-extrabold hover:underline"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Menu Dishes Grid */}
        <div className="px-4 mt-3">
          {loading ? (
            <div className="grid grid-cols-1 gap-3">
              {[...Array(6)].map((_, i) => (
                <DishCardSkeleton key={i} />
              ))}
            </div>
          ) : fetchError ? (
            <NetworkErrorState onRetry={loadMenu} />
          ) : filteredItems.length === 0 ? (
            <EmptySearchState
              query={searchQuery}
              onClear={() => {
                setSearchQuery("");
                setSelectedCategory("All");
                setIsVegOnly(false);
                setSelectedQuickFilter("");
              }}
            />
          ) : (
            <div className="grid grid-cols-1 gap-3.5">
              {filteredItems.map((item) => (
                <DishCard
                  key={item.id}
                  item={item}
                  onOpenDetail={(dish) => setDetailItem(dish)}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Floating Bottom Cart Bar */}
      <FloatingCartBar onOpenCart={() => setCartOpen(true)} />

      {/* Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === "account") setAccountOpen(true);
          if (tab === "search") {
            window.scrollTo({ top: 0, behavior: "smooth" });
          }
          if (tab === "menu") {
            window.scrollTo({ top: 0, behavior: "smooth" });
          }
        }}
        onOpenCart={() => setCartOpen(true)}
      />

      {/* Zomato-Style Location Selector Drawer (Image 2) */}
      {locationSelectOpen && (
        <LocationSelectDrawer
          isOpen={locationSelectOpen}
          onClose={() => setLocationSelectOpen(false)}
          onOpenMapPicker={() => setMapPickerOpen(true)}
        />
      )}

      {/* Interactive Leaflet Map Modal */}
      {mapPickerOpen && (
        <LocationPickerModal
          isOpen={mapPickerOpen}
          onClose={() => setMapPickerOpen(false)}
          initialAddress={deliveryAddress}
          onSelectLocation={(newAddr) => {
            setDeliveryAddress(newAddr);
            setMapPickerOpen(false);
          }}
        />
      )}

      {/* Zomato-Style Dish Detail & Cooking Customization Modal (Image 3) */}
      {detailItem && (
        <DishDetailModal
          item={detailItem}
          allItems={items}
          onSelectDish={(dish) => setDetailItem(dish)}
          onClose={() => setDetailItem(null)}
        />
      )}

      {/* Cart & Checkout Modal */}
      {cartOpen && (
        <CartModal
          isOpen={cartOpen}
          allItems={items}
          onSelectDish={(dish) => {
            setCartOpen(false);
            setDetailItem(dish);
          }}
          onClose={() => setCartOpen(false)}
          onOpenLogin={() => {
            setCartOpen(false);
            setAccountOpen(true);
          }}
          onOrderSuccess={(order) => setTrackingOrder(order)}
          isOnlineOpen={storeStatus.is_online_open}
          storeNotice={storeStatus.notice}
        />
      )}

      {/* Live Order Tracking Modal */}
      {trackingOrder && (
        <OrderTrackingModal
          order={trackingOrder}
          onBack={() => {
            if (trackingReturnToAccount) {
              setTrackingOrder(null);
              setAccountOpen(true);
              setTrackingReturnToAccount(false);
            } else {
              setTrackingOrder(null);
            }
          }}
          onClose={() => {
            setTrackingOrder(null);
            setTrackingReturnToAccount(false);
          }}
        />
      )}

      {/* Table QR Scanner */}
      {tableScannerOpen && (
        <TableQrScannerModal
          isOpen={tableScannerOpen}
          onClose={() => setTableScannerOpen(false)}
        />
      )}

      {/* Customer Account & Orders */}
      {accountOpen && (
        <AccountModal
          isOpen={accountOpen}
          onClose={() => setAccountOpen(false)}
          onTrackOrder={(order) => {
            setTrackingReturnToAccount(true);
            setAccountOpen(false);
            setTrackingOrder(order);
          }}
        />
      )}

      {/* Push Notification Permission Explainer */}
      <NotificationPermissionPrompt customerPhone={customer?.phone} />
    </div>
  );
}
