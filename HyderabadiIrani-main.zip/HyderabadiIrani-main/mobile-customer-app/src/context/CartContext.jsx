import { createContext, useContext, useState, useEffect, useMemo } from "react";
import { toast } from "sonner";
import { STORE_LOCATION } from "../lib/deliveryTerms";

const CartContext = createContext(null);

const DEFAULT_HOTEL_ADDRESS = {
  street: "Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta",
  area: "Godumakunta",
  city: "Secunderabad",
  pincode: "501302",
  lat: STORE_LOCATION.lat,
  lng: STORE_LOCATION.lng,
  label: "At Hotel",
};

export function CartProvider({ children }) {
  const [lines, setLines] = useState(() => {
    try {
      const saved = localStorage.getItem("hi_cart_lines");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [serviceType, setServiceType] = useState(() => {
    return localStorage.getItem("hi_service_type") || "delivery"; // delivery, takeaway, dinein
  });

  const [tableNo, setTableNo] = useState(() => {
    return localStorage.getItem("hi_table_no") || "";
  });

  const [deliveryAddress, setDeliveryAddress] = useState(() => {
    try {
      const saved = localStorage.getItem("hi_delivery_addr");
      if (saved) {
        const parsed = JSON.parse(saved);
        // If legacy address contained Gunfoundry or default 500001, reset to actual hotel location
        if (
          parsed.street?.includes("Gunfoundry") ||
          parsed.pincode === "500001" ||
          !parsed.lat
        ) {
          return DEFAULT_HOTEL_ADDRESS;
        }
        return parsed;
      }
      return DEFAULT_HOTEL_ADDRESS;
    } catch {
      return DEFAULT_HOTEL_ADDRESS;
    }
  });

  const [recentOrders, setRecentOrders] = useState(() => {
    try {
      const saved = localStorage.getItem("hi_recent_orders");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [promoCode, setPromoCode] = useState("");
  const [discountAmount, setDiscountAmount] = useState(0);

  useEffect(() => {
    localStorage.setItem("hi_cart_lines", JSON.stringify(lines));
  }, [lines]);

  useEffect(() => {
    localStorage.setItem("hi_service_type", serviceType);
  }, [serviceType]);

  useEffect(() => {
    localStorage.setItem("hi_table_no", tableNo);
  }, [tableNo]);

  useEffect(() => {
    localStorage.setItem("hi_delivery_addr", JSON.stringify(deliveryAddress));
  }, [deliveryAddress]);

  useEffect(() => {
    localStorage.setItem("hi_recent_orders", JSON.stringify(recentOrders));
  }, [recentOrders]);

  const addItem = (item, delta = 1, notes = "", variant = null) => {
    if (item.available === false) {
      toast.error(`"${item.name}" is currently Out of Stock`);
      return;
    }

    const rawId = item.id || item.base_item_id || item.item_id;
    const lineId = variant
      ? `${rawId}_${variant.name.toLowerCase()}`
      : item.item_id || rawId;

    const baseName = item.name ? item.name.replace(/\s*\([^)]*\)$/, "") : "";
    const lineName = variant
      ? `${baseName} (${variant.name})`
      : item.name;

    const unitPrice = variant
      ? Number(variant.price)
      : Number(item.price) || 0;

    setLines((prev) => {
      const existing = prev.find((l) => l.item_id === lineId);
      if (existing) {
        const newQty = existing.qty + delta;
        if (newQty <= 0) {
          return prev.filter((l) => l.item_id !== lineId);
        }
        return prev.map((l) =>
          l.item_id === lineId
            ? { ...l, qty: newQty, notes: notes || l.notes || "" }
            : l
        );
      }
      if (delta > 0) {
        return [
          ...prev,
          {
            item_id: lineId,
            base_item_id: rawId,
            name: lineName,
            variant: variant ? variant.name : item.variant || null,
            price: unitPrice,
            qty: delta,
            veg: Boolean(item.veg),
            notes: notes || item.notes || "",
            image_url: item.image_url || "",
            category: item.category || "General",
            station: item.station || "kitchen",
          },
        ];
      }
      return prev;
    });

    if (delta > 0) {
      toast.success(`Added ${lineName} to order 🛒`, { duration: 1500 });
    }
  };

  const updateLineQty = (lineId, delta) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.item_id === lineId);
      if (!existing) return prev;
      const newQty = existing.qty + delta;
      if (newQty <= 0) {
        return prev.filter((l) => l.item_id !== lineId);
      }
      return prev.map((l) =>
        l.item_id === lineId ? { ...l, qty: newQty } : l
      );
    });
  };

  const removeItem = (itemId) => {
    setLines((prev) => prev.filter((l) => l.item_id !== itemId));
    toast.info("Item removed from cart");
  };

  const updateItemNotes = (itemId, notes) => {
    setLines((prev) =>
      prev.map((l) => (l.item_id === itemId ? { ...l, notes } : l))
    );
  };

  const clearCart = () => {
    setLines([]);
    setPromoCode("");
    setDiscountAmount(0);
  };

  const addPlacedOrder = (order) => {
    setRecentOrders((prev) => [order, ...prev.slice(0, 19)]);
  };

  const itemCount = useMemo(() => {
    return lines.reduce((acc, l) => acc + (l.qty || 0), 0);
  }, [lines]);

  const subtotal = useMemo(() => {
    return lines.reduce((acc, l) => acc + (l.price || 0) * (l.qty || 0), 0);
  }, [lines]);

  const deliveryFee = useMemo(() => {
    if (serviceType !== "delivery") return 0;
    if (subtotal === 0) return 0;
    if (subtotal >= 499) return 0; // Free delivery above 499
    return 20;
  }, [serviceType, subtotal]);

  const total = useMemo(() => {
    return Math.max(0, subtotal + deliveryFee - discountAmount);
  }, [subtotal, deliveryFee, discountAmount]);

  const getItemQty = (itemId) => {
    return lines
      .filter(
        (l) =>
          l.item_id === itemId ||
          l.base_item_id === itemId ||
          (typeof l.item_id === "string" && l.item_id.startsWith(`${itemId}_`))
      )
      .reduce((sum, l) => sum + (l.qty || 0), 0);
  };

  return (
    <CartContext.Provider
      value={{
        lines,
        addItem,
        updateLineQty,
        removeItem,
        updateItemNotes,
        clearCart,
        itemCount,
        subtotal,
        deliveryFee,
        discountAmount,
        total,
        serviceType,
        setServiceType,
        tableNo,
        setTableNo,
        deliveryAddress,
        setDeliveryAddress,
        recentOrders,
        addPlacedOrder,
        getItemQty,
        promoCode,
        setPromoCode,
        setDiscountAmount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
