import { createContext, useContext, useState, useEffect, useRef } from "react";
import { api, errMsg } from "../lib/api";
import { setSecureItem, getSecureItem, removeSecureItem } from "../lib/storage";
import { syncCustomerTokenWithPhone } from "../lib/notifications";
import { toast } from "sonner";

const AuthContext = createContext(null);

const CUSTOMER_STORAGE_KEY = "hi_customer_profile";
const TOKEN_STORAGE_KEY = "hi_customer_token";

export function AuthProvider({ children }) {
  const [customer, setCustomer] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const timerRef = useRef(null);

  // Restore secure session on app startup
  useEffect(() => {
    async function loadSavedSession() {
      try {
        const savedToken = await getSecureItem(TOKEN_STORAGE_KEY);
        const savedProfileStr = await getSecureItem(CUSTOMER_STORAGE_KEY);

        if (savedToken) {
          setToken(savedToken);
        }

        if (savedProfileStr) {
          try {
            const parsed = JSON.parse(savedProfileStr);
            setCustomer(parsed);
          } catch {}
        }

        // If we have a token, verify and refresh latest profile and coins from server
        if (savedToken) {
          api
            .get("/customer/auth/me")
            .then(async (res) => {
              if (res.data) {
                setCustomer(res.data);
                await setSecureItem(CUSTOMER_STORAGE_KEY, JSON.stringify(res.data));
              }
            })
            .catch(() => {
              // Token might be expired or invalid
            });
        }
      } catch (err) {
        console.error("[AUTH] Error initializing session:", err);
      } finally {
        setLoading(false);
      }
    }

    loadSavedSession();
  }, []);

  // Cooldown timer interval
  useEffect(() => {
    if (cooldown > 0) {
      timerRef.current = setInterval(() => {
        setCooldown((c) => {
          if (c <= 1) {
            clearInterval(timerRef.current);
            return 0;
          }
          return c - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [cooldown]);

  // Request OTP
  const sendOtp = async (phone) => {
    const cleanPhone = phone.replace(/\D/g, "").slice(-10);
    if (!cleanPhone || cleanPhone.length !== 10) {
      toast.error("Please enter a valid 10-digit Indian mobile number");
      return { ok: false, error: "Invalid mobile number" };
    }

    if (cooldown > 0) {
      toast.info(`Please wait ${cooldown}s before requesting another OTP`);
      return { ok: false, error: "Cooldown active" };
    }

    setSendingOtp(true);
    try {
      const res = await api.post("/customer/auth/send-otp", { phone: cleanPhone });
      const data = res.data || {};
      setCooldown(data.cooldown_seconds || 45);
      toast.success(data.message || `OTP sent to +91 ${cleanPhone}`);
      return {
        ok: true,
        phone: cleanPhone,
        message: data.message,
        debug_otp: data.debug_otp,
      };
    } catch (err) {
      const msg = errMsg(err);
      toast.error(msg || "Failed to send verification code");
      return { ok: false, error: msg };
    } finally {
      setSendingOtp(false);
    }
  };

  // Verify OTP
  const verifyOtp = async (phone, otp, name = "") => {
    const cleanPhone = phone.replace(/\D/g, "").slice(-10);
    const cleanOtp = otp.replace(/\D/g, "").slice(0, 6);

    if (!cleanPhone || cleanPhone.length !== 10) {
      toast.error("Invalid mobile number");
      return { ok: false, error: "Invalid mobile number" };
    }

    if (!cleanOtp || cleanOtp.length !== 6) {
      toast.error("Please enter the complete 6-digit OTP code");
      return { ok: false, error: "Invalid OTP length" };
    }

    setVerifyingOtp(true);
    try {
      const res = await api.post("/customer/auth/verify-otp", {
        phone: cleanPhone,
        otp: cleanOtp,
        name: name ? name.trim() : undefined,
      });

      const { access_token, customer: verifiedCustomer } = res.data;

      if (!access_token || !verifiedCustomer) {
        throw new Error("Invalid response from server");
      }

      setToken(access_token);
      setCustomer(verifiedCustomer);

      // Save securely on device
      await setSecureItem(TOKEN_STORAGE_KEY, access_token);
      await setSecureItem(CUSTOMER_STORAGE_KEY, JSON.stringify(verifiedCustomer));
      await setSecureItem("hi_customer_phone", cleanPhone);

      // Associate device push notification token with phone
      syncCustomerTokenWithPhone(cleanPhone);

      toast.success(
        `Welcome to Hyderabadi Irani, ${verifiedCustomer.name || "Foodie"}! ☕`
      );

      return { ok: true, customer: verifiedCustomer, token: access_token };
    } catch (err) {
      const msg = errMsg(err);
      toast.error(msg || "Verification failed. Please check the code.");
      return { ok: false, error: msg };
    } finally {
      setVerifyingOtp(false);
    }
  };

  // Refresh customer profile & loyalty points
  const refreshProfile = async () => {
    if (!token && !customer?.phone) return;
    try {
      const res = await api.get("/customer/auth/me");
      if (res.data) {
        setCustomer(res.data);
        await setSecureItem(CUSTOMER_STORAGE_KEY, JSON.stringify(res.data));
      }
    } catch {}
  };

  // Logout & revoke secure tokens
  const logout = async () => {
    setCustomer(null);
    setToken(null);
    setCooldown(0);
    await removeSecureItem(TOKEN_STORAGE_KEY);
    await removeSecureItem(CUSTOMER_STORAGE_KEY);
    toast.info("Signed out of your account");
  };

  return (
    <AuthContext.Provider
      value={{
        customer,
        token,
        isLoggedIn: Boolean(customer?.phone && token),
        loading,
        sendingOtp,
        verifyingOtp,
        cooldown,
        sendOtp,
        verifyOtp,
        refreshProfile,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
