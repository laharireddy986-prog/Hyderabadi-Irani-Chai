import React, { useState, useEffect, useRef } from "react";
import {
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Coins,
  Flame,
  Moon,
  Truck,
  QrCode,
} from "lucide-react";

export default function HeroCarousel({
  onSelectCategory,
  onSelectFilter,
  onOpenAccount,
  onOpenTableScanner,
}) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);

  const SLIDES = [
    {
      id: "irani_chai",
      badge: "HERITAGE BREW",
      title: "Royal Irani Chai & Osmania",
      subtitle: "Slow-brewed saffron milk tea with fresh, crispy Osmania biscuits",
      cta: "Order Chai ₹25",
      bgGradient: "from-[#451a03] via-[#78350f] to-[#92400e]",
      accentColor: "text-amber-300",
      badgeBg: "bg-amber-400 text-amber-950",
      imgUrl:
        "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500&auto=format&fit=crop&q=80",
      action: () => onSelectCategory && onSelectCategory("Tea"),
      icon: Flame,
    },
    {
      id: "handi_biryani",
      badge: "FLAT ₹180 OFF",
      title: "Handi Dum Biryani",
      subtitle: "Authentic copper handi slow-cooked biryani with Mirchi ka Salan & Raita",
      cta: "Explore Biryani",
      bgGradient: "from-[#7f1d1d] via-[#991b1b] to-[#b91c1c]",
      accentColor: "text-red-200",
      badgeBg: "bg-red-500 text-white",
      imgUrl:
        "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&auto=format&fit=crop&q=80",
      action: () => onSelectCategory && onSelectCategory("Biryani"),
      icon: Sparkles,
    },
    {
      id: "loyalty_coins",
      badge: "100 COINS JOINING BONUS",
      title: "Get 100 Loyalty Coins!",
      subtitle: "Claim ₹25 OFF on each of your first 4 orders above ₹249 (Total ₹100 Welcome Gift)",
      cta: "Claim 100 Coins",
      bgGradient: "from-[#1e1b4b] via-[#312e81] to-[#4338ca]",
      accentColor: "text-yellow-300",
      badgeBg: "bg-yellow-400 text-yellow-950",
      imgUrl:
        "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=500&auto=format&fit=crop&q=80",
      action: () => onOpenAccount && onOpenAccount(),
      icon: Coins,
    },
    {
      id: "tandoori_kebabs",
      badge: "CHEF SPECIAL",
      title: "Tandoori & Nizami Kebabs",
      subtitle: "Smoky tandoori chicken tikka, mutton seekh & fresh rumali rotis",
      cta: "View Kebabs",
      bgGradient: "from-[#831843] via-[#9d174d] to-[#be185d]",
      accentColor: "text-pink-200",
      badgeBg: "bg-pink-500 text-white",
      imgUrl:
        "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=500&auto=format&fit=crop&q=80",
      action: () => onSelectCategory && onSelectCategory("Starters"),
      icon: Flame,
    },
    {
      id: "midnight_craving",
      badge: "OPEN TILL 6 AM",
      title: "Midnight Hunger Delivery",
      subtitle: "Late-night hot biryanis, shawarmas & tea delivered to your doorstep",
      cta: "Midnight Menu",
      bgGradient: "from-[#0f172a] via-[#1e293b] to-[#334155]",
      accentColor: "text-cyan-300",
      badgeBg: "bg-cyan-500 text-slate-950",
      imgUrl:
        "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=500&auto=format&fit=crop&q=80",
      action: () => onSelectFilter && onSelectFilter("under200"),
      icon: Moon,
    },
    {
      id: "free_delivery",
      badge: "ZERO CHARGE",
      title: "FREE Delivery Above ₹499",
      subtitle: "Enjoy free doorstep delivery on all family meals and group orders",
      cta: "Order Now",
      bgGradient: "from-[#064e3b] via-[#047857] to-[#059669]",
      accentColor: "text-emerald-200",
      badgeBg: "bg-emerald-400 text-emerald-950",
      imgUrl:
        "https://images.unsplash.com/photo-1526367790999-0150786686a2?w=500&auto=format&fit=crop&q=80",
      action: () => onSelectFilter && onSelectFilter("under250"),
      icon: Truck,
    },
    {
      id: "table_qr",
      badge: "DINE-IN CONTACTLESS",
      title: "Table QR Self-Ordering",
      subtitle: "Scan your table QR code to order instantly and track kitchen status",
      cta: "Scan Table QR",
      bgGradient: "from-[#312e81] via-[#4c1d95] to-[#581c87]",
      accentColor: "text-purple-200",
      badgeBg: "bg-purple-400 text-purple-950",
      imgUrl:
        "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=500&auto=format&fit=crop&q=80",
      action: () => onOpenTableScanner && onOpenTableScanner(),
      icon: QrCode,
    },
  ];

  // Auto slide
  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [isPaused, SLIDES.length]);

  const handleTouchStart = (e) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e) => {
    touchEndX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartX.current - touchEndX.current > 50) {
      // Swipe Left -> Next
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    } else if (touchStartX.current - touchEndX.current < -50) {
      // Swipe Right -> Prev
      setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
    }
  };

  const current = SLIDES[currentSlide];
  const CurrentIcon = current.icon;

  return (
    <div className="px-4 py-2 select-none font-sans">
      <div className="flex items-center justify-between pb-2 px-1 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-medium text-stone-500">Powered by</span>
          <span className="bg-stone-900 text-white px-2 py-0.5 rounded-md font-black text-[10px] tracking-wider uppercase shadow-2xs">
            NovaSaaS
          </span>
        </div>
        <div className="flex items-center gap-1 text-[11px] font-bold text-amber-800">
          <Sparkles size={12} className="text-amber-500 fill-amber-400" />
          <span>7 Daily Offers</span>
        </div>
      </div>

      {/* Main Slide Card Container */}
      <div
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-r ${current.bgGradient} p-4 text-white shadow-lg border border-white/15 transition-all duration-500`}
      >
        {/* Decorative Background Elements */}
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-black/20 blur-xl pointer-events-none" />

        {/* Slide Content Grid */}
        <div className="relative z-10 flex items-center justify-between gap-3">
          {/* Left Text Info */}
          <div className="flex-1 min-w-0 pr-1">
            {/* Top Badge */}
            <div className="flex items-center gap-1.5 mb-1.5">
              <span
                className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider shadow-xs ${current.badgeBg}`}
              >
                {current.badge}
              </span>
              <CurrentIcon size={13} className={current.accentColor} />
            </div>

            {/* Slide Title */}
            <h3 className="text-base sm:text-lg font-black text-white leading-tight tracking-tight line-clamp-1">
              {current.title}
            </h3>

            {/* Slide Subtitle */}
            <p className="text-[11px] sm:text-xs text-white/80 line-clamp-2 mt-1 leading-relaxed">
              {current.subtitle}
            </p>

            {/* Action CTA Button */}
            <button
              type="button"
              onClick={current.action}
              className="active-press mt-3 bg-white text-stone-900 hover:bg-stone-100 px-3.5 py-1.5 rounded-xl font-extrabold text-[11px] sm:text-xs tracking-wide flex items-center gap-1 shadow-md transition"
            >
              <span>{current.cta}</span>
              <ChevronRight size={13} className="stroke-[3]" />
            </button>
          </div>

          {/* Right Dish / Offer Photo */}
          <div
            onClick={current.action}
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-white/30 shadow-md flex-shrink-0 cursor-pointer bg-black/30 group"
          >
            <img
              src={current.imgUrl}
              alt={current.title}
              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
            />
          </div>
        </div>

        {/* Carousel Navigation Dots & Prev/Next Arrows */}
        <div className="relative z-10 mt-3 pt-2 border-t border-white/10 flex items-center justify-between">
          {/* Dot Indicators for 7 Slides */}
          <div className="flex items-center gap-1.5">
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentSlide(idx)}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  currentSlide === idx
                    ? "w-6 bg-white shadow-xs"
                    : "w-1.5 bg-white/40 hover:bg-white/70"
                }`}
                title={`Slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Prev / Next Arrows */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() =>
                setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length)
              }
              className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition active:scale-90"
              title="Previous offer"
            >
              <ChevronLeft size={13} className="stroke-[2.5]" />
            </button>
            <span className="text-[10px] font-bold text-white/70 font-mono">
              {currentSlide + 1} / {SLIDES.length}
            </span>
            <button
              type="button"
              onClick={() =>
                setCurrentSlide((prev) => (prev + 1) % SLIDES.length)
              }
              className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition active:scale-90"
              title="Next offer"
            >
              <ChevronRight size={13} className="stroke-[2.5]" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
