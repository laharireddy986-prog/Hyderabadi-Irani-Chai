import React from "react";

export function DishCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl p-3.5 border border-stone-200/70 shadow-sm flex gap-3.5 items-center justify-between animate-pulse">
      {/* Left Details Skeleton */}
      <div className="flex-1 min-w-0 space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-3.5 h-3.5 rounded bg-stone-200" />
          <div className="w-16 h-3 rounded bg-stone-200" />
        </div>
        <div className="w-3/4 h-4 rounded bg-stone-200" />
        <div className="w-16 h-4 rounded bg-stone-200" />
        <div className="w-full h-3 rounded bg-stone-100" />
      </div>

      {/* Right Image / Button Skeleton */}
      <div className="flex flex-col items-center justify-center flex-shrink-0 w-24 gap-2">
        <div className="w-20 h-20 rounded-xl bg-stone-200" />
        <div className="w-full h-7 rounded-xl bg-stone-200" />
      </div>
    </div>
  );
}

export function CategoryStoriesSkeleton() {
  return (
    <div className="flex items-center gap-2 px-4 overflow-x-auto no-scrollbar py-2 animate-pulse">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div
          key={i}
          className="h-8 w-24 rounded-2xl bg-stone-200/80 flex-shrink-0"
        />
      ))}
    </div>
  );
}

export function OrderHistorySkeleton() {
  return (
    <div className="space-y-3 animate-pulse">
      {[1, 2, 3].map((i) => (
        <div
          key={i}
          className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-2.5"
        >
          <div className="flex justify-between items-center">
            <div className="w-24 h-4 rounded bg-stone-200" />
            <div className="w-14 h-4 rounded bg-stone-200" />
          </div>
          <div className="w-3/4 h-3 rounded bg-stone-100" />
          <div className="flex gap-2 pt-1">
            <div className="flex-1 h-7 rounded-xl bg-stone-200" />
            <div className="w-20 h-7 rounded-xl bg-stone-200" />
          </div>
        </div>
      ))}
    </div>
  );
}
