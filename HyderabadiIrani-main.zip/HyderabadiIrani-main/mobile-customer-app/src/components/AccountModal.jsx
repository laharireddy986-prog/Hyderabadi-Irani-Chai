import React, { useState, useEffect, useRef } from "react";
import {
  X,
  User,
  Phone,
  Sparkles,
  Clock,
  LogOut,
  ShieldCheck,
  RotateCcw,
  CheckCircle,
  ArrowLeft,
  KeyRound,
  Loader2,
  RefreshCw,
  Info,
} from "lucide-react";
import { money, api, errMsg } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { EmptyOrdersState } from "./EmptyState";
import { OrderHistorySkeleton } from "./Skeletons";
import PrivacyPolicyModal from "./PrivacyPolicyModal";
import { toast } from "sonner";

export default function AccountModal({ isOpen, onClose, onTrackOrder }) {
  const {
    customer,
    isLoggedIn,
    loading,
    sendingOtp,
    verifyingOtp,
    cooldown,
    sendOtp,
    verifyOtp,
    logout,
  } = useAuth();

  const { recentOrders: localRecentOrders, addItem } = useCart();

  // Auth Form State
  const [step, setStep] = useState("phone"); // "phone" | "otp"
  const [phoneInput, setPhoneInput] = useState("");
  const [nameInput, setNameInput] = useState("");
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const [debugOtp, setDebugOtp] = useState("");

  // Account Tabs: "orders" | "passbook"
  const [accountTab, setAccountTab] = useState("orders");
  const [transactions, setTransactions] = useState([]);
  const [loadingTx, setLoadingTx] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);

  // Server-side order history (survives app reinstall / new device — unlike
  // the device-local recentOrders in CartContext, which only remembers
  // orders placed on this specific install).
  const [serverOrders, setServerOrders] = useState(null);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const recentOrders = serverOrders !== null ? serverOrders : localRecentOrders;

  const otpInputRefs = useRef([]);

  // Fetch loyalty transactions when modal is open and user is logged in
  useEffect(() => {
    async function loadTransactions() {
      if (!isOpen || !isLoggedIn) return;
      setLoadingTx(true);
      try {
        const res = await api.get("/customer/loyalty/transactions");
        setTransactions(res.data || []);
      } catch (err) {
        console.warn("[LOYALTY] Could not fetch transactions:", errMsg(err));
      } finally {
        setLoadingTx(false);
      }
    }
    loadTransactions();
  }, [isOpen, isLoggedIn, customer?.loyalty_points]);

  // Fetch the customer's real order history from the server (this is what
  // actually shows past orders after a reinstall / on a fresh device).
  useEffect(() => {
    async function loadOrders() {
      if (!isOpen || !isLoggedIn) return;
      setLoadingOrders(true);
      try {
        const res = await api.get("/customer/orders");
        setServerOrders(res.data || []);
      } catch (err) {
        console.warn("[ORDERS] Could not fetch order history:", errMsg(err));
      } finally {
        setLoadingOrders(false);
      }
    }
    loadOrders();
  }, [isOpen, isLoggedIn]);

  // Reset form state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setStep("phone");
      setOtpDigits(["", "", "", "", "", ""]);
      setDebugOtp("");
      setAccountTab("orders");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Step 1: Send OTP
  const handleRequestOtp = async (e) => {
    e.preventDefault();
    const cleanPhone = phoneInput.replace(/\D/g, "").slice(-10);
    if (!cleanPhone || cleanPhone.length !== 10) {
      toast.error("Please enter a valid 10-digit Indian mobile number");
      return;
    }

    const res = await sendOtp(cleanPhone);
    if (res.ok) {
      setStep("otp");
      if (res.debug_otp) {
        setDebugOtp(res.debug_otp);
      }
      // Focus first OTP input box after render
      setTimeout(() => {
        if (otpInputRefs.current[0]) {
          otpInputRefs.current[0].focus();
        }
      }, 150);
    }
  };

  // Step 2: Resend OTP
  const handleResendOtp = async () => {
    if (cooldown > 0) return;
    const res = await sendOtp(phoneInput);
    if (res.ok && res.debug_otp) {
      setDebugOtp(res.debug_otp);
    }
  };

  // Handle single digit input and auto-advance
  const handleOtpChange = (index, value) => {
    const digit = value.replace(/\D/g, "").slice(-1);
    const newDigits = [...otpDigits];
    newDigits[index] = digit;
    setOtpDigits(newDigits);

    // Auto-advance to next input if digit entered
    if (digit && index < 5 && otpInputRefs.current[index + 1]) {
      otpInputRefs.current[index + 1].focus();
    }
  };

  // Handle backspace navigation between OTP boxes
  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) {
      if (otpInputRefs.current[index - 1]) {
        otpInputRefs.current[index - 1].focus();
      }
    }
  };

  // Handle paste full OTP code
  const handleOtpPaste = (e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (pasted) {
      const newDigits = [...otpDigits];
      for (let i = 0; i < 6; i++) {
        newDigits[i] = pasted[i] || "";
      }
      setOtpDigits(newDigits);
      if (pasted.length === 6 && otpInputRefs.current[5]) {
        otpInputRefs.current[5].focus();
      }
    }
  };

  // Step 3: Verify OTP
  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    const fullOtp = otpDigits.join("");
    if (fullOtp.length !== 6) {
      toast.error("Please enter the complete 6-digit verification code");
      return;
    }

    const res = await verifyOtp(phoneInput, fullOtp, nameInput);
    if (res.ok) {
      setStep("phone");
      setOtpDigits(["", "", "", "", "", ""]);
      setDebugOtp("");
    }
  };

  // 1-Click Reorder
  const handleReorder = (order) => {
    (order.items || []).forEach((it) => {
      addItem(
        {
          id: it.item_id,
          name: it.name,
          price: it.price,
          veg: true,
        },
        it.qty || 1
      );
    });
    toast.success("Items added back to your cart 🛒");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg h-full sm:h-auto rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[100dvh] sm:max-h-[92vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Modal Top Header */}
        <div className="bg-brand-900 text-white p-4 sm:p-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 active:scale-95 transition flex-shrink-0"
              title="Back"
            >
              <ArrowLeft size={18} />
            </button>
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-amber-400 text-brand-950 flex items-center justify-center font-bold text-lg shadow flex-shrink-0">
              <User size={20} />
            </div>
            <div className="min-w-0">
              <h3 className="font-serif text-base sm:text-lg font-bold truncate">
                {isLoggedIn ? customer.name || "Irani Food Lover" : "Welcome Foodie!"}
              </h3>
              <p className="text-xs text-amber-200 truncate">
                {isLoggedIn
                  ? `+91 ${customer.phone}`
                  : "Sign in with OTP for verified orders"}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 active:scale-95 transition flex-shrink-0"
            title="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          {/* ===================== NOT LOGGED IN FLOW ===================== */}
          {!isLoggedIn ? (
            <div className="space-y-4">
              {step === "phone" ? (
                /* Step 1: Mobile Number Input */
                <form
                  onSubmit={handleRequestOtp}
                  className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-3.5"
                >
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={18} className="text-emerald-700" />
                    <h4 className="font-bold text-xs uppercase tracking-wider text-stone-800">
                      Secure Phone Verification (OTP)
                    </h4>
                  </div>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    Enter your mobile number to receive a 6-digit SMS verification code. No password required.
                  </p>

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-stone-600 mb-1">
                      10-Digit Mobile Number *
                    </label>
                    <div className="flex items-center gap-2">
                      <span className="bg-stone-200 text-stone-700 px-3 py-2.5 rounded-xl text-xs font-mono font-bold border border-stone-300">
                        🇮🇳 +91
                      </span>
                      <input
                        type="tel"
                        maxLength={10}
                        value={phoneInput}
                        onChange={(e) =>
                          setPhoneInput(e.target.value.replace(/\D/g, "").slice(0, 10))
                        }
                        placeholder="e.g. 8331807704"
                        className="flex-1 bg-white border border-stone-300 rounded-xl px-3.5 py-2.5 text-xs font-mono font-bold outline-none focus:ring-2 focus:ring-brand-700/20"
                        required
                        autoFocus
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-stone-600 mb-1">
                      Your Full Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      placeholder="e.g. Lokesh"
                      className="w-full bg-white border border-stone-300 rounded-xl px-3.5 py-2.5 text-xs outline-none focus:ring-2 focus:ring-brand-700/20"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={sendingOtp || phoneInput.length < 10}
                    className="active-press w-full bg-brand-900 hover:bg-brand-950 text-white py-3 rounded-xl font-bold text-xs uppercase tracking-wider shadow flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {sendingOtp ? (
                      <>
                        <Loader2 size={15} className="animate-spin text-amber-300" />
                        <span>Sending SMS OTP…</span>
                      </>
                    ) : (
                      <>
                        <KeyRound size={14} />
                        <span>Get Verification Code</span>
                      </>
                    )}
                  </button>
                  <div className="bg-amber-50/80 border border-amber-200/80 p-3 rounded-xl space-y-1.5 pt-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                      <span>👑</span>
                      <span>100 Coins Joining Bonus Offer</span>
                    </div>
                    <ul className="text-[11px] text-amber-900/90 space-y-1 list-disc list-inside">
                      <li><strong>100 Royalty Coins</strong> credited instantly on first sign in.</li>
                      <li>Redeem <strong>₹25 OFF</strong> on each of your <strong>first 4 orders</strong>.</li>
                      <li>Applicable on food orders <strong>above ₹249</strong> (1 Coin = ₹1).</li>
                    </ul>
                  </div>
                </form>
              ) : (
                /* Step 2: 6-Digit OTP Input Screen */
                <form
                  onSubmit={handleVerifyOtp}
                  className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setStep("phone")}
                      className="flex items-center gap-1 text-xs text-stone-600 font-bold hover:text-stone-900"
                    >
                      <ArrowLeft size={14} />
                      <span>Change Mobile</span>
                    </button>
                    <span className="text-xs font-mono font-bold text-brand-900 bg-brand-100 px-2 py-0.5 rounded-full">
                      +91 {phoneInput}
                    </span>
                  </div>

                  <div className="text-center">
                    <h4 className="font-bold text-sm text-stone-900">
                      Enter 6-Digit Verification Code
                    </h4>
                    <p className="text-xs text-stone-500 mt-1">
                      We've sent a code to your mobile phone via SMS.
                    </p>
                  </div>

                  {/* 6 Individual Numeric OTP Input Boxes */}
                  <div
                    className="flex justify-center gap-2 sm:gap-2.5 py-1"
                    onPaste={handleOtpPaste}
                  >
                    {otpDigits.map((digit, idx) => (
                      <input
                        key={idx}
                        ref={(el) => (otpInputRefs.current[idx] = el)}
                        type="tel"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpChange(idx, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                        className="w-10 h-12 text-center text-lg font-mono font-extrabold bg-white border-2 border-stone-300 rounded-xl focus:border-brand-800 focus:ring-2 focus:ring-brand-700/20 outline-none shadow-xs transition"
                        autoComplete="one-time-code"
                      />
                    ))}
                  </div>

                  {/* Dev / Testing Helper Banner */}
                  {debugOtp && (
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[11px] text-amber-800 font-medium">
                        Testing Code:{" "}
                        <strong className="font-mono font-bold text-brand-900 text-xs">
                          {debugOtp}
                        </strong>
                      </span>
                    </div>
                  )}

                  {/* Resend Cooldown Countdown */}
                  <div className="flex items-center justify-between text-xs pt-1">
                    <span className="text-stone-500">Didn't receive SMS?</span>
                    {cooldown > 0 ? (
                      <span className="font-mono font-bold text-stone-500 bg-stone-200 px-2 py-0.5 rounded-md text-[11px]">
                        Resend in {cooldown}s
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleResendOtp}
                        disabled={sendingOtp}
                        className="font-bold text-brand-800 hover:text-brand-950 flex items-center gap-1"
                      >
                        <RefreshCw size={12} />
                        <span>Resend OTP</span>
                      </button>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={verifyingOtp || otpDigits.join("").length !== 6}
                    className="active-press w-full bg-brand-900 hover:bg-brand-950 text-white py-3 rounded-xl font-bold text-xs uppercase tracking-wider shadow flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {verifyingOtp ? (
                      <>
                        <Loader2 size={15} className="animate-spin text-amber-300" />
                        <span>Verifying Code…</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle size={15} />
                        <span>Verify & Claim 100 Coins</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          ) : (
            /* ===================== LOGGED IN PROFILE VIEW ===================== */
            <div className="space-y-4">
              {/* Verified Identity Badge */}
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-2xl flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center flex-shrink-0">
                  <ShieldCheck size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-emerald-900 truncate">
                    Verified Customer Account
                  </p>
                  <p className="text-[11px] text-emerald-700 font-mono truncate">
                    +91 {customer?.phone}
                  </p>
                </div>
              </div>

              {/* Loyalty Coins Card */}
              <div className="bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 text-white p-4 rounded-2xl shadow-md space-y-2.5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-amber-100">
                      <Sparkles size={13} className="text-white fill-white" />
                      <span>Irani Royalty Balance</span>
                    </div>
                    <div className="text-2xl font-extrabold font-mono mt-1">
                      {customer?.loyalty_points !== undefined ? customer.loyalty_points : 100}{" "}
                      <span className="text-sm font-sans font-bold">Coins (₹{customer?.loyalty_points !== undefined ? customer.loyalty_points : 100})</span>
                    </div>
                  </div>

                  <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center font-bold text-xl">
                    👑
                  </div>
                </div>

                <div className="bg-black/15 backdrop-blur-xs p-2.5 rounded-xl text-[11px] space-y-1 text-amber-50">
                  <div className="flex items-center justify-between font-bold">
                    <span>Joining Bonus Terms:</span>
                    <span className="bg-amber-400 text-amber-950 px-1.5 py-0.2 rounded font-mono text-[10px]">₹25 OFF / Order</span>
                  </div>
                  <p className="text-[10.5px] opacity-95">
                    Redeem ₹25 per order on your first 4 orders above ₹249. 1 Coin = ₹1.
                  </p>
                </div>
              </div>

              {/* Section Tabs: Recent Orders vs Coin Passbook */}
              <div className="bg-stone-100 p-1 rounded-2xl grid grid-cols-2 gap-1 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setAccountTab("orders")}
                  className={`py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
                    accountTab === "orders"
                      ? "bg-brand-900 text-white shadow-xs"
                      : "text-stone-600 hover:text-stone-900"
                  }`}
                >
                  <Clock size={13} />
                  <span>Recent Orders ({recentOrders.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setAccountTab("passbook")}
                  className={`py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
                    accountTab === "passbook"
                      ? "bg-brand-900 text-white shadow-xs"
                      : "text-stone-600 hover:text-stone-900"
                  }`}
                >
                  <span>👑</span>
                  <span>Coin Passbook ({transactions.length})</span>
                </button>
              </div>

              {/* View 1: Past Orders List */}
              {accountTab === "orders" && (
                <div className="space-y-2">
                  {loadingOrders ? (
                    <OrderHistorySkeleton />
                  ) : recentOrders.length === 0 ? (
                    <EmptyOrdersState onBrowseMenu={onClose} />
                  ) : (
                    <div className="space-y-2.5">
                      {recentOrders.map((ord, idx) => (
                        <div
                          key={ord.id || ord._id || idx}
                          className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2"
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="text-[10px] font-mono font-bold uppercase bg-stone-200 text-stone-700 px-1.5 py-0.5 rounded">
                                #{ord.order_no || String(ord.id || "").slice(-6)}
                              </span>
                              <p className="text-xs font-bold text-stone-900 mt-1 capitalize">
                                {ord.order_type} ·{" "}
                                <span className="text-emerald-700 font-bold capitalize">
                                  {ord.status || "Placed"}
                                </span>
                              </p>
                            </div>

                            <span className="font-mono font-extrabold text-sm text-brand-900">
                              {money(ord.total || 0)}
                            </span>
                          </div>

                          <div className="text-[11px] text-stone-500 line-clamp-1">
                            {(ord.items || []).map((i) => `${i.qty}x ${i.name}`).join(", ")}
                          </div>

                          <div className="flex gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => onTrackOrder && onTrackOrder(ord)}
                              className="flex-1 bg-brand-900 text-white py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1"
                            >
                              Track Status
                            </button>

                            <button
                              type="button"
                              onClick={() => handleReorder(ord)}
                              className="bg-white border border-stone-300 text-stone-700 py-1.5 px-3 rounded-xl text-xs font-bold flex items-center gap-1 hover:bg-stone-100"
                              title="Reorder items"
                            >
                              <RotateCcw size={12} />
                              <span>Reorder</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* View 2: Loyalty Coin Passbook (Audit Ledger) */}
              {accountTab === "passbook" && (
                <div className="space-y-2">
                  {loadingTx ? (
                    <OrderHistorySkeleton />
                  ) : transactions.length === 0 ? (
                    <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-xs text-stone-500 space-y-1">
                      <p className="font-bold text-stone-700">No Coin Activity Yet</p>
                      <p className="text-[11px]">Earn 1 coin for every ₹100 spent on Biryani & Chai!</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {transactions.map((tx, idx) => {
                        const isCredit = tx.points > 0;
                        return (
                          <div
                            key={tx.id || idx}
                            className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between gap-3"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                                  isCredit
                                    ? "bg-emerald-100 text-emerald-800"
                                    : "bg-amber-100 text-amber-800"
                                }`}
                              >
                                {tx.type === "welcome_bonus"
                                  ? "👑"
                                  : isCredit
                                  ? "☕"
                                  : "🏷️"}
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-stone-900 truncate">
                                  {tx.description || `${tx.type.replace("_", " ").toUpperCase()}`}
                                </p>
                                <p className="text-[10px] text-stone-400 font-mono mt-0.5">
                                  {tx.created_at ? new Date(tx.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "Recent"}
                                  {tx.balance_after !== undefined && ` · Balance: ${tx.balance_after} coins`}
                                </p>
                              </div>
                            </div>

                            <span
                              className={`text-xs font-mono font-extrabold px-2 py-0.5 rounded-full flex-shrink-0 ${
                                isCredit
                                  ? "bg-emerald-100 text-emerald-800"
                                  : "bg-amber-100 text-amber-800"
                              }`}
                            >
                              {isCredit ? `+${tx.points}` : `${tx.points}`} Coins
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Logout Button */}
              <button
                type="button"
                onClick={logout}
                className="w-full text-red-700 bg-red-50 hover:bg-red-100 py-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition border border-red-200"
              >
                <LogOut size={14} />
                <span>Log Out</span>
              </button>
            </div>
          )}

          {/* Restaurant Legal & Contact Card */}
          <div className="bg-stone-50 p-3.5 rounded-2xl border border-stone-200 space-y-2 text-xs text-stone-600">
            <div className="font-bold text-stone-800">
              Hyderabadi Irani Food Court
            </div>
            <div className="text-[11px]">
              GSTIN: 36BLUPM3251R1Z6 · FSSAI: 23625033000700
            </div>
            <div className="text-[11px]">
              Support: 8331807704 · Email: hyderabadiirani1@gmail.com
            </div>

            <div className="pt-2 border-t border-stone-200 flex gap-2">
              <button
                type="button"
                onClick={() => setShowPrivacy(true)}
                className="flex-1 py-1.5 px-2.5 rounded-xl bg-white border border-stone-300 text-[11px] font-bold text-brand-950 hover:bg-stone-100 flex items-center justify-center gap-1 transition"
              >
                <ShieldCheck size={12} className="text-emerald-700" />
                <span>Privacy & Data Safety</span>
              </button>

              <a
                href="https://hyderabadiirani.net/terms"
                target="_blank"
                rel="noopener noreferrer"
                className="py-1.5 px-2.5 rounded-xl bg-white border border-stone-300 text-[11px] font-bold text-stone-700 hover:bg-stone-100 flex items-center justify-center transition"
              >
                Terms
              </a>
            </div>

            <div className="pt-2 text-center text-[10px] text-stone-400">
              App powered by <span className="font-bold text-stone-500">NovaSaaS</span>
            </div>
          </div>
        </div>
      </div>

      <PrivacyPolicyModal
        isOpen={showPrivacy}
        onClose={() => setShowPrivacy(false)}
      />
    </div>
  );
}
