import React from "react";
import { ShoppingBag, Search, Clock, WifiOff, RefreshCw, ArrowRight } from "lucide-react";

export function EmptyCartState({ onBrowseMenu }) {
  return (
    <div className="py-12 px-6 text-center flex flex-col items-center justify-center">
      <div className="w-16 h-16 rounded-3xl bg-amber-50 text-brand-800 flex items-center justify-center mb-3 shadow-inner border border-amber-200/60">
        <ShoppingBag size={28} />
      </div>
      <h3 className="font-serif font-bold text-base text-brand-950">
        Your Cart is Empty
      </h3>
      <p className="text-xs text-stone-500 max-w-xs mt-1.5 leading-relaxed">
        Explore our authentic Hyderabadi Dum Biryani, slow-brewed Irani Chai, and sizzling Starters!
      </p>
      {onBrowseMenu && (
        <button
          type="button"
          onClick={onBrowseMenu}
          className="active-press mt-4 bg-brand-900 text-white px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md hover:bg-brand-950 transition"
        >
          <span>Explore Menu</span>
          <ArrowRight size={13} />
        </button>
      )}
    </div>
  );
}

export function EmptyOrdersState({ onBrowseMenu }) {
  return (
    <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 flex flex-col items-center justify-center">
      <div className="w-12 h-12 rounded-2xl bg-white text-stone-400 flex items-center justify-center mb-2 shadow-xs border border-stone-200">
        <Clock size={22} />
      </div>
      <h4 className="font-bold text-xs uppercase tracking-wider text-stone-800">
        No Orders Placed Yet
      </h4>
      <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
        Your order history will appear here once you place your first delicious order.
      </p>
      {onBrowseMenu && (
        <button
          type="button"
          onClick={onBrowseMenu}
          className="active-press mt-3 bg-brand-900 text-white px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider shadow"
        >
          Order Now
        </button>
      )}
    </div>
  );
}

export function EmptySearchState({ query, onClear }) {
  return (
    <div className="bg-white rounded-2xl p-8 text-center border border-stone-200/80 shadow-xs my-4 flex flex-col items-center justify-center">
      <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 flex items-center justify-center mb-2">
        <Search size={22} />
      </div>
      <h3 className="font-bold text-sm text-stone-800">
        No dishes found matching "{query}"
      </h3>
      <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
        Check your spelling or explore other categories like Biryani, Chai, or Starters.
      </p>
      {onClear && (
        <button
          type="button"
          onClick={onClear}
          className="active-press mt-3 bg-brand-900 text-white px-4 py-1.5 rounded-xl text-xs font-bold"
        >
          Clear Filter
        </button>
      )}
    </div>
  );
}

export function NetworkErrorState({ message, onRetry }) {
  return (
    <div className="bg-white rounded-2xl p-8 text-center border border-red-200 shadow-xs my-4 flex flex-col items-center justify-center">
      <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mb-2">
        <WifiOff size={22} />
      </div>
      <h3 className="font-bold text-sm text-stone-900">
        Unable to Load Menu
      </h3>
      <p className="text-xs text-stone-500 mt-1 max-w-xs leading-relaxed">
        {message || "We couldn't connect to the restaurant kitchen. Please check your network connection."}
      </p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="active-press mt-3.5 bg-brand-900 text-white px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md"
        >
          <RefreshCw size={13} />
          <span>Tap to Retry</span>
        </button>
      )}
    </div>
  );
}
