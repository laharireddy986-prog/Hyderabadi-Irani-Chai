import React from "react";
import { Plus, Minus, Sparkles, Heart } from "lucide-react";
import { money } from "../lib/api";
import { useCart } from "../context/CartContext";
import { toast } from "sonner";

export default function PairingRecommendationsShelf({
  pairings = [],
  title = "You will love pairing it with",
  subtitle = "Frequently ordered together",
  onSelectDish,
}) {
  const { addItem, getItemQty } = useCart();

  if (!pairings || pairings.length === 0) return null;

  return (
    <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-2xs space-y-3">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-full bg-red-50 text-red-600 flex items-center justify-center flex-shrink-0">
            <Sparkles size={13} className="fill-red-500 text-red-500" />
          </div>
          <div>
            <h3 className="font-sans text-xs sm:text-sm font-extrabold text-stone-900 leading-none">
              {title}
            </h3>
            {subtitle && (
              <p className="text-[10px] text-stone-400 font-medium mt-0.5 leading-none">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        <span className="text-[9px] font-extrabold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
          Must Try
        </span>
      </div>

      {/* Horizontal Scrollable Carousel */}
      <div className="flex items-stretch gap-3 overflow-x-auto no-scrollbar pb-1 pt-0.5 -mx-1 px-1">
        {pairings.map((dish) => {
          const qty = getItemQty(dish.id || dish._id);
          const hasPortions = Boolean(
            dish.has_variants && dish.variants && dish.variants.length >= 2
          );
          const displayPrice = hasPortions
            ? dish.variants[0].price
            : dish.price;

          const imageSrc =
            dish.image_url ||
            (dish.category?.toLowerCase() === "biryani"
              ? "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400&auto=format&fit=crop&q=80"
              : dish.category?.toLowerCase() === "tea" || dish.category?.toLowerCase() === "chai"
              ? "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=400&auto=format&fit=crop&q=80"
              : "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=80");

          const handleInstantAdd = (e) => {
            e.stopPropagation();
            if (hasPortions && onSelectDish) {
              onSelectDish(dish);
              return;
            }
            addItem(dish, 1);
          };

          return (
            <div
              key={dish.id || dish._id}
              onClick={() => onSelectDish && onSelectDish(dish)}
              className="w-36 sm:w-40 flex-shrink-0 bg-[#fafafa] rounded-2xl border border-stone-200/90 hover:border-red-300 hover:shadow-xs p-2 flex flex-col justify-between transition cursor-pointer group active-press"
            >
              {/* Dish Photo Thumbnail & Veg Tag */}
              <div className="relative w-full h-24 rounded-xl overflow-hidden bg-stone-100 mb-2 flex-shrink-0">
                <img
                  src={imageSrc}
                  alt={dish.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  loading="lazy"
                />

                {/* Veg / Non-Veg Emblem badge */}
                <div className="absolute top-1.5 left-1.5 bg-white/90 backdrop-blur-xs p-1 rounded-md shadow-xs">
                  <span
                    className={`w-3 h-3 rounded-xs border flex items-center justify-center p-0.2 ${
                      dish.veg
                        ? "border-emerald-600 bg-emerald-50"
                        : "border-red-600 bg-red-50"
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        dish.veg ? "bg-emerald-600" : "bg-red-600"
                      }`}
                    />
                  </span>
                </div>
              </div>

              {/* Dish Name & Info */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-bold text-xs text-stone-900 line-clamp-2 leading-tight group-hover:text-red-600 transition">
                    {dish.name}
                  </h4>
                  <span className="text-[10px] text-stone-400 font-medium uppercase mt-0.5 block">
                    {dish.category}
                  </span>
                </div>

                {/* Price & Instant Add Button */}
                <div className="flex items-center justify-between gap-1 mt-2 pt-1 border-t border-stone-200/60">
                  <div className="flex flex-col">
                    <span className="font-mono font-black text-xs text-stone-900">
                      ₹{displayPrice}
                    </span>
                    {hasPortions && (
                      <span className="text-[8px] text-stone-400 font-bold uppercase">
                        {dish.variants[0].name}
                      </span>
                    )}
                  </div>

                  {qty > 0 ? (
                    <div
                      className="flex items-center gap-1 bg-white border border-red-500 text-red-600 rounded-lg p-0.5 shadow-2xs"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={() => addItem(dish, -1)}
                        className="w-5 h-5 flex items-center justify-center hover:bg-red-50 rounded text-red-600 font-bold"
                      >
                        <Minus size={11} className="stroke-[3]" />
                      </button>
                      <span className="text-[11px] font-black font-mono px-0.5">
                        {qty}
                      </span>
                      <button
                        type="button"
                        onClick={() => addItem(dish, 1)}
                        className="w-5 h-5 flex items-center justify-center hover:bg-red-50 rounded text-red-600 font-bold"
                      >
                        <Plus size={11} className="stroke-[3]" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={handleInstantAdd}
                      className="active-press bg-white hover:bg-red-50 text-red-600 border border-red-500 px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-0.5 shadow-2xs hover:shadow-xs transition"
                    >
                      <span>ADD</span>
                      <Plus size={11} className="stroke-[3]" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
