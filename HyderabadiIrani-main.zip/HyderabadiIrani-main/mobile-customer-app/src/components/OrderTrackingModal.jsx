import React, { useState, useEffect, useCallback } from "react";
import {
  X,
  ArrowLeft,
  CheckCircle2,
  Clock,
  ChefHat,
  Bike,
  Sparkles,
  Phone,
  MessageCircle,
  Copy,
  MapPin,
  UtensilsCrossed,
  PackageCheck,
  AlertCircle,
  Navigation,
} from "lucide-react";
import { api, money } from "../lib/api";
import { toast } from "sonner";

export default function OrderTrackingModal({ order, onClose, onBack }) {
  const [liveOrder, setLiveOrder] = useState(order);
  const [loading, setLoading] = useState(false);

  const fetchLiveStatus = useCallback(async () => {
    if (!order) return;
    const identifier = order.order_no || order.id || order._id;
    if (!identifier) return;

    try {
      // First attempt public tracking endpoint by order_no / ID
      const res = await api.get(`/public/orders/${identifier}`);
      if (res?.data) {
        setLiveOrder(res.data);
        return;
      }
    } catch {
      // Fallback to internal orders endpoint
      try {
        const fallbackId = order.id || order._id || order.order_no;
        const res = await api.get(`/orders/${fallbackId}`);
        if (res?.data) {
          setLiveOrder(res.data);
        }
      } catch {
        /* Silent retry */
      }
    }
  }, [order]);

  useEffect(() => {
    fetchLiveStatus();
    // Poll status every 3 seconds for instant real-time stage transitions
    const interval = setInterval(fetchLiveStatus, 3000);
    return () => clearInterval(interval);
  }, [fetchLiveStatus]);

  if (!order) return null;

  const currentStatus = (liveOrder?.status || order?.status || "placed").toLowerCase();
  const orderType = (liveOrder?.order_type || order?.order_type || "delivery").toLowerCase();
  const isDelivery = orderType === "delivery";
  const isDineIn = orderType === "dinein" || orderType === "dine-in";
  const isCancelled = currentStatus === "cancelled";

  // Step definitions tailored for Delivery vs Dine-in vs Takeaway funnels
  const getDeliverySteps = () => [
    {
      key: "placed",
      label: "Order Placed & Confirmed",
      desc: "Sent to Hyderabadi Irani kitchen",
      icon: Clock,
    },
    {
      key: "preparing",
      label: "Cooking Fresh",
      desc: "Chef is preparing your hot delicious meal",
      icon: ChefHat,
    },
    {
      key: "ready",
      label: "Food Ready & Packed",
      desc: "Order is packed fresh · Waiting for rider",
      icon: PackageCheck,
    },
    {
      key: "out_for_delivery",
      label: "Out for Delivery",
      desc: "Delivery partner is on the way to your doorstep",
      icon: Bike,
    },
    {
      key: "completed",
      label: "Order Delivered",
      desc: "Delivered at doorstep · Enjoy your authentic Irani meal! ☕",
      icon: CheckCircle2,
    },
  ];

  const getDineInSteps = () => [
    {
      key: "placed",
      label: "Order Received",
      desc: "Sent to Hyderabadi Irani kitchen",
      icon: Clock,
    },
    {
      key: "preparing",
      label: "Cooking Fresh",
      desc: "Chef is preparing your hot meal",
      icon: ChefHat,
    },
    {
      key: "ready",
      label: "Food Ready",
      desc: "Dish is ready at the kitchen pass",
      icon: PackageCheck,
    },
    {
      key: "completed",
      label: liveOrder?.table_no ? `Served to Table ${liveOrder.table_no}` : "Food Served",
      desc: "Hot food served to your table · Enjoy your meal!",
      icon: UtensilsCrossed,
    },
  ];

  const getTakeawaySteps = () => [
    {
      key: "placed",
      label: "Order Placed",
      desc: "Sent to kitchen queue",
      icon: Clock,
    },
    {
      key: "preparing",
      label: "Cooking Fresh",
      desc: "Chef is preparing your hot meal",
      icon: ChefHat,
    },
    {
      key: "ready",
      label: "Ready for Pickup",
      desc: "Hot & packed at the takeaway counter",
      icon: PackageCheck,
    },
    {
      key: "completed",
      label: "Order Collected",
      desc: "Handed over to customer · Enjoy your meal! ☕",
      icon: CheckCircle2,
    },
  ];

  const STEPS = isDelivery
    ? getDeliverySteps()
    : isDineIn
    ? getDineInSteps()
    : getTakeawaySteps();

  // Determine which step is currently active
  const getActiveIndex = (st) => {
    if (isCancelled) return -1;
    if (isDelivery) {
      if (st === "completed" || st === "delivered") return 4;
      if (st === "out_for_delivery") return 3;
      if (st === "ready") return 2;
      if (st === "preparing") return 1;
      return 0;
    } else {
      // Dine-in / Takeaway (4 steps)
      if (st === "completed" || st === "delivered" || st === "served") return 3;
      if (st === "ready") return 2;
      if (st === "preparing") return 1;
      return 0;
    }
  };

  const activeIndex = getActiveIndex(currentStatus);

  const copyOrderId = () => {
    const textToCopy = liveOrder?.order_no || order.order_no || order.id || "";
    navigator.clipboard.writeText(textToCopy);
    toast.success("Order # copied to clipboard");
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg h-full sm:h-auto rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[100dvh] sm:max-h-[92vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Top Header */}
        <div className="bg-brand-900 text-white p-4 sm:p-5 flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5 flex-1 min-w-0">
            <button
              type="button"
              onClick={onBack || onClose}
              className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 active:scale-95 transition flex-shrink-0"
              title="Back"
            >
              <ArrowLeft size={18} />
            </button>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] font-extrabold uppercase bg-amber-400 text-brand-950 px-2 py-0.5 rounded-full tracking-wider">
                  {isCancelled ? "Order Cancelled" : "Live Funnel Tracking"}
                </span>
                <span
                  className="text-xs font-mono opacity-80 cursor-pointer hover:opacity-100 flex items-center gap-1 bg-white/10 px-2 py-0.5 rounded"
                  onClick={copyOrderId}
                  title="Click to copy"
                >
                  #{liveOrder?.order_no || order.order_no || String(order.id || "").slice(-6)} <Copy size={11} />
                </span>
              </div>
              <h2 className="font-serif text-lg sm:text-xl font-bold mt-1 flex items-center gap-2 truncate">
                <span className="truncate">Hyderabadi Irani Kitchen</span>
                {isDelivery && <span className="text-xs bg-amber-500/30 text-amber-200 px-2 py-0.5 rounded-md font-sans flex-shrink-0">Delivery</span>}
                {isDineIn && <span className="text-xs bg-amber-500/30 text-amber-200 px-2 py-0.5 rounded-md font-sans flex-shrink-0">Table {liveOrder?.table_no || order?.table_no}</span>}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 active:scale-95 transition flex-shrink-0"
            title="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* Cancelled Banner */}
        {isCancelled && (
          <div className="bg-red-50 border-b border-red-200 p-4 flex items-center gap-3 text-red-800">
            <AlertCircle size={20} className="text-red-600 flex-shrink-0" />
            <div className="text-xs">
              <p className="font-bold">This order has been cancelled.</p>
              <p className="text-red-600 mt-0.5">Please contact the restaurant if you need further help or a refund.</p>
            </div>
          </div>
        )}

        {/* Status Timeline */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1">
          {/* Animated Timeline */}
          {!isCancelled && (
            <div className="space-y-4 relative">
              {STEPS.map((step, idx) => {
                const Icon = step.icon;
                const isPassed = idx < activeIndex;
                const isCurrent = idx === activeIndex;
                const isPending = idx > activeIndex;

                return (
                  <div key={step.key} className="flex items-start gap-3.5 relative">
                    {/* Connecting Vertical Line */}
                    {idx < STEPS.length - 1 && (
                      <div
                        className={`absolute left-[17px] top-[34px] w-0.5 h-[calc(100%-8px)] -z-0 transition-colors duration-500 ${
                          idx < activeIndex ? "bg-emerald-600" : "bg-stone-200"
                        }`}
                      />
                    )}

                    {/* Step Circle */}
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 z-10 transition-all duration-300 ${
                        isPassed
                          ? "bg-emerald-600 text-white shadow-sm"
                          : isCurrent
                          ? "bg-brand-900 text-amber-300 ring-4 ring-amber-400/30 animate-pulse shadow-md"
                          : "bg-stone-100 text-stone-400 border border-stone-200"
                      }`}
                    >
                      {isPassed ? <CheckCircle2 size={18} /> : <Icon size={16} />}
                    </div>

                    {/* Step Text */}
                    <div className="flex-1 pt-0.5">
                      <div className="flex items-center gap-2">
                        <h4
                          className={`text-sm font-bold ${
                            isCurrent
                              ? "text-brand-950 font-extrabold"
                              : isPassed
                              ? "text-emerald-900"
                              : "text-stone-400"
                          }`}
                        >
                          {step.label}
                        </h4>
                        {isCurrent && (
                          <span className="text-[9px] uppercase font-bold tracking-wider bg-amber-100 text-brand-900 px-2 py-0.5 rounded-full animate-pulse">
                            Live Stage
                          </span>
                        )}
                      </div>
                      <p
                        className={`text-xs mt-0.5 ${
                          isCurrent
                            ? "text-stone-700 font-medium"
                            : isPassed
                            ? "text-stone-600"
                            : "text-stone-400"
                        }`}
                      >
                        {step.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Delivery Rider Card (When Out for Delivery or Rider Assigned) */}
          {(currentStatus === "out_for_delivery" || liveOrder?.driver_name) && (
            <div className="bg-emerald-50 border-2 border-emerald-500/40 p-4 rounded-2xl text-emerald-950 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-xs">
                    🛵
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-extrabold tracking-wider bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded">
                      Assigned Delivery Partner
                    </span>
                    <h3 className="font-bold text-sm text-stone-900 mt-0.5">
                      {liveOrder?.driver_name || "Hyderabadi Express Rider"}
                    </h3>
                    <p className="text-[11px] text-emerald-800">
                      Food is on the way to your location
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-1">
                {liveOrder?.driver_phone && (
                  <a
                    href={`tel:${liveOrder.driver_phone}`}
                    className="flex-1 bg-emerald-700 hover:bg-emerald-800 text-white py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition"
                  >
                    <Phone size={13} />
                    <span>Call Driver ({liveOrder.driver_phone})</span>
                  </a>
                )}

                {liveOrder?.driver_lat && liveOrder?.driver_lng && (
                  <a
                    href={`https://www.google.com/maps?q=${liveOrder.driver_lat},${liveOrder.driver_lng}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-white border border-emerald-600 text-emerald-900 hover:bg-emerald-50 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition"
                  >
                    <Navigation size={13} className="text-emerald-700" />
                    <span>Live GPS</span>
                  </a>
                )}
              </div>
            </div>
          )}

          {/* Order Details Checklist */}
          <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Ordered Items
              </h4>
              <span className="text-[11px] font-mono text-stone-500 capitalize">
                Mode: {liveOrder?.payment_mode || order?.payment_mode || "Counter / Cash"}
              </span>
            </div>

            <div className="space-y-1.5 divide-y divide-stone-100 pt-1">
              {(liveOrder?.items || order.items || []).map((it, i) => (
                <div key={i} className="pt-1.5 flex justify-between text-xs">
                  <span className="text-stone-800 font-medium">
                    {it.qty}x {it.name}
                  </span>
                  <span className="font-mono font-bold text-stone-900">
                    {money(it.price * (it.qty || 1))}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-stone-200 flex justify-between font-extrabold text-sm text-brand-900">
              <span>Total Paid / Payable</span>
              <span className="font-mono">{money(liveOrder?.total || order.total || 0)}</span>
            </div>
          </div>

          {/* Quick Help & Support */}
          <div className="flex gap-2">
            <a
              href="tel:8331807704"
              className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-800 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition border border-stone-200"
            >
              <Phone size={14} className="text-brand-700" />
              <span>Call Restaurant (8331807704)</span>
            </a>

            <a
              href={`https://api.whatsapp.com/send?phone=918331807704&text=Hello%20Hyderabadi%20Irani%2C%20tracking%20my%20order%20%23${liveOrder?.order_no || order.order_no || ""}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition border border-emerald-300"
            >
              <MessageCircle size={14} className="text-emerald-600" />
              <span>WhatsApp Help</span>
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 pb-safe">
          <button
            type="button"
            onClick={onBack || onClose}
            className="w-full bg-brand-900 hover:bg-brand-950 text-white py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition active:scale-[0.99]"
          >
            Close Tracking
          </button>
        </div>
      </div>
    </div>
  );
}
