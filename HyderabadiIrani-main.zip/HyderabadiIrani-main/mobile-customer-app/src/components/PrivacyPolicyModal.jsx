import React from "react";
import { X, ShieldCheck, MapPin, Phone, Lock, ExternalLink, FileText, CheckCircle2 } from "lucide-react";

export default function PrivacyPolicyModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-brand-100 text-brand-900 flex items-center justify-center">
              <ShieldCheck size={18} />
            </div>
            <div>
              <h3 className="font-serif font-bold text-base text-brand-950">
                Privacy & Data Safety Policy
              </h3>
              <p className="text-[10px] text-stone-500 font-mono">
                Hyderabadi Irani Food Court · App ID: com.hyderabadiirani.app
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200 text-stone-700 flex items-center justify-center hover:bg-stone-300 transition"
          >
            <X size={16} />
          </button>
        </div>

        {/* Scrollable Policy Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-stone-700 leading-relaxed flex-1">
          {/* Summary Box */}
          <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl space-y-1.5 text-emerald-900">
            <div className="flex items-center gap-1.5 font-bold text-xs text-emerald-950">
              <CheckCircle2 size={14} className="text-emerald-700" />
              <span>Play Store Data Safety Commitment</span>
            </div>
            <p className="text-[11px] leading-normal text-emerald-800">
              Hyderabadi Irani does NOT sell, rent, or monetize your personal data. Data is collected solely to authenticate your account and fulfill your food orders.
            </p>
          </div>

          {/* Section 1: Phone & Account Data */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-xs uppercase tracking-wider text-brand-950 flex items-center gap-1.5">
              <Phone size={13} className="text-brand-800" />
              <span>1. Mobile Number & Account Authentication</span>
            </h4>
            <p className="text-stone-600">
              We collect your 10-digit mobile number to send secure one-time password (OTP) verification codes and critical live updates regarding your food order (confirmation, kitchen preparation, and delivery arrival).
            </p>
          </div>

          {/* Section 2: Location Data */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-xs uppercase tracking-wider text-brand-950 flex items-center gap-1.5">
              <MapPin size={13} className="text-brand-800" />
              <span>2. Location & GPS Data Usage</span>
            </h4>
            <p className="text-stone-600">
              When you select Home Delivery, the app accesses your device GPS coordinates solely to verify delivery eligibility within our 5.0 km radius from Rampally, Secunderabad, and to provide accurate door delivery navigation. Location data is never shared with third-party advertisers.
            </p>
          </div>

          {/* Section 3: Payments & Financial Security */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-xs uppercase tracking-wider text-brand-950 flex items-center gap-1.5">
              <Lock size={13} className="text-brand-800" />
              <span>3. Payment Gateway Security (PCI-DSS)</span>
            </h4>
            <p className="text-stone-600">
              All digital online payments (UPI, Cards, NetBanking) are processed via RBI-authorized <strong>Razorpay Software Private Limited</strong> using 256-bit TLS encryption. Hyderabadi Irani does not store card numbers, CVVs, or bank credentials.
            </p>
          </div>

          {/* Section 4: Data Retention & User Rights */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-xs uppercase tracking-wider text-brand-950 flex items-center gap-1.5">
              <FileText size={13} className="text-brand-800" />
              <span>4. Data Deletion & Customer Support</span>
            </h4>
            <p className="text-stone-600">
              You have the full right to review your saved delivery addresses, past tax invoices, or request account and data deletion at any time by emailing <strong>hyderabadiirani1@gmail.com</strong> or contacting our helpline at <strong>+91 8331807704</strong>.
            </p>
          </div>

          {/* Hosted URL Link */}
          <div className="pt-2 border-t border-stone-200">
            <a
              href="https://hyderabadiirani.net/privacy"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-stone-100 hover:bg-stone-200 text-brand-950 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-between transition"
            >
              <span>View Full Web Privacy Policy</span>
              <ExternalLink size={13} className="text-stone-500" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 pb-safe">
          <button
            type="button"
            onClick={onClose}
            className="active-press w-full bg-brand-900 text-white py-3 rounded-2xl font-bold text-xs uppercase tracking-wider shadow-md"
          >
            I Understand & Agree
          </button>
        </div>
      </div>
    </div>
  );
}
