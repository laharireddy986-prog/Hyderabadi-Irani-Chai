import React from "react";
import { ShoppingBag, ChevronRight } from "lucide-react";
import { money } from "../lib/api";
import { useCart } from "../context/CartContext";

export default function FloatingCartBar({ onOpenCart }) {
  const { lines, itemCount, total, serviceType, tableNo } = useCart();

  if (!lines.length) return null;

  return (
    <div className="fixed bottom-16 left-0 right-0 z-40 px-4 pb-2 animate-in slide-in-from-bottom-5 duration-300">
      <div
        onClick={onOpenCart}
        className="active-press bg-brand-900 text-white rounded-2xl p-3.5 shadow-floating border border-brand-800 flex items-center justify-between cursor-pointer"
      >
        {/* Left: Summary */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-brand-950 flex items-center justify-center font-bold shadow">
              <ShoppingBag size={18} />
            </div>
            <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-600 text-white text-[11px] font-extrabold rounded-full flex items-center justify-center border-2 border-brand-900">
              {itemCount}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="font-extrabold text-base font-mono leading-none text-amber-300">
              {money(total)}
            </span>
            <span className="text-[10px] text-white/80 font-medium mt-0.5">
              {serviceType === "dinein"
                ? `Dine-in ${tableNo ? `(Table ${tableNo})` : ""}`
                : serviceType === "takeaway"
                ? "Self Takeaway"
                : "Home Delivery"}
            </span>
          </div>
        </div>

        {/* Right: Action */}
        <div className="flex items-center gap-1 bg-white/15 px-3 py-1.5 rounded-xl font-bold text-xs uppercase tracking-wider text-white">
          <span>View Cart</span>
          <ChevronRight size={14} />
        </div>
      </div>
    </div>
  );
}
