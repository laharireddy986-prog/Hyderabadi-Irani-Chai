import React from "react";
import {
  MapPin,
  QrCode,
  Search,
  Sparkles,
  ChevronDown,
  Wallet,
  User,
} from "lucide-react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

export default function Header({
  onOpenSearch,
  onOpenTableScanner,
  onOpenAccount,
  onOpenLocation,
}) {
  const { serviceType, tableNo, deliveryAddress } = useCart();
  const { customer, isLoggedIn } = useAuth();

  const formattedLocation =
    deliveryAddress?.area ||
    deliveryAddress?.label ||
    deliveryAddress?.street?.split(",")[0] ||
    "Godumakunta";

  const subLocation =
    deliveryAddress?.city ||
    deliveryAddress?.street?.split(",")[1] ||
    "Secunderabad";

  // Initial for user avatar
  const userInitial = customer?.name ? customer.name.charAt(0).toUpperCase() : "L";

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200/80 px-4 pt-safe pb-2.5 transition-all shadow-xs">
      <div className="flex items-center justify-between gap-2.5">
        {/* Left: Location Selector Trigger (Zomato style) */}
        <div
          className="flex items-center gap-2.5 flex-1 min-w-0 cursor-pointer group"
          onClick={onOpenLocation}
        >
          <div className="relative flex-shrink-0">
            <div className="w-9 h-9 rounded-full bg-red-50 border border-red-200 flex items-center justify-center text-red-600 shadow-xs group-hover:scale-105 transition">
              <MapPin size={18} className="fill-red-500 text-red-600" />
            </div>
          </div>

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1">
              <span className="font-sans font-extrabold text-base sm:text-lg tracking-tight text-stone-900 leading-none truncate">
                {serviceType === "dinein"
                  ? `Dine-In ${tableNo ? `· Table ${tableNo}` : ""}`
                  : serviceType === "takeaway"
                  ? "Takeaway Pickup"
                  : formattedLocation}
              </span>
              <ChevronDown
                size={16}
                className="text-stone-600 flex-shrink-0 group-hover:translate-y-0.5 transition stroke-[2.5]"
              />
            </div>

            <p className="text-[11px] font-medium text-stone-500 truncate mt-0.5">
              {serviceType === "dinein"
                ? "Hyderabadi Irani Dining Hall"
                : serviceType === "takeaway"
                ? "Self-Pickup from Counter"
                : subLocation}
            </p>
          </div>
        </div>

        {/* Right Actions: Wallet & Profile Avatar (Zomato Style) */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {/* Table QR Scanner */}
          <button
            type="button"
            onClick={onOpenTableScanner}
            className="active-press w-9 h-9 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700 transition shadow-2xs"
            title="Scan Table QR for Dine-In"
          >
            <QrCode size={16} />
          </button>

          {/* Wallet / Loyalty Points Button */}
          <button
            type="button"
            onClick={onOpenAccount}
            className="active-press w-9 h-9 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-800 transition shadow-2xs relative"
            title="Wallet & Cashback"
          >
            <Wallet size={16} />
            {isLoggedIn && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 text-white text-[8px] font-extrabold rounded-full flex items-center justify-center">
                ★
              </span>
            )}
          </button>

          {/* User Profile Avatar (Zomato circular initial 'L') */}
          <button
            type="button"
            onClick={onOpenAccount}
            className="active-press w-9 h-9 rounded-full bg-indigo-50 border-2 border-indigo-200 text-indigo-700 font-extrabold text-sm flex items-center justify-center hover:scale-105 transition shadow-xs"
            title="Customer Account"
          >
            {userInitial}
          </button>
        </div>
      </div>
    </header>
  );
}
