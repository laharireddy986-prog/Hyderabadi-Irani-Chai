import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Search,
  Crosshair,
  MapPin,
  Plus,
  Clock,
  ChevronRight,
  ChevronDown,
  Loader2,
  Map,
  Store,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { STORE_LOCATION, calculateDistanceKm } from "../lib/deliveryTerms";
import { toast } from "sonner";

// Exact Restaurant Hotel Coordinates & Details
export const HOTEL_LOCATION = {
  name: "Hyderabadi Irani (At Hotel)",
  street: "Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta, Secunderabad",
  area: "Godumakunta / Rampally",
  city: "Secunderabad",
  pincode: "501302",
  lat: 17.4812,
  lng: 78.6385,
  label: "At Hotel",
  distanceDisplay: "0 km (At Hotel)",
};

// Curated Popular Local Hubs in Rampally / Secunderabad / Hyderabad
const POPULAR_NEARBY_HUBS = [
  {
    name: "Godumakunta Main Road",
    subtext: "Godumakunta, Secunderabad, Telangana",
    lat: 17.4812,
    lng: 78.6385,
    distanceDisplay: "0 km",
  },
  {
    name: "Elephant Enclave",
    subtext: "Rampally, Secunderabad",
    lat: 17.4725,
    lng: 78.6441,
    distanceDisplay: "720 m",
  },
  {
    name: "Rampally X Roads",
    subtext: "Rampally, Secunderabad",
    lat: 17.4680,
    lng: 78.6480,
    distanceDisplay: "1.2 km",
  },
  {
    name: "ECIL Cross Roads",
    subtext: "Secunderabad, Telangana",
    lat: 17.4708,
    lng: 78.5724,
    distanceDisplay: "2.4 km",
  },
  {
    name: "Sainikpuri / AS Rao Nagar",
    subtext: "Secunderabad, Telangana",
    lat: 17.4842,
    lng: 78.5471,
    distanceDisplay: "3.8 km",
  },
];

const INITIAL_RECENT_LOCATIONS = [
  {
    name: "Hyderabadi Irani (At Hotel)",
    subtext: "Rampally Main Road, Godumakunta, Secunderabad",
    lat: 17.4812,
    lng: 78.6385,
    distanceDisplay: "0 km",
  },
  {
    name: "Elephant Enclave",
    subtext: "Rampally, Secunderabad",
    lat: 17.4725,
    lng: 78.6441,
    distanceDisplay: "720 m",
  },
  {
    name: "Godumakunta",
    subtext: "Secunderabad",
    lat: 17.4812,
    lng: 78.6385,
    distanceDisplay: "100 m",
  },
];

export default function LocationSelectDrawer({
  isOpen,
  onClose,
  onOpenMapPicker,
}) {
  const { deliveryAddress, setDeliveryAddress, setServiceType } = useCart();
  const { customer } = useAuth();

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [detectingGps, setDetectingGps] = useState(false);
  const [recentLocations, setRecentLocations] = useState(() => {
    try {
      const saved = localStorage.getItem("hi_recent_locations");
      return saved ? JSON.parse(saved) : INITIAL_RECENT_LOCATIONS;
    } catch {
      return INITIAL_RECENT_LOCATIONS;
    }
  });

  const [showAddAddressForm, setShowAddAddressForm] = useState(false);
  const [customForm, setCustomForm] = useState({
    flatNo: "",
    landmark: "",
    area: "Godumakunta",
    city: "Secunderabad",
    pincode: "501302",
    tag: "Home",
  });

  const debounceRef = useRef(null);

  useEffect(() => {
    if (!isOpen) {
      setSearchQuery("");
      setSearchResults([]);
      setShowAddAddressForm(false);
    }
  }, [isOpen]);

  // Reverse Geocoding helper
  const reverseGeocodeCoords = async (latitude, longitude) => {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1`,
        {
          headers: { "Accept-Language": "en" },
        }
      );
      const data = await res.json();
      if (data && data.address) {
        const addr = data.address;
        const streetPart = [
          addr.house_number,
          addr.building,
          addr.road || addr.pedestrian || addr.footway,
        ]
          .filter(Boolean)
          .join(" ");
        const areaPart =
          addr.suburb ||
          addr.neighbourhood ||
          addr.residential ||
          addr.village ||
          addr.city_district ||
          "";
        const cityPart =
          addr.city || addr.town || addr.county || "Secunderabad";
        const pinPart = addr.postcode || "501302";

        const formatted = [streetPart, areaPart, cityPart]
          .filter(Boolean)
          .join(", ");
        return {
          street: formatted || data.display_name?.split(",").slice(0, 3).join(","),
          area: areaPart || "Godumakunta",
          city: cityPart,
          pincode: pinPart,
        };
      }
    } catch (err) {
      console.warn("Reverse geocode lookup:", err);
    }
    return {
      street: "Godumakunta, Secunderabad",
      area: "Godumakunta",
      city: "Secunderabad",
      pincode: "501302",
    };
  };

  // Search input handler
  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchQuery(val);

    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (!val.trim()) {
      setSearchResults([]);
      setSearching(false);
      return;
    }

    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      const localMatches = POPULAR_NEARBY_HUBS.filter(
        (h) =>
          h.name.toLowerCase().includes(val.toLowerCase()) ||
          h.subtext.toLowerCase().includes(val.toLowerCase())
      );

      try {
        const queryTerm = encodeURIComponent(val.trim() + " Secunderabad Hyderabad");
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${queryTerm}&countrycodes=in&limit=5`,
          {
            headers: { "Accept-Language": "en" },
          }
        );
        const data = await res.json();
        const apiResults = (data || []).map((item) => ({
          name: item.display_name.split(",")[0],
          subtext: item.display_name.split(",").slice(1, 4).join(",").trim(),
          lat: parseFloat(item.lat),
          lng: parseFloat(item.lon),
          distanceDisplay: `${calculateDistanceKm(parseFloat(item.lat), parseFloat(item.lon))} km`,
        }));

        const combined = [...localMatches];
        apiResults.forEach((ar) => {
          if (!combined.some((c) => c.name.toLowerCase() === ar.name.toLowerCase())) {
            combined.push(ar);
          }
        });
        setSearchResults(combined);
      } catch (err) {
        setSearchResults(localMatches);
      } finally {
        setSearching(false);
      }
    }, 350);
  };

  // Select any address and save to recent history
  const saveAndSelectLocation = (addrObj) => {
    setDeliveryAddress(addrObj);
    setServiceType("delivery");

    const dist = calculateDistanceKm(addrObj.lat || STORE_LOCATION.lat, addrObj.lng || STORE_LOCATION.lng);
    const distText = dist < 0.1 ? "0 km (At Hotel)" : dist < 1 ? `${Math.round(dist * 1000)} m` : `${dist} km`;

    const updated = [
      {
        name: addrObj.area || addrObj.street?.split(",")[0] || "Saved Location",
        subtext: addrObj.street || `${addrObj.city}, Telangana`,
        lat: addrObj.lat || STORE_LOCATION.lat,
        lng: addrObj.lng || STORE_LOCATION.lng,
        distanceDisplay: distText,
      },
      ...recentLocations.filter(
        (r) =>
          r.name.toLowerCase() !==
          (addrObj.area || addrObj.street?.split(",")[0] || "").toLowerCase()
      ),
    ].slice(0, 6);

    setRecentLocations(updated);
    try {
      localStorage.setItem("hi_recent_locations", JSON.stringify(updated));
      localStorage.setItem("hi_delivery_addr", JSON.stringify(addrObj));
    } catch {}

    onClose();
  };

  // Quick 1-Tap Select: At Hotel
  const handleSelectHotelLocation = () => {
    saveAndSelectLocation({
      street: HOTEL_LOCATION.street,
      area: "Godumakunta",
      city: "Secunderabad",
      pincode: "501302",
      lat: HOTEL_LOCATION.lat,
      lng: HOTEL_LOCATION.lng,
      label: "At Hotel",
    });
    toast.success("Location set to Hyderabadi Irani Hotel (0 km)! ☕");
  };

  // Live GPS Detect Location (Zomato "Use current location")
  const handleUseCurrentLocation = async () => {
    setDetectingGps(true);
    try {
      let lat = STORE_LOCATION.lat;
      let lng = STORE_LOCATION.lng;

      if (navigator.geolocation) {
        const pos = await new Promise((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0,
          });
        });
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      }

      // Check distance from store
      const distFromStore = calculateDistanceKm(lat, lng, STORE_LOCATION.lat, STORE_LOCATION.lng);
      
      // If user is within 500m of hotel, automatically tag as At Hotel
      if (distFromStore <= 0.5) {
        handleSelectHotelLocation();
        return;
      }

      const geo = await reverseGeocodeCoords(lat, lng);
      const newAddr = {
        street: geo.street,
        landmark: "",
        area: geo.area,
        city: geo.city,
        pincode: geo.pincode,
        lat: lat,
        lng: lng,
        label: "Current Location",
      };

      saveAndSelectLocation(newAddr);
      toast.success("Live GPS Location detected! 📍");
    } catch (err) {
      console.warn("GPS Detection notice:", err);
      handleSelectHotelLocation();
    } finally {
      setDetectingGps(false);
    }
  };

  // Save manual address form
  const handleSaveCustomAddress = () => {
    if (!customForm.flatNo.trim() || !customForm.area.trim()) {
      toast.error("Please enter your Flat/House No. and Area");
      return;
    }

    const fullStreet = `${customForm.flatNo.trim()}, ${customForm.area.trim()}${
      customForm.landmark.trim() ? `, Near ${customForm.landmark.trim()}` : ""
    }`;

    const newAddr = {
      street: fullStreet,
      flat_landmark: customForm.flatNo.trim(),
      landmark: customForm.landmark.trim(),
      area: customForm.area.trim(),
      city: customForm.city,
      pincode: customForm.pincode,
      lat: STORE_LOCATION.lat,
      lng: STORE_LOCATION.lng,
      label: customForm.tag,
    };

    saveAndSelectLocation(newAddr);
    toast.success("Delivery address saved! 🏠");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 font-sans">
      <div className="bg-[#f8f9fb] w-full max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[94vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Drawer Header (Down chevron + "Select a location") */}
        <div className="px-5 pt-4 pb-3 bg-white border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="text-stone-700 hover:text-stone-900 transition active-press p-1 -ml-1"
            >
              <ChevronDown size={22} className="stroke-[2.5]" />
            </button>
            <h2 className="text-lg font-black text-stone-900 tracking-tight">
              Select a location
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center text-stone-500 hover:bg-stone-200 transition"
          >
            <X size={15} />
          </button>
        </div>

        {/* Search Bar (Red Magnifying Glass + Rounded border) */}
        <div className="px-4 py-3 bg-white border-b border-stone-200/60">
          <div className="relative flex items-center">
            <Search size={18} className="absolute left-3.5 text-red-500 stroke-[2.5]" />
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              placeholder="Search for area, street name..."
              className="w-full bg-white border border-stone-200 rounded-2xl pl-10 pr-10 py-3 text-xs sm:text-sm font-medium text-stone-900 outline-none focus:border-red-500 shadow-2xs placeholder:text-stone-400"
              autoFocus
            />
            {searching ? (
              <Loader2 size={16} className="absolute right-3.5 text-stone-400 animate-spin" />
            ) : searchQuery ? (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery("");
                  setSearchResults([]);
                }}
                className="absolute right-3.5 text-stone-400 hover:text-stone-600 p-0.5"
              >
                <X size={15} />
              </button>
            ) : null}
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto flex-1 p-4 space-y-4">
          {/* Active Search Results */}
          {searchQuery ? (
            <div className="space-y-2 bg-white rounded-2xl p-3 border border-stone-200/80 shadow-2xs">
              <h3 className="text-[11px] font-extrabold uppercase tracking-wider text-stone-400 px-1">
                Search Results ({searchResults.length})
              </h3>
              {searchResults.length === 0 && !searching ? (
                <div className="py-6 text-center text-stone-500 text-xs">
                  <p className="font-bold">No matching localities found.</p>
                  <p className="text-[11px] text-stone-400 mt-1">
                    Try searching "Godumakunta", "Elephant Enclave", "Rampally", or "ECIL"
                  </p>
                </div>
              ) : (
                searchResults.map((res, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() =>
                      saveAndSelectLocation({
                        street: `${res.name}, ${res.subtext}`,
                        area: res.name,
                        city: "Secunderabad",
                        pincode: "501302",
                        lat: res.lat,
                        lng: res.lng,
                        label: res.name,
                      })
                    }
                    className="w-full text-left p-3 rounded-xl hover:bg-red-50/60 border-b border-stone-100 last:border-b-0 flex items-start gap-3 transition active-press group"
                  >
                    <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center text-red-600 flex-shrink-0 mt-0.5">
                      <MapPin size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-sm text-stone-900 truncate">
                          {res.name}
                        </h4>
                        <span className="text-[10px] font-bold text-stone-400 font-mono">
                          {res.distanceDisplay}
                        </span>
                      </div>
                      <p className="text-xs text-stone-500 line-clamp-1 mt-0.5">
                        {res.subtext}
                      </p>
                    </div>
                  </button>
                ))
              )}
            </div>
          ) : (
            <>
              {/* Primary Actions Container (White Card Box) */}
              <div className="bg-white rounded-2xl border border-stone-200/80 shadow-2xs divide-y divide-stone-100 overflow-hidden">
                {/* 1. At Hotel Option (Instant 1-Tap) */}
                <button
                  type="button"
                  onClick={handleSelectHotelLocation}
                  className="w-full text-left p-3.5 hover:bg-amber-50/50 bg-amber-50/20 flex items-center justify-between transition active-press group"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-7 h-7 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0 text-amber-800">
                      <Store size={16} className="stroke-[2.5]" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-sm text-amber-900">
                          At Hyderabadi Irani Hotel
                        </span>
                        <span className="text-[9px] bg-emerald-100 text-emerald-800 font-black px-1.5 py-0.2 rounded-full uppercase">
                          0 km · Free
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 font-medium truncate mt-0.5">
                        Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta
                      </p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-stone-400 group-hover:translate-x-0.5 transition flex-shrink-0" />
                </button>

                {/* 2. Use Current GPS Location */}
                <button
                  type="button"
                  disabled={detectingGps}
                  onClick={handleUseCurrentLocation}
                  className="w-full text-left p-3.5 hover:bg-stone-50/80 flex items-center justify-between transition active-press group"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-7 h-7 flex items-center justify-center flex-shrink-0 text-red-500">
                      {detectingGps ? (
                        <Loader2 size={20} className="animate-spin text-red-500" />
                      ) : (
                        <Crosshair size={20} className="stroke-[2.5]" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-red-500">
                          Use current location
                        </span>
                        {detectingGps && (
                          <span className="text-[10px] text-red-500 animate-pulse font-bold">
                            (Locating GPS...)
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-stone-700 font-medium truncate mt-0.5">
                        {deliveryAddress?.street || "Godumakunta, Secunderabad"}
                      </p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-stone-400 group-hover:translate-x-0.5 transition flex-shrink-0" />
                </button>

                {/* 3. Add Custom Address */}
                <button
                  type="button"
                  onClick={() => setShowAddAddressForm(!showAddAddressForm)}
                  className="w-full text-left p-3.5 hover:bg-stone-50/80 flex items-center justify-between transition active-press group"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-7 h-7 flex items-center justify-center flex-shrink-0 text-red-500">
                      <Plus size={20} className="stroke-[2.5]" />
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-sm text-red-500">
                        Add Address
                      </span>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-stone-400 group-hover:translate-x-0.5 transition flex-shrink-0" />
                </button>

                {/* 4. Interactive Map Pin */}
                {onOpenMapPicker && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenMapPicker();
                    }}
                    className="w-full text-left p-3.5 hover:bg-stone-50/80 flex items-center justify-between transition active-press group"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="w-7 h-7 flex items-center justify-center flex-shrink-0 text-red-500">
                        <Map size={18} className="stroke-[2.5]" />
                      </div>
                      <div className="min-w-0">
                        <span className="font-bold text-sm text-red-500">
                          Set Exact Doorstep on Interactive Map
                        </span>
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-stone-400 group-hover:translate-x-0.5 transition flex-shrink-0" />
                  </button>
                )}
              </div>

              {/* Add Address Form Accordion */}
              {showAddAddressForm && (
                <div className="bg-white rounded-2xl p-4 border border-stone-200 space-y-3 shadow-xs animate-in fade-in">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-stone-700">
                    Enter Complete Address
                  </h4>

                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="House / Flat / Block No."
                      value={customForm.flatNo}
                      onChange={(e) =>
                        setCustomForm({ ...customForm, flatNo: e.target.value })
                      }
                      className="bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-red-500 font-medium"
                    />
                    <input
                      type="text"
                      placeholder="Area / Locality"
                      value={customForm.area}
                      onChange={(e) =>
                        setCustomForm({ ...customForm, area: e.target.value })
                      }
                      className="bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-red-500 font-medium"
                    />
                  </div>

                  <input
                    type="text"
                    placeholder="Landmark (e.g. Near Bus Stop, Pillar 12)"
                    value={customForm.landmark}
                    onChange={(e) =>
                      setCustomForm({ ...customForm, landmark: e.target.value })
                    }
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs outline-none focus:border-red-500 font-medium"
                  />

                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-[11px] font-bold text-stone-500">Save as:</span>
                    {["Home", "Work", "Other"].map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => setCustomForm({ ...customForm, tag })}
                        className={`px-3 py-1 rounded-full text-[11px] font-bold border transition ${
                          customForm.tag === tag
                            ? "bg-red-500 text-white border-red-600 shadow-xs"
                            : "bg-stone-50 text-stone-600 border-stone-200"
                        }`}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={handleSaveCustomAddress}
                    className="active-press w-full bg-red-500 hover:bg-red-600 text-white py-2.5 rounded-xl text-xs font-extrabold uppercase tracking-wider shadow-sm transition"
                  >
                    Save & Select Address
                  </button>
                </div>
              )}

              {/* NEARBY LOCATIONS */}
              <div className="space-y-2 pt-1">
                <h3 className="text-[12px] font-extrabold uppercase tracking-wider text-stone-500 px-1">
                  NEARBY LOCATIONS
                </h3>

                <div className="bg-white rounded-2xl border border-stone-200/80 shadow-2xs divide-y divide-stone-100 overflow-hidden">
                  {POPULAR_NEARBY_HUBS.map((hub, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() =>
                        saveAndSelectLocation({
                          street: `${hub.name}, ${hub.subtext}`,
                          area: hub.name,
                          city: "Secunderabad",
                          pincode: "501302",
                          lat: hub.lat,
                          lng: hub.lng,
                          label: hub.name,
                        })
                      }
                      className="w-full text-left p-3.5 hover:bg-stone-50 flex items-start gap-3 transition active-press group"
                    >
                      <div className="w-5 h-5 flex items-center justify-center text-stone-600 flex-shrink-0 mt-0.5">
                        <MapPin size={17} className="stroke-[2.2]" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm text-stone-900 truncate">
                          {hub.name}
                        </h4>
                        <p className="text-xs text-stone-500 truncate mt-0.5">
                          <span className="font-semibold text-stone-700">{hub.distanceDisplay}</span> · {hub.subtext}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* RECENT LOCATIONS */}
              {recentLocations.length > 0 && (
                <div className="space-y-2 pt-1">
                  <h3 className="text-[12px] font-extrabold uppercase tracking-wider text-stone-500 px-1">
                    RECENT LOCATIONS
                  </h3>

                  <div className="bg-white rounded-2xl border border-stone-200/80 shadow-2xs divide-y divide-stone-100 overflow-hidden">
                    {recentLocations.map((rec, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() =>
                          saveAndSelectLocation({
                            street: rec.subtext || rec.name,
                            area: rec.name,
                            city: "Secunderabad",
                            pincode: "501302",
                            lat: rec.lat,
                            lng: rec.lng,
                            label: rec.name,
                          })
                        }
                        className="w-full text-left p-3.5 hover:bg-stone-50 flex items-start gap-3 transition active-press group"
                      >
                        <div className="w-5 h-5 flex items-center justify-center text-stone-600 flex-shrink-0 mt-0.5">
                          <Clock size={17} className="stroke-[2.2]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-sm text-stone-900 truncate">
                            {rec.name}
                          </h4>
                          <p className="text-xs text-stone-500 truncate mt-0.5">
                            <span className="font-semibold text-stone-700">{rec.distanceDisplay}</span> · {rec.subtext}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
