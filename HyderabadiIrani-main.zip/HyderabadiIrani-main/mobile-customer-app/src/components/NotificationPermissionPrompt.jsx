import React, { useState, useEffect } from "react";
import { Bell, Sparkles, X, CheckCircle2 } from "lucide-react";
import { requestPushPermission } from "../lib/notifications";
import { getSecureItem, setSecureItem } from "../lib/storage";

const PROMPT_DISMISSED_KEY = "hi_notif_prompt_dismissed_v1";

export default function NotificationPermissionPrompt({ customerPhone }) {
  const [visible, setVisible] = useState(false);
  const [enabling, setEnabling] = useState(false);

  useEffect(() => {
    async function checkPromptStatus() {
      try {
        const dismissed = await getSecureItem(PROMPT_DISMISSED_KEY);
        if (!dismissed) {
          // Delay showing by 2.5 seconds so user first sees the menu
          const timer = setTimeout(() => {
            setVisible(true);
          }, 2500);
          return () => clearTimeout(timer);
        }
      } catch {}
    }
    checkPromptStatus();
  }, []);

  if (!visible) return null;

  const handleEnable = async () => {
    setEnabling(true);
    try {
      await requestPushPermission(customerPhone);
      await setSecureItem(PROMPT_DISMISSED_KEY, "true");
    } finally {
      setEnabling(false);
      setVisible(false);
    }
  };

  const handleDismiss = async () => {
    await setSecureItem(PROMPT_DISMISSED_KEY, "true");
    setVisible(false);
  };

  return (
    <div className="fixed bottom-20 left-4 right-4 z-40 max-w-md mx-auto animate-in slide-in-from-bottom-6 duration-300">
      <div className="bg-brand-950 text-white p-4 rounded-3xl shadow-2xl border border-brand-800/80 relative">
        <button
          type="button"
          onClick={handleDismiss}
          className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition"
          title="Dismiss"
        >
          <X size={14} />
        </button>

        <div className="flex items-start gap-3.5 pr-6">
          <div className="w-10 h-10 rounded-2xl bg-amber-400 text-brand-950 flex items-center justify-center flex-shrink-0 shadow-md">
            <Bell size={20} className="animate-bounce" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 text-[11px] font-extrabold uppercase tracking-wider text-amber-300 mb-0.5">
              <Sparkles size={11} />
              <span>Live Order Alerts</span>
            </div>
            <h3 className="font-serif font-bold text-sm leading-tight text-white">
              Never Miss a Fresh Update!
            </h3>
            <p className="text-xs text-stone-300 mt-1 leading-relaxed">
              Get instant notifications when your Biryani is cooking and on its way to your doorstep or table.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 mt-3.5 pt-2 border-t border-brand-800/60">
          <button
            type="button"
            onClick={handleDismiss}
            className="flex-1 py-2 text-xs font-bold text-stone-400 hover:text-white transition rounded-xl text-center"
          >
            Maybe Later
          </button>

          <button
            type="button"
            disabled={enabling}
            onClick={handleEnable}
            className="flex-1 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-brand-950 py-2.5 px-3 rounded-xl font-extrabold text-xs uppercase tracking-wider transition shadow-md flex items-center justify-center gap-1.5"
          >
            <CheckCircle2 size={14} className="stroke-[2.5]" />
            <span>{enabling ? "Enabling…" : "Enable Alerts"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
