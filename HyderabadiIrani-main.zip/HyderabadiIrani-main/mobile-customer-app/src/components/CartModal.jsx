import React, { useState, useEffect, useMemo } from "react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { money, api, errMsg } from "../lib/api";
import { STORE_LOCATION, calculateDistanceKm, calculateDeliveryFee } from "../lib/deliveryTerms";
import LocationPickerModal from "./LocationPickerModal";
import { EmptyCartState } from "./EmptyState";
import { getCartPairings } from "../lib/pairings";
import PairingRecommendationsShelf from "./PairingRecommendationsShelf";
import {
  X,
  Plus,
  Minus,
  Trash2,
  Bike,
  UtensilsCrossed,
  ShoppingBag,
  Sparkles,
  Loader2,
  Banknote,
  CreditCard,
  CheckCircle2,
  MapPin,
  Crosshair,
  Navigation,
  ChevronRight,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";

export default function CartModal({
  isOpen,
  onClose,
  onOrderSuccess,
  isOnlineOpen = true,
  storeNotice = "",
  allItems = [],
  onSelectDish,
  onOpenLogin,
}) {
  const {
    lines,
    addItem,
    updateLineQty,
    removeItem,
    clearCart,
    subtotal,
    deliveryFee: contextDeliveryFee,
    discountAmount,
    total,
    serviceType,
    setServiceType,
    tableNo,
    setTableNo,
    deliveryAddress,
    setDeliveryAddress,
    addPlacedOrder,
  } = useCart();

  const { customer, isLoggedIn } = useAuth();

  const [customerName, setCustomerName] = useState(customer?.name || "");
  const [customerPhone, setCustomerPhone] = useState(customer?.phone || "");
  const [payMode, setPayMode] = useState("razorpay"); // razorpay or cod
  const [orderNotes, setOrderNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [useRoyaltyCoins, setUseRoyaltyCoins] = useState(false);
  const [locationPickerOpen, setLocationPickerOpen] = useState(false);
  const [locatingQuick, setLocatingQuick] = useState(false);

  // Quick GPS Geolocation helper
  const handleQuickGps = async () => {
    setLocatingQuick(true);
    try {
      let position = null;
      if (window.Capacitor?.isPluginAvailable("Geolocation")) {
        try {
          const { Geolocation } = await import("@capacitor/geolocation");
          position = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10000 });
        } catch {}
      }
      if (!position) {
        position = await new Promise((resolve, reject) => {
          if (!navigator.geolocation) return reject(new Error("Geolocation not supported"));
          navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 });
        });
      }

      const userLat = position.coords.latitude;
      const userLng = position.coords.longitude;

      // Reverse geocode via Nominatim
      try {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/reverse?lat=${userLat}&lon=${userLng}&format=json&addressdetails=1`
        );
        const data = await res.json();
        const addr = data?.address || {};
        const road = [addr.house_number, addr.building, addr.road].filter(Boolean).join(" ");
        const locality = addr.suburb || addr.neighbourhood || addr.city_district || "";
        const city = addr.city || addr.town || "Secunderabad";
        const pin = addr.postcode || "501302";
        const fullStreet = [road, locality, city].filter(Boolean).join(", ") || data.display_name?.split(",").slice(0, 3).join(",") || "Rampally X Road";

        setDeliveryAddress({
          ...deliveryAddress,
          street: fullStreet,
          landmark: locality,
          city,
          pincode: pin,
          lat: userLat,
          lng: userLng,
        });
        toast.success("Location pinned via GPS! 📍");
      } catch {
        setDeliveryAddress({
          ...deliveryAddress,
          lat: userLat,
          lng: userLng,
        });
        toast.info("GPS coordinates detected.");
      }
    } catch {
      toast.error("Could not fetch GPS location. Tap 'Pick on Map'.");
    } finally {
      setLocatingQuick(false);
    }
  };

  // Calculate dynamic delivery fee based on coordinates if present
  const calculatedDistance = deliveryAddress?.lat && deliveryAddress?.lng
    ? calculateDistanceKm(deliveryAddress.lat, deliveryAddress.lng)
    : 1.5;
  const dynamicDeliveryTier = calculateDeliveryFee(calculatedDistance, subtotal);
  const deliveryFee = serviceType === "delivery" ? dynamicDeliveryTier.fee : 0;

  // Payment failure / retry flow state
  const [pendingOrder, setPendingOrder] = useState(null);
  const [switchingToCod, setSwitchingToCod] = useState(false);

  // Loyalty points redemption calculations (100 coins welcome: 4 orders x ₹25 OFF on subtotal > ₹249)
  const availableCoins = customer?.loyalty_points !== undefined ? customer.loyalty_points : 0;
  const ordersCompleted = customer?.orders_count ?? 0;
  const isFirstFourOrders = ordersCompleted < 4;
  const meetsMinOrderValue = subtotal > 249; // MOV requirement > ₹249
  const orderShortfall = Math.max(0, 250 - subtotal);
  
  // Redeemable coins calculation: 25 coins for ₹25 off per order if subtotal > 249
  const maxRedeemableCoins = isFirstFourOrders 
    ? (availableCoins >= 25 ? 25 : availableCoins)
    : Math.min(availableCoins, 25);
  const canRedeemCoins = meetsMinOrderValue && availableCoins >= 25;
  const coinsToRedeem = useRoyaltyCoins && canRedeemCoins ? maxRedeemableCoins : 0;
  const coinDiscount = coinsToRedeem * 1.0;

  const payableTotal = Math.max(0, subtotal - discountAmount - coinDiscount + deliveryFee);
  const potentialCoinsEarned = Math.floor(payableTotal / 100);

  // Cross-sell Pairing Recommendations based on current cart contents
  const cartPairings = useMemo(() => {
    return getCartPairings(lines, allItems, 6);
  }, [lines, allItems]);

  // Sync state when customer logs in
  useEffect(() => {
    if (customer?.phone) {
      setCustomerPhone(customer.phone);
    }
    if (customer?.name) {
      setCustomerName(customer.name);
    }
  }, [customer]);

  // Dine-in bookings are prepaid-only — snap back to online payment if the
  // customer switches into dine-in while COD was selected.
  useEffect(() => {
    if (serviceType === "dinein" && payMode === "cod") {
      setPayMode("razorpay");
    }
  }, [serviceType, payMode]);

  if (!isOpen) return null;

  const triggerRazorpayCheckout = async (order) => {
    try {
      // 1. Fetch Razorpay config & Order details from backend
      let keyId = null;
      let rzpOrderId = null;

      try {
        const [configRes, rzpRes] = await Promise.all([
          api.get("/payments/config"),
          api.post("/payments/razorpay/order", { order_no: order.order_no }),
        ]);
        if (configRes.data?.key_id) {
          keyId = configRes.data.key_id;
        }
        if (rzpRes.data?.razorpay_order_id) {
          rzpOrderId = rzpRes.data.razorpay_order_id;
        }
        if (!keyId && rzpRes.data?.key_id) {
          keyId = rzpRes.data.key_id;
        }
      } catch (err) {
        console.error("[PAYMENT] Razorpay order creation failed:", err);
        const userMsg = errMsg(err) || "Online payment gateway is temporarily unavailable. Please switch to Cash on Delivery.";
        toast.error(userMsg);
        setPendingOrder(order);
        setSubmitting(false);
        return;
      }

      if (!keyId || !rzpOrderId) {
        toast.error("Online payment is currently unavailable. Please switch to Cash on Delivery.");
        setPendingOrder(order);
        setSubmitting(false);
        return;
      }

      const verifyAndFinalize = async (response) => {
        try {
          if (response.razorpay_signature) {
            const verifyRes = await api.post("/payments/razorpay/verify", {
              order_no: order.order_no,
              razorpay_order_id: response.razorpay_order_id || rzpOrderId,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            });
            toast.success("Payment verified! Order confirmed. ☕");
            finalizeOrder(verifyRes.data.order || order);
          } else {
            toast.success("Payment received! Order confirmed. ☕");
            finalizeOrder(order);
          }
        } catch (e) {
          toast.error("Payment verification failed. Please contact counter.");
          setPendingOrder(order);
        }
      };

      const logFailure = async (status, extra = {}) => {
        try {
          await api.post("/payments/log-attempt", { order_no: order.order_no, status, ...extra });
        } catch {}
      };

      // On a real device, use the native Razorpay Checkout SDK — the web
      // checkout.js widget can't launch UPI/wallet apps or receive their
      // redirect callback from inside a Capacitor WebView, so it silently
      // fails there (missing UPI option, "payment failed" after a wallet).
      if (window.Capacitor?.isNativePlatform() && window.Capacitor?.isPluginAvailable("Checkout")) {
        try {
          const { Checkout } = await import("capacitor-razorpay");
          const result = await Checkout.open({
            key: keyId,
            amount: String(Math.round(order.total * 100)),
            currency: "INR",
            name: "Hyderabadi Irani Food Court",
            description: `Order #${order.order_no}`,
            image: "https://hyderabadiirani.net/logo.png",
            order_id: rzpOrderId,
            prefill: {
              name: order.customer_name || customerName,
              contact: order.phone || customerPhone,
            },
            theme: { color: "#78350f" },
          });
          const response = result?.response || {};
          await verifyAndFinalize(response);
        } catch (err) {
          let desc = "Online payment was not completed.";
          if (typeof err === "string") {
            try {
              const p = JSON.parse(err);
              desc = p.description || p.message || err;
            } catch {
              desc = err;
            }
          } else if (err && typeof err === "object") {
            if (err.description) {
              desc = err.description;
            } else if (err.message) {
              try {
                const p = JSON.parse(err.message);
                desc = p.description || p.message || err.message;
              } catch {
                desc = err.message;
              }
            }
          }
          const isCancel =
            String(desc).toLowerCase().includes("cancel") ||
            String(desc).toLowerCase().includes("dismiss") ||
            String(desc).toLowerCase().includes("back");
          await logFailure(
            isCancel ? "cancelled" : "failed",
            { error_description: String(desc) }
          );
          toast.error(isCancel ? "Payment cancelled." : String(desc));
          setPendingOrder(order);
          setSubmitting(false);
        }
        return;
      }

      // Browser / dev preview fallback: standard web checkout.js widget
      const options = {
        key: keyId,
        amount: Math.round(order.total * 100),
        currency: "INR",
        name: "Hyderabadi Irani Food Court",
        description: `Order #${order.order_no}`,
        image: "/logo.png",
        order_id: rzpOrderId || undefined,
        prefill: {
          name: order.customer_name || customerName,
          contact: order.phone || customerPhone,
        },
        theme: {
          color: "#78350f",
        },
        handler: async function (response) {
          await verifyAndFinalize(response);
        },
        modal: {
          ondismiss: async function () {
            await logFailure("cancelled", {
              error_code: "user_dismissed",
              error_description: "Customer dismissed Razorpay window",
            });
            toast.error("Online payment was not completed.");
            setPendingOrder(order);
            setSubmitting(false);
          },
        },
      };

      if (window.Razorpay) {
        const rzp = new window.Razorpay(options);
        rzp.on("payment.failed", async function (response) {
          await logFailure("failed", {
            payment_id: response.error?.metadata?.payment_id,
            error_code: response.error?.code,
            error_description: response.error?.description,
          });
          toast.error(response.error?.description || "Payment failed.");
          setPendingOrder(order);
          setSubmitting(false);
        });
        rzp.open();
      } else {
        // Fallback for testing environments without live Razorpay JS
        toast.success("Test Payment Verified! Order confirmed.");
        finalizeOrder(order);
      }
    } catch (err) {
      toast.error(errMsg(err) || "Failed to trigger payment gateway.");
      setPendingOrder(order);
      setSubmitting(false);
    }
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();

    if (!lines.length) {
      toast.error("Your cart is empty");
      return;
    }

    if (!isLoggedIn || !customer?.phone) {
      toast.error("Please Sign In or Register with your mobile number to place your order.");
      if (onOpenLogin) onOpenLogin();
      return;
    }

    // Phone Validation (10 digits starting with 6, 7, 8, 9)
    const cleanPhone = (customer?.phone || customerPhone).replace(/\D/g, "").slice(-10);
    if (!cleanPhone || cleanPhone.length !== 10 || !/^[6-9]\d{9}$/.test(cleanPhone)) {
      toast.error("Please enter a valid 10-digit mobile number (e.g. 8331807704)");
      return;
    }

    // Delivery Address Validation
    if (serviceType === "delivery") {
      const addr = deliveryAddress.street.trim();
      if (!addr || addr.length < 6) {
        toast.error("Please enter a complete delivery address (House/Flat No., Street, Area)");
        return;
      }
    }

    // Dine-In Table Validation
    if (serviceType === "dinein" && !tableNo.trim()) {
      toast.error("Please select or enter your Table Number (e.g. T-01)");
      return;
    }

    // In-house (dine-in) bookings placed via the app must be prepaid
    // online — cash is only available when ordering at the counter.
    // Enforced server-side too (see backend/server.py).
    if (serviceType === "dinein" && payMode !== "razorpay") {
      toast.error("Dine-in bookings must be prepaid online. Cash is only available at the counter.");
      return;
    }

    setSubmitting(true);

    try {
      // 1. Format order payload matching OrderIn
      const orderPayload = {
        customer_name: (customerName || "Mobile App Guest").trim(),
        phone: cleanPhone,
        address:
          serviceType === "delivery"
            ? `${deliveryAddress.street.trim()}, ${deliveryAddress.landmark ? deliveryAddress.landmark.trim() + ", " : ""}${deliveryAddress.city || "Secunderabad"} - ${deliveryAddress.pincode || "501302"}`
            : "",
        table_no: serviceType === "dinein" ? tableNo.trim().toUpperCase() : "",
        order_type: serviceType === "dinein" ? "dine-in" : serviceType,
        payment_mode: payMode === "razorpay" ? "razorpay" : "cash",
        items: lines.map((l) => ({
          // l.item_id is the cart LINE key (e.g. "<menuItemId>_half" for a
          // portion variant, so two sizes of the same dish can sit in the
          // cart as separate lines) — it is not a real menu item id, so the
          // backend's ObjectId(item_id) lookup would reject it. The actual
          // menu item id is base_item_id for variant lines, and item_id
          // itself for plain (non-variant) lines.
          item_id: l.base_item_id || l.item_id,
          name: l.name,
          variant: l.variant || null,
          price: l.price,
          qty: l.qty,
          station: l.station || "kitchen",
          notes: (l.notes || "").trim(),
        })),
        notes: (orderNotes || "").trim().slice(0, 150),
        points_redeemed: coinsToRedeem,
        delivery_fee: deliveryFee,
        lat: deliveryAddress.lat || null,
        lng: deliveryAddress.lng || null,
      };

      // 2. Submit to backend API
      const res = await api.post("/public/orders", orderPayload);
      const createdOrder = res.data;

      // 3. If Razorpay, trigger payment flow; else finalize COD order immediately
      if (payMode === "razorpay") {
        await triggerRazorpayCheckout(createdOrder);
      } else {
        toast.success(`Order #${createdOrder.order_no} placed successfully! ☕`);
        finalizeOrder(createdOrder);
      }
    } catch (err) {
      toast.error(errMsg(err) || "Failed to place order. Please retry.");
      setSubmitting(false);
    }
  };

  const handleSwitchToCod = async () => {
    if (!pendingOrder) return;
    setSwitchingToCod(true);
    try {
      const res = await api.put(`/orders/${pendingOrder.order_no}/switch-to-cod`);
      toast.success("Order switched to Cash on Delivery / Pay at Counter! ☕");
      finalizeOrder(res.data?.order || { ...pendingOrder, payment_mode: "cash", status: "placed" });
    } catch (err) {
      toast.error(errMsg(err) || "Could not switch order to Cash on Delivery.");
    } finally {
      setSwitchingToCod(false);
    }
  };

  const finalizeOrder = (order) => {
    addPlacedOrder(order);
    clearCart();
    setSubmitting(false);
    setPendingOrder(null);
    onClose();
    if (onOrderSuccess) onOrderSuccess(order);
  };

  // -------------------------------------------------------------
  // RENDER: PAYMENT FAILED / INCOMPLETE SCREEN
  // -------------------------------------------------------------
  if (pendingOrder) {
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
        <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-800 mx-auto flex items-center justify-center shadow-inner">
              <AlertCircle size={30} />
            </div>
            <h3 className="font-serif font-bold text-lg text-brand-950">
              Online Payment Incomplete
            </h3>
            <p className="text-xs text-stone-600 max-w-sm mx-auto leading-relaxed">
              Your order <span className="font-mono font-bold text-brand-900">#{pendingOrder.order_no}</span> (Total: {money(pendingOrder.total)}) is reserved. You can retry paying online or switch to Cash on Delivery without creating a duplicate order.
            </p>
          </div>

          <div className="bg-stone-50 rounded-2xl p-3 border border-stone-200 text-xs space-y-1.5 font-mono">
            <div className="flex justify-between text-stone-600">
              <span>Order Number:</span>
              <span className="font-bold text-brand-950">#{pendingOrder.order_no}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Amount Due:</span>
              <span className="font-bold text-brand-950">{money(pendingOrder.total)}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Fulfillment:</span>
              <span className="font-bold uppercase text-brand-950">{pendingOrder.order_type}</span>
            </div>
          </div>

          <div className="space-y-2.5 pt-2">
            <button
              type="button"
              disabled={submitting}
              onClick={() => {
                setSubmitting(true);
                triggerRazorpayCheckout(pendingOrder);
              }}
              className="active-press w-full bg-brand-900 hover:bg-brand-950 text-white py-3 px-4 rounded-xl font-extrabold text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2"
            >
              <RefreshCw size={14} className={submitting ? "animate-spin" : ""} />
              <span>{submitting ? "Opening Payment…" : "Retry Online Payment (UPI / Cards)"}</span>
            </button>

            <button
              type="button"
              disabled={switchingToCod}
              onClick={handleSwitchToCod}
              className="active-press w-full bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-brand-950 py-3 px-4 rounded-xl font-extrabold text-xs uppercase tracking-wider shadow flex items-center justify-center gap-2"
            >
              <Banknote size={15} />
              <span>{switchingToCod ? "Confirming COD…" : "Switch to Cash on Delivery (COD)"}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setPendingOrder(null);
                onClose();
              }}
              className="w-full py-2 text-stone-400 hover:text-stone-700 text-xs font-bold text-center"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // RENDER: MAIN CART MODAL
  // -------------------------------------------------------------
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <h2 className="font-serif text-lg font-bold text-brand-950">
              Your Order Summary
            </h2>
            <span className="text-xs font-mono font-bold bg-brand-100 text-brand-900 px-2 py-0.5 rounded-full">
              {lines.length} items
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200/70 hover:bg-stone-300 flex items-center justify-center text-stone-600 transition"
          >
            <X size={16} />
          </button>
        </div>

        {/* Modal Body */}
        {lines.length === 0 ? (
          <EmptyCartState onBrowseMenu={onClose} />
        ) : (
          <form
            onSubmit={handlePlaceOrder}
            className="overflow-y-auto p-4 space-y-4 flex-1 text-stone-800"
          >
            {/* Service Mode Selector */}
            <div className="bg-stone-100 p-1 rounded-2xl grid grid-cols-3 gap-1">
              <button
                type="button"
                onClick={() => setServiceType("delivery")}
                className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  serviceType === "delivery"
                    ? "bg-brand-900 text-white shadow-xs"
                    : "text-stone-600 hover:text-stone-900"
                }`}
              >
                <Bike size={13} />
                <span>Delivery</span>
              </button>

              <button
                type="button"
                onClick={() => setServiceType("dinein")}
                className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  serviceType === "dinein"
                    ? "bg-brand-900 text-white shadow-xs"
                    : "text-stone-600 hover:text-stone-900"
                }`}
              >
                <UtensilsCrossed size={13} />
                <span>Dine-In</span>
              </button>

              <button
                type="button"
                onClick={() => setServiceType("takeaway")}
                className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  serviceType === "takeaway"
                    ? "bg-brand-900 text-white shadow-xs"
                    : "text-stone-600 hover:text-stone-900"
                }`}
              >
                <ShoppingBag size={13} />
                <span>Takeaway</span>
              </button>
            </div>

            {/* Cart Items List */}
            <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
              {lines.map((item) => (
                <div
                  key={item.item_id}
                  className="bg-stone-50 p-3 rounded-2xl border border-stone-200/80 flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                          item.veg ? "bg-emerald-600" : "bg-red-600"
                        }`}
                      />
                      <h4 className="font-bold text-xs text-stone-900 truncate">
                        {item.name}
                      </h4>
                    </div>
                    <div className="text-[11px] font-mono text-stone-500 mt-0.5">
                      {money(item.price)} × {item.qty} ={" "}
                      <span className="font-bold text-brand-950">
                        {money(item.price * item.qty)}
                      </span>
                    </div>
                    {item.notes && (
                      <div className="text-[10px] text-red-600 bg-red-50 font-bold px-1.5 py-0.5 rounded-md mt-1 w-fit truncate max-w-[200px]">
                        📝 {item.notes}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 bg-stone-200/80 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => updateLineQty(item.item_id, -1)}
                      className="w-6 h-6 rounded-lg bg-white shadow-xs flex items-center justify-center font-bold text-stone-800 hover:bg-red-50"
                      title="Decrease quantity"
                    >
                      {item.qty === 1 ? <Trash2 size={11} className="text-red-500" /> : <Minus size={11} />}
                    </button>
                    <span className="text-xs font-bold font-mono px-1">
                      {item.qty}
                    </span>
                    <button
                      type="button"
                      onClick={() => updateLineQty(item.item_id, 1)}
                      className="w-6 h-6 rounded-lg bg-white shadow-xs flex items-center justify-center font-bold text-stone-800 hover:bg-emerald-50"
                      title="Increase quantity"
                    >
                      <Plus size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Zomato-Style "Complete your meal with" Pairing Shelf */}
            {cartPairings.length > 0 && (
              <PairingRecommendationsShelf
                pairings={cartPairings}
                title="Complete your meal with"
                subtitle="Popular pairings & add-ons for your order"
                onSelectDish={onSelectDish}
              />
            )}

            {/* Customer & Fulfillment Details */}
            <div className="bg-stone-50 p-3.5 rounded-2xl border border-stone-200/80 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-600">
                Customer & Fulfillment Details
              </h3>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[10px] font-bold uppercase text-stone-500">
                      Mobile Number *
                    </label>
                    {isLoggedIn && (
                      <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded-full flex items-center gap-0.5">
                        <CheckCircle2 size={10} /> Verified
                      </span>
                    )}
                  </div>
                  <input
                    type="tel"
                    maxLength={10}
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="10-digit number"
                    className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs font-mono outline-none focus:border-brand-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Lokesh"
                    className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-brand-900"
                  />
                </div>
              </div>

              {serviceType === "delivery" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] font-bold uppercase text-stone-500">
                      Delivery Location *
                    </label>
                    <button
                      type="button"
                      onClick={handleQuickGps}
                      disabled={locatingQuick}
                      className="text-[11px] font-bold text-amber-900 hover:text-amber-800 flex items-center gap-1 bg-amber-100/70 hover:bg-amber-100 px-2 py-0.5 rounded-lg transition disabled:opacity-50"
                    >
                      <Crosshair size={11} className={locatingQuick ? "animate-spin text-amber-700" : "text-amber-700"} />
                      <span>{locatingQuick ? "Locating..." : "Use Current GPS"}</span>
                    </button>
                  </div>

                  {/* Selected Address Display Card */}
                  <div
                    onClick={() => setLocationPickerOpen(true)}
                    className="p-3 bg-white rounded-2xl border border-stone-300 hover:border-amber-700 hover:shadow-xs transition cursor-pointer flex items-start justify-between gap-2.5 text-left group"
                  >
                    <div className="flex items-start gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <MapPin size={16} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-stone-900">
                            {deliveryAddress.label || "Delivery Location"}
                          </span>
                          <span className="text-[10px] font-mono text-amber-900 font-bold bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                            {calculatedDistance} km
                          </span>
                        </div>
                        <p className="text-xs text-stone-700 font-medium mt-0.5 line-clamp-2">
                          {deliveryAddress.street || "Tap to set street address / pin on map"}
                        </p>
                        {deliveryAddress.landmark && (
                          <p className="text-[11px] text-stone-400 mt-0.5 line-clamp-1">
                            Landmark: {deliveryAddress.landmark}
                          </p>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setLocationPickerOpen(true);
                      }}
                      className="px-2 py-1 bg-stone-100 group-hover:bg-amber-100 group-hover:text-amber-950 text-stone-600 rounded-lg text-[11px] font-bold flex items-center gap-0.5 transition flex-shrink-0"
                    >
                      <span>Change</span>
                      <ChevronRight size={12} />
                    </button>
                  </div>

                  {/* Quick manual street edit if needed */}
                  <div>
                    <input
                      type="text"
                      value={deliveryAddress.street}
                      onChange={(e) =>
                        setDeliveryAddress({ ...deliveryAddress, street: e.target.value })
                      }
                      placeholder="e.g. Flat 302, Green Meadows, Rampally"
                      className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-brand-900"
                      required
                    />
                  </div>
                </div>
              )}

              {serviceType === "dinein" && (
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1">
                    Table Number *
                  </label>
                  <input
                    type="text"
                    value={tableNo}
                    onChange={(e) => setTableNo(e.target.value.toUpperCase())}
                    placeholder="e.g. T-01, T-05"
                    className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs font-mono font-bold outline-none focus:border-brand-900"
                    required
                  />
                </div>
              )}

              {/* Cooking Notes / Special Instructions */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-[10px] font-bold uppercase text-stone-500">
                    Cooking Notes / Instructions
                  </label>
                  <span className="text-[10px] font-mono text-stone-400">
                    {orderNotes.length}/150
                  </span>
                </div>
                <input
                  type="text"
                  maxLength={150}
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="e.g. Extra spicy, less oil, separate gravy"
                  className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-brand-900"
                />
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="block text-[10px] font-bold uppercase text-stone-500">
                Select Payment Mode
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPayMode("razorpay")}
                  className={`p-3 rounded-2xl border text-left transition flex items-center gap-2.5 ${
                    payMode === "razorpay"
                      ? "border-brand-900 bg-brand-50/60 ring-2 ring-brand-900/10"
                      : "border-stone-200 bg-white"
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center ${
                      payMode === "razorpay"
                        ? "bg-brand-900 text-white"
                        : "bg-stone-100 text-stone-600"
                    }`}
                  >
                    <CreditCard size={14} />
                  </div>
                  <div>
                    <div className="font-bold text-xs text-brand-950">
                      UPI / Online
                    </div>
                    <div className="text-[10px] text-stone-500">
                      GPay, PhonePe, Cards
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (serviceType === "dinein") {
                      toast.error("Dine-in bookings must be prepaid online. Cash is only available at the counter.");
                      return;
                    }
                    setPayMode("cod");
                  }}
                  disabled={serviceType === "dinein"}
                  className={`p-3 rounded-2xl border text-left transition flex items-center gap-2.5 ${
                    serviceType === "dinein"
                      ? "border-stone-200 bg-stone-100 opacity-50 cursor-not-allowed"
                      : payMode === "cod"
                      ? "border-brand-900 bg-brand-50/60 ring-2 ring-brand-900/10"
                      : "border-stone-200 bg-white"
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center ${
                      payMode === "cod" && serviceType !== "dinein"
                        ? "bg-brand-900 text-white"
                        : "bg-stone-100 text-stone-600"
                    }`}
                  >
                    <Banknote size={14} />
                  </div>
                  <div>
                    <div className="font-bold text-xs text-brand-950">
                      {serviceType === "dinein" ? "Pay at Table (Closed)" : "Cash on Delivery"}
                    </div>
                    <div className="text-[10px] text-stone-500">
                      {serviceType === "dinein" ? "Available only at the counter" : "Cash or Counter QR"}
                    </div>
                  </div>
                </button>
              </div>
            </div>

            {/* Irani Royalty Points Redemption Card */}
            {isLoggedIn && (
              <div className="bg-gradient-to-r from-amber-500/10 via-amber-600/10 to-amber-700/10 border border-amber-300/80 p-3 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                    <span className="text-sm">👑</span>
                    <span>Irani Royalty Coins</span>
                    {isFirstFourOrders && (
                      <span className="text-[10px] bg-amber-200/80 text-amber-950 font-bold px-1.5 py-0.2 rounded-md">
                        Order {ordersCompleted + 1} of 4
                      </span>
                    )}
                  </div>
                  <span className="text-xs font-mono font-extrabold text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded-full">
                    {availableCoins} Coins (₹{availableCoins})
                  </span>
                </div>

                {canRedeemCoins ? (
                  <label className="flex items-center gap-2 cursor-pointer pt-1 border-t border-amber-200/60">
                    <input
                      type="checkbox"
                      checked={useRoyaltyCoins}
                      onChange={(e) => setUseRoyaltyCoins(e.target.checked)}
                      className="w-4 h-4 rounded text-brand-900 accent-amber-600 cursor-pointer"
                    />
                    <span className="text-xs text-stone-800 font-medium">
                      Redeem <strong className="font-mono text-brand-950">{maxRedeemableCoins} coins</strong> for <strong className="text-emerald-700 font-bold">₹{maxRedeemableCoins} OFF</strong> this order
                    </span>
                  </label>
                ) : (
                  <div className="text-[11px] text-amber-800/90 pt-0.5 border-t border-amber-200/40">
                    {!meetsMinOrderValue ? (
                      <p>
                        💡 Add items worth <strong className="text-brand-950 font-mono">₹{orderShortfall.toFixed(0)}</strong> more to claim <strong className="text-emerald-800 font-bold">₹25 OFF</strong> with your loyalty coins (Min order ₹250).
                      </p>
                    ) : availableCoins < 25 ? (
                      <p>
                        You have {availableCoins} coins. Earn 1 coin for every ₹100 spent!
                      </p>
                    ) : (
                      <p>
                        Redeem ₹25 on your orders above ₹249.
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Bill Breakdown */}
            <div className="bg-stone-50 p-3.5 rounded-2xl border border-stone-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Item Subtotal</span>
                <span className="font-mono">{money(subtotal)}</span>
              </div>

              {serviceType === "delivery" && (
                <div className="flex justify-between text-stone-600">
                  <span>Delivery Fee</span>
                  <span className="font-mono">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-700 font-bold uppercase">
                        Free
                      </span>
                    ) : (
                      money(deliveryFee)
                    )}
                  </span>
                </div>
              )}

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span>Special Discount</span>
                  <span className="font-mono">-{money(discountAmount)}</span>
                </div>
              )}

              {coinDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span>Royalty Coins Applied ({coinsToRedeem} Coins)</span>
                  <span className="font-mono">-{money(coinDiscount)}</span>
                </div>
              )}

              <div className="pt-2 border-t border-stone-200 flex justify-between font-bold text-sm text-brand-950">
                <span>To Pay</span>
                <span className="font-mono text-base">{money(payableTotal)}</span>
              </div>

              {/* Earn Preview Banner */}
              <div className="pt-2 border-t border-amber-200/80 flex items-center justify-between text-[11px] font-bold text-amber-900 bg-amber-50/70 p-2 rounded-xl">
                <span className="flex items-center gap-1">
                  <span>☕</span>
                  <span>Coins You'll Earn:</span>
                </span>
                <span className="font-mono font-extrabold text-amber-950">
                  +{potentialCoinsEarned} Coins
                </span>
              </div>
            </div>

            {/* Store Closed Warning Banner */}
            {!isOnlineOpen && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-2 text-xs text-red-800 font-medium">
                <AlertCircle size={16} className="text-red-600 flex-shrink-0" />
                <span>
                  {storeNotice || "Online ordering is currently closed by the restaurant. Please check back later!"}
                </span>
              </div>
            )}

            {/* Place Order CTA Button */}
            <button
              type="submit"
              disabled={submitting || !isOnlineOpen}
              className="active-press w-full bg-brand-900 hover:bg-brand-950 disabled:bg-stone-400 text-white py-3.5 px-4 rounded-2xl font-extrabold text-xs uppercase tracking-wider transition shadow-lg flex items-center justify-between disabled:cursor-not-allowed"
            >
              <div className="flex items-center gap-1.5">
                <Sparkles size={14} className="text-amber-400" />
                <span>
                  {!isOnlineOpen
                    ? "Store Currently Closed"
                    : submitting
                    ? "Placing Order…"
                    : payMode === "razorpay"
                    ? "Pay Online & Confirm"
                    : "Confirm Order"}
                </span>
              </div>
              <div className="font-mono font-bold text-sm">
                {submitting ? <Loader2 size={16} className="animate-spin" /> : money(payableTotal)}
              </div>
            </button>
          </form>
        )}
      </div>

      {/* Interactive Location Picker & GPS Map Modal */}
      <LocationPickerModal
        isOpen={locationPickerOpen}
        onClose={() => setLocationPickerOpen(false)}
        initialAddress={deliveryAddress}
        subtotal={subtotal}
        onSelectLocation={(loc) => {
          setDeliveryAddress({
            ...deliveryAddress,
            street: loc.street,
            landmark: [loc.flat_landmark, loc.landmark].filter(Boolean).join(" · "),
            area: loc.area,
            pincode: loc.pincode,
            lat: loc.lat,
            lng: loc.lng,
            label: loc.label,
          });
        }}
      />
    </div>
  );
}
