import React, { useState, useEffect, useRef } from "react";
import {
  X,
  MapPin,
  Crosshair,
  Navigation,
  Home,
  Building2,
  Check,
  Plus,
  Loader2,
  Sparkles,
  Store,
  ChevronRight,
  Info,
} from "lucide-react";
import { STORE_LOCATION, calculateDistanceKm, calculateDeliveryFee } from "../lib/deliveryTerms";
import { useAuth } from "../context/AuthContext";
import { api, errMsg } from "../lib/api";
import { toast } from "sonner";
import L from "leaflet";

// Fix Leaflet's default marker icon paths in bundled environments
const customPinIcon = L.divIcon({
  className: "custom-map-pin",
  html: `
    <div style="position: relative; transform: translate(-50%, -100%);">
      <div style="
        width: 38px;
        height: 38px;
        background: linear-gradient(135deg, #b45309, #78350f);
        border: 2.5px solid #ffffff;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 14px rgba(120, 53, 15, 0.4);
      ">
        <div style="
          width: 14px;
          height: 14px;
          background: #ffffff;
          border-radius: 50%;
          transform: rotate(45deg);
        "></div>
      </div>
      <div style="
        position: absolute;
        bottom: -6px;
        left: 50%;
        transform: translateX(-50%);
        width: 16px;
        height: 6px;
        background: rgba(0, 0, 0, 0.25);
        border-radius: 50%;
        filter: blur(1px);
      "></div>
    </div>
  `,
  iconSize: [38, 38],
  iconAnchor: [19, 38],
});

// Distinct "you are here" marker (Google Maps / Zomato style blue dot),
// separate from the draggable amber delivery pin above.
const currentLocationIcon = L.divIcon({
  className: "current-location-pin",
  html: `
    <div style="position: relative; width: 20px; height: 20px;">
      <div style="
        position: absolute; inset: -6px;
        background: rgba(66, 133, 244, 0.2);
        border-radius: 50%;
      "></div>
      <div style="
        position: absolute; inset: 0;
        background: #4285f4;
        border: 2.5px solid #ffffff;
        border-radius: 50%;
        box-shadow: 0 1px 4px rgba(0,0,0,0.4);
      "></div>
    </div>
  `,
  iconSize: [20, 20],
  iconAnchor: [10, 10],
});

const storePinIcon = L.divIcon({
  className: "store-map-pin",
  html: `
    <div style="position: relative; transform: translate(-50%, -100%);">
      <div style="
        background: #1c1917;
        color: #fef08a;
        font-size: 10px;
        font-weight: 800;
        padding: 4px 8px;
        border-radius: 12px;
        border: 1.5px solid #ca8a04;
        display: flex;
        align-items: center;
        gap: 4px;
        white-space: nowrap;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      ">
        <span>☕</span>
        <span>Hyderabadi Irani (Hotel)</span>
      </div>
    </div>
  `,
  iconSize: [140, 30],
  iconAnchor: [70, 30],
});

export default function LocationPickerModal({
  isOpen,
  onClose,
  initialAddress,
  onSelectLocation,
  subtotal = 0,
}) {
  const { customer, refreshProfile, isLoggedIn } = useAuth();
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const userMarkerRef = useRef(null);
  const currentLocationMarkerRef = useRef(null);
  const [currentGps, setCurrentGps] = useState(null); // { lat, lng } — device's actual GPS fix, if known

  // Active Coordinates & Address details (defaults to Store/Hotel in Godumakunta/Rampally)
  const defaultLat = initialAddress?.lat && initialAddress?.lat !== 17.3850 ? initialAddress.lat : STORE_LOCATION.lat;
  const defaultLng = initialAddress?.lng && initialAddress?.lng !== 78.4867 ? initialAddress.lng : STORE_LOCATION.lng;

  const [lat, setLat] = useState(defaultLat);
  const [lng, setLng] = useState(defaultLng);
  const [addressLine, setAddressLine] = useState(
    initialAddress?.street || "Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta, Secunderabad"
  );
  const [flatNo, setFlatNo] = useState(initialAddress?.flat_landmark || "");
  const [landmark, setLandmark] = useState(initialAddress?.landmark || "");
  const [pincode, setPincode] = useState(initialAddress?.pincode || "501302");
  const [area, setArea] = useState(initialAddress?.area || "Godumakunta");
  const [selectedTag, setSelectedTag] = useState(initialAddress?.label || "Home");
  const [saveToProfile, setSaveToProfile] = useState(false);

  const [locating, setLocating] = useState(false);
  const [geocoding, setGeocoding] = useState(false);
  const [savingAddress, setSavingAddress] = useState(false);
  const [activeTab, setActiveTab] = useState("map"); // "map" | "saved"

  const savedAddresses = customer?.addresses || [];
  const distanceKm = calculateDistanceKm(lat, lng);
  const deliveryTier = calculateDeliveryFee(distanceKm, subtotal);

  // Initialize and tear down Leaflet map
  useEffect(() => {
    if (!isOpen || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const initialLat = lat || STORE_LOCATION.lat;
      const initialLng = lng || STORE_LOCATION.lng;

      const map = L.map(mapContainerRef.current, {
        center: [initialLat, initialLng],
        zoom: 15,
        zoomControl: false,
      });

      // Light, low-clutter basemap (closer to the plain white/gray look of
      // Google Maps used by apps like Zomato, instead of the more colorful
      // "Voyager" style this used before).
      L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
        maxZoom: 19,
      }).addTo(map);

      // Store hub marker
      L.marker([STORE_LOCATION.lat, STORE_LOCATION.lng], { icon: storePinIcon }).addTo(map);

      // 5km delivery radius circle
      L.circle([STORE_LOCATION.lat, STORE_LOCATION.lng], {
        radius: 5000,
        color: "#b45309",
        fillColor: "#fef3c7",
        fillOpacity: 0.1,
        weight: 1.5,
        dashArray: "4, 6",
      }).addTo(map);

      // User Draggable Marker
      const userMarker = L.marker([initialLat, initialLng], {
        icon: customPinIcon,
        draggable: true,
      }).addTo(map);

      userMarker.on("dragend", (e) => {
        const { lat: newLat, lng: newLng } = e.target.getLatLng();
        setLat(newLat);
        setLng(newLng);
        reverseGeocode(newLat, newLng);
      });

      map.on("click", (e) => {
        const { lat: newLat, lng: newLng } = e.latlng;
        setLat(newLat);
        setLng(newLng);
        userMarker.setLatLng([newLat, newLng]);
        reverseGeocode(newLat, newLng);
      });

      mapInstanceRef.current = map;
      userMarkerRef.current = userMarker;
    }

    // Force map resize check once rendered inside modal
    setTimeout(() => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    }, 250);

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        userMarkerRef.current = null;
        currentLocationMarkerRef.current = null;
      }
    };
  }, [isOpen]);

  // Silently grab the device's actual GPS fix once the picker opens (best
  // effort — no toast/error on failure) purely as a reference point, so we
  // can show a distinct "you are here" dot and a "X away from your current
  // location" banner like Zomato's picker, without moving the delivery pin.
  useEffect(() => {
    if (!isOpen || currentGps) return;
    (async () => {
      try {
        let position = null;
        if (window.Capacitor?.isPluginAvailable("Geolocation")) {
          try {
            const { Geolocation } = await import("@capacitor/geolocation");
            position = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 8000 });
          } catch {}
        }
        if (!position && navigator.geolocation) {
          position = await new Promise((resolve, reject) =>
            navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 8000 })
          );
        }
        if (position) {
          setCurrentGps({ lat: position.coords.latitude, lng: position.coords.longitude });
        }
      } catch {
        // No permission / no fix yet — the banner and blue dot simply won't show.
      }
    })();
  }, [isOpen, currentGps]);

  // Place/update the distinct blue "you are here" marker whenever we have a
  // GPS fix and the map is ready.
  useEffect(() => {
    if (!mapInstanceRef.current || !currentGps) return;
    if (currentLocationMarkerRef.current) {
      currentLocationMarkerRef.current.setLatLng([currentGps.lat, currentGps.lng]);
    } else {
      currentLocationMarkerRef.current = L.marker([currentGps.lat, currentGps.lng], {
        icon: currentLocationIcon,
        interactive: false,
        zIndexOffset: -100,
      }).addTo(mapInstanceRef.current);
    }
  }, [currentGps]);

  // Distance between the selected delivery pin and the device's actual GPS
  // fix — this is what Zomato's "X m away from your current location" line
  // is showing, distinct from the pin's distance to the store.
  const distanceFromCurrentKm = currentGps ? calculateDistanceKm(lat, lng, currentGps.lat, currentGps.lng) : null;

  // Update marker position when lat/lng state changes
  useEffect(() => {
    if (userMarkerRef.current && mapInstanceRef.current && lat && lng) {
      userMarkerRef.current.setLatLng([lat, lng]);
      mapInstanceRef.current.panTo([lat, lng], { animate: true, duration: 0.5 });
    }
  }, [lat, lng]);

  // Reverse Geocoding with OpenStreetMap Nominatim
  const reverseGeocode = async (latitude, longitude) => {
    // If within 500m of hotel
    const dist = calculateDistanceKm(latitude, longitude, STORE_LOCATION.lat, STORE_LOCATION.lng);
    if (dist <= 0.3) {
      setAddressLine("Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta, Secunderabad");
      setArea("Godumakunta");
      setPincode("501302");
      return;
    }

    setGeocoding(true);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1`,
        {
          headers: {
            "Accept-Language": "en",
          },
        }
      );
      const data = await res.json();
      if (data && data.address) {
        const addr = data.address;
        const streetPart = [
          addr.house_number,
          addr.building,
          addr.road || addr.pedestrian || addr.footway,
        ]
          .filter(Boolean)
          .join(" ");

        const areaPart = addr.suburb || addr.neighbourhood || addr.residential || addr.village || addr.city_district || "";
        const cityPart = addr.city || addr.town || addr.county || "Secunderabad";
        const pinPart = addr.postcode || "501302";

        const fullStreet = [streetPart, areaPart, cityPart].filter(Boolean).join(", ");

        if (fullStreet) {
          setAddressLine(fullStreet);
        } else if (data.display_name) {
          setAddressLine(data.display_name.split(",").slice(0, 3).join(","));
        }

        if (areaPart) setArea(areaPart);
        if (pinPart) setPincode(pinPart);
      }
    } catch (err) {
      console.warn("[GEOCODE] Reverse lookup notice:", err);
    } finally {
      setGeocoding(false);
    }
  };

  // Quick 1-Tap Snap Pin to Hotel
  const handleSnapToHotel = () => {
    setLat(STORE_LOCATION.lat);
    setLng(STORE_LOCATION.lng);
    setAddressLine("Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta, Secunderabad");
    setArea("Godumakunta");
    setPincode("501302");
    setSelectedTag("Hotel");
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([STORE_LOCATION.lat, STORE_LOCATION.lng], 16, { animate: true });
    }
    toast.success("Pin snapped to Hyderabadi Irani Hotel (0 km)! ☕");
  };

  // Get User Live Location (Capacitor Geolocation or Browser Geolocation)
  const handleDetectLiveLocation = async () => {
    setLocating(true);
    try {
      let position = null;
      if (window.Capacitor?.isPluginAvailable("Geolocation")) {
        try {
          const { Geolocation } = await import("@capacitor/geolocation");
          position = await Geolocation.getCurrentPosition({
            enableHighAccuracy: true,
            timeout: 10000,
          });
        } catch {}
      }

      if (!position) {
        position = await new Promise((resolve, reject) => {
          if (!navigator.geolocation) {
            return reject(new Error("Geolocation is not supported by your browser"));
          }
          navigator.geolocation.getCurrentPosition(
            (pos) => resolve(pos),
            (err) => reject(err),
            { enableHighAccuracy: true, timeout: 10000 }
          );
        });
      }

      const userLat = position.coords.latitude;
      const userLng = position.coords.longitude;
      setCurrentGps({ lat: userLat, lng: userLng });

      const dist = calculateDistanceKm(userLat, userLng, STORE_LOCATION.lat, STORE_LOCATION.lng);
      if (dist <= 0.5) {
        handleSnapToHotel();
        return;
      }

      setLat(userLat);
      setLng(userLng);

      if (mapInstanceRef.current) {
        mapInstanceRef.current.setView([userLat, userLng], 16, { animate: true });
      }

      toast.success("Live GPS Location detected! 📍");
      await reverseGeocode(userLat, userLng);
    } catch (err) {
      toast.info("Using Hotel / Godumakunta location 📍");
      handleSnapToHotel();
    } finally {
      setLocating(false);
    }
  };

  // Select a Saved Address
  const handleSelectSaved = (addr) => {
    if (!addr) return;
    setAddressLine(addr.address || "");
    setFlatNo(addr.flat_landmark || "");
    setLandmark(addr.landmark || "");
    setSelectedTag(addr.label || "Home");
    if (addr.lat && addr.lng) {
      setLat(addr.lat);
      setLng(addr.lng);
      if (mapInstanceRef.current) {
        mapInstanceRef.current.setView([addr.lat, addr.lng], 16);
      }
    }
    toast.success(`Selected ${addr.label || "Saved"} Address! 🏠`);
    setActiveTab("map");
  };

  // Confirm and deliver to this location
  const handleConfirmLocation = async () => {
    const cleanStreet = addressLine.trim();
    if (!cleanStreet || cleanStreet.length < 5) {
      toast.error("Please enter a complete street / building address.");
      return;
    }

    const fullFormatted = [flatNo ? `Flat/House: ${flatNo}` : "", cleanStreet, landmark ? `Near ${landmark}` : "", pincode ? `PIN: ${pincode}` : ""]
      .filter(Boolean)
      .join(", ");

    const locationData = {
      label: selectedTag,
      street: cleanStreet,
      flat_landmark: flatNo.trim(),
      landmark: landmark.trim(),
      area: area.trim(),
      pincode: pincode.trim(),
      full_address: fullFormatted,
      lat: lat || STORE_LOCATION.lat,
      lng: lng || STORE_LOCATION.lng,
      distance_km: distanceKm,
      delivery_fee: deliveryTier.fee,
    };

    if (saveToProfile && isLoggedIn) {
      setSavingAddress(true);
      try {
        await api.post("/customer/addresses", {
          label: selectedTag,
          address: cleanStreet,
          flat_landmark: [flatNo, landmark].filter(Boolean).join(" · "),
          lat: lat || undefined,
          lng: lng || undefined,
          is_default: savedAddresses.length === 0,
        });
        await refreshProfile();
        toast.success("Saved to your profile addresses! 🌟");
      } catch (err) {
        console.warn("[ADDRESS] Error saving address to profile:", errMsg(err));
      } finally {
        setSavingAddress(false);
      }
    }

    if (onSelectLocation) {
      onSelectLocation(locationData);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200 font-sans">
      <div className="w-full max-w-md bg-[#faf8f5] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-stone-200 animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="bg-white px-4 py-3.5 border-b border-stone-200 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-sm">
              <MapPin size={16} />
            </div>
            <div>
              <h2 className="font-bold text-sm text-stone-900 leading-tight">
                Select Delivery Location
              </h2>
              <p className="text-[11px] text-stone-500 font-medium">
                Accurate pin ensures fast & hot delivery
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 text-stone-600 hover:bg-stone-200 flex items-center justify-center transition"
          >
            <X size={16} />
          </button>
        </div>

        {/* Tab Selector (Map / Saved) */}
        {savedAddresses.length > 0 && (
          <div className="bg-white px-4 pt-2 pb-2 border-b border-stone-100 flex gap-2">
            <button
              type="button"
              onClick={() => setActiveTab("map")}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                activeTab === "map"
                  ? "bg-amber-900 text-white shadow-xs"
                  : "bg-stone-100 text-stone-600 hover:bg-stone-200"
              }`}
            >
              <Navigation size={13} />
              <span>Map & GPS Pin</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("saved")}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                activeTab === "saved"
                  ? "bg-amber-900 text-white shadow-xs"
                  : "bg-stone-100 text-stone-600 hover:bg-stone-200"
              }`}
            >
              <Home size={13} />
              <span>Saved Addresses ({savedAddresses.length})</span>
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === "saved" ? (
            /* View: Saved Addresses List */
            <div className="p-4 space-y-2.5">
              <p className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Your Saved Locations
              </p>
              {savedAddresses.map((addr, idx) => (
                <div
                  key={addr.id || idx}
                  onClick={() => handleSelectSaved(addr)}
                  className="p-3 bg-white rounded-2xl border border-stone-200 hover:border-amber-500 hover:shadow-xs transition cursor-pointer flex items-center justify-between gap-3 text-left"
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center flex-shrink-0 mt-0.5">
                      {addr.label?.toLowerCase() === "work" ? (
                        <Building2 size={16} />
                      ) : (
                        <Home size={16} />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-stone-900">
                          {addr.label || "Saved Address"}
                        </span>
                        {addr.is_default && (
                          <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded-full font-bold">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-stone-600 mt-0.5 line-clamp-2">
                        {addr.address}
                      </p>
                      {addr.flat_landmark && (
                        <p className="text-[11px] text-stone-400 mt-0.5 line-clamp-1">
                          {addr.flat_landmark}
                        </p>
                      )}
                    </div>
                  </div>

                  <ChevronRight size={16} className="text-stone-400 flex-shrink-0" />
                </div>
              ))}

              <button
                type="button"
                onClick={() => setActiveTab("map")}
                className="w-full py-2.5 border-2 border-dashed border-stone-300 rounded-2xl text-xs font-bold text-amber-900 hover:bg-amber-50 flex items-center justify-center gap-1.5 transition mt-3"
              >
                <Plus size={14} />
                <span>Set New Location on Map</span>
              </button>
            </div>
          ) : (
            /* View: Interactive Map & Form */
            <div>
              {/* Map Container */}
              <div className="relative w-full h-52 bg-stone-200 border-b border-stone-200">
                <div ref={mapContainerRef} className="w-full h-full" />

                {/* Left Action: At Hotel 1-Tap */}
                <button
                  type="button"
                  onClick={handleSnapToHotel}
                  className="absolute bottom-3 left-3 z-[400] bg-amber-950 text-amber-200 px-2.5 py-1.5 rounded-xl shadow-lg border border-amber-800 text-[11px] font-bold flex items-center gap-1 hover:bg-amber-900 active:scale-95 transition"
                >
                  <Store size={13} className="text-amber-400" />
                  <span>At Hotel (0 km)</span>
                </button>

                {/* Detect GPS Overlay Button */}
                <button
                  type="button"
                  onClick={handleDetectLiveLocation}
                  disabled={locating}
                  className="absolute bottom-3 right-3 z-[400] bg-white text-stone-900 px-3 py-1.5 rounded-xl shadow-lg border border-stone-200 text-xs font-bold flex items-center gap-1.5 hover:bg-stone-50 active:scale-95 transition disabled:opacity-50"
                >
                  <Crosshair size={14} className={`text-amber-600 ${locating ? "animate-spin" : ""}`} />
                  <span>{locating ? "Locating..." : "Use GPS"}</span>
                </button>

                {/* Distance & Delivery Fee Badge */}
                <div className="absolute top-3 left-3 z-[400] bg-stone-900/90 backdrop-blur-xs text-white px-2.5 py-1.5 rounded-xl shadow-md text-[11px] font-medium flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>{distanceKm <= 0.1 ? "At Hotel (0 km)" : `${distanceKm} km away`}</span>
                  <span className="text-stone-400">·</span>
                  <span className="text-amber-300 font-bold">
                    {deliveryTier.isFree ? "Free Delivery 🎉" : `₹${deliveryTier.fee} Fee`}
                  </span>
                </div>
              </div>

              {/* "X away from your current location" banner — like Zomato's
                  picker, shown only once we have a real GPS fix and the
                  selected pin is meaningfully far from it. */}
              {distanceFromCurrentKm !== null && distanceFromCurrentKm > 0.05 && (
                <div className="mx-4 mt-3 p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                  This address is{" "}
                  <strong>
                    {distanceFromCurrentKm < 1
                      ? `${Math.round(distanceFromCurrentKm * 1000)} m`
                      : `${distanceFromCurrentKm} km`}
                  </strong>{" "}
                  away from your current location.
                  <button
                    type="button"
                    onClick={handleDetectLiveLocation}
                    className="block font-bold text-amber-800 underline mt-0.5"
                  >
                    Use current location →
                  </button>
                </div>
              )}

              {/* Address Form Inputs */}
              <div className="p-4 space-y-3 bg-[#faf8f5]">
                {/* Detected Street Address */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[10px] font-bold uppercase text-stone-500">
                      Street / Building / Area *
                    </label>
                    {geocoding && (
                      <span className="text-[10px] text-amber-700 flex items-center gap-1">
                        <Loader2 size={10} className="animate-spin" /> Detecting address...
                      </span>
                    )}
                  </div>
                  <textarea
                    rows={2}
                    value={addressLine}
                    onChange={(e) => setAddressLine(e.target.value)}
                    placeholder="e.g. Plot 38 Chandra Properties, Rampally Main Rd, Godumakunta"
                    className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs text-stone-900 outline-none focus:border-amber-800 transition"
                    required
                  />
                </div>

                {/* House/Flat & Landmark */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1">
                      House / Flat / Floor No.
                    </label>
                    <input
                      type="text"
                      value={flatNo}
                      onChange={(e) => setFlatNo(e.target.value)}
                      placeholder="e.g. Flat 302, 3rd Floor"
                      className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs text-stone-900 outline-none focus:border-amber-800 transition"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1">
                      Nearby Landmark
                    </label>
                    <input
                      type="text"
                      value={landmark}
                      onChange={(e) => setLandmark(e.target.value)}
                      placeholder="e.g. Opp. Bus Stop"
                      className="w-full bg-white border border-stone-300 rounded-xl px-3 py-2 text-xs text-stone-900 outline-none focus:border-amber-800 transition"
                    />
                  </div>
                </div>

                {/* Tag Selection (Home / Work / Other / Hotel) */}
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-500 mb-1.5">
                    Save Address As
                  </label>
                  <div className="flex gap-2">
                    {[
                      { label: "Home", icon: Home },
                      { label: "Work", icon: Building2 },
                      { label: "Hotel", icon: Store },
                      { label: "Other", icon: MapPin },
                    ].map((tag) => {
                      const Icon = tag.icon;
                      const isSel = selectedTag === tag.label;
                      return (
                        <button
                          key={tag.label}
                          type="button"
                          onClick={() => setSelectedTag(tag.label)}
                          className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold border transition flex items-center justify-center gap-1.5 ${
                            isSel
                              ? "bg-amber-900 text-white border-amber-900 shadow-xs"
                              : "bg-white text-stone-700 border-stone-300 hover:border-stone-400"
                          }`}
                        >
                          <Icon size={12} />
                          <span>{tag.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Save to Profile Checkbox (if logged in) */}
                {isLoggedIn && (
                  <label className="flex items-center gap-2 pt-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={saveToProfile}
                      onChange={(e) => setSaveToProfile(e.target.checked)}
                      className="rounded border-stone-300 text-amber-800 focus:ring-amber-800"
                    />
                    <span className="text-xs text-stone-600 font-medium">
                      Save this address to my profile for future orders
                    </span>
                  </label>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer CTA Button */}
        {activeTab === "map" && (
          <div className="p-3.5 bg-white border-t border-stone-200 flex-shrink-0 flex items-center gap-3">
            <button
              type="button"
              onClick={handleConfirmLocation}
              disabled={savingAddress}
              className="w-full bg-amber-900 hover:bg-amber-800 active:scale-[0.99] text-white py-3 rounded-2xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition disabled:opacity-50"
            >
              {savingAddress ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>Saving Location...</span>
                </>
              ) : (
                <>
                  <Check size={16} />
                  <span>Deliver to this Location</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
