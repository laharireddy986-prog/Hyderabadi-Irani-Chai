import React, { useMemo } from "react";
import { Plus, Minus, Star, Flame, MessageSquare } from "lucide-react";
import { money } from "../lib/api";
import { useCart } from "../context/CartContext";

export default function DishCard({ item, onOpenDetail }) {
  const { addItem, getItemQty, lines } = useCart();
  const qty = getItemQty(item.id);
  const isAvailable = item.available !== false;

  const currentLine = lines.find((l) => l.item_id === item.id || l.base_item_id === item.id);
  const hasCustomNotes = Boolean(currentLine?.notes);

  const portionVariants = useMemo(() => {
    if (!item) return [];
    if (item.variants && Array.isArray(item.variants) && item.variants.length >= 2) {
      return item.variants;
    }
    if (item.price_half && item.price_full) {
      const isSingle =
        item.category?.toLowerCase() === "biryani" ||
        item.category?.toLowerCase() === "combo pack";
      const name1 = isSingle ? "Single" : "Half";
      return [
        { name: name1, label: name1, price: Number(item.price_half), is_default: true },
        { name: "Full", label: "Full", price: Number(item.price_full), is_default: false },
      ];
    }
    if (item.description) {
      const m = item.description.match(/\((Single|Half):\s*₹?(\d+)\s*\/\s*Full:\s*₹?(\d+)\)/i);
      if (m) {
        const name1 = m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
        return [
          { name: name1, label: name1, price: Number(m[2]), is_default: true },
          { name: "Full", label: "Full", price: Number(m[3]), is_default: false },
        ];
      }
    }
    return [];
  }, [item]);

  const hasPortions = portionVariants.length >= 2;

  return (
    <div
      className={`bg-white rounded-3xl p-4 border border-stone-200/80 shadow-xs flex gap-3.5 items-center justify-between transition-all ${
        !isAvailable ? "opacity-60 grayscale-[30%]" : "hover:border-stone-300 hover:shadow-sm"
      }`}
    >
      {/* Left Details */}
      <div
        className="flex-1 min-w-0 pr-2 cursor-pointer"
        onClick={() => onOpenDetail && onOpenDetail(item)}
      >
        {/* Veg/Non-Veg Tag & Bestseller badge */}
        <div className="flex items-center gap-2 mb-1.5">
          <span
            className={`w-3.5 h-3.5 rounded border flex items-center justify-center p-0.5 ${
              item.veg
                ? "border-emerald-600 bg-emerald-50"
                : "border-red-600 bg-red-50"
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                item.veg ? "bg-emerald-600" : "bg-red-600"
              }`}
            />
          </span>

          {item.category?.toLowerCase() === "tea" && (
            <span className="text-[10px] font-extrabold uppercase bg-amber-50 text-amber-900 border border-amber-200 px-1.5 py-0.2 rounded-md tracking-wider flex items-center gap-0.5">
              <Flame size={10} className="text-amber-600" /> Irani Special
            </span>
          )}

          {item.category?.toLowerCase() === "biryani" && item.name?.toLowerCase().includes("dum") && (
            <span className="text-[10px] font-extrabold uppercase bg-red-50 text-red-700 border border-red-200 px-1.5 py-0.2 rounded-md tracking-wider flex items-center gap-0.5">
              <Star size={10} className="text-red-600 fill-red-600" /> Handi Dum
            </span>
          )}
        </div>

        {/* Dish Name */}
        <h3 className="font-extrabold text-sm sm:text-base text-stone-900 leading-snug line-clamp-2">
          {item.name}
        </h3>

        {/* Price */}
        {/* Price */}
        <div className="flex items-baseline gap-1.5 mt-1">
          {hasPortions ? (
            <div className="flex items-baseline gap-1">
              <span className="font-extrabold text-base text-stone-900 font-mono">
                ₹{portionVariants[0].price}
              </span>
              <span className="text-xs font-bold text-stone-400 font-mono">
                / ₹{portionVariants[1].price}
              </span>
              <span className="text-[9px] font-extrabold text-red-600 bg-red-50 border border-red-200 px-1 py-0.2 rounded ml-1">
                {portionVariants[0].name}/{portionVariants[1].name}
              </span>
            </div>
          ) : (
            <>
              <span className="font-extrabold text-base text-stone-900 font-mono">
                {money(item.price)}
              </span>
              <span className="text-[10px] text-stone-400 font-normal">
                GST Incl.
              </span>
            </>
          )}
        </div>

        {/* Description */}
        {item.description && (
          <p className="text-xs text-stone-500 mt-1 line-clamp-2 leading-relaxed">
            {item.description}
          </p>
        )}

        {/* Customized Cooking Note Indicator */}
        {hasCustomNotes && (
          <div className="mt-1.5 flex items-center gap-1 text-[11px] font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-lg w-fit">
            <MessageSquare size={11} />
            <span className="truncate max-w-[150px]">{currentLine.notes}</span>
          </div>
        )}
      </div>

      {/* Right Action / Image & Button (Zomato Style) */}
      <div className="relative flex flex-col items-center justify-center flex-shrink-0 w-24">
        {item.image_url ? (
          <div
            className="w-24 h-24 rounded-2xl overflow-hidden mb-[-14px] border border-stone-200 shadow-sm cursor-pointer relative group"
            onClick={() => onOpenDetail && onOpenDetail(item)}
          >
            <img
              src={item.image_url}
              alt={item.name}
              className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              loading="lazy"
            />
          </div>
        ) : (
          <div className="w-24 h-12" />
        )}

        {/* Add / Stepper Button */}
        <div className="relative z-10 w-full px-1">
          {!isAvailable ? (
            <span className="block text-center text-[10px] font-extrabold uppercase text-red-700 bg-red-50 border border-red-200 px-2 py-1 rounded-xl shadow-xs">
              Sold Out
            </span>
          ) : hasPortions ? (
            <button
              type="button"
              onClick={() => onOpenDetail && onOpenDetail(item)}
              className="active-press w-full bg-white hover:bg-red-50 text-red-600 border-2 border-red-500 py-1.5 px-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1 transition shadow-md"
            >
              {qty > 0 ? (
                <span className="font-mono text-xs font-black">{qty} in cart +</span>
              ) : (
                <>
                  <Plus size={13} className="stroke-[3]" />
                  <span>ADD</span>
                </>
              )}
            </button>
          ) : qty > 0 ? (
            <div className="flex items-center justify-between bg-white text-red-600 rounded-xl border-2 border-red-500 px-1 py-1 w-full shadow-md">
              <button
                type="button"
                onClick={() => addItem(item, -1)}
                className="active-press w-6 h-6 flex items-center justify-center hover:bg-red-50 rounded-lg transition"
                title="Decrease quantity"
              >
                <Minus size={13} className="stroke-[3]" />
              </button>
              <span className="text-xs font-black font-mono">{qty}</span>
              <button
                type="button"
                onClick={() => addItem(item, 1)}
                className="active-press w-6 h-6 flex items-center justify-center hover:bg-red-50 rounded-lg transition"
                title="Increase quantity"
              >
                <Plus size={13} className="stroke-[3]" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => addItem(item, 1)}
              className="active-press w-full bg-white hover:bg-red-50 text-red-600 border-2 border-red-500 py-1.5 px-2 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1 transition shadow-md"
            >
              <Plus size={13} className="stroke-[3]" />
              <span>ADD</span>
            </button>
          )}

          {/* Customizable subtext */}
          {isAvailable && (
            <span
              className="block text-center text-[9px] text-stone-400 font-bold mt-1 cursor-pointer hover:text-red-500"
              onClick={() => onOpenDetail && onOpenDetail(item)}
            >
              {hasPortions ? "options available" : "customisable"}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
