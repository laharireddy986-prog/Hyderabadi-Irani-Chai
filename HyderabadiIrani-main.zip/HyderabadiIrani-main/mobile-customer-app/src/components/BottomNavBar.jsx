import React from "react";
import { Home, Search, ShoppingBag, User } from "lucide-react";
import { useCart } from "../context/CartContext";

export default function BottomNavBar({ activeTab, onSelectTab, onOpenCart }) {
  const { itemCount } = useCart();

  const TABS = [
    { key: "menu", label: "Menu", icon: Home },
    { key: "search", label: "Search", icon: Search },
    { key: "cart", label: "Cart", icon: ShoppingBag, badge: itemCount },
    { key: "account", label: "Account", icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-lg border-t border-stone-200/80 px-3 pt-2 pb-safe shadow-lg">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;

          return (
            <button
              key={tab.key}
              type="button"
              onClick={() => {
                if (tab.key === "cart") onOpenCart();
                else onSelectTab(tab.key);
              }}
              className={`relative flex flex-col items-center justify-center flex-1 py-1 transition-all ${
                isActive ? "text-brand-900 font-bold" : "text-stone-400 hover:text-stone-600 font-medium"
              }`}
            >
              <div className="relative">
                <Icon size={20} className={isActive ? "stroke-[2.5]" : "stroke-[1.8]"} />
                {typeof tab.badge === "number" && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 bg-red-600 text-white text-[10px] font-extrabold rounded-full w-4 h-4 flex items-center justify-center border-2 border-white shadow">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-1 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
