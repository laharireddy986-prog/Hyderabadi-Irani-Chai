import React, { useState } from "react";
import { X, QrCode, Check, Utensils } from "lucide-react";
import { useCart } from "../context/CartContext";
import { toast } from "sonner";

export default function TableQrScannerModal({ isOpen, onClose }) {
  const { tableNo, setTableNo, setServiceType } = useCart();
  const [selectedTable, setSelectedTable] = useState(tableNo || "T-01");

  if (!isOpen) return null;

  const handleConfirm = () => {
    setTableNo(selectedTable);
    setServiceType("dinein");
    toast.success(`Dine-in activated for Table ${selectedTable} 🍽️`);
    onClose();
  };

  const TABLES = Array.from({ length: 50 }, (_, i) => `T-${String(i + 1).padStart(2, "0")}`);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[85vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <QrCode size={18} className="text-brand-700" />
            <h3 className="font-serif font-bold text-base text-brand-950">
              Select Your Table
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-200 text-stone-700 flex items-center justify-center hover:bg-stone-300 transition"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          <p className="text-xs text-stone-600 leading-relaxed">
            Please tap your seated table number below to send your orders directly to the live kitchen screen.
          </p>

          <div className="grid grid-cols-5 gap-2 max-h-60 overflow-y-auto p-1">
            {TABLES.map((tbl) => (
              <button
                key={tbl}
                type="button"
                onClick={() => setSelectedTable(tbl)}
                className={`py-2 rounded-xl text-xs font-mono font-bold transition border ${
                  selectedTable === tbl
                    ? "bg-brand-900 text-white border-brand-950 shadow-md scale-105"
                    : "bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100"
                }`}
              >
                {tbl}
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 pb-safe">
          <button
            type="button"
            onClick={handleConfirm}
            className="active-press w-full bg-brand-900 text-white py-3 rounded-2xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-lg"
          >
            <Check size={14} />
            <span>Confirm Table {selectedTable}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
