import React from "react";
import { SlidersHorizontal, Flame, ChevronDown, Check } from "lucide-react";

// Curated high-resolution food images matching Zomato's exact category visual standards
const CATEGORY_IMAGES = {
  All: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=240&auto=format&fit=crop&q=80",
  Biryani: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=240&auto=format&fit=crop&q=80",
  Tea: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/hyderabadi_irani_chai_authentic.webp",
  Chai: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/hyderabadi_irani_chai_authentic.webp",
  Combos: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/combo_chicken_dum_biryani_jumbo.webp",
  Tiffins: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/masala_dosa.webp",
  Breakfast: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/idly.webp",
  Snacks: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/onion_samosa.webp",
  Sweets: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/apricot_delight.webp",
  Chinese: "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=240&auto=format&fit=crop&q=80",
  Noodles: "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=240&auto=format&fit=crop&q=80",
  Burger: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=240&auto=format&fit=crop&q=80",
  Starters: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=240&auto=format&fit=crop&q=80",
  "Tandoori Kebabs": "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=240&auto=format&fit=crop&q=80",
  "Sea Food": "https://images.unsplash.com/photo-1535924299324-ea8b1a37cce1?w=240&auto=format&fit=crop&q=80",
  Fish: "https://images.unsplash.com/photo-1535924299324-ea8b1a37cce1?w=240&auto=format&fit=crop&q=80",
  Soups: "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=240&auto=format&fit=crop&q=80",
  Currys: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=240&auto=format&fit=crop&q=80",
  Curries: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=240&auto=format&fit=crop&q=80",
  Rotis: "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=240&auto=format&fit=crop&q=80",
  Breads: "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=240&auto=format&fit=crop&q=80",
  Shawarma: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=240&auto=format&fit=crop&q=80",
  "Fried Rice": "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=240&auto=format&fit=crop&q=80",
  Bakery: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=240&auto=format&fit=crop&q=80",
  Beverages: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=240&auto=format&fit=crop&q=80",
  Desserts: "https://storage.googleapis.com/hyderabadi-irani-menu-assets-metal-density-504117-k9/menu/apricot_delight.webp",
};

const DEFAULT_CATEGORY_IMG =
  "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=240&auto=format&fit=crop&q=80";

export default function CategoryStories({
  categories = [],
  items = [],
  selectedCategory,
  onSelectCategory,
  isVegOnly,
  onToggleVegOnly,
  itemsCountMap = {},
  selectedQuickFilter = "",
  onSelectQuickFilter,
}) {
  const allCategories = ["All", ...categories];

  // Dynamically map real dish photos uploaded in database for each category
  const categoryDishMap = React.useMemo(() => {
    const map = {};
    if (Array.isArray(items)) {
      for (const it of items) {
        if (it?.category && it?.image_url && !map[it.category]) {
          map[it.category] = it.image_url;
        }
      }
    }
    return map;
  }, [items]);

  return (
    <div className="py-2.5 select-none bg-white border-b border-stone-200/80 shadow-2xs">
      {/* Category Horizontal Circular Image Carousel (Exact Zomato Style from Image 4) */}
      <div className="flex items-start gap-4 px-4 overflow-x-auto no-scrollbar pt-1 pb-2">
        {/* Special Promo Card on Far Left (Image 4: "MEALS UNDER ₹250") */}
        <button
          type="button"
          onClick={() => {
            if (onSelectQuickFilter) {
              onSelectQuickFilter(selectedQuickFilter === "under250" ? "" : "under250");
            }
          }}
          className={`flex flex-col items-center flex-shrink-0 group focus:outline-none transition active-press ${
            selectedQuickFilter === "under250" ? "scale-105" : ""
          }`}
          style={{ width: "72px" }}
        >
          <div
            className={`w-[66px] h-[66px] rounded-2xl p-1.5 flex flex-col justify-between items-center text-center shadow-xs transition-all duration-200 ${
              selectedQuickFilter === "under250"
                ? "bg-gradient-to-b from-red-500 to-red-600 text-white ring-2 ring-red-500 ring-offset-2"
                : "bg-gradient-to-b from-red-50 to-amber-50 text-red-900 border border-red-200 hover:border-red-300"
            }`}
          >
            <span className="text-[8px] font-extrabold tracking-tighter uppercase leading-tight">
              FOOD UNDER
            </span>
            <span className="text-sm font-black font-mono leading-none">
              ₹250
            </span>
            <span
              className={`text-[8px] font-bold px-1.5 py-0.2 rounded-full leading-tight ${
                selectedQuickFilter === "under250"
                  ? "bg-white text-red-600 font-extrabold"
                  : "bg-red-500 text-white font-bold"
              }`}
            >
              Explore &gt;
            </span>
          </div>

          <span
            className={`text-xs mt-1.5 text-center font-bold tracking-tight line-clamp-1 transition ${
              selectedQuickFilter === "under250" ? "text-red-600 font-black" : "text-stone-700"
            }`}
          >
            Pocket Deals
          </span>

          <div
            className={`w-6 h-0.5 mt-1 rounded-full transition-all duration-300 ${
              selectedQuickFilter === "under250" ? "bg-red-500 scale-100" : "bg-transparent scale-0"
            }`}
          />
        </button>

        {/* Regular Food Category Items with Real Photography Dishes */}
        {allCategories.map((cat) => {
          const isSelected =
            selectedQuickFilter !== "under250" &&
            selectedCategory.toLowerCase() === cat.toLowerCase();
          const imgUrl = categoryDishMap[cat] || CATEGORY_IMAGES[cat] || DEFAULT_CATEGORY_IMG;
          const count = itemsCountMap[cat];

          return (
            <button
              key={cat}
              type="button"
              onClick={() => {
                onSelectCategory(cat);
              }}
              className="flex flex-col items-center flex-shrink-0 group focus:outline-none transition active-press"
              style={{ width: "68px" }}
            >
              {/* Circular Dish Image with Ring & Badge */}
              <div
                className={`relative w-[66px] h-[66px] rounded-full p-0.5 transition-all duration-300 ${
                  isSelected
                    ? "ring-2 ring-red-500 ring-offset-2 scale-105 shadow-md shadow-red-500/20"
                    : "ring-1 ring-stone-200/80 group-hover:scale-105 shadow-xs"
                }`}
              >
                <div className="w-full h-full rounded-full overflow-hidden bg-stone-100">
                  <img
                    src={imgUrl}
                    alt={cat}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    loading="lazy"
                    onError={(e) => {
                      e.target.src = DEFAULT_CATEGORY_IMG;
                    }}
                  />
                </div>

                {/* Count Pill */}
                {typeof count === "number" && count > 0 && (
                  <span
                    className={`absolute -bottom-0.5 right-0 text-[9px] font-extrabold px-1.5 py-0.2 rounded-full border shadow-2xs ${
                      isSelected
                        ? "bg-red-500 text-white border-white"
                        : "bg-white text-stone-700 border-stone-200"
                    }`}
                  >
                    {count}
                  </span>
                )}
              </div>

              {/* Category Name */}
              <span
                className={`text-xs mt-1.5 text-center font-bold tracking-tight line-clamp-1 capitalize transition ${
                  isSelected ? "text-red-600 font-black" : "text-stone-700 group-hover:text-stone-900"
                }`}
              >
                {cat === "Tea" ? "Chai" : cat}
              </span>

              {/* Active Indicator Underline (Zomato style from Image 4) */}
              <div
                className={`w-6 h-0.5 mt-1 rounded-full transition-all duration-300 ${
                  isSelected ? "bg-red-500 scale-100" : "bg-transparent scale-0"
                }`}
              />
            </button>
          );
        })}
      </div>

      {/* Quick Filter Pills Row (Exact Zomato Style from Image 4) */}
      <div className="flex items-center gap-2 px-4 pt-1 overflow-x-auto no-scrollbar">
        {/* Filters Dropdown Pill */}
        <button
          type="button"
          onClick={() => {
            if (onSelectQuickFilter) {
              onSelectQuickFilter(selectedQuickFilter ? "" : "bestseller");
            }
          }}
          className={`active-press flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition flex-shrink-0 shadow-2xs ${
            selectedQuickFilter
              ? "bg-red-50 text-red-600 border-red-300"
              : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
          }`}
        >
          <SlidersHorizontal size={13} className="text-stone-600" />
          <span>Filters</span>
          <ChevronDown size={13} className="text-stone-400" />
        </button>

        {/* Under ₹200 */}
        <button
          type="button"
          onClick={() =>
            onSelectQuickFilter &&
            onSelectQuickFilter(selectedQuickFilter === "under200" ? "" : "under200")
          }
          className={`active-press px-3 py-1.5 rounded-xl border text-xs font-bold transition flex-shrink-0 shadow-2xs ${
            selectedQuickFilter === "under200"
              ? "bg-red-50 text-red-700 border-red-400 font-extrabold"
              : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
          }`}
        >
          Under ₹200
        </button>

        {/* Pure Veg Pill with Green Indicator */}
        <button
          type="button"
          onClick={onToggleVegOnly}
          className={`active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-extrabold transition flex-shrink-0 shadow-2xs ${
            isVegOnly
              ? "bg-emerald-50 text-emerald-800 border-emerald-500 shadow-emerald-100"
              : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
          }`}
        >
          <span
            className={`w-3.5 h-3.5 rounded border flex items-center justify-center p-0.5 ${
              isVegOnly ? "border-emerald-600 bg-emerald-600" : "border-emerald-600 bg-emerald-50"
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isVegOnly ? "bg-white" : "bg-emerald-600"
              }`}
            />
          </span>
          <span>Pure Veg</span>
        </button>

        {/* Bestseller */}
        <button
          type="button"
          onClick={() =>
            onSelectQuickFilter &&
            onSelectQuickFilter(selectedQuickFilter === "bestseller" ? "" : "bestseller")
          }
          className={`active-press flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition flex-shrink-0 shadow-2xs ${
            selectedQuickFilter === "bestseller"
              ? "bg-amber-50 text-amber-900 border-amber-400 font-extrabold"
              : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
          }`}
        >
          <Flame size={13} className="text-amber-500 fill-amber-400" />
          <span>Bestseller</span>
        </button>

        {/* Spicy */}
        <button
          type="button"
          onClick={() =>
            onSelectQuickFilter &&
            onSelectQuickFilter(selectedQuickFilter === "spicy" ? "" : "spicy")
          }
          className={`active-press flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition flex-shrink-0 shadow-2xs ${
            selectedQuickFilter === "spicy"
              ? "bg-red-50 text-red-700 border-red-400 font-extrabold"
              : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
          }`}
        >
          <span>🌶️ Spicy</span>
        </button>
      </div>
    </div>
  );
}
