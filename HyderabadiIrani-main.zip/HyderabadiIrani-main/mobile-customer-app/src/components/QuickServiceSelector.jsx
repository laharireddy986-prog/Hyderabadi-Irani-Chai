import React from "react";
import { Bike, Utensils, ShoppingBag } from "lucide-react";
import { useCart } from "../context/CartContext";

export default function QuickServiceSelector({ onOpenTableScanner }) {
  const { serviceType, setServiceType, tableNo } = useCart();

  const handleSelect = (type) => {
    setServiceType(type);
    if (type === "dinein" && !tableNo && onOpenTableScanner) {
      onOpenTableScanner();
    }
  };

  return (
    <div className="px-4 py-2">
      <div className="grid grid-cols-3 gap-2 bg-stone-100/90 p-1.5 rounded-2xl border border-stone-200/80 shadow-inner">
        {/* Delivery */}
        <button
          type="button"
          onClick={() => handleSelect("delivery")}
          className={`active-press py-2.5 px-2 rounded-xl flex flex-col items-center justify-center transition-all ${
            serviceType === "delivery"
              ? "bg-white text-brand-900 shadow-md border border-brand-200/60 font-bold scale-[1.02]"
              : "text-stone-600 hover:text-stone-900 font-medium"
          }`}
        >
          <Bike
            size={18}
            className={serviceType === "delivery" ? "text-brand-700" : "text-stone-400"}
          />
          <span className="text-xs mt-1 leading-tight">Delivery</span>
          <span className="text-[9px] text-stone-400 font-normal">To Doorstep</span>
        </button>

        {/* Dine-in */}
        <button
          type="button"
          onClick={() => handleSelect("dinein")}
          className={`active-press py-2.5 px-2 rounded-xl flex flex-col items-center justify-center transition-all ${
            serviceType === "dinein"
              ? "bg-white text-brand-900 shadow-md border border-brand-200/60 font-bold scale-[1.02]"
              : "text-stone-600 hover:text-stone-900 font-medium"
          }`}
        >
          <Utensils
            size={18}
            className={serviceType === "dinein" ? "text-brand-700" : "text-stone-400"}
          />
          <span className="text-xs mt-1 leading-tight">
            {tableNo ? `Table ${tableNo}` : "Dine-In"}
          </span>
          <span className="text-[9px] text-stone-400 font-normal">Table QR</span>
        </button>

        {/* Takeaway */}
        <button
          type="button"
          onClick={() => handleSelect("takeaway")}
          className={`active-press py-2.5 px-2 rounded-xl flex flex-col items-center justify-center transition-all ${
            serviceType === "takeaway"
              ? "bg-white text-brand-900 shadow-md border border-brand-200/60 font-bold scale-[1.02]"
              : "text-stone-600 hover:text-stone-900 font-medium"
          }`}
        >
          <ShoppingBag
            size={18}
            className={serviceType === "takeaway" ? "text-brand-700" : "text-stone-400"}
          />
          <span className="text-xs mt-1 leading-tight">Takeaway</span>
          <span className="text-[9px] text-stone-400 font-normal">Self Pickup</span>
        </button>
      </div>
    </div>
  );
}
