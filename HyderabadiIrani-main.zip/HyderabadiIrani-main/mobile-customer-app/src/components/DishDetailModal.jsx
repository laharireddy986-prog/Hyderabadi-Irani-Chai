import React, { useState, useEffect, useMemo } from "react";
import {
  X,
  Plus,
  Minus,
  Flame,
  Bookmark,
  Share2,
  Sparkles,
} from "lucide-react";
import { money } from "../lib/api";
import { useCart } from "../context/CartContext";
import { toast } from "sonner";
import { getDishPairings } from "../lib/pairings";
import PairingRecommendationsShelf from "./PairingRecommendationsShelf";

// Zomato-style quick cooking request chips (from Image 3)
const QUICK_COOKING_REQUESTS = [
  { id: "less_spicy", label: "Less Spicy" },
  { id: "non_spicy", label: "Non spicy" },
  { id: "mild_spicy", label: "Mild spicy" },
  { id: "extra_spicy", label: "Extra spicy" },
  { id: "no_onion_garlic", label: "No Onion / Garlic" },
  { id: "extra_salan", label: "Extra Salan / Gravy" },
  { id: "extra_raita", label: "Extra Raita" },
  { id: "extra_butter", label: "Extra Maska / Butter" },
];

export default function DishDetailModal({ item, onClose, allItems = [], onSelectDish }) {
  const { addItem, getItemQty } = useCart();
  const [notes, setNotes] = useState("");
  const [selectedChips, setSelectedChips] = useState([]);
  const [localQty, setLocalQty] = useState(1);
  const [isSaved, setIsSaved] = useState(false);

  // Compute pairing recommendations for current dish
  const pairings = useMemo(() => {
    return getDishPairings(item, allItems, 6);
  }, [item, allItems]);

  // Robust portion variants resolver (from variants array, price_half/full, or description)
  const portionVariants = useMemo(() => {
    if (!item) return [];
    if (item.variants && Array.isArray(item.variants) && item.variants.length >= 2) {
      return item.variants;
    }
    if (item.price_half && item.price_full) {
      const isSingle =
        item.category?.toLowerCase() === "biryani" ||
        item.category?.toLowerCase() === "combo pack";
      const name1 = isSingle ? "Single" : "Half";
      return [
        { name: name1, label: name1, price: Number(item.price_half), is_default: true },
        { name: "Full", label: "Full", price: Number(item.price_full), is_default: false },
      ];
    }
    if (item.description) {
      const m = item.description.match(/\((Single|Half):\s*₹?(\d+)\s*\/\s*Full:\s*₹?(\d+)\)/i);
      if (m) {
        const name1 = m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
        return [
          { name: name1, label: name1, price: Number(m[2]), is_default: true },
          { name: "Full", label: "Full", price: Number(m[3]), is_default: false },
        ];
      }
    }
    return [];
  }, [item]);

  const hasPortions = portionVariants.length >= 2;
  const [selectedVariant, setSelectedVariant] = useState(
    portionVariants.length >= 2 ? portionVariants[0] : null
  );

  useEffect(() => {
    if (item) {
      if (portionVariants.length >= 2) {
        setSelectedVariant(portionVariants[0]);
      } else {
        setSelectedVariant(null);
      }
      setLocalQty(1);
      setNotes("");
      setSelectedChips([]);
    }
  }, [item?.id, item?.name, portionVariants]);

  if (!item) return null;

  const currentCartQty = getItemQty(item.id);
  const isAvailable = item.available !== false;

  // Toggle quick chip and sync with notes textarea
  const handleToggleChip = (chipLabel) => {
    let updatedChips;
    if (selectedChips.includes(chipLabel)) {
      updatedChips = selectedChips.filter((c) => c !== chipLabel);
    } else {
      updatedChips = [...selectedChips, chipLabel];
    }
    setSelectedChips(updatedChips);

    if (updatedChips.length > 0) {
      setNotes(updatedChips.join(", "));
    } else {
      setNotes("");
    }
  };

  const handleNotesChange = (e) => {
    const val = e.target.value.slice(0, 100);
    setNotes(val);
    setSelectedChips([]);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: item.name,
          text: `Order ${item.name} from Hyderabadi Irani!`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      toast.success("Dish link copied to clipboard! 📋");
    }
  };

  const handleAdd = () => {
    addItem(item, localQty, notes, selectedVariant);
    const variantTag = selectedVariant ? ` (${selectedVariant.name})` : "";
    toast.success(`Added ${localQty}x ${item.name}${variantTag} to cart! 🛒`);
    onClose();
  };

  // High-res hero image fallback
  const heroImage =
    item.image_url ||
    (item.category?.toLowerCase() === "biryani"
      ? "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=80"
      : item.category?.toLowerCase() === "tea" || item.category?.toLowerCase() === "chai"
      ? "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80"
      : "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80");

  const portionDescription =
    item.description ||
    (item.category?.toLowerCase() === "biryani"
      ? "(Serves 1-2) Juicy chicken marinated in yogurt, fresh herbs, and special spices, layered with aromatic basmati rice and slow- cooked on dum for that authentic Hyderabadi taste. Served hot with boiled egg, raita and salan."
      : item.category?.toLowerCase() === "tea" || item.category?.toLowerCase() === "chai"
      ? "Brewed authentic Hyderabadi Irani Chai with rich condensed milk, infused with aromatic cardamom and saffron notes. Best paired with crispy Osmania Biscuits."
      : `(Serves 1-2) Freshly prepared delicious ${item.name} made with premium ingredients and traditional Nizami spices.`);

  const currentUnitPrice = selectedVariant
    ? Number(selectedVariant.price) || 0
    : Number(item.price) || 0;
  const totalPrice = currentUnitPrice * localQty;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      {/* Modal Card (Zomato Style from Image 3) */}
      <div className="bg-[#f8f9fb] w-full max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col animate-in slide-in-from-bottom duration-300">
        {/* Hero Image Section with Dark Close X & Actions */}
        <div className="relative w-full h-52 sm:h-60 bg-stone-900 flex-shrink-0">
          <img
            src={heroImage}
            alt={item.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/25" />

          {/* Close 'X' Button on Top Center / Left */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 left-4 w-8 h-8 rounded-full bg-black/70 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/90 transition active-press shadow-md z-10"
          >
            <X size={17} />
          </button>

          {/* Share & Bookmark Actions */}
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              type="button"
              onClick={() => {
                setIsSaved(!isSaved);
                toast.success(
                  isSaved ? "Removed from Favorites" : "Saved to Favorites ❤️"
                );
              }}
              className={`w-8 h-8 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center transition active-press shadow-md ${
                isSaved ? "text-red-500" : "text-white"
              }`}
            >
              <Bookmark size={15} className={isSaved ? "fill-red-500" : ""} />
            </button>
            <button
              type="button"
              onClick={handleShare}
              className="w-8 h-8 rounded-full bg-black/70 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/90 transition active-press shadow-md"
            >
              <Share2 size={15} />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 space-y-3.5 overflow-y-auto flex-1 bg-[#f8f9fb]">
          {/* Main Dish Details Card (White Box) */}
          <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-2xs space-y-2">
            {/* Veg / Non-Veg Emblem */}
            <div className="flex items-center gap-2">
              <span
                className={`w-4 h-4 rounded border flex items-center justify-center p-0.5 ${
                  item.veg
                    ? "border-emerald-600 bg-emerald-50"
                    : "border-red-600 bg-red-50"
                }`}
              >
                {item.veg ? (
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                ) : (
                  <span
                    className="w-0 h-0 border-l-[3.5px] border-l-transparent border-r-[3.5px] border-r-transparent border-b-[6px] border-b-red-600"
                  />
                )}
              </span>
              <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                {item.category}
              </span>
            </div>

            {/* Dish Title */}
            <h2 className="font-sans text-lg sm:text-xl font-black text-stone-900 leading-snug">
              {item.name}
            </h2>

            {/* Highly Reordered Green Status Tag (Exact Image 3 style) */}
            <div className="flex items-center gap-1.5 pt-0.5">
              <span className="w-6 h-1.5 rounded-full bg-emerald-600" />
              <span className="text-xs font-bold text-stone-700">
                Highly reordered
              </span>
            </div>

            {/* Portion / Description */}
            <p className="text-xs text-stone-600 leading-relaxed font-normal pt-1">
              {portionDescription}
            </p>
          </div>

          {/* Portion Size Selection Card (Swiggy / Zomato Style) */}
          {hasPortions && (
            <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-sans text-sm font-extrabold text-stone-900">
                  Select Portion Size
                </h3>
                <span className="text-[10px] font-extrabold text-red-600 bg-red-50 px-2 py-0.5 rounded-full border border-red-200 uppercase tracking-wider">
                  REQUIRED
                </span>
              </div>

              <div className="space-y-2">
                {portionVariants.map((v) => {
                  const isSelected = selectedVariant?.name === v.name;
                  return (
                    <label
                      key={v.name}
                      onClick={() => setSelectedVariant(v)}
                      className={`flex items-center justify-between p-3 rounded-xl border-2 transition cursor-pointer active-press ${
                        isSelected
                          ? "border-red-500 bg-red-50/40 shadow-2xs"
                          : "border-stone-200 bg-stone-50/40 hover:bg-stone-100/50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition ${
                            isSelected
                              ? "border-red-500 bg-red-500"
                              : "border-stone-300 bg-white"
                          }`}
                        >
                          {isSelected && (
                            <span className="w-2 h-2 rounded-full bg-white" />
                          )}
                        </div>
                        <div>
                          <p className="font-bold text-sm text-stone-900 leading-none">
                            {v.name} Portion
                          </p>
                          <p className="text-[11px] text-stone-500 mt-0.5">
                            {v.name === "Single"
                              ? "Standard 1 person serving"
                              : v.name === "Half"
                              ? "Good for 1-2 persons"
                              : "Generous serving for 2-3 persons"}
                          </p>
                        </div>
                      </div>
                      <span className="font-mono font-black text-sm text-stone-900">
                        {money(v.price)}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add a Cooking Request Card (Exact Image 3 Style) */}
          <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-2xs space-y-3">
            <div>
              <h3 className="font-sans text-sm font-extrabold text-stone-900">
                Add a cooking request (optional)
              </h3>
              <p className="text-[11px] text-stone-500 mt-1 leading-snug">
                The restaurant will try its best to fulfil your requests. However, refunds or cancellations related to such requests won't be possible.
              </p>
            </div>

            {/* Cooking Request Textarea */}
            <div className="relative">
              <textarea
                rows={2}
                value={notes}
                onChange={handleNotesChange}
                placeholder="e.g. Don't make it too spicy"
                className="w-full bg-[#f4f5f8] border border-stone-200 rounded-xl p-3 text-xs text-stone-800 outline-none focus:border-red-500 focus:bg-white transition resize-none placeholder:text-stone-400 font-medium"
              />
              <span className="absolute bottom-2.5 right-3 text-[10px] font-bold text-stone-400 font-mono">
                {100 - notes.length}
              </span>
            </div>

            {/* Quick Request Chips (Image 3 Style: Less Spicy, Non spicy, Mild spicy...) */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-0.5">
              {QUICK_COOKING_REQUESTS.map((chip) => {
                const isSelected = selectedChips.includes(chip.label);
                return (
                  <button
                    key={chip.id}
                    type="button"
                    onClick={() => handleToggleChip(chip.label)}
                    className={`active-press px-3 py-1.5 rounded-full border text-xs font-bold transition flex-shrink-0 ${
                      isSelected
                        ? "bg-red-500 text-white border-red-500 shadow-2xs"
                        : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
                    }`}
                  >
                    {chip.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* "You will love pairing it with" Zomato-Style Cross-sell Shelf */}
          {pairings.length > 0 && (
            <PairingRecommendationsShelf
              pairings={pairings}
              title="You will love pairing it with"
              subtitle="Frequently ordered together"
              onSelectDish={(dish) => {
                if (onSelectDish) onSelectDish(dish);
              }}
            />
          )}
        </div>

        {/* Sticky Bottom Action Bar (Zomato Style: Stepper + Red Add item ₹389 Button) */}
        <div className="p-3 bg-white border-t border-stone-200/80 flex items-center gap-3 pb-safe shadow-lg">
          {/* Stepper [- 1 +] */}
          <div className="flex items-center justify-between bg-white border border-red-200 rounded-xl p-1 w-24 sm:w-28 flex-shrink-0 shadow-2xs">
            <button
              type="button"
              disabled={localQty <= 1}
              onClick={() => setLocalQty((q) => Math.max(1, q - 1))}
              className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-red-600 disabled:opacity-30 active-press hover:bg-red-50 transition"
            >
              <Minus size={15} className="stroke-[2.5]" />
            </button>
            <span className="font-mono font-black text-sm text-stone-900 w-6 text-center">
              {localQty}
            </span>
            <button
              type="button"
              onClick={() => setLocalQty((q) => q + 1)}
              className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-red-600 active-press hover:bg-red-50 transition"
            >
              <Plus size={15} className="stroke-[2.5]" />
            </button>
          </div>

          {/* Add item Button */}
          <button
            type="button"
            disabled={!isAvailable}
            onClick={handleAdd}
            className="active-press flex-1 bg-[#EB3A44] hover:bg-red-600 text-white py-3 px-4 rounded-xl font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-md shadow-red-500/20 transition disabled:opacity-50"
          >
            <span>{isAvailable ? `Add item ${money(totalPrice)}` : "Sold Out"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
