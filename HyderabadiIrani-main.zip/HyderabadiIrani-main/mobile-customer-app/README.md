# 📱 Hyderabadi Irani - Customer Android Mobile App

SaaS-grade native mobile customer ordering application built for **Hyderabadi Irani Food Court**.

---

## 🌟 Key Features Implemented

1. **Slideable Top Hero Presentation**:
   - Auto-sliding and swipeable promo cards showcasing signature Biryani, Irani Chai, and combo deals.
2. **1-Touch Service Mode Switcher**:
   - `🛵 Delivery` (Doorstep address + GPS)
   - `🍽️ Table Dine-In` (Quick table picker `T-01` to `T-50` with direct kitchen dispatch)
   - `🥡 Takeaway` (Skip counter queue)
3. **Visual Category Catalog**:
   - Story-style category chips (`Tea`, `Biryani`, `Starters`, `Tandoori Kebabs`, `Currys`, `Rotis`, `Shawarma`, `Snacks`, `Fried Rice`, `Noodles`).
   - Pure Veg filter toggle switch.
4. **Dish Cards with Quick Controls**:
   - Veg/Non-Veg tag, ratings, pricing, and live In-Stock / Out-of-Stock status.
   - 1-click `+ ADD` and `- 1 +` interactive quantity stepper.
   - Special cooking notes input ("Less spicy", "Extra crispy", etc.).
5. **Floating Bottom Cart & Checkout Drawer**:
   - Persistent summary bar with item count, subtotal, and total amount.
   - Address picker, table selector, and customer mobile number prefill.
   - **Payment Modes**: Razorpay Online (UPI, GPay, PhonePe, Cards) & Cash on Delivery (COD).
6. **Live Animated Order Tracking**:
   - Real-time status timeline: `Order Received` ➔ `Cooking Fresh` ➔ `Out for Delivery / Table Serving` ➔ `Delivered`.
   - Direct 1-tap Restaurant Call (`8331807704`) and WhatsApp support.
7. **Secure Phone Authentication (OTP)**:
   - 6-digit SMS verification code with 45s resend cooldown.
   - Hardware-backed secure storage (`@capacitor/preferences`) for customer session tokens.
   - Welcome **50 Irani Royalty Coins** credited to verified phone numbers.
8. **Real-time Push Notifications (FCM)**:
   - Live alerts when chef begins cooking, when food is out for delivery or served to table, and on delivery.
   - Pre-permission hospitality prompt with deep-linking directly into the live order tracking modal.
   - Owner/CRM audible new order alerts.

---

## 🚀 How to Run Locally (Web Preview)

```bash
cd "c:\Hyderabadi Irani\mobile-customer-app"
npm run dev
```
Open **`http://localhost:3001`** in Chrome or mobile responsive view (`Ctrl+Shift+M`).

---

## 📱 How to Build the Android APK / Play Store AAB

### Step 1: Sync Assets to Native Android
```bash
npm run build
npx cap sync android
```

### Step 2: Open in Android Studio
```bash
npx cap open android
```
- Or open the folder `c:\Hyderabadi Irani\mobile-customer-app\android` directly in **Android Studio**.

### Step 3: Generate APK or Signed AAB for Google Play Store
1. In Android Studio, go to **Build** ➔ **Generate Signed Bundle / APK...**
2. Choose **Android App Bundle (.aab)** for Google Play Store or **APK** for direct testing on your phone.
3. Select your keystore and click **Finish**.
4. The generated APK will be in:
   `android/app/build/outputs/apk/release/app-release.apk`
