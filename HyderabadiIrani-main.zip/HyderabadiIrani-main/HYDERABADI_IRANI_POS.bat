@echo off
title Hyderabadi Irani POS - 0-Click Auto Print
color 0A

echo ====================================================================
echo   HYDERABADI IRANI - 100%% 0-CLICK SILENT AUTO-PRINT POS
echo ====================================================================
echo.
echo [1/2] Starting Background TVS Thermal Print Agent...
cd /d "%~dp0"
start /min "" "%~dp0start_print_agent.bat"

echo [2/2] Launching POS in Silent Kiosk Printing Mode (0 Popups)...
timeout /t 2 /nobreak >nul

:: Find Chrome Executable
set CHROME_PATH=""
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set CHROME_PATH="%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set CHROME_PATH="%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set CHROME_PATH="%LocalAppData%\Google\Chrome\Application\chrome.exe"

if not %CHROME_PATH%=="" (
    start "" %CHROME_PATH% --kiosk-printing --app="https://hyderabadiirani.net/admin/pos"
) else (
    :: Fallback to Microsoft Edge with Kiosk Printing
    if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
        start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --kiosk-printing --app="https://hyderabadiirani.net/admin/pos"
    ) else (
        start https://hyderabadiirani.net/admin/pos
    )
)

echo.
echo ====================================================================
echo   🟢 POS is ready!
echo   * Every bill / KOT will now print INSTANTLY with ZERO dialogs!
echo ====================================================================
