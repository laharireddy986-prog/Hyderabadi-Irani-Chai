import { useEffect, useState, useMemo, useRef } from "react";
import { toast } from "sonner";
import { api, errMsg, money } from "@/lib/api";
import {
  Plus,
  Pencil,
  Trash2,
  X,
  TrendingUp,
  ArrowUpDown,
  FileSpreadsheet,
  Upload,
  Search,
  Check,
  ChevronUp,
  ChevronDown,
  AlertTriangle,
  Image as ImageIcon,
  UploadCloud,
  CheckCircle2,
  Loader2,
  Layers,
  Sparkles,
} from "lucide-react";

const STANDARD_CATEGORIES = [
  "Tea",
  "Tiffins",
  "Snacks",
  "Biryani",
  "Starters",
  "Tandoori Kebabs",
  "Currys",
  "Rotis",
  "Shawarma",
  "Sweets",
  "Fried Rice",
  "Noodles",
  "Sea Food",
  "Soups",
  "Desserts",
  "Beverages",
  "Combos",
];

const EMPTY = {
  name: "",
  description: "",
  price: "",
  price_half: "",
  price_full: "",
  has_variants: false,
  variant_type: "single_full", // "single_full" (Single & Full) or "half_full" (Half & Full)
  category: "Biryani",
  suggested_items: [],
  image_url: "",
  veg: true,
  available: true,
  station: "kitchen",
};

export default function MenuAdmin() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filterCat, setFilterCat] = useState("All");
  const [searchQ, setSearchQ] = useState("");

  // Edit / Add Form
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [open, setOpen] = useState(false);
  const [isCustomCategory, setIsCustomCategory] = useState(false);
  const [pairingSearch, setPairingSearch] = useState("");

  // Modals
  const [bulkPriceModal, setBulkPriceModal] = useState(false);
  const [categoryOrderModal, setCategoryOrderModal] = useState(false);
  const [importModal, setImportModal] = useState(false);
  const [clearModal, setClearModal] = useState(false);

  // Bulk Price Adjust state
  const [bulkCategory, setBulkCategory] = useState("All");
  const [bulkDelta, setBulkDelta] = useState(10);
  const [bulkPercent, setBulkPercent] = useState(0);

  // Category Ordering state
  const [orderedCats, setOrderedCats] = useState([]);

  // Import state
  const [pasteData, setPasteData] = useState("");
  const [replaceAll, setReplaceAll] = useState(false);
  const [parsedImportItems, setParsedImportItems] = useState([]);

  // Store Online/Offline Open/Closed State
  const [storeStatus, setStoreStatus] = useState({ is_online_open: true, notice: "" });
  const [updatingStoreStatus, setUpdatingStoreStatus] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [menuRes, catsRes, statusRes] = await Promise.all([
        api.get("/menu"),
        api.get("/menu/categories"),
        api.get("/store/status").catch(() => ({ data: { is_online_open: true, notice: "" } })),
      ]);
      setItems(menuRes.data || []);
      const loadedCats = catsRes.data?.categories || [];
      setCategories(loadedCats);
      setOrderedCats(loadedCats);
      if (statusRes.data) {
        setStoreStatus(statusRes.data);
      }
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  // Toggle Store Online/Offline Status
  const toggleStoreStatus = async () => {
    setUpdatingStoreStatus(true);
    const newStatus = !storeStatus.is_online_open;
    try {
      await api.put("/store/status", { is_online_open: newStatus });
      setStoreStatus((prev) => ({ ...prev, is_online_open: newStatus }));
      if (newStatus) {
        toast.success("🟢 Online Store is now OPEN (Accepting delivery & online orders)");
      } else {
        toast.warning("🔴 Online Store is now PAUSED / OFFLINE (Counter dine-in only)");
      }
    } catch (e) {
      toast.error(errMsg(e) || "Failed to update store status");
    } finally {
      setUpdatingStoreStatus(false);
    }
  };

  // Toggle Individual Item Availability (In Stock / Out of Stock)
  const toggleItemAvailability = async (item) => {
    const nextVal = item.available === false;
    // Optimistic UI update
    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, available: nextVal } : i))
    );
    try {
      await api.put(`/menu/${item.id}/availability`, { available: nextVal });
      toast.success(
        nextVal
          ? `🟢 "${item.name}" marked In Stock (Available)`
          : `🔴 "${item.name}" marked Out of Stock (Unavailable)`
      );
    } catch (e) {
      toast.error(errMsg(e) || "Failed to update item availability");
      // Rollback
      setItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, available: !nextVal } : i))
      );
    }
  };

  // Toggle Entire Category Availability (Bulk Available / Unavailable)
  const toggleCategoryAvailability = async (catName, targetAvailable) => {
    if (catName === "All") {
      if (
        !window.confirm(
          `Are you sure you want to mark ALL ${items.length} dishes ${
            targetAvailable ? "In Stock" : "Out of Stock"
          }?`
        )
      )
        return;
      // Optimistically update all
      setItems((prev) => prev.map((i) => ({ ...i, available: targetAvailable })));
      try {
        await Promise.all(
          categories.map((c) =>
            api.put(`/menu/category/${encodeURIComponent(c)}/availability`, {
              available: targetAvailable,
            })
          )
        );
        toast.success(
          targetAvailable
            ? "🟢 All menu items marked In Stock!"
            : "🔴 All menu items marked Out of Stock!"
        );
      } catch (e) {
        toast.error(errMsg(e));
        load();
      }
      return;
    }

    // Optimistically update category items
    setItems((prev) =>
      prev.map((i) =>
        i.category?.toLowerCase() === catName.toLowerCase()
          ? { ...i, available: targetAvailable }
          : i
      )
    );
    try {
      await api.put(`/menu/category/${encodeURIComponent(catName)}/availability`, {
        available: targetAvailable,
      });
      toast.success(
        targetAvailable
          ? `🟢 All dishes in "${catName}" marked In Stock!`
          : `🔴 All dishes in "${catName}" marked Out of Stock!`
      );
    } catch (e) {
      toast.error(errMsg(e));
      load();
    }
  };

  // Filtered items
  const filteredItems = useMemo(() => {
    return items.filter((i) => {
      const matchCat = filterCat === "All" || i.category?.toLowerCase() === filterCat.toLowerCase();
      const matchSearch =
        !searchQ ||
        i.name?.toLowerCase().includes(searchQ.toLowerCase()) ||
        i.category?.toLowerCase().includes(searchQ.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [items, filterCat, searchQ]);

  // Category in-stock / out-of-stock stats
  const categoryStats = useMemo(() => {
    const targetItems =
      filterCat === "All"
        ? items
        : items.filter((i) => i.category?.toLowerCase() === filterCat.toLowerCase());
    const total = targetItems.length;
    const available = targetItems.filter((i) => i.available !== false).length;
    const outOfStock = total - available;
    return { total, available, outOfStock };
  }, [items, filterCat]);

  // Image Upload state
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadStats, setUploadStats] = useState(null);
  const fileInputRef = useRef(null);

  // Compress image on client to WebP & upload directly to GCS
  const handleImageFilePick = async (file) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload a valid image file (PNG, JPG, WebP)");
      return;
    }

    setUploadingImage(true);
    setUploadStats(null);
    try {
      // 1. Read file as Image
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const img = new Image();
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = dataUrl;
      });

      // 2. Compress via HTML5 Canvas (max 600x600 px) to WebP
      const canvas = document.createElement("canvas");
      const maxDim = 600;
      let width = img.width;
      let height = img.height;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);

      // Export as WebP
      const webpBase64 = canvas.toDataURL("image/webp", 0.82);

      // 3. Upload to backend GCS endpoint
      const { data } = await api.post("/menu/upload-image", {
        image_base64: webpBase64,
        filename: form.name || file.name,
        item_name: form.name,
      });

      setForm((prev) => ({ ...prev, image_url: data.url }));
      setUploadStats({
        size_kb: data.size_kb,
        url: data.url,
        dimensions: `${data.width}x${data.height}`,
      });
      toast.success(`Image compressed (${data.size_kb} KB WebP) & uploaded to Google Cloud Storage! 🚀`);
    } catch (e) {
      console.error(e);
      toast.error(errMsg(e) || "Failed to compress/upload image to cloud");
    } finally {
      setUploadingImage(false);
    }
  };

  // Single Item CRUD
  const submit = async (e) => {
    e.preventDefault();
    const nameClean = form.name?.trim() || "";
    if (!nameClean) {
      toast.error("Please enter a valid item name");
      return;
    }

    // Check for duplicate menu item name (case-insensitive & trimmed)
    const duplicate = items.find(
      (i) => i.id !== editing && i.name?.trim().toLowerCase() === nameClean.toLowerCase()
    );
    if (duplicate) {
      toast.error(
        `Item "${duplicate.name}" already exists in the menu! Please edit the existing item or use a unique name.`,
        { duration: 4000 }
      );
      return;
    }

    let hasVars = Boolean(form.has_variants);
    let variants = [];
    let basePrice = parseFloat(form.price) || 0;
    let halfVal = parseFloat(form.price_half) || null;
    let fullVal = parseFloat(form.price_full) || null;

    if (hasVars) {
      if (!halfVal || !fullVal) {
        toast.error("Please enter both portion prices (Single/Half & Full)");
        return;
      }
      const label1 = form.variant_type === "single_full" ? "Single" : "Half";
      const label2 = "Full";
      variants = [
        { name: label1, label: label1, price: halfVal, is_default: true },
        { name: label2, label: label2, price: fullVal, is_default: false },
      ];
      basePrice = halfVal;
    } else {
      if (!basePrice) {
        toast.error("Please enter a valid dish price");
        return;
      }
      halfVal = null;
      fullVal = null;
      variants = [];
    }

    const payload = {
      name: nameClean,
      description: form.description || "",
      price: basePrice,
      price_half: halfVal,
      price_full: fullVal,
      has_variants: hasVars,
      variants: variants,
      category: form.category || "General",
      suggested_items: Array.isArray(form.suggested_items) ? form.suggested_items : [],
      image_url: form.image_url || "",
      veg: Boolean(form.veg),
      available: Boolean(form.available),
      station: form.station || "kitchen",
    };

    try {
      if (editing) await api.put(`/menu/${editing}`, payload);
      else await api.post("/menu", payload);
      toast.success(editing ? "Item updated successfully" : "Item added successfully");
      setForm(EMPTY);
      setUploadStats(null);
      setEditing(null);
      setOpen(false);
      load();
    } catch (e2) {
      toast.error(errMsg(e2));
    }
  };

  const remove = async (id) => {
    if (!window.confirm("Are you sure you want to delete this menu item?")) return;
    try {
      await api.delete(`/menu/${id}`);
      toast.success("Item deleted");
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const allCategoryOptions = useMemo(() => {
    const list = [...STANDARD_CATEGORIES];
    categories.forEach((c) => {
      if (c && !list.some((existing) => existing.toLowerCase() === c.toLowerCase())) {
        list.push(c);
      }
    });
    return list;
  }, [categories]);

  const startEdit = (i) => {
    setEditing(i.id);
    const isSingleType =
      i.category?.toLowerCase() === "biryani" ||
      i.category?.toLowerCase() === "combo pack" ||
      i.variants?.[0]?.name === "Single";

    const cat = i.category || "Biryani";
    const isCustom = !STANDARD_CATEGORIES.some((c) => c.toLowerCase() === cat.toLowerCase()) &&
      !categories.some((c) => c.toLowerCase() === cat.toLowerCase());
    setIsCustomCategory(isCustom);
    setPairingSearch("");

    setForm({
      name: i.name,
      description: i.description || "",
      price: String(i.price ?? ""),
      price_half: String(i.price_half ?? (i.variants?.[0]?.price ?? "")),
      price_full: String(i.price_full ?? (i.variants?.[1]?.price ?? "")),
      has_variants: Boolean(i.has_variants || (i.variants && i.variants.length > 1)),
      variant_type: isSingleType ? "single_full" : "half_full",
      category: cat,
      suggested_items: Array.isArray(i.suggested_items) ? i.suggested_items : [],
      image_url: i.image_url || "",
      veg: i.veg !== false,
      available: i.available !== false,
      station: i.station || "kitchen",
    });
    setUploadStats(i.image_url ? { url: i.image_url, size_kb: "<50" } : null);
    setOpen(true);
  };

  // Bulk Price Hike
  const handleBulkPriceHike = async () => {
    try {
      const { data } = await api.post("/menu/bulk-price-adjust", {
        category: bulkCategory === "All" ? null : bulkCategory,
        delta: Number(bulkDelta) || 0,
        percent: Number(bulkPercent) || 0,
      });
      toast.success(`Updated prices for ${data.updated_count} items!`);
      setBulkPriceModal(false);
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  // Category Ordering
  const moveCategory = (idx, direction) => {
    const newCats = [...orderedCats];
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= newCats.length) return;
    const temp = newCats[idx];
    newCats[idx] = newCats[targetIdx];
    newCats[targetIdx] = temp;
    setOrderedCats(newCats);
  };

  const saveCategoryOrder = async () => {
    try {
      await api.put("/menu/categories/order", { categories: orderedCats });
      toast.success("Category order saved successfully!");
      setCategoryOrderModal(false);
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  // Parse Excel / CSV / Pasted text
  const parsePastedMenu = (text) => {
    setPasteData(text);
    if (!text.trim()) {
      setParsedImportItems([]);
      return;
    }
    const lines = text.trim().split(/\r?\n/);
    const parsed = [];
    for (const rawLine of lines) {
      if (!rawLine.trim()) continue;
      // Split by tab, comma, or pipe
      const parts = rawLine.includes("\t")
        ? rawLine.split("\t")
        : rawLine.includes(",")
        ? rawLine.split(",")
        : rawLine.split("|");

      const trimmed = parts.map((p) => p.trim().replace(/^["']|["']$/g, ""));
      if (trimmed.length < 2) continue;

      let category = "Tea";
      let veg = true;
      let name = "";
      let price = 0;
      let description = "";

      if (trimmed.length >= 4) {
        // format: Category | Veg/Non-Veg | Name | Price
        category = trimmed[0] || "General";
        const vegText = trimmed[1].toUpperCase();
        veg = vegText.includes("VEG") && !vegText.includes("NON");
        name = trimmed[2];
        price = parseFloat(trimmed[3].replace(/[^\d.]/g, "")) || 0;
        if (trimmed[4]) description = trimmed[4];
      } else if (trimmed.length === 3) {
        // format: Name | Category | Price
        name = trimmed[0];
        category = trimmed[1];
        price = parseFloat(trimmed[2].replace(/[^\d.]/g, "")) || 0;
      } else if (trimmed.length === 2) {
        // format: Name | Price
        name = trimmed[0];
        price = parseFloat(trimmed[1].replace(/[^\d.]/g, "")) || 0;
      }

      if (name && price > 0) {
        parsed.push({
          name,
          category,
          price,
          veg,
          description: description || `${name} served fresh.`,
          station: category.toLowerCase().includes("tea") ? "tea" : "kitchen",
          available: true,
        });
      }
    }
    setParsedImportItems(parsed);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target.result;
      parsePastedMenu(text);
    };
    reader.readAsText(file);
  };

  const executeImport = async () => {
    if (!parsedImportItems.length) return toast.error("No valid menu items to import");
    try {
      const { data } = await api.post("/menu/bulk-import", {
        items: parsedImportItems,
        replace_all: replaceAll,
      });
      toast.success(`Successfully imported ${data.inserted_count} menu items!`);
      setImportModal(false);
      setPasteData("");
      setParsedImportItems([]);
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const handleClearAll = async () => {
    try {
      await api.delete("/menu/clear-all");
      toast.success("All old menu items cleared!");
      setClearModal(false);
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const field =
    "w-full border border-foreground bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-foreground";

  return (
    <div className="p-5 sm:p-8 space-y-6" data-testid="menu-admin-page">
      {/* Header & Quick Action Buttons */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-foreground/20 pb-6">
        <div>
          <p className="overline text-primary">Kitchen catalogue & pricing</p>
          <h1 className="text-3xl sm:text-4xl font-semibold tracking-tighter mt-1">
            Menu & Availability Management
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            {items.length} dishes total · All prices are GST-Inclusive
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => setCategoryOrderModal(true)}
            className="border border-foreground bg-card px-4 py-2.5 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 hover:bg-muted"
          >
            <ArrowUpDown size={14} className="text-primary" /> Category Order (Tea First)
          </button>

          <button
            onClick={() => setBulkPriceModal(true)}
            className="border border-foreground bg-card px-4 py-2.5 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 hover:bg-muted"
          >
            <TrendingUp size={14} className="text-emerald-600" /> Bulk Price Hike / Update
          </button>

          <button
            onClick={() => {
              setPasteData("");
              setParsedImportItems([]);
              setImportModal(true);
            }}
            className="border border-foreground bg-card px-4 py-2.5 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 hover:bg-muted"
          >
            <FileSpreadsheet size={14} className="text-blue-600" /> Import Excel / CSV
          </button>

          <button
            onClick={() => {
              setEditing(null);
              setForm({ ...EMPTY, suggested_items: [] });
              setIsCustomCategory(false);
              setPairingSearch("");
              setOpen(true);
            }}
            className="hard-shadow border border-foreground bg-primary text-primary-foreground px-5 py-2.5 text-xs uppercase tracking-widest flex items-center gap-2"
          >
            <Plus size={14} /> Add Item
          </button>
        </div>
      </div>

      {/* Online / Offline Store Master Control Banner */}
      <div
        className={`p-4 sm:p-5 border-2 hard-shadow flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-lg transition ${
          storeStatus.is_online_open
            ? "bg-emerald-50 text-emerald-950 border-emerald-600"
            : "bg-red-50 text-red-950 border-red-600"
        }`}
      >
        <div className="flex items-center gap-3.5">
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg text-white shadow ${
              storeStatus.is_online_open ? "bg-emerald-600" : "bg-red-600"
            }`}
          >
            {storeStatus.is_online_open ? "🟢" : "🔴"}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold tracking-tight">
                {storeStatus.is_online_open
                  ? "Online Store is OPEN (Accepting Orders)"
                  : "Online Store is PAUSED / OFFLINE (Counter Only)"}
              </h3>
              <span
                className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                  storeStatus.is_online_open
                    ? "bg-emerald-200 text-emerald-900 border border-emerald-400"
                    : "bg-red-200 text-red-900 border border-red-400 animate-pulse"
                }`}
              >
                {storeStatus.is_online_open ? "Live Accepting" : "Paused"}
              </span>
            </div>
            <p className="text-xs opacity-85 mt-0.5">
              {storeStatus.is_online_open
                ? "Online delivery & takeaway ordering is active on hyderabadiirani.net for customers."
                : "Online ordering is temporarily stopped for customers. In-store POS billing & counter dine-in remain fully functional."}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={toggleStoreStatus}
          disabled={updatingStoreStatus}
          className={`px-5 py-2.5 text-xs font-extrabold uppercase tracking-wider rounded border-2 shadow-md transition whitespace-nowrap ${
            storeStatus.is_online_open
              ? "bg-red-600 text-white hover:bg-red-700 border-red-800"
              : "bg-emerald-600 text-white hover:bg-emerald-700 border-emerald-800"
          }`}
        >
          {updatingStoreStatus
            ? "Updating…"
            : storeStatus.is_online_open
            ? "⏸️ Pause Online Ordering"
            : "▶️ Turn Online Store ON"}
        </button>
      </div>

      {/* Category filter & Search */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-1.5 overflow-x-auto">
            {["All", ...categories].map((c) => (
              <button
                key={c}
                onClick={() => setFilterCat(c)}
                className={`border border-foreground px-3.5 py-1.5 text-xs uppercase tracking-wider font-semibold rounded transition ${
                  filterCat === c
                    ? "bg-foreground text-background shadow-sm"
                    : "bg-card hover:bg-muted"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="relative min-w-[260px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Search dish or category..."
              className="w-full border border-foreground bg-background pl-8 pr-3 py-2 text-xs outline-none rounded"
            />
          </div>
        </div>

        {/* Category-wise Bulk Availability Quick Action Bar */}
        <div className="p-3 border border-foreground/30 bg-muted/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 rounded-lg">
          <div className="flex items-center gap-2">
            <span className="font-bold text-xs uppercase text-foreground">
              Category: <strong className="text-primary font-mono text-sm">{filterCat}</strong>
            </span>
            <span className="text-xs text-muted-foreground">
              ({categoryStats.total} dishes ·{" "}
              <span className="text-emerald-700 font-bold font-mono">{categoryStats.available} In Stock</span>,{" "}
              <span className="text-red-700 font-bold font-mono">{categoryStats.outOfStock} Out of Stock</span>)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => toggleCategoryAvailability(filterCat, true)}
              className="border border-emerald-600 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded flex items-center gap-1.5 transition shadow-sm"
              title={`Mark all items in "${filterCat}" as In Stock`}
            >
              <Check size={13} className="text-emerald-700" />
              <span>Turn All In Stock</span>
            </button>

            <button
              type="button"
              onClick={() => toggleCategoryAvailability(filterCat, false)}
              className="border border-red-600 bg-red-50 text-red-800 hover:bg-red-100 px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded flex items-center gap-1.5 transition shadow-sm"
              title={`Mark all items in "${filterCat}" as Out of Stock`}
            >
              <X size={13} className="text-red-700" />
              <span>Turn All Out of Stock</span>
            </button>
          </div>
        </div>
      </div>

      {/* Add / Edit Form Modal */}
      {open && (
        <form
          onSubmit={submit}
          className="mt-6 border-2 border-foreground bg-card p-5 sm:p-6 grid gap-4 sm:grid-cols-2 shadow-xl"
          data-testid="menu-item-form"
        >
          <div className="sm:col-span-2 flex items-center justify-between border-b border-foreground/20 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xs">
                {editing ? <Pencil size={15} /> : <Plus size={15} />}
              </span>
              <h2 className="text-xl font-bold tracking-tight">
                {editing ? "Edit Menu Dish" : "Create New Menu Dish"}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                setUploadStats(null);
              }}
              className="p-1.5 hover:bg-muted rounded"
            >
              <X size={18} />
            </button>
          </div>

          <div>
            <label className="block overline mb-1.5">Dish Name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
              placeholder="e.g. Chicken Dum Biryani"
              className={field}
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block overline">Category</label>
              {isCustomCategory ? (
                <button
                  type="button"
                  onClick={() => {
                    setIsCustomCategory(false);
                    setForm({ ...form, category: allCategoryOptions[0] || "Biryani" });
                  }}
                  className="text-[10px] text-primary hover:underline font-bold uppercase tracking-wider"
                >
                  ← Select Preset
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setIsCustomCategory(true);
                    setForm({ ...form, category: "" });
                  }}
                  className="text-[10px] text-primary hover:underline font-bold uppercase tracking-wider"
                >
                  + Custom Category
                </button>
              )}
            </div>

            {!isCustomCategory ? (
              <select
                value={form.category}
                onChange={(e) => {
                  if (e.target.value === "__NEW__") {
                    setIsCustomCategory(true);
                    setForm({ ...form, category: "" });
                  } else {
                    setForm({ ...form, category: e.target.value });
                  }
                }}
                className={field}
              >
                {allCategoryOptions.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
                <option value="__NEW__" className="font-bold text-primary">
                  + Add New Category...
                </option>
              </select>
            ) : (
              <input
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                required
                autoFocus
                placeholder="Enter custom category name (e.g. Desserts)"
                className={field}
              />
            )}
          </div>

          {/* Portion Sizing & Pricing Box */}
          <div className="sm:col-span-2 border border-foreground/30 bg-muted/20 p-4 rounded-lg space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 text-foreground">
                <Layers size={15} className="text-primary" /> Portion Sizing &amp; Pricing
              </span>
              <div className="flex items-center gap-4 text-xs font-semibold">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="has_variants_toggle"
                    checked={!form.has_variants}
                    onChange={() => setForm({ ...form, has_variants: false })}
                  />
                  Fixed Single Price
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="has_variants_toggle"
                    checked={form.has_variants}
                    onChange={() => setForm({ ...form, has_variants: true })}
                  />
                  Portion Variants (Single/Half &amp; Full)
                </label>
              </div>
            </div>

            {!form.has_variants ? (
              <div>
                <label className="block overline mb-1.5">Price (₹ Incl. GST)</label>
                <input
                  type="number"
                  step="1"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  placeholder="e.g. 130"
                  required={!form.has_variants}
                  className={field}
                />
              </div>
            ) : (
              <div className="grid sm:grid-cols-3 gap-3 pt-2">
                <div>
                  <label className="block overline mb-1.5">Portion Scheme</label>
                  <select
                    value={form.variant_type}
                    onChange={(e) => setForm({ ...form, variant_type: e.target.value })}
                    className={field}
                  >
                    <option value="single_full">Single &amp; Full (Biryani / Combos)</option>
                    <option value="half_full">Half &amp; Full (Starters / Curries / Rice)</option>
                  </select>
                </div>
                <div>
                  <label className="block overline mb-1.5">
                    {form.variant_type === "single_full" ? "Single Price (₹)" : "Half Price (₹)"}
                  </label>
                  <input
                    type="number"
                    step="1"
                    value={form.price_half}
                    onChange={(e) => setForm({ ...form, price_half: e.target.value })}
                    placeholder="e.g. 130"
                    required={form.has_variants}
                    className={field}
                  />
                </div>
                <div>
                  <label className="block overline mb-1.5">Full Price (₹)</label>
                  <input
                    type="number"
                    step="1"
                    value={form.price_full}
                    onChange={(e) => setForm({ ...form, price_full: e.target.value })}
                    placeholder="e.g. 220"
                    required={form.has_variants}
                    className={field}
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block overline mb-1.5">Preparation Station</label>
            <select
              value={form.station}
              onChange={(e) => setForm({ ...form, station: e.target.value })}
              className={field}
            >
              <option value="kitchen">Main Kitchen</option>
              <option value="tea">Chai / Beverage Station</option>
              <option value="bakery">Bakery / Patisserie</option>
            </select>
          </div>

          <div>
            <label className="block overline mb-1.5">Description</label>
            <input
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Dish description & flavour notes..."
              className={field}
            />
          </div>

          {/* Dish Image Upload & Cloud Storage Zone */}
          <div className="sm:col-span-2 border border-foreground/30 bg-muted/20 p-4 rounded-lg space-y-3">
            <label className="block font-bold text-xs uppercase tracking-wider text-foreground flex items-center gap-1.5">
              <ImageIcon size={15} className="text-primary" /> Dish Food Photo (Optimized to &lt; 50 KB WebP &amp; Cloud Storage)
            </label>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              {form.image_url ? (
                <div className="relative w-24 h-24 rounded-lg overflow-hidden border-2 border-foreground shrink-0 bg-muted shadow-sm group">
                  <img src={form.image_url} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => {
                      setForm({ ...form, image_url: "" });
                      setUploadStats(null);
                    }}
                    className="absolute top-1 right-1 bg-black/80 text-white rounded-full p-1 hover:bg-black"
                    title="Remove image"
                  >
                    <X size={12} />
                  </button>
                </div>
              ) : (
                <div className="w-24 h-24 rounded-lg border-2 border-dashed border-foreground/40 flex flex-col items-center justify-center shrink-0 text-muted-foreground bg-card">
                  <ImageIcon size={28} className="opacity-40" />
                  <span className="text-[10px] mt-1">No Photo</span>
                </div>
              )}

              <div className="flex-1 w-full space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/png, image/jpeg, image/webp"
                    onChange={(e) => handleImageFilePick(e.target.files?.[0])}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploadingImage}
                    onClick={() => fileInputRef.current?.click()}
                    className="border border-foreground bg-primary text-primary-foreground hover:bg-foreground hover:text-background px-4 py-2 text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition disabled:opacity-50"
                  >
                    {uploadingImage ? (
                      <>
                        <Loader2 size={14} className="animate-spin" /> Compressing &amp; Uploading...
                      </>
                    ) : (
                      <>
                        <UploadCloud size={14} /> Upload Food Image (&lt; 50 KB WebP)
                      </>
                    )}
                  </button>

                  {uploadStats && (
                    <span className="text-xs text-emerald-700 font-bold bg-emerald-50 border border-emerald-300 px-2.5 py-1 rounded flex items-center gap-1">
                      <CheckCircle2 size={13} /> {uploadStats.size_kb} KB WebP · Google Cloud Storage
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    value={form.image_url}
                    onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                    placeholder="Or paste public GCS / image link"
                    className={`${field} text-xs`}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Recommended Pairings / Cross-sell Dishes Box */}
          <div className="sm:col-span-2 border border-foreground/30 bg-muted/20 p-4 rounded-lg space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 text-foreground">
                  <Sparkles size={15} className="text-amber-500" /> Recommended Pairings ("You will love pairing it with")
                </span>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  Choose dishes to suggest when a customer views or adds this item (e.g. Biryani → Mirchi Ka Salan, Double Ka Meetha, Irani Chai, Chicken 65).
                </p>
              </div>
              <span className="text-[11px] font-mono font-bold bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded">
                {(form.suggested_items || []).length} selected
              </span>
            </div>

            {/* Selected Pairing Chips */}
            {(form.suggested_items || []).length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                    Active Recommendations:
                  </span>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, suggested_items: [] })}
                    className="text-[10px] text-destructive hover:underline font-bold uppercase"
                  >
                    Clear All
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(form.suggested_items || []).map((pairingId) => {
                    const dish = items.find((it) => it.id === pairingId);
                    if (!dish) return null;
                    return (
                      <span
                        key={pairingId}
                        className="inline-flex items-center gap-2 bg-card border border-foreground/30 px-2.5 py-1 rounded-md text-xs font-semibold shadow-2xs group"
                      >
                        <span
                          className={`w-2 h-2 rounded-full flex-shrink-0 ${
                            dish.veg ? "bg-emerald-600" : "bg-red-600"
                          }`}
                        />
                        <span className="text-foreground">{dish.name}</span>
                        <span className="font-mono text-[11px] text-muted-foreground">
                          ({money(dish.price)})
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setForm({
                              ...form,
                              suggested_items: (form.suggested_items || []).filter((id) => id !== pairingId),
                            })
                          }
                          className="text-muted-foreground hover:text-destructive p-0.5 rounded transition"
                          title="Remove pairing"
                        >
                          <X size={13} />
                        </button>
                      </span>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quick Popular Add Suggestions */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block">
                Quick Suggestions:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  "Mirchi Ka Salan",
                  "Double Ka Meetha",
                  "Hyderabadi Irani Chai",
                  "Chicken 65",
                  "Osmania Biscuits",
                  "Raita",
                  "Butter Naan",
                  "Gulab Jamun",
                  "Thums Up",
                ].map((quickName) => {
                  const matchDish = items.find(
                    (it) =>
                      it.name.toLowerCase().includes(quickName.toLowerCase()) &&
                      it.id !== editing
                  );
                  if (!matchDish) return null;
                  const isSelected = (form.suggested_items || []).includes(matchDish.id);
                  return (
                    <button
                      key={quickName}
                      type="button"
                      onClick={() => {
                        const current = form.suggested_items || [];
                        if (isSelected) {
                          setForm({ ...form, suggested_items: current.filter((id) => id !== matchDish.id) });
                        } else {
                          setForm({ ...form, suggested_items: [...current, matchDish.id] });
                        }
                      }}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium border transition flex items-center gap-1 ${
                        isSelected
                          ? "bg-primary text-primary-foreground border-primary font-bold shadow-2xs"
                          : "bg-background hover:bg-muted text-foreground border-foreground/20"
                      }`}
                    >
                      <span>{isSelected ? "✓" : "+"}</span>
                      <span>{matchDish.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Search & Dish Picker Dropdown */}
            <div className="space-y-2 pt-1">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-2.5 text-muted-foreground" />
                <input
                  type="text"
                  value={pairingSearch}
                  onChange={(e) => setPairingSearch(e.target.value)}
                  placeholder="Filter dishes by name or category to add pairing..."
                  className={`${field} pl-8 text-xs`}
                />
                {pairingSearch && (
                  <button
                    type="button"
                    onClick={() => setPairingSearch("")}
                    className="absolute right-2.5 top-2 text-muted-foreground hover:text-foreground"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              {/* Scrollable Dish Selector Grid */}
              <div className="border border-foreground/20 rounded-md bg-background max-h-44 overflow-y-auto divide-y divide-foreground/10 text-xs">
                {items
                  .filter(
                    (it) =>
                      it.id !== editing &&
                      (!pairingSearch ||
                        it.name.toLowerCase().includes(pairingSearch.toLowerCase()) ||
                        it.category?.toLowerCase().includes(pairingSearch.toLowerCase()))
                  )
                  .slice(0, 35)
                  .map((it) => {
                    const isSelected = (form.suggested_items || []).includes(it.id);
                    return (
                      <div
                        key={it.id}
                        onClick={() => {
                          const current = form.suggested_items || [];
                          if (isSelected) {
                            setForm({ ...form, suggested_items: current.filter((id) => id !== it.id) });
                          } else {
                            setForm({ ...form, suggested_items: [...current, it.id] });
                          }
                        }}
                        className={`p-2 flex items-center justify-between hover:bg-muted/60 cursor-pointer transition ${
                          isSelected ? "bg-primary/5 font-semibold" : ""
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0 pr-2">
                          <span
                            className={`w-2 h-2 rounded-full flex-shrink-0 ${
                              it.veg ? "bg-emerald-600" : "bg-red-600"
                            }`}
                          />
                          <span className="truncate text-foreground">{it.name}</span>
                          <span className="text-[10px] text-muted-foreground uppercase">
                            ({it.category})
                          </span>
                        </div>
                        <div className="flex items-center gap-3 flex-shrink-0">
                          <span className="font-mono text-xs">{money(it.price)}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${
                              isSelected
                                ? "bg-primary text-primary-foreground border-primary"
                                : "bg-muted text-muted-foreground border-foreground/20"
                            }`}
                          >
                            {isSelected ? "Added ✓" : "+ Add"}
                          </span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>

          <div className="sm:col-span-2 flex flex-wrap items-center gap-6 pt-2">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={form.veg}
                onChange={(e) => setForm({ ...form, veg: e.target.checked })}
              />{" "}
              Vegetarian (Green Dot)
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={form.available}
                onChange={(e) => setForm({ ...form, available: e.target.checked })}
              />{" "}
              Available for Ordering
            </label>
            <button className="hard-shadow ml-auto border border-foreground bg-primary text-primary-foreground px-6 py-2.5 text-xs uppercase tracking-widest font-semibold">
              {editing ? "Update Dish" : "Save Dish"}
            </button>
          </div>
        </form>
      )}

      {/* Bulk Price Hike Modal */}
      {bulkPriceModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border-2 border-foreground w-full max-w-lg p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-foreground/20 pb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="text-emerald-600" size={20} />
                <h3 className="text-xl font-bold tracking-tight">Bulk Price Hike / Adjustment</h3>
              </div>
              <button onClick={() => setBulkPriceModal(false)} className="p-1 hover:bg-muted">
                <X size={18} />
              </button>
            </div>

            <p className="text-xs text-muted-foreground">
              Adjust prices across your entire menu or by category in one click. All prices remain GST inclusive.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block overline mb-1">Target Category</label>
                <select
                  value={bulkCategory}
                  onChange={(e) => setBulkCategory(e.target.value)}
                  className={field}
                >
                  <option value="All">All Categories ({items.length} dishes)</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c} (
                      {items.filter((i) => i.category?.toLowerCase() === c.toLowerCase()).length} dishes)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block overline mb-1">Quick Price Adjust Buttons</label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { label: "+₹10", d: 10, p: 0 },
                    { label: "+₹20", d: 20, p: 0 },
                    { label: "+₹50", d: 50, p: 0 },
                    { label: "-₹10", d: -10, p: 0 },
                    { label: "+5%", d: 0, p: 5 },
                    { label: "+10%", d: 0, p: 10 },
                    { label: "+15%", d: 0, p: 15 },
                    { label: "+20%", d: 0, p: 20 },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        setBulkDelta(preset.d);
                        setBulkPercent(preset.p);
                      }}
                      className={`border border-foreground py-2 text-xs font-bold uppercase ${
                        bulkDelta === preset.d && bulkPercent === preset.p
                          ? "bg-foreground text-background"
                          : "bg-muted hover:bg-muted/80"
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block overline mb-1">Fixed ₹ Hike / Cut</label>
                  <input
                    type="number"
                    value={bulkDelta}
                    onChange={(e) => {
                      setBulkDelta(Number(e.target.value));
                      setBulkPercent(0);
                    }}
                    placeholder="e.g. 10 or 20"
                    className={field}
                  />
                </div>
                <div>
                  <label className="block overline mb-1">Percentage Hike (%)</label>
                  <input
                    type="number"
                    value={bulkPercent}
                    onChange={(e) => {
                      setBulkPercent(Number(e.target.value));
                      setBulkDelta(0);
                    }}
                    placeholder="e.g. 10"
                    className={field}
                  />
                </div>
              </div>

              <div className="border border-foreground/30 bg-muted/30 p-3 text-xs">
                <span className="font-bold">Summary:</span> Each dish in{" "}
                <strong>{bulkCategory}</strong> will have its price updated by{" "}
                <span className="text-emerald-700 font-bold">
                  {bulkDelta !== 0 ? `${bulkDelta >= 0 ? "+" : ""}₹${bulkDelta}` : ""}
                  {bulkPercent !== 0 ? ` +${bulkPercent}%` : ""}
                </span>
                . (e.g. ₹90 &rarr; ₹
                {Math.max(1, Math.round(90 + bulkDelta + (90 * bulkPercent) / 100))})
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-foreground/20">
              <button
                onClick={() => setBulkPriceModal(false)}
                className="border border-foreground px-4 py-2 text-xs uppercase font-semibold hover:bg-muted"
              >
                Cancel
              </button>
              <button
                onClick={handleBulkPriceHike}
                className="border border-foreground bg-primary text-primary-foreground px-6 py-2 text-xs uppercase tracking-wider font-bold hover:opacity-90"
              >
                Apply Price Hike
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Order Reordering Modal */}
      {categoryOrderModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border-2 border-foreground w-full max-w-md p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-foreground/20 pb-3">
              <div className="flex items-center gap-2">
                <ArrowUpDown className="text-primary" size={20} />
                <h3 className="text-xl font-bold tracking-tight">Category Display Order</h3>
              </div>
              <button onClick={() => setCategoryOrderModal(false)} className="p-1 hover:bg-muted">
                <X size={18} />
              </button>
            </div>

            <p className="text-xs text-muted-foreground">
              Rearrange the tabs shown on your Storefront & POS. Use the buttons to position <strong>TEA</strong> first.
            </p>

            <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
              {orderedCats.map((catName, idx) => (
                <div
                  key={catName}
                  className="flex items-center justify-between border border-foreground bg-background px-3 py-2 text-sm font-medium"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-muted-foreground w-6">#{idx + 1}</span>
                    <span className={catName.toLowerCase() === "tea" ? "font-bold text-primary" : ""}>
                      {catName}
                    </span>
                    {catName.toLowerCase() === "tea" && (
                      <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.2 uppercase font-bold">
                        Top Priority
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => moveCategory(idx, -1)}
                      className="border border-foreground p-1 hover:bg-muted disabled:opacity-30"
                    >
                      <ChevronUp size={14} />
                    </button>
                    <button
                      type="button"
                      disabled={idx === orderedCats.length - 1}
                      onClick={() => moveCategory(idx, 1)}
                      className="border border-foreground p-1 hover:bg-muted disabled:opacity-30"
                    >
                      <ChevronDown size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-foreground/20">
              <button
                onClick={() => setCategoryOrderModal(false)}
                className="border border-foreground px-4 py-2 text-xs uppercase font-semibold hover:bg-muted"
              >
                Cancel
              </button>
              <button
                onClick={saveCategoryOrder}
                className="border border-foreground bg-primary text-primary-foreground px-6 py-2 text-xs uppercase tracking-wider font-bold hover:opacity-90"
              >
                Save Order
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Excel / CSV Import Modal */}
      {importModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border-2 border-foreground w-full max-w-2xl p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-foreground/20 pb-3">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="text-blue-600" size={20} />
                <h3 className="text-xl font-bold tracking-tight">Import Menu (Excel / CSV / Paste)</h3>
              </div>
              <button onClick={() => setImportModal(false)} className="p-1 hover:bg-muted">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <div className="border border-dashed border-foreground p-4 bg-muted/20 text-center">
                <label className="cursor-pointer block">
                  <Upload size={24} className="mx-auto text-muted-foreground mb-1" />
                  <span className="text-xs font-bold uppercase tracking-wider">
                    Upload .CSV File or Paste Rows Below
                  </span>
                  <input
                    type="file"
                    accept=".csv,.tsv,.txt"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <div>
                <label className="block overline mb-1">
                  Paste rows directly from Excel / Google Sheets:
                </label>
                <textarea
                  rows={6}
                  value={pasteData}
                  onChange={(e) => parsePastedMenu(e.target.value)}
                  placeholder={`FRIED RICE\tVEG\tVEG FRIED RICE\t90\nFRIED RICE\tVEG\tGARLIC FRIED RICE\t100\nNOODLES\tNON-VEG\tCHICKEN NOODLES\t110`}
                  className="w-full border border-foreground bg-background p-3 text-xs font-mono outline-none"
                />
              </div>

              <div className="flex items-center gap-2 p-2 border border-destructive/50 bg-destructive/10 text-xs">
                <input
                  type="checkbox"
                  id="replace-check"
                  checked={replaceAll}
                  onChange={(e) => setReplaceAll(e.target.checked)}
                />
                <label htmlFor="replace-check" className="font-semibold text-destructive cursor-pointer">
                  Clear and REPLACE ALL existing menu items before importing
                </label>
              </div>

              {parsedImportItems.length > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold uppercase">
                      Parsed Dishes ({parsedImportItems.length}):
                    </span>
                  </div>
                  <div className="border border-foreground max-h-48 overflow-y-auto text-xs">
                    <table className="w-full border-collapse">
                      <thead className="bg-muted sticky top-0">
                        <tr>
                          <th className="p-1.5 text-left">Category</th>
                          <th className="p-1.5 text-left">Dish Name</th>
                          <th className="p-1.5 text-right">Price</th>
                          <th className="p-1.5 text-center">Type</th>
                        </tr>
                      </thead>
                      <tbody>
                        {parsedImportItems.slice(0, 20).map((it, idx) => (
                          <tr key={idx} className="border-b border-foreground/10">
                            <td className="p-1.5">{it.category}</td>
                            <td className="p-1.5 font-medium">{it.name}</td>
                            <td className="p-1.5 text-right font-mono">₹{it.price}</td>
                            <td className="p-1.5 text-center">{it.veg ? "Veg" : "Non-Veg"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {parsedImportItems.length > 20 && (
                      <p className="p-2 text-center text-muted-foreground">
                        ...and {parsedImportItems.length - 20} more items
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-foreground/20">
              <button
                onClick={() => setClearModal(true)}
                className="text-xs text-destructive hover:underline font-bold"
              >
                Clear Entire Menu
              </button>

              <div className="flex gap-3">
                <button
                  onClick={() => setImportModal(false)}
                  className="border border-foreground px-4 py-2 text-xs uppercase font-semibold hover:bg-muted"
                >
                  Cancel
                </button>
                <button
                  disabled={!parsedImportItems.length}
                  onClick={executeImport}
                  className="border border-foreground bg-primary text-primary-foreground px-6 py-2 text-xs uppercase tracking-wider font-bold disabled:opacity-50"
                >
                  Import {parsedImportItems.length} Items
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Clear Menu Confirmation Modal */}
      {clearModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-card border-2 border-destructive max-w-sm w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-destructive font-bold">
              <AlertTriangle size={20} />
              <span>Confirm Clear All Menu</span>
            </div>
            <p className="text-xs text-foreground leading-relaxed">
              Are you sure you want to delete ALL {items.length} menu dishes? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setClearModal(false)}
                className="border border-foreground px-3 py-1.5 text-xs uppercase font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="border border-destructive bg-destructive text-destructive-foreground px-4 py-1.5 text-xs uppercase font-bold"
              >
                Yes, Delete All
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Menu Items Table */}
      <div
        className="mt-6 border border-foreground bg-card overflow-x-auto shadow-sm"
        data-testid="menu-table"
      >
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-muted text-left">
              {["Dish", "Category", "Price / Portions (GST Incl.)", "Type", "Station", "Status", "Actions"].map(
                (h) => (
                  <th
                    key={h}
                    className="border-b border-foreground px-4 py-3 overline whitespace-nowrap"
                  >
                    {h}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((i) => (
              <tr
                key={i.id}
                data-testid={`menu-row-${i.id}`}
                className="border-b border-foreground/15 hover:bg-muted/60"
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {i.image_url ? (
                      <img
                        src={i.image_url}
                        alt={i.name}
                        className="w-11 h-11 rounded-lg object-cover border border-foreground/30 shrink-0 bg-muted"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-11 h-11 rounded-lg border border-foreground/20 bg-muted/60 flex items-center justify-center shrink-0 text-muted-foreground text-xs font-bold font-mono">
                        {i.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <div>
                      <p className="font-semibold text-foreground leading-snug">{i.name}</p>
                      {i.description && (
                        <p className="text-xs text-muted-foreground truncate max-w-xs">{i.description}</p>
                      )}
                      {Array.isArray(i.suggested_items) && i.suggested_items.length > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-[10px] font-bold text-amber-900 bg-amber-50 border border-amber-300 px-1.5 py-0.2 rounded flex items-center gap-1">
                            <Sparkles size={10} className="text-amber-600" /> {i.suggested_items.length} Pairings
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap font-medium text-xs uppercase tracking-wider">
                  {i.category}
                </td>
                <td className="px-4 py-3 whitespace-nowrap font-mono">
                  {i.has_variants && i.variants && i.variants.length >= 2 ? (
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-foreground flex items-center gap-1.5">
                        <span className="bg-primary/10 text-primary px-1.5 py-0.5 rounded text-[10px] uppercase font-bold">
                          {i.variants[0].name}
                        </span>
                        <span>{money(i.variants[0].price)}</span>
                      </div>
                      <div className="text-xs font-bold text-foreground flex items-center gap-1.5">
                        <span className="bg-foreground/10 text-foreground px-1.5 py-0.5 rounded text-[10px] uppercase font-bold">
                          {i.variants[1].name}
                        </span>
                        <span>{money(i.variants[1].price)}</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-sm font-bold text-foreground">
                      {money(i.price)}
                    </span>
                  )}
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2 py-0.5 border ${
                      i.veg
                        ? "border-emerald-600 text-emerald-700 bg-emerald-50"
                        : "border-red-600 text-red-700 bg-red-50"
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${i.veg ? "bg-emerald-600" : "bg-red-600"}`}
                    />
                    {i.veg ? "Veg" : "Non-Veg"}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs uppercase opacity-80 whitespace-nowrap">
                  {i.station || "kitchen"}
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleItemAvailability(i)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-wider rounded border transition shadow-sm ${
                      i.available !== false
                        ? "bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700"
                        : "bg-red-100 text-red-800 border-red-300 hover:bg-red-200"
                    }`}
                    title="Click to toggle In Stock / Out of Stock"
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        i.available !== false ? "bg-white animate-pulse" : "bg-red-600"
                      }`}
                    />
                    {i.available !== false ? "In Stock" : "Out of Stock"}
                  </button>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <div className="flex gap-2">
                    <button
                      data-testid={`edit-menu-${i.id}`}
                      onClick={() => startEdit(i)}
                      className="border border-foreground p-1.5 hover:bg-muted"
                      title="Edit dish"
                    >
                      <Pencil size={13} />
                    </button>
                    <button
                      data-testid={`delete-menu-${i.id}`}
                      onClick={() => remove(i.id)}
                      className="border border-foreground p-1.5 hover:bg-destructive hover:text-destructive-foreground"
                      title="Delete dish"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {!filteredItems.length && (
              <tr>
                <td colSpan={7} className="text-center py-12 text-muted-foreground text-sm">
                  No dishes found matching your filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
