import { useEffect, useMemo, useState, useRef } from "react";
import { toast } from "sonner";
import { api, errMsg, money, API } from "@/lib/api";
import {
  Minus,
  Plus,
  Trash2,
  Search,
  Printer,
  ChefHat,
  RefreshCw,
  Award,
  Tag,
  Share2,
  CheckCircle2,
  MessageSquare,
  Sparkles,
  Edit3,
  Plug,
  X,
  Layers,
  Image as ImageIcon,
} from "lucide-react";
import {
  saveMenuCache,
  getMenuCache,
  saveOfflineOrder,
  getPendingOfflineOrders,
} from "@/lib/offlineDb";
import { isOnline, syncOfflineOrders, subscribeSyncStatus } from "@/lib/syncEngine";
import { generateEscPosInvoice, generateEscPosKot, generateTvsTestSlip } from "@/lib/escpos";
import {
  connectSerialPrinter,
  connectWebUsbPrinter,
  printViaUsbOrSerial,
  disconnectUsbPrinter,
  isWebSerialSupported,
  isWebUsbSupported,
} from "@/lib/usbPrinter";
import {
  checkPrintAgentStatus,
  subscribeAgentStatus,
  printViaLocalAgent,
  printAgentTestSlip,
} from "@/lib/printAgentClient";

const round2 = (num) => Math.round((Number(num) || 0) * 100) / 100;

export default function Pos() {
  const [items, setItems] = useState([]);
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const [lines, setLines] = useState([]);
  const [meta, setMeta] = useState({
    customer_name: "Walk-in Guest",
    phone: "",
    table_no: "",
    order_type: "dine-in",
    payment_mode: "cash",
  });
  const [busy, setBusy] = useState(false);
  const [bill, setBill] = useState(null);

  // Petpooja-Style Local Print Agent State (ws://127.0.0.1:8989)
  const [localAgent, setLocalAgent] = useState(null);

  // Direct USB / Serial Printer State
  const [usbPrinter, setUsbPrinter] = useState(null);
  const [connectingUsb, setConnectingUsb] = useState(false);

  // E-Bill & WhatsApp modal state
  const [ebillModal, setEbillModal] = useState(null);
  const [ebillPhone, setEbillPhone] = useState("");

  // Customer Loyalty State
  const [loyaltyInfo, setLoyaltyInfo] = useState(null);
  const [cashTendered, setCashTendered] = useState("");

  // Discount & Coupon State
  const [discountCode, setDiscountCode] = useState("");
  const [customDiscount, setCustomDiscount] = useState(0);
  const [couponInfo, setCouponInfo] = useState(null);

  // Active Editing Note for Line Item
  const [editingNoteId, setEditingNoteId] = useState(null);

  // Portion Variant Selection Modal Item (Single/Half vs Full)
  const [variantModalItem, setVariantModalItem] = useState(null);

  // Offline state (80mm TVS Thermal is the locked standard)
  const [online, setOnline] = useState(isOnline());
  const [pendingSync, setPendingSync] = useState(0);
  const paperWidth = "80mm";

  // Search input ref for keyboard shortcut
  const searchInputRef = useRef(null);

  // Load menu & setup sync listeners
  useEffect(() => {
    loadMenu();
    updatePendingCount();

    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    const unsubscribe = subscribeSyncStatus((evt) => {
      if (evt.type === "SYNC_COMPLETE") {
        updatePendingCount();
        if (evt.synced > 0) {
          toast.success(`Synced ${evt.synced} offline bill(s) with server`);
        }
      }
    });

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      unsubscribe();
    };
  }, []);

  // Persistent Subscription to Petpooja-Style Local Print Agent (ws://127.0.0.1:8989)
  useEffect(() => {
    const unsub = subscribeAgentStatus((status) => {
      setLocalAgent(status);
    });
    return () => unsub();
  }, []);

  // Keyboard Shortcuts (F2: Search, F4: Print Bill, F8: E-Bill, F9: KOT, Esc: Clear)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "F2") {
        e.preventDefault();
        searchInputRef.current?.focus();
      } else if (e.key === "F4") {
        e.preventDefault();
        if (lines.length && !busy) executeOrderAndPrint("print_bill");
      } else if (e.key === "F8") {
        e.preventDefault();
        if (lines.length && !busy) executeOrderAndPrint("save_ebill");
      } else if (e.key === "F9") {
        e.preventDefault();
        if (lines.length && !busy) executeOrderAndPrint("print_kot");
      } else if (e.key === "Escape") {
        if (lines.length) {
          setLines([]);
          toast.info("Current bill cleared");
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines, busy, meta]);

  const updatePendingCount = async () => {
    const pending = await getPendingOfflineOrders();
    setPendingSync(pending.length);
  };

  const loadMenu = async () => {
    try {
      const { data } = await api.get("/menu");
      setItems(data);
      saveMenuCache(data);
    } catch (e) {
      console.warn("API unreachable, attempting offline menu cache fetch:", e);
      const cached = await getMenuCache();
      if (cached && cached.length) {
        setItems(cached);
        toast.info("Using cached menu items (Offline mode)");
      } else {
        toast.error("No menu items available offline");
      }
    }
  };

  const handlePhoneChange = async (val) => {
    setMeta((p) => ({ ...p, phone: val }));
    const clean = val.replace(/\D/g, "");
    if (clean.length >= 10 && online) {
      try {
        const { data } = await api.get(`/customers/lookup?phone=${clean}`);
        if (data.found) {
          setMeta((p) => ({ ...p, customer_name: data.customer_name || p.customer_name }));
          setLoyaltyInfo(data);
          toast.success(`Welcome ${data.customer_name}! (${data.loyalty_points} Loyalty Points)`);
        } else {
          setLoyaltyInfo(null);
        }
      } catch {
        setLoyaltyInfo(null);
      }
    } else {
      setLoyaltyInfo(null);
    }
  };

  const handleApplyCoupon = async () => {
    if (!discountCode.trim()) return toast.error("Enter a coupon code");
    if (!subtotal) return toast.error("Add items to bill before applying coupon");
    try {
      const { data } = await api.get(`/coupons/validate?code=${discountCode.trim()}&subtotal=${subtotal}`);
      setCouponInfo(data);
      toast.success(`Coupon ${data.code} applied! Saved ${money(data.discount_amount)}`);
    } catch (e) {
      toast.error(errMsg(e));
      setCouponInfo(null);
    }
  };

  const triggerManualSync = async () => {
    if (!online) return toast.error("You are currently offline");
    setBusy(true);
    try {
      const res = await syncOfflineOrders();
      await updatePendingCount();
      if (res?.successCount > 0) {
        toast.success(`Successfully synced ${res.successCount} offline bill(s)`);
      } else if (res?.failCount > 0) {
        toast.error(`Failed to sync ${res.failCount} bill(s)`);
      } else {
        toast.info("No pending offline bills to sync");
      }
    } finally {
      setBusy(false);
    }
  };

  const [categoriesOrder, setCategoriesOrder] = useState([]);

  useEffect(() => {
    api.get("/menu/categories")
      .then((r) => {
        if (r.data?.categories) setCategoriesOrder(r.data.categories);
      })
      .catch(() => {});
  }, []);

  const cats = useMemo(() => {
    const set = new Set(items.map((i) => i.category).filter(Boolean));
    const ordered = ["All"];
    const preferredOrder = categoriesOrder.length
      ? categoriesOrder
      : ["Tea", "Tiffins", "Snacks", "Biryani", "Starters", "Tandoori Kebabs", "Currys", "Rotis", "Shawarma", "Sweets", "Fried Rice", "Noodles"];

    preferredOrder.forEach((c) => {
      for (const itemCat of set) {
        if (itemCat.toLowerCase() === c.toLowerCase()) {
          if (!ordered.includes(itemCat)) ordered.push(itemCat);
        }
      }
    });

    for (const itemCat of set) {
      if (!ordered.includes(itemCat)) ordered.push(itemCat);
    }
    return ordered;
  }, [items, categoriesOrder]);

  const shown = useMemo(() => {
    return items.filter(
      (i) => (cat === "All" || i.category === cat) && i.name.toLowerCase().includes(q.toLowerCase())
    );
  }, [items, cat, q]);

  const subtotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
  const discountAmount = couponInfo ? couponInfo.discount_amount : Math.min(subtotal, Number(customDiscount || 0));
  const total = Math.max(0, subtotal - discountAmount);

  // Cart item lines map for quick quantity count (including variant items)
  const cartQtyMap = useMemo(() => {
    const map = {};
    for (const l of lines) {
      map[l.item_id] = (map[l.item_id] || 0) + l.qty;
      // Also map base id for items with composite variant IDs (e.g. 64a..._single)
      if (l.item_id && l.item_id.includes("_")) {
        const baseId = l.item_id.split("_")[0];
        map[baseId] = (map[baseId] || 0) + l.qty;
      }
    }
    return map;
  }, [lines]);

  // Click handler for menu grid item
  const handleItemClick = (i) => {
    if (!i.available) return;
    if (i.has_variants && i.variants && i.variants.length >= 2) {
      setVariantModalItem(i);
    } else {
      add(i);
    }
  };

  const add = (i) =>
    setLines((p) =>
      p.find((l) => l.item_id === i.id)
        ? p.map((l) => (l.item_id === i.id ? { ...l, qty: l.qty + 1 } : l))
        : [...p, { item_id: i.id, name: i.name, price: Number(i.price) || 0, qty: 1, station: i.station || "kitchen", notes: "" }]
    );

  const addVariant = (item, variant) => {
    const lineId = `${item.id}_${variant.name.toLowerCase()}`;
    const lineName = `${item.name} (${variant.name})`;
    setLines((p) => {
      const existing = p.find((l) => l.item_id === lineId);
      if (existing) {
        return p.map((l) => (l.item_id === lineId ? { ...l, qty: l.qty + 1 } : l));
      }
      return [
        ...p,
        {
          item_id: lineId,
          base_item_id: item.id,
          name: lineName,
          variant: variant.name,
          price: Number(variant.price),
          qty: 1,
          station: item.station || "kitchen",
          notes: "",
        },
      ];
    });
    setVariantModalItem(null);
    toast.success(`Added ${lineName} to bill 📋`, { duration: 1200 });
  };

  const setQty = (id, qty) =>
    setLines((p) => (qty <= 0 ? p.filter((l) => l.item_id !== id) : p.map((l) => (l.item_id === id ? { ...l, qty } : l))));

  const updateItemNote = (id, noteText) => {
    setLines((p) => p.map((l) => (l.item_id === id ? { ...l, notes: noteText } : l)));
  };

  const handleConnectUsbPrinter = async () => {
    setConnectingUsb(true);
    try {
      if (!isWebUsbSupported()) {
        toast.error("WebUSB is not supported in this browser. Please use Google Chrome or Microsoft Edge.");
        return;
      }
      const p = await connectWebUsbPrinter();
      setUsbPrinter(p);
      toast.success(`🟢 TVS USB Printer Connected: ${p.name || "RP 3200"}`);
    } catch (err) {
      console.warn("WebUSB connect error:", err);
      if (err.name !== "NotFoundError" && !err.message?.includes("No USB printer selected")) {
        toast.error(err.message || "Failed to connect to USB printer");
      }
    } finally {
      setConnectingUsb(false);
    }
  };

  const handleConnectSerialPrinter = async () => {
    setConnectingUsb(true);
    try {
      if (!isWebSerialSupported()) {
        toast.error("WebSerial is not supported in this browser. Please use Google Chrome or Microsoft Edge.");
        return;
      }
      const p = await connectSerialPrinter(9600);
      setUsbPrinter(p);
      toast.success("🟢 TVS RP 3200 Connected via Serial/COM!");
    } catch (err) {
      console.warn("Serial connect error:", err);
      if (err.name !== "NotFoundError" && !err.message?.includes("No printer selected")) {
        toast.error(err.message || "Failed to connect to Serial/COM port");
      }
    } finally {
      setConnectingUsb(false);
    }
  };

  const handleDisconnectUsbPrinter = async () => {
    await disconnectUsbPrinter();
    setUsbPrinter(null);
    toast.info("TVS USB Printer disconnected");
  };

  const handlePrintTestSlip = async () => {
    // 1. Petpooja-Style Local Print Agent (Fastest & 100% Reliable Raw Spooler)
    if (localAgent && localAgent.status === "online") {
      try {
        await printAgentTestSlip();
        toast.success(`🟢 TVS RP 3200 Test Slip Printed via Petpooja Agent (${localAgent.printer})`);
        return;
      } catch (err) {
        console.warn("Print agent test error, trying WebUSB/browser:", err);
      }
    }

    // 2. Direct WebUSB
    if (usbPrinter && usbPrinter.connected) {
      try {
        const buffer = generateTvsTestSlip("80mm");
        await printViaUsbOrSerial(buffer);
        toast.success("Printed TVS RP 3200 Test Slip (Direct USB)");
        return;
      } catch (e) {
        console.warn("Direct USB test print failed, falling back to browser print:", e);
        toast.error("Direct USB failed, falling back to browser print");
      }
    }

    // 3. Browser Print Fallback
    const mockBill = {
      order_no: "97889",
      token_no: "1047",
      customer_name: "",
      phone: "",
      order_type: "dine-in",
      table_no: "8",
      payment_mode: "cash",
      created_at: new Date().toISOString(),
      items: [
        { name: "Hydi Irani Tea", qty: 1, price: 20 },
      ],
      subtotal: 20,
      discount: 0,
      total: 20,
    };
    printThermalBrowser(mockBill, "invoice");
    toast.success("Printed TVS RP 3200 Test Bill");
  };

  const renderThermalReceiptHtml = (targetBill, type = "invoice", width = "80mm") => {
    const isKot = type === "kot";
    const orderNo = targetBill.order_no || targetBill.offline_id || "97889";
    const tokenNo = targetBill.token_no || (orderNo.length > 4 ? orderNo.slice(-4) : orderNo);
    
    const d = targetBill.created_at ? new Date(targetBill.created_at) : new Date();
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = String(d.getFullYear()).slice(-2);
    const dateStr = `${day}/${month}/${year}`;
    const hours = String(d.getHours()).padStart(2, "0");
    const mins = String(d.getMinutes()).padStart(2, "0");
    const timeStr = `${hours}:${mins}`;

    const orderType = String(targetBill.order_type || "dine-in").toLowerCase();
    const tableOrType = orderType === "dine-in"
      ? `Dine In: ${targetBill.table_no || "Counter"}`
      : "Take Away";

    const subtotalVal = round2(targetBill.subtotal || 0).toFixed(2);
    const discountVal = round2(targetBill.discount || 0);
    const totalVal = round2(targetBill.total != null ? targetBill.total : targetBill.subtotal - discountVal).toFixed(2);
    
    let totalQty = 0;
    const itemsRows = (targetBill.items || []).map(item => {
      const qty = Number(item.qty) || 1;
      const price = Number(item.price) || 0;
      const amt = (qty * price).toFixed(2);
      totalQty += qty;
      return `
        <tr>
          <td style="text-align: left; padding: 2px 4px 2px 0; word-break: break-word; font-weight: 500;">
            ${item.name}
            ${item.notes ? `<div style="font-size: 10px; font-style: italic; color: #333;">👉 Note: ${item.notes}</div>` : ""}
          </td>
          <td style="text-align: center; padding: 2px 4px; font-weight: 500;">&nbsp;${qty}&nbsp;</td>
          ${!isKot ? `
            <td style="text-align: right; padding: 2px 4px; font-weight: 500;">&nbsp;${price.toFixed(2)}&nbsp;</td>
            <td style="text-align: right; padding: 2px 0 2px 4px; font-weight: 500;">&nbsp;${amt}</td>
          ` : ""}
        </tr>
      `;
    }).join("");

    const custName = targetBill.customer_name && targetBill.customer_name !== "Walk-in Guest" ? targetBill.customer_name : "";

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>${isKot ? "KOT" : "Bill"}_${orderNo}</title>
          <style>
            @page {
              size: 80mm auto;
              margin: 0;
            }
            @media print {
              @page {
                size: 80mm auto;
                margin: 0;
              }
              html, body {
                margin: 0 !important;
                padding: 0 !important;
                width: 64mm !important;
                max-width: 64mm !important;
              }
            }
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body {
              font-family: Arial, "Noto Sans", "Segoe UI", Helvetica, sans-serif;
              font-size: 11.5px;
              line-height: 1.2;
              color: #000;
              background: #fff;
              width: 64mm;
              max-width: 64mm;
              margin: 0;
              padding: 0 1.5mm 2mm 1mm;
              -webkit-print-color-adjust: exact;
            }
            table { width: 100%; border-collapse: collapse; table-layout: fixed; }
            td, th { vertical-align: top; }
            .divider { border-top: 1px solid #000; margin: 2px 0; }
          </style>
        </head>
        <body>
          <!-- 1. Store Header -->
          <div style="text-align: center; margin-bottom: 2px;">
            <div style="font-size: 14px; font-weight: 800; letter-spacing: 0.5px;">HYDERABADI IRANI</div>
            <div style="font-size: 10.5px; margin-top: 1px;">PLOT NO:38,CHANDRA</div>
            <div style="font-size: 10.5px;">PROPERTIES,RAMPALLY, Hyderabad</div>
            <div style="font-size: 10.5px;">501301</div>
          </div>
          <div class="divider"></div>

          <!-- 2. Customer Name -->
          ${custName ? `
            <div style="font-size: 11.5px; padding: 1px 0;">
              Name: &nbsp;${custName}
            </div>
            <div class="divider"></div>
          ` : ""}

          <!-- 3. Order Info -->
          <table style="font-size: 11px; margin: 1px 0;">
            <tr>
              <td style="text-align: left; width: 46%;">Date: ${dateStr}</td>
              <td style="text-align: right; width: 54%; font-weight: 800; font-size: 11.5px; word-break: break-word;">${tableOrType}</td>
            </tr>
            <tr>
              <td style="text-align: left;" colspan="2">${timeStr}</td>
            </tr>
            <tr>
              <td style="text-align: left; width: 44%;">Cashier: biller</td>
              <td style="text-align: right; width: 56%; word-break: break-all;">Bill No: ${orderNo}</td>
            </tr>
            <tr>
              <td style="text-align: left; font-weight: 800; font-size: 12px; padding-top: 1px;" colspan="2">Token No.: ${tokenNo}</td>
            </tr>
          </table>
          <div class="divider"></div>

          <!-- 4. Line Items Table -->
          <table style="font-size: 11px; margin: 2px 0;">
            <thead>
              <tr style="border-bottom: 1px solid #000;">
                <th style="text-align: left; width: 42%; padding: 1px 2px 1px 0; font-weight: 700;">Item</th>
                <th style="text-align: center; width: 14%; padding: 1px 2px; font-weight: 700;">Qty.</th>
                ${!isKot ? `
                  <th style="text-align: right; width: 20%; padding: 1px 2px; font-weight: 700;">Price</th>
                  <th style="text-align: right; width: 24%; padding: 1px 0 1px 2px; font-weight: 700;">Amount</th>
                ` : ""}
              </tr>
            </thead>
            <tbody>
              ${itemsRows}
            </tbody>
          </table>
          <div class="divider"></div>

          <!-- 5. Totals -->
          ${!isKot ? `
            <table style="font-size: 11px; margin: 2px 0;">
              <tr>
                <td style="text-align: left; width: 45%; font-weight: 600; padding: 1px 0;">Total Qty: ${totalQty}</td>
                <td style="text-align: right; width: 55%; font-weight: 600; padding: 1px 0;">Sub Total &nbsp;${subtotalVal}</td>
              </tr>
              ${discountVal > 0 ? `
                <tr>
                  <td style="text-align: left; padding: 1px 0;">Discount</td>
                  <td style="text-align: right; padding: 1px 0;">-${discountVal.toFixed(2)}</td>
                </tr>
              ` : ""}
            </table>
            <div class="divider"></div>

            <table style="margin: 2px 0;">
              <tr>
                <td style="text-align: left; font-size: 13px; font-weight: 800; padding: 2px 0;">Grand Total</td>
                <td style="text-align: right; font-size: 13px; font-weight: 800; padding: 2px 0;">Rs. ${totalVal}</td>
              </tr>
            </table>
            <div class="divider"></div>
          ` : ""}

          <!-- 6. Footer -->
          <div style="text-align: center; margin: 3px 0 2px 0; font-size: 11px;">
            ${!isKot ? "<div>Thanks</div>" : "<div>--- KOT Ready ---</div>"}
            <div style="font-size: 9.5px; font-weight: 700; letter-spacing: 0.3px; color: #222; margin-top: 2px;">
              Powered by NovaSaaS
            </div>
          </div>
        </body>
      </html>
    `;
  };

  const printThermalBrowser = (targetBill, type = "invoice") => {
    try {
      const htmlContent = renderThermalReceiptHtml(targetBill, type, "80mm");
      
      // Remove any existing print iframes to avoid overlaps
      const oldIframe = document.getElementById("pos-thermal-print-frame");
      if (oldIframe) {
        oldIframe.remove();
      }

      const iframe = document.createElement("iframe");
      iframe.id = "pos-thermal-print-frame";
      iframe.style.position = "fixed";
      iframe.style.right = "0";
      iframe.style.bottom = "0";
      iframe.style.width = "0";
      iframe.style.height = "0";
      iframe.style.border = "0";
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow.document;
      doc.open();
      doc.write(htmlContent);
      doc.close();

      iframe.contentWindow.focus();
      setTimeout(() => {
        iframe.contentWindow.print();
        setTimeout(() => {
          if (iframe && iframe.parentNode) {
            iframe.parentNode.removeChild(iframe);
          }
        }, 2000);
      }, 300);
    } catch (e) {
      console.warn("Direct iframe print failed:", e);
      toast.error("Print dialog failed to open");
    }
  };

  const triggerAutoPrint = async (targetBill, type = "invoice") => {
    if (!targetBill) return;

    // 1. Try Petpooja-Style Local Agent (100% Instant, 0 Dialogs, Raw Spool)
    try {
      const buf = type === "kot" 
        ? generateEscPosKot(targetBill, "80mm") 
        : generateEscPosInvoice(targetBill, "80mm");
      await printViaLocalAgent(buf);
      toast.success(`🟢 ${type === "kot" ? "KOT" : "Receipt"} printed automatically via Print Agent`);
      return true;
    } catch (err) {
      console.warn("Print agent print attempt failed/not running, trying USB/browser:", err);
    }

    // 2. Try Direct WebUSB / Serial
    if (usbPrinter && usbPrinter.connected) {
      try {
        const buf = type === "kot" 
          ? generateEscPosKot(targetBill, "80mm") 
          : generateEscPosInvoice(targetBill, "80mm");
        await printViaUsbOrSerial(buf);
        toast.success(`🟢 ${type === "kot" ? "KOT" : "Receipt"} printed directly to TVS RP 3200`);
        return true;
      } catch (err) {
        console.warn("Direct USB print error, falling back to browser print:", err);
      }
    }

    // 3. Fallback: Browser Print (If launched with Chrome --kiosk-printing, this is 100% silent 0-click)
    printThermalBrowser(targetBill, type);
    return false;
  };

  const getISTBizDateStr = () => {
    const now = new Date();
    const utc = now.getTime() + now.getTimezoneOffset() * 60000;
    const ist = new Date(utc + 3600000 * 5.5);
    if (ist.getHours() < 4) {
      ist.setDate(ist.getDate() - 1);
    }
    const yy = String(ist.getFullYear()).slice(-2);
    const mm = String(ist.getMonth() + 1).padStart(2, "0");
    const dd = String(ist.getDate()).padStart(2, "0");
    return `${yy}${mm}${dd}`;
  };

  const getNextLocalSequence = () => {
    const bizDate = getISTBizDateStr();
    const key = `pos_local_seq_${bizDate}`;
    const current = parseInt(localStorage.getItem(key) || "0", 10);
    const next = current + 1;
    localStorage.setItem(key, next.toString());
    return next;
  };

  const executeOrderAndPrint = async (actionType = "print_bill") => {
    if (!lines.length) return toast.error("Add items to the bill first");
    setBusy(true);

    const orderPayload = {
      ...meta,
      customer_name: meta.customer_name.trim() || "Walk-in Guest",
      // See the identical fix in Checkout.jsx / CartContext.jsx — item_id
      // on a variant line is the cart line key, not the real menu item id.
      items: lines.map((l) => ({ ...l, item_id: l.base_item_id || l.item_id })),
      discount_code: couponInfo?.code || (discountCode ? discountCode.toUpperCase() : ""),
      discount: discountAmount,
      address: "",
      notes: "",
    };

    let generatedBill = null;
    let isOfflineBill = false;

    if (online) {
      try {
        const { data } = await api.post("/orders", orderPayload);
        generatedBill = data;
        toast.success(`Bill #${data.order_no} created successfully`);
      } catch (e) {
        console.warn("Online order creation failed, falling back to offline bill:", e);
        isOfflineBill = true;
      }
    } else {
      isOfflineBill = true;
    }

    if (isOfflineBill) {
      const bizDate = getISTBizDateStr();
      const seq = getNextLocalSequence();
      const seqStr = seq.toString().padStart(4, "0");
      const orderNo = `${bizDate}-${seqStr}`;
      const offlineId = `OFF-${orderNo}`;
      generatedBill = {
        ...orderPayload,
        offline_id: offlineId,
        order_no: orderNo,
        token_no: seqStr,
        subtotal,
        discount: discountAmount,
        tax: 0,
        total,
        created_at: new Date().toISOString(),
        status: "placed",
        synced: false,
      };

      try {
        await saveOfflineOrder(generatedBill);
        await updatePendingCount();
        toast.success(`Bill #${orderNo} saved locally (Queued for sync)`);
      } catch (err) {
        toast.error("Failed to save offline bill locally");
      }
    }

    setBill(generatedBill);
    setLines([]);
    setDiscountCode("");
    setCustomDiscount(0);
    setCouponInfo(null);
    setLoyaltyInfo(null);
    setCashTendered("");
    setBusy(false);

    // Direct 1-Tap Thermal Printing Actions (TVS RP 3200)
    if (generatedBill) {
      if (actionType === "print_bill") {
        await triggerAutoPrint(generatedBill, "invoice");
      } else if (actionType === "save_ebill") {
        setEbillPhone(generatedBill.phone || "");
        setEbillModal(generatedBill);
      } else if (actionType === "print_kot") {
        await triggerAutoPrint(generatedBill, "kot");
      } else if (actionType === "print_both") {
        await triggerAutoPrint(generatedBill, "invoice");
        setTimeout(() => triggerAutoPrint(generatedBill, "kot"), 500);
      }
    }
  };

  const openWhatsAppEbill = (orderData, targetPhone) => {
    const p = (targetPhone || orderData.phone || "").replace(/\D/g, "");
    if (!p) {
      return toast.error("Please enter a customer mobile number to send WhatsApp E-Bill");
    }

    const itemsSummary = (orderData.items || [])
      .map((it) => `• ${it.qty}x ${it.name} - ₹${(it.qty * it.price).toFixed(2)}`)
      .join("\n");

    const message = `*HYDERABADI IRANI FOOD COURT* ☕\n🧾 *E-Bill Receipt: #${orderData.order_no}*\n━━━━━━━━━━━━━━━━━━━━\n👤 Guest: ${orderData.customer_name || "Walk-in"}\n🍽️ Type: ${(orderData.order_type || "Dine-in").toUpperCase()} ${orderData.table_no ? `(Table: ${orderData.table_no})` : ""}\n💳 Payment: ${(orderData.payment_mode || "CASH").toUpperCase()}\n━━━━━━━━━━━━━━━━━━━━\n${itemsSummary}\n━━━━━━━━━━━━━━━━━━━━\n*Total Amount: ₹${(orderData.total != null ? orderData.total : orderData.subtotal).toFixed(2)}*\n\n📄 *View & Download Tax Invoice:* \nhttps://hyderabadiirani.net/track?order=${orderData.order_no}\n\n🙏 Thank you for dining with us! Visit again.\n_⚡ Powered by NovaSaaS_`;

    window.open(`https://api.whatsapp.com/send?phone=91${p}&text=${encodeURIComponent(message)}`, "_blank");
    toast.success("WhatsApp E-Bill link opened!");
  };

  const field = "border border-foreground bg-background px-2.5 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary w-full";

  // Change to return calculation
  const tenderedNum = Number(cashTendered) || 0;
  const changeToReturn = tenderedNum > total ? tenderedNum - total : 0;

  return (
    <div className="grid lg:grid-cols-[1fr_390px] xl:grid-cols-[1fr_420px] min-h-screen bg-background">
      {/* Menu / Catalog Section */}
      <section className="p-3 sm:p-5 lg:p-6 overflow-y-auto">
        {/* Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-foreground pb-3">
          <div className="flex items-center gap-2">
            {online ? (
              <span className="flex items-center gap-1 text-[11px] text-emerald-800 bg-emerald-100 font-bold px-2 py-0.5 rounded border border-emerald-300">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" /> ONLINE
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[11px] text-amber-900 bg-amber-200 font-bold px-2 py-0.5 rounded border border-amber-400">
                OFFLINE MODE ({pendingSync} queued)
              </span>
            )}
            {pendingSync > 0 && online && (
              <button
                onClick={triggerManualSync}
                disabled={busy}
                className="flex items-center gap-1 text-[11px] font-bold border border-foreground bg-amber-400 text-black px-2 py-0.5 hover:bg-amber-500"
              >
                <RefreshCw size={11} className={busy ? "animate-spin" : ""} /> Sync {pendingSync}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs">
            {localAgent && localAgent.status === "online" ? (
              <div className="flex items-center gap-1.5 bg-emerald-100 border border-emerald-400 px-2.5 py-1 rounded text-emerald-950 shadow-sm" title="Petpooja-Style Direct Spooler is Active on this PC">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                <span className="font-bold text-[11px]">⚡ Agent: {localAgent.printer || "TVS RP 3200"}</span>
              </div>
            ) : usbPrinter && usbPrinter.connected ? (
              <div className="flex items-center gap-1.5">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold border border-emerald-600 bg-emerald-50 text-emerald-900 rounded">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                  TVS RP 3200 (Direct USB)
                </span>
                <button
                  onClick={handleDisconnectUsbPrinter}
                  className="border border-foreground/30 bg-muted hover:bg-card px-2 py-1 text-[11px] font-bold rounded"
                  title="Disconnect USB"
                >
                  Disconnect
                </button>
              </div>
            ) : (
              <button
                onClick={async () => {
                  const st = await checkPrintAgentStatus();
                  if (st) {
                    setLocalAgent(st);
                    toast.success(`Connected to Petpooja Agent: ${st.printer}`);
                  } else {
                    handleConnectUsbPrinter();
                  }
                }}
                disabled={connectingUsb}
                className="border border-foreground bg-primary text-primary-foreground hover:opacity-90 px-3 py-1 text-xs font-bold uppercase transition rounded flex items-center gap-1.5 shadow-sm"
                title="Connect TVS RP 3200"
              >
                <Plug size={13} /> {connectingUsb ? "Connecting..." : "Connect TVS USB"}
              </button>
            )}

            <button
              onClick={handlePrintTestSlip}
              className="border border-foreground bg-card hover:bg-foreground hover:text-background px-3 py-1 text-xs font-bold uppercase transition rounded flex items-center gap-1 font-bold"
              title="Print TVS RP 3200 Test Slip"
            >
              <Printer size={13} /> Test Print
            </button>
          </div>
        </div>

        {/* Full View Wrapped Category Bar & Search */}
        <div className="mt-2.5 space-y-2">
          {/* Quick Category Buttons (All visible on single screen without sliding) */}
          <div className="flex flex-wrap items-center gap-1.5 bg-muted/40 p-2 rounded-lg border border-foreground/20">
            {cats.map((c) => {
              const count = c === "All" 
                ? items.length 
                : items.filter((i) => (i.category || "").toLowerCase() === c.toLowerCase()).length;
              return (
                <button
                  key={c}
                  data-testid={`pos-category-${c.toLowerCase().replace(/\s+/g, "-")}`}
                  onClick={() => setCat(c)}
                  className={`border px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider transition rounded-md flex items-center gap-1 shadow-xs active:scale-95 ${
                    cat === c
                      ? "bg-foreground text-background border-foreground shadow-sm"
                      : "bg-card text-foreground hover:bg-muted border-foreground/30 hover:border-foreground"
                  }`}
                >
                  <span>{c}</span>
                  {count > 0 && (
                    <span
                      className={`text-[9px] px-1 py-0.2 rounded-full font-mono font-semibold ${
                        cat === c ? "bg-background/20 text-background" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Fast Search Bar */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                ref={searchInputRef}
                data-testid="pos-search-input"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search dish name / item (Press F2)…"
                className={`${field} pl-8 py-1.5 rounded text-xs`}
              />
              {q && (
                <button
                  onClick={() => setQ("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground font-bold"
                >
                  ✕
                </button>
              )}
            </div>
            {q && (
              <span className="text-[11px] text-muted-foreground font-medium whitespace-nowrap">
                Found {shown.length} items
              </span>
            )}
          </div>
        </div>

        {/* Compact Menu Grid with 2-Line Name Visibility */}
        <div
          className="mt-3 grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2"
          data-testid="pos-item-grid"
        >
          {shown.map((i) => {
            const inCart = cartQtyMap[i.id] || 0;
            const hasPortions = Boolean(i.has_variants && i.variants && i.variants.length >= 2);
            return (
              <button
                key={i.id}
                data-testid={`pos-add-${i.id}`}
                onClick={() => handleItemClick(i)}
                disabled={!i.available}
                title={i.name}
                className={`text-left border border-foreground/30 bg-card p-2 sm:p-2.5 min-h-[82px] sm:min-h-[88px] flex flex-col justify-between hover:border-primary hover:shadow-sm active:scale-[0.98] transition rounded-lg relative overflow-hidden group disabled:opacity-40 ${
                  inCart > 0 ? "border-primary bg-amber-500/5 ring-1 ring-primary" : ""
                }`}
              >
                {/* Quantity Badge if in cart */}
                {inCart > 0 && (
                  <span className="absolute top-1.5 right-1.5 bg-primary text-primary-foreground font-mono font-extrabold text-[10px] px-1.5 py-0.5 rounded-full shadow z-10">
                    {inCart}x
                  </span>
                )}

                <div className={inCart > 0 ? "pr-6" : ""}>
                  <div className="flex items-center gap-1">
                    <p className="text-xs sm:text-[12.5px] font-bold leading-snug line-clamp-2 break-words group-hover:text-primary transition">
                      {i.name}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between w-full mt-1 pt-1 border-t border-foreground/5">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-muted-foreground uppercase font-medium truncate max-w-[80px]">
                      {i.category}
                    </span>
                    {hasPortions && (
                      <span className="bg-primary/10 text-primary font-bold text-[9px] px-1 py-0.2 rounded">
                        {i.variants[0].name}/{i.variants[1].name}
                      </span>
                    )}
                  </div>
                  <span className="font-mono text-xs sm:text-[13px] font-extrabold text-primary">
                    {hasPortions
                      ? `₹${i.variants[0].price} / ₹${i.variants[1].price}`
                      : money(i.price)}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Ultra-Compact POS Billing Sidebar */}
      <aside className="bg-card p-3 sm:p-4 border-l border-foreground flex flex-col justify-between h-auto lg:h-screen lg:sticky lg:top-0 overflow-y-auto print:hidden">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between border-b border-foreground/20 pb-2.5">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">Current Bill</h2>
              <span className="bg-primary/10 text-primary font-mono text-xs font-bold px-2 py-0.5 rounded-full">
                {lines.reduce((s, l) => s + l.qty, 0)} Items
              </span>
            </div>
            {lines.length > 0 && (
              <button
                onClick={() => setLines([])}
                className="text-[11px] text-destructive hover:underline font-bold uppercase tracking-wider"
                title="Clear current bill (Esc)"
              >
                Clear (Esc)
              </button>
            )}
          </div>

          {/* Customer Details (100% Optional) */}
          <div className="mt-2.5 grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] uppercase font-bold tracking-wider text-muted-foreground mb-0.5">
                Phone (Optional)
              </label>
              <input
                data-testid="pos-phone-input"
                value={meta.phone}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder="10-digit mobile"
                className={field}
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold tracking-wider text-muted-foreground mb-0.5">
                Customer Name
              </label>
              <input
                data-testid="pos-customer-input"
                value={meta.customer_name}
                onChange={(e) => setMeta({ ...meta, customer_name: e.target.value })}
                placeholder="Walk-in Guest"
                className={field}
              />
            </div>

            {/* Loyalty Badge if customer recognized */}
            {loyaltyInfo && loyaltyInfo.found && (
              <div className="col-span-2 border border-emerald-500 bg-emerald-50 p-1.5 text-xs text-emerald-900 flex items-center justify-between rounded">
                <div className="flex items-center gap-1 font-semibold text-[11px]">
                  <Award size={13} className="text-emerald-600" />
                  <span>Loyalty Guest ({loyaltyInfo.total_orders} Orders)</span>
                </div>
                <span className="font-mono font-bold bg-emerald-600 text-white px-2 py-0.2 text-[10px] rounded-full">
                  {loyaltyInfo.loyalty_points} Pts
                </span>
              </div>
            )}

            {/* Table Selection & Order Type */}
            <div>
              <label className="block text-[10px] uppercase font-bold tracking-wider text-muted-foreground mb-0.5">
                Table (Optional)
              </label>
              <select
                data-testid="pos-table-select"
                value={meta.table_no}
                onChange={(e) => setMeta({ ...meta, table_no: e.target.value })}
                className={field}
              >
                <option value="">No Table (Counter)</option>
                {Array.from({ length: 50 }, (_, i) => {
                  const num = `T-${String(i + 1).padStart(2, "0")}`;
                  return (
                    <option key={num} value={num}>
                      Table {num}
                    </option>
                  );
                })}
              </select>
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold tracking-wider text-muted-foreground mb-0.5">
                Order Type
              </label>
              <select
                data-testid="pos-type-select"
                value={meta.order_type}
                onChange={(e) => setMeta({ ...meta, order_type: e.target.value })}
                className={field}
              >
                <option value="dine-in">🍽️ Dine-in</option>
                <option value="takeaway">🛍️ Takeaway</option>
                <option value="delivery">🛵 Delivery</option>
              </select>
            </div>
          </div>

          {/* Payment Mode Selector with Quick Tabs */}
          <div className="mt-2.5">
            <label className="block text-[10px] uppercase font-bold tracking-wider text-muted-foreground mb-1">
              Payment Mode
            </label>
            <div className="grid grid-cols-3 gap-1">
              {[
                { id: "cash", label: "💵 Cash" },
                { id: "upi", label: "📱 UPI / QR" },
                { id: "card", label: "💳 Card" },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMeta({ ...meta, payment_mode: m.id })}
                  className={`py-1.5 text-xs font-bold uppercase tracking-wider border border-foreground transition rounded ${
                    meta.payment_mode === m.id
                      ? "bg-foreground text-background shadow-sm"
                      : "bg-card hover:bg-muted text-foreground"
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Cash Tender / Change Calculator (When Cash mode is active) */}
          {meta.payment_mode === "cash" && lines.length > 0 && (
            <div className="mt-2 p-2 border border-foreground/20 bg-muted/30 rounded space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-semibold uppercase text-muted-foreground">Cash Tendered:</span>
                <input
                  type="number"
                  placeholder="₹ Amount"
                  value={cashTendered}
                  onChange={(e) => setCashTendered(e.target.value)}
                  className="w-24 border border-foreground px-2 py-0.5 text-xs font-mono font-bold bg-background text-right rounded"
                />
              </div>

              {/* Quick Cash Presets */}
              <div className="flex flex-wrap gap-1">
                <button
                  type="button"
                  onClick={() => setCashTendered(total.toString())}
                  className="border border-foreground/30 bg-card hover:bg-muted px-2 py-0.5 text-[10px] font-bold font-mono rounded"
                >
                  Exact ({money(total)})
                </button>
                {[50, 100, 200, 500, 2000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setCashTendered(amt.toString())}
                    className="border border-foreground/30 bg-card hover:bg-muted px-2 py-0.5 text-[10px] font-bold font-mono rounded"
                  >
                    ₹{amt}
                  </button>
                ))}
              </div>

              {tenderedNum >= total && tenderedNum > 0 && (
                <div className="flex justify-between items-center text-xs font-bold pt-1 border-t border-foreground/10 text-emerald-700">
                  <span>Change to Return:</span>
                  <span className="font-mono text-sm">₹{changeToReturn.toFixed(2)}</span>
                </div>
              )}
            </div>
          )}

          {/* Bill Line Items Table with Note/Customization Field */}
          <div className="mt-3 border border-foreground divide-y divide-foreground/10 max-h-[220px] overflow-y-auto rounded bg-card" data-testid="pos-bill-lines">
            {lines.length === 0 ? (
              <p data-testid="pos-bill-empty" className="p-4 text-center text-xs text-muted-foreground">
                Tap items on the left to add to bill.
              </p>
            ) : (
              lines.map((l) => (
                <div key={l.item_id} className="p-2 space-y-1" data-testid={`pos-line-${l.item_id}`}>
                  <div className="flex items-start gap-1.5">
                    <div className="flex-1 min-w-0 pr-1">
                      <p className="text-xs font-bold leading-tight line-clamp-2 break-words" title={l.name}>{l.name}</p>
                      <p className="font-mono text-[10px] text-muted-foreground mt-0.5">
                        {money(l.price)} · <span className="uppercase">{l.station || "kitchen"}</span>
                      </p>
                    </div>

                    <div className="flex items-center border border-foreground bg-background rounded shrink-0">
                      <button
                        data-testid={`pos-dec-${l.item_id}`}
                        onClick={() => setQty(l.item_id, l.qty - 1)}
                        className="p-1 hover:bg-muted"
                      >
                        <Minus size={10} />
                      </button>
                      <span className="font-mono text-xs w-5 text-center font-bold">{l.qty}</span>
                      <button
                        data-testid={`pos-inc-${l.item_id}`}
                        onClick={() => setQty(l.item_id, l.qty + 1)}
                        className="p-1 hover:bg-muted"
                      >
                        <Plus size={10} />
                      </button>
                    </div>

                    <span className="font-mono text-xs font-bold w-14 text-right shrink-0">
                      {money(l.price * l.qty)}
                    </span>

                    <button
                      data-testid={`pos-remove-${l.item_id}`}
                      onClick={() => setQty(l.item_id, 0)}
                      className="text-muted-foreground hover:text-destructive p-1 shrink-0"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>

                  {/* Optional Item Note / Kitchen Instructions */}
                  <div className="pl-0.5 flex items-center gap-1">
                    {editingNoteId === l.item_id ? (
                      <div className="flex items-center gap-1 w-full">
                        <input
                          type="text"
                          value={l.notes || ""}
                          onChange={(e) => updateItemNote(l.item_id, e.target.value)}
                          placeholder="e.g. Less spicy, No onion, Extra tea…"
                          className="flex-1 border border-foreground/30 bg-background px-1.5 py-0.5 text-[10px] rounded focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                        <button
                          type="button"
                          onClick={() => setEditingNoteId(null)}
                          className="text-[10px] font-bold bg-foreground text-background px-1.5 py-0.5 rounded"
                        >
                          Done
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setEditingNoteId(l.item_id)}
                        className="text-[10px] text-muted-foreground hover:text-primary flex items-center gap-1 italic"
                      >
                        <Edit3 size={9} />
                        {l.notes ? <span className="font-medium text-amber-800">Note: {l.notes}</span> : "+ Add Note"}
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Quick Discount & Coupon Bar (Compact) */}
          <div className="mt-2.5 p-2 border border-foreground/20 bg-muted/40 rounded space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-semibold">
              <span className="flex items-center gap-1 text-muted-foreground uppercase">
                <Tag size={12} /> Discount
              </span>
              {couponInfo && (
                <span className="text-emerald-700 font-bold">
                  {couponInfo.code}: -{money(couponInfo.discount_amount)}
                </span>
              )}
            </div>

            {/* Quick Discount Presets */}
            <div className="flex flex-wrap gap-1">
              {[
                { label: "5%", val: subtotal * 0.05 },
                { label: "10%", val: subtotal * 0.10 },
                { label: "₹20", val: 20 },
                { label: "₹50", val: 50 },
              ].map((d) => (
                <button
                  key={d.label}
                  type="button"
                  onClick={() => {
                    setCouponInfo(null);
                    setCustomDiscount(Math.round(d.val));
                  }}
                  className="border border-foreground/20 bg-card hover:bg-muted px-2 py-0.5 text-[10px] font-bold rounded"
                >
                  {d.label}
                </button>
              ))}
              {customDiscount > 0 && (
                <button
                  type="button"
                  onClick={() => setCustomDiscount(0)}
                  className="text-[10px] text-destructive hover:underline font-bold px-1"
                >
                  Reset
                </button>
              )}
            </div>

            <div className="flex gap-1.5">
              <input
                value={discountCode}
                onChange={(e) => setDiscountCode(e.target.value.toUpperCase())}
                placeholder="Coupon code (IRANI10)"
                className="flex-1 border border-foreground/30 px-2 py-0.5 text-[11px] uppercase bg-background rounded"
              />
              <button
                onClick={handleApplyCoupon}
                className="border border-foreground bg-foreground text-background px-2.5 py-0.5 text-[10px] uppercase font-bold rounded"
              >
                Apply
              </button>
            </div>
          </div>
        </div>

        {/* Calculation & Action Buttons */}
        <div className="mt-3 pt-2.5 border-t border-foreground">
          {/* Math Summary */}
          <div className="font-mono text-xs space-y-1 mb-2.5">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span data-testid="pos-subtotal">{money(subtotal)}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700 font-bold">
                <span>Discount Applied</span>
                <span>-{money(discountAmount)}</span>
              </div>
            )}
            <div className="flex justify-between text-base font-bold border-t border-foreground/20 pt-1 text-foreground">
              <span>Total Payable</span>
              <span data-testid="pos-total" className="text-primary text-lg">
                {money(total)}
              </span>
            </div>
          </div>

          {/* Action Buttons (Petpooja-style Super POS) */}
          <div className="space-y-1.5">
            {/* Primary Settle & Print Bill */}
            <button
              data-testid="direct-print-bill-btn"
              onClick={() => executeOrderAndPrint("print_bill")}
              disabled={busy || !lines.length}
              className="hard-shadow w-full border border-foreground bg-primary text-primary-foreground py-3 px-3 text-xs font-extrabold uppercase tracking-wider flex items-center justify-center gap-2 hover:opacity-95 disabled:opacity-40 rounded"
            >
              <Printer size={15} />
              {busy ? "Processing…" : `Print Bill · ${money(total)} (F4)`}
            </button>

            {/* Save & E-Bill (WhatsApp / SMS / QR) & KOT */}
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => executeOrderAndPrint("save_ebill")}
                disabled={busy || !lines.length}
                className="border border-emerald-600 bg-emerald-50 text-emerald-900 py-2 px-1 text-[11px] font-extrabold uppercase tracking-wider flex items-center justify-center gap-1 hover:bg-emerald-100 disabled:opacity-40 rounded"
                title="Save order and send instant WhatsApp E-Bill & Customer QR (F8)"
              >
                <Share2 size={12} className="text-emerald-700" /> Save & E-Bill
              </button>

              <button
                onClick={() => executeOrderAndPrint("print_kot")}
                disabled={busy || !lines.length}
                className="border border-foreground bg-card py-2 px-1 text-[11px] font-bold uppercase tracking-wider flex items-center justify-center gap-1 hover:bg-muted disabled:opacity-40 rounded"
                title="Print Kitchen Order Ticket (F9)"
              >
                <ChefHat size={12} className="text-primary" /> KOT
              </button>

              <button
                onClick={() => executeOrderAndPrint("save_only")}
                disabled={busy || !lines.length}
                className="border border-foreground bg-card py-2 px-1 text-[11px] font-bold uppercase tracking-wider flex items-center justify-center gap-1 hover:bg-muted disabled:opacity-40 rounded"
                title="Save without printing"
              >
                Save Only
              </button>
            </div>
          </div>

          {/* Last Bill Reference */}
          {bill && (
            <div className="mt-2.5 border border-foreground/20 bg-muted/40 p-2 rounded text-xs flex items-center justify-between">
              <div>
                <span className="text-[10px] text-muted-foreground uppercase font-bold block">Last Bill</span>
                <span className="font-mono font-bold">{bill.order_no} ({money(bill.total)})</span>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={() => openWhatsAppEbill(bill, bill.phone)}
                  className="p-1.5 bg-emerald-600 text-white rounded hover:bg-emerald-700"
                  title="Send WhatsApp E-Bill"
                >
                  <MessageSquare size={12} />
                </button>
                <button
                  onClick={() => triggerAutoPrint(bill, "invoice")}
                  className="p-1.5 border border-foreground bg-background rounded hover:bg-muted"
                  title="Re-print Bill"
                >
                  <Printer size={12} />
                </button>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Save & E-Bill Modal (Petpooja-style WhatsApp & QR Receipt) */}
      {ebillModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="border border-foreground bg-card p-6 sm:p-8 max-w-md w-full hard-shadow space-y-5 animate-in fade-in zoom-in-95 rounded-lg">
            <div className="flex items-start justify-between border-b border-foreground/20 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-extrabold tracking-tight">Order #{ebillModal.order_no}</h3>
                  <p className="text-xs text-muted-foreground">Order saved · Total: {money(ebillModal.total != null ? ebillModal.total : ebillModal.subtotal)}</p>
                </div>
              </div>
              <button
                onClick={() => setEbillModal(null)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold border border-foreground/20 px-2 py-1 rounded"
              >
                ✕
              </button>
            </div>

            {/* Customer Phone Input for WhatsApp Send */}
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-foreground">
                Customer WhatsApp Mobile Number
              </label>
              <div className="flex gap-2">
                <span className="inline-flex items-center px-3 border border-foreground bg-muted text-xs font-mono font-bold rounded">
                  +91
                </span>
                <input
                  type="text"
                  value={ebillPhone}
                  onChange={(e) => setEbillPhone(e.target.value)}
                  placeholder="Enter 10-digit mobile"
                  className="flex-1 border border-foreground bg-background px-3 py-2 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-primary rounded"
                />
              </div>

              <button
                type="button"
                onClick={() => openWhatsAppEbill(ebillModal, ebillPhone)}
                className="w-full hard-shadow bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 rounded transition"
              >
                <MessageSquare size={16} /> Send E-Bill on WhatsApp
              </button>
            </div>

            {/* Live On-Screen Customer Scan QR */}
            <div className="border border-foreground/20 bg-muted/40 p-4 rounded text-center space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground block">
                Or Scan QR for Instant Digital Bill
              </span>
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(`https://hyderabadiirani.net/track?order=${ebillModal.order_no}`)}`}
                alt="E-Bill QR Code"
                className="w-36 h-36 mx-auto border-2 border-foreground p-1 bg-white rounded shadow-sm"
              />
              <p className="text-[10px] text-muted-foreground">
                Customer can scan with phone camera to view and download bill.
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  triggerAutoPrint(ebillModal, "invoice");
                  setEbillModal(null);
                }}
                className="flex-1 border border-foreground bg-card hover:bg-muted py-2.5 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 rounded"
              >
                <Printer size={14} /> Print Paper Bill
              </button>
              <button
                type="button"
                onClick={() => setEbillModal(null)}
                className="border border-foreground px-4 py-2.5 text-xs font-bold uppercase tracking-wider hover:bg-muted rounded"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fast POS Portion Variant Selector Modal (Single/Half vs Full) */}
      {variantModalItem && (
        <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="border-2 border-foreground bg-card p-5 sm:p-6 max-w-sm w-full hard-shadow space-y-4 animate-in fade-in zoom-in-95 rounded-xl">
            <div className="flex items-start justify-between border-b border-foreground/20 pb-3">
              <div className="flex items-center gap-3">
                {variantModalItem.image_url ? (
                  <img
                    src={variantModalItem.image_url}
                    alt={variantModalItem.name}
                    className="w-12 h-12 rounded-lg object-cover border border-foreground/30 shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary border border-foreground/20 flex items-center justify-center font-bold text-xs">
                    {variantModalItem.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <div>
                  <h3 className="text-base font-extrabold tracking-tight leading-tight">
                    {variantModalItem.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] text-muted-foreground uppercase font-bold">
                      {variantModalItem.category}
                    </span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                        variantModalItem.veg
                          ? "border-emerald-600 text-emerald-700 bg-emerald-50"
                          : "border-red-600 text-red-700 bg-red-50"
                      }`}
                    >
                      {variantModalItem.veg ? "Veg" : "Non-Veg"}
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setVariantModalItem(null)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold border border-foreground/20 p-1.5 rounded hover:bg-muted"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Select Portion Size:
              </p>
              <div className="grid grid-cols-2 gap-3 pt-1">
                {variantModalItem.variants?.map((v, idx) => (
                  <button
                    key={v.name}
                    type="button"
                    autoFocus={idx === 0}
                    onClick={() => addVariant(variantModalItem, v)}
                    className="border-2 border-foreground bg-primary hover:bg-foreground text-primary-foreground hover:text-background p-4 rounded-xl flex flex-col items-center justify-center gap-1.5 transition active:scale-95 shadow-md group"
                  >
                    <span className="text-sm font-black uppercase tracking-wider">
                      {v.name}
                    </span>
                    <span className="font-mono text-base font-black">
                      ₹{v.price}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={() => setVariantModalItem(null)}
              className="w-full border border-foreground py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground rounded"
            >
              Cancel (Esc)
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
