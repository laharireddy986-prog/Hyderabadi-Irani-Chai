import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api, money, resolveImageUrl } from "@/lib/api";
import { useCart } from "@/context/CartContext";
import { useCustomerAuth } from "@/context/CustomerAuthContext";
import CustomerAuthModal from "@/components/CustomerAuthModal";
import { getMenuCache, saveMenuCache } from "@/lib/offlineDb";
import {
  ShoppingBag,
  Plus,
  Minus,
  Leaf,
  Search,
  Truck,
  Info,
  Sparkles,
  Clock,
  X,
  User,
  LogIn,
  Award,
  ShieldCheck,
  Flame,
  Star,
  CheckCircle2,
  HelpCircle,
  Coffee,
  ChevronDown,
  ChevronUp,
  Heart,
  Soup
} from "lucide-react";
import { DELIVERY_TERMS, FREE_DELIVERY_THRESHOLD, isNightSession } from "@/lib/deliveryTerms";
import { getCartPairings } from "@/lib/pairings";
import PairingShelf from "@/components/PairingShelf";

const HERO =
  "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600";

const FAQS = [
  {
    q: "Is all the meat served 100% Halal certified?",
    a: "Yes, absolutely! All our chicken, mutton, and meat preparations are 100% Halal certified, procured fresh daily from verified local suppliers with zero frozen meat or preservatives."
  },
  {
    q: "What makes your Irani Chai and Dum Biryani authentic?",
    a: "Our Irani Chai is slow-brewed using traditional copper degh decoctions blended with rich, condensed creamy milk (khoya/rabdi). Our Dum Biryanis are sealed with dough and slow-cooked over wood fire and live coals following royal Nizami recipes."
  },
  {
    q: "What are your delivery timings and radius?",
    a: "We deliver within a 5.0 km radius from our Secunderabad store. Regular daytime delivery runs from 6:00 AM to 10:00 PM, and our late-night prepaid delivery session operates from 10:00 PM to 6:00 AM."
  },
  {
    q: "How do I get Free Delivery on my order?",
    a: "All online orders above ₹499 automatically unlock 100% FREE Express Delivery! For orders below ₹499, nominal distance-based charges apply (starting at just ₹20)."
  },
  {
    q: "Do you accept bulk party orders or catering?",
    a: "Yes! We specialize in Family & Jumbo Biryani Handis, Party Starters, and Bulk Irani Chai Flasks for events, corporate meetings, and family celebrations. Order directly from the Combos section or call us."
  }
];

const TESTIMONIALS = [
  {
    name: "Mohammed Farhan",
    location: "Secunderabad",
    rating: 5,
    dish: "Mutton Dum Biryani & Irani Chai",
    text: "The most authentic Irani Chai and Dum Biryani in the area! The meat melts in the mouth and the khada chammach chai brings back Old City nostalgia."
  },
  {
    name: "Sravani Reddy",
    location: "Rampally Main Road",
    rating: 5,
    dish: "Ghee Karam Dosa & Filter Coffee",
    text: "Crispy, spicy, drenched in pure desi ghee! Delivered steaming hot within 25 minutes. Packaging is leak-proof and clean."
  },
  {
    name: "Vikram Sharma",
    location: "ECIL / Kushaiguda",
    rating: 5,
    dish: "Chicken Dum Biryani Jumbo Pack",
    text: "Ordered the Jumbo Biryani for our family weekend get-together. The portion was huge, delicious aromatics, and the salan was top notch!"
  }
];

export default function Storefront() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [cat, setCat] = useState("All");
  const [dietFilter, setDietFilter] = useState("all"); // "all", "veg", "nonveg", "bestseller"
  const [q, setQ] = useState("");
  const [activeTable, setActiveTable] = useState("");
  const [showTerms, setShowTerms] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [variantModalItem, setVariantModalItem] = useState(null);
  const [counterNoticeItem, setCounterNoticeItem] = useState(null);
  const [openFaq, setOpenFaq] = useState(null);
  const isNight = isNightSession();
  const { add, addVariant, setQty, lines, count, subtotal } = useCart();
  const { customer, isCustomerLoggedIn } = useCustomerAuth();

  const fetchMenu = async (retryCount = 0) => {
    try {
      const cached = await getMenuCache();
      if (cached && cached.length) {
        setItems(cached.filter((i) => i.available !== false));
        setLoading(false);
      }
    } catch {
      /* ignore */
    }

    try {
      const res = await api.get("/menu", { params: { only_available: true } });
      const data = res.data || [];
      if (data.length > 0) {
        setItems(data);
        saveMenuCache(data);
      }
      setLoading(false);
      setError(null);
    } catch (err) {
      console.error("Failed to load menu from server:", err);
      setItems((currentItems) => {
        if (currentItems.length === 0) {
          if (retryCount < 2) {
            setTimeout(() => fetchMenu(retryCount + 1), 1000 * (retryCount + 1));
          } else {
            setError("Unable to load menu. Please tap to retry.");
            setLoading(false);
          }
        } else {
          setLoading(false);
        }
        return currentItems;
      });
    }
  };

  useEffect(() => {
    fetchMenu();

    const searchParams = new URLSearchParams(window.location.search);
    const tableParam = searchParams.get("table");
    if (tableParam) {
      let formattedTable = tableParam.toUpperCase().trim();
      if (!formattedTable.startsWith("T-")) {
        try {
          formattedTable = `T-${parseInt(formattedTable, 10).toString().padStart(2, "0")}`;
        } catch {
          /* use as is */
        }
      }
      sessionStorage.setItem("table_no", formattedTable);
      setActiveTable(formattedTable);
    } else {
      const stored = sessionStorage.getItem("table_no");
      if (stored) setActiveTable(stored);
    }

    const catParam = searchParams.get("category");
    if (catParam) setCat(catParam);
  }, []);

  const [categoriesOrder, setCategoriesOrder] = useState([]);

  useEffect(() => {
    api.get("/menu/categories")
      .then((r) => {
        if (r.data?.categories) setCategoriesOrder(r.data.categories);
      })
      .catch(() => { });
  }, []);

  const cats = useMemo(() => {
    const set = new Set(items.map((i) => i.category).filter(Boolean));
    const ordered = ["All"];
    const preferredOrder = categoriesOrder.length
      ? categoriesOrder
      : ["Tea", "Tiffins", "Snacks", "Biryani", "Starters", "Tandoori Kebabs", "Currys", "Rotis", "Shawarma", "Sweets", "Fried Rice", "Noodles"];

    preferredOrder.forEach((c) => {
      for (const itemCat of set) {
        if (itemCat.toLowerCase() === c.toLowerCase()) {
          if (!ordered.includes(itemCat)) ordered.push(itemCat);
        }
      }
    });

    for (const itemCat of set) {
      if (!ordered.includes(itemCat)) ordered.push(itemCat);
    }
    return ordered;
  }, [items, categoriesOrder]);

  // Counts for diet filters
  const dietCounts = useMemo(() => {
    const vegCount = items.filter((i) => i.veg).length;
    const nonVegCount = items.filter((i) => !i.veg).length;
    return { all: items.length, veg: vegCount, nonveg: nonVegCount };
  }, [items]);

  const shown = useMemo(() => {
    return items.filter((i) => {
      const matchCat = cat === "All" || i.category?.toLowerCase() === cat.toLowerCase();
      const matchQuery =
        !q ||
        i.name?.toLowerCase().includes(q.toLowerCase()) ||
        i.description?.toLowerCase().includes(q.toLowerCase());
      let matchDiet = true;
      if (dietFilter === "veg") matchDiet = Boolean(i.veg);
      if (dietFilter === "nonveg") matchDiet = !i.veg;
      if (dietFilter === "bestseller")
        matchDiet =
          i.category === "Biryani" ||
          i.category === "Combos" ||
          i.name?.toLowerCase().includes("chai") ||
          i.name?.toLowerCase().includes("dosa");
      return matchCat && matchQuery && matchDiet;
    });
  }, [items, cat, q, dietFilter]);

  const [storeStatus, setStoreStatus] = useState({ is_online_open: true, notice: "" });

  useEffect(() => {
    api.get("/store/status")
      .then((r) => {
        if (r.data) setStoreStatus(r.data);
      })
      .catch(() => { });
  }, []);

  const qtyOf = (id) => lines.find((l) => l.item_id === id)?.qty || 0;

  const cartPairings = useMemo(() => {
    return getCartPairings(lines, items, 6);
  }, [lines, items]);

  // Free delivery progress calculation
  const freeDeliveryThreshold = FREE_DELIVERY_THRESHOLD || 499;
  const freeDeliveryProgress = Math.min(100, Math.round((subtotal / freeDeliveryThreshold) * 100));
  const amountNeededForFree = Math.max(0, freeDeliveryThreshold - subtotal);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Offline Paused Notice Banner */}
      {!storeStatus.is_online_open && (
        <div className="bg-red-600 text-white text-center py-2 px-4 text-xs font-bold uppercase tracking-wider border-b border-foreground flex justify-between items-center max-w-7xl mx-auto">
          <span>⚠️ Online Ordering is temporarily paused right now. Counter Dine-in & Takeaway are active!</span>
          <span className="opacity-90 font-mono text-[10px] hidden sm:inline">Counter Open</span>
        </div>
      )}

      {activeTable && (
        <div className="bg-primary text-primary-foreground text-center py-2 px-4 text-xs font-bold uppercase tracking-widest border-b border-foreground flex justify-between items-center max-w-7xl mx-auto">
          <span>🍽️ Dine-in Self-Ordering Active: <strong>{activeTable}</strong></span>
          <span className="opacity-90 font-mono text-[10px]">Hyderabadi Irani</span>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-foreground bg-background/95 backdrop-blur">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-3 flex items-center gap-6">
          <Link to="/" className="flex items-center gap-3 group" data-testid="brand-logo">
            <img
              src="/logo.png"
              alt="Hyderabadi Irani Food Court"
              className="h-11 w-11 sm:h-13 sm:w-13 object-contain rounded-full border border-amber-900/20 shadow-sm group-hover:scale-105 transition-transform"
            />
            <div className="flex flex-col">
              <span className="serif text-2xl sm:text-3xl font-extrabold tracking-tight text-primary leading-none">
                Hyderabadi Irani
              </span>
              <span className="text-[10px] sm:text-xs uppercase font-bold tracking-widest text-muted-foreground mt-0.5">
                Food Court · Estd. Heritage
              </span>
            </div>
          </Link>

          <nav className="ml-auto flex items-center gap-3 sm:gap-5 text-xs uppercase tracking-widest">
            {isCustomerLoggedIn ? (
              <Link
                to="/account"
                data-testid="customer-account-link"
                className="flex items-center gap-1.5 font-bold text-primary hover:opacity-80 transition"
              >
                <User size={14} className="text-primary" />
                <span className="max-w-[100px] truncate">{customer.name?.split(" ")[0] || "Account"}</span>
                {customer.loyalty_points > 0 && (
                  <span className="hidden sm:inline bg-amber-500/20 text-amber-900 px-1.5 py-0.5 rounded text-[10px] lowercase font-mono">
                    {customer.loyalty_points}pts
                  </span>
                )}
              </Link>
            ) : (
              <button
                type="button"
                onClick={() => setAuthModalOpen(true)}
                data-testid="customer-login-button"
                className="flex items-center gap-1.5 font-bold hover:text-primary transition"
              >
                <LogIn size={14} />
                <span>Sign In</span>
              </button>
            )}

            <Link
              to="/checkout"
              data-testid="cart-button"
              className="hard-shadow flex items-center gap-2 border border-foreground bg-foreground text-background px-4 py-2 text-xs uppercase font-bold tracking-widest hover:bg-primary transition-colors rounded"
            >
              <ShoppingBag size={14} />
              <span className="hidden sm:inline">Cart</span>
              {count > 0 && (
                <span className="bg-primary text-primary-foreground text-[11px] font-bold px-1.5 py-0.2 rounded-full mono">
                  {count}
                </span>
              )}
            </Link>
          </nav>
        </div>

        {/* Free Delivery Dynamic Progress Meter */}
        {count > 0 && (
          <div className="bg-amber-500/15 border-t border-foreground/15 px-5 sm:px-8 py-2">
            <div className="mx-auto max-w-7xl flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <Truck size={14} className="text-primary" />
                {amountNeededForFree > 0 ? (
                  <span>
                    Add <b className="text-primary font-mono">{money(amountNeededForFree)}</b> more to unlock{" "}
                    <b className="text-emerald-800 uppercase font-black">FREE Express Delivery!</b>
                  </span>
                ) : (
                  <span className="text-emerald-800 font-bold flex items-center gap-1">
                    <CheckCircle2 size={13} className="text-emerald-600" /> 🎉 Congratulations! You've unlocked FREE Delivery!
                  </span>
                )}
              </div>
              <div className="w-full sm:w-48 bg-muted border border-foreground/30 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-primary h-full transition-all duration-300 rounded-full"
                  style={{ width: `${freeDeliveryProgress}%` }}
                />
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative border-b border-foreground bg-card overflow-hidden">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 sm:px-8 py-14 sm:py-20 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 border border-foreground/30 bg-amber-500/10 px-3 py-1 text-xs uppercase tracking-widest font-bold text-amber-900 rounded-full">
              <Sparkles size={13} className="text-amber-600" />
              <span>Hyderabadi Irani Dum Cooking &amp; Chai</span>
            </div>
            <h1 className="serif text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.05]">
              Authentic Irani Chai, Dum Biryani &amp; Tiffins
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground leading-relaxed max-w-xl">
              Slow-cooked with fragrant basmati, pure desi ghee, and time-honored authentic Hyderabadi Irani spices. Served piping hot to your table and doorstep.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <a
                href="#menu"
                data-testid="explore-menu-cta"
                className="hard-shadow border border-foreground bg-primary text-primary-foreground px-7 py-3.5 text-xs font-bold uppercase tracking-widest hover:bg-foreground hover:text-background transition-colors"
              >
                Order Online Now
              </a>
              <Link
                to="/track"
                className="border border-foreground bg-card px-6 py-3.5 text-xs font-bold uppercase tracking-widest hover:bg-muted transition-colors flex items-center gap-2"
              >
                <Clock size={14} />
                <span>Live Tracker</span>
              </Link>
            </div>

            {/* Quick stats / trust chips */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-foreground/15 max-w-lg">
              <div>
                <div className="serif text-2xl font-black text-primary">214+</div>
                <div className="text-[11px] uppercase font-bold text-muted-foreground tracking-wider">Dishes &amp; Chai</div>
              </div>
              <div>
                <div className="serif text-2xl font-black text-foreground">4.8 ★</div>
                <div className="text-[11px] uppercase font-bold text-muted-foreground tracking-wider">2,480+ Foodies</div>
              </div>
              <div>
                <div className="serif text-2xl font-black text-emerald-700">25–35m</div>
                <div className="text-[11px] uppercase font-bold text-muted-foreground tracking-wider">Avg Dispatch</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="hard-shadow aspect-[4/3] sm:aspect-square overflow-hidden border-2 border-foreground bg-muted relative rounded-2xl">
              <img
                src={HERO}
                alt="Hyderabadi Irani Chai & Biryani feast"
                className="h-full w-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-6 text-white">
                <span className="text-xs uppercase font-bold tracking-widest text-amber-300">Live Heritage Counter</span>
                <p className="serif text-2xl font-bold mt-1">Fresh Zafrani Chai &amp; Dum Biryani</p>
                <p className="text-xs text-white/80 mt-0.5">Slow wood-fired brewing all day &amp; night</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Marquee Banner */}
      <div className="border-b border-foreground bg-secondary py-3 text-secondary-foreground overflow-hidden">
        <div className="marquee-track flex whitespace-nowrap">
          {[...Array(2)].map((_, idx) => (
            <div key={idx} className="flex shrink-0 items-center">
              {[
                "🔥 Slow Coal Dum Biryani",
                "☕ Authentic Hyderabadi Irani Chai",
                "🥞 Crispy Ghee Karam Dosas & Tiffins",
                "🚚 Free Delivery Above ₹499",
                "🌙 Late Night 10PM–6AM Online Orders",
                "🌿 100% Certified Halal Meats",
                "🥖 Fresh Osmania Biscuits & Bun Maska",
              ].map((t) => (
                <span key={t} className="overline px-6 text-secondary-foreground/90 font-bold">
                  {t} —
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* 4 Nizami Heritage Trust Pillars */}
      <section className="border-b border-foreground bg-muted/30 py-8 px-5 sm:px-8">
        <div className="mx-auto max-w-7xl grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="border border-foreground/30 bg-card p-4 rounded-xl space-y-2">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 text-amber-900 flex items-center justify-center">
              <Flame size={18} />
            </div>
            <h4 className="font-bold text-sm">Slow Coal Dum</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Steamed in dough-sealed deghs over slow burning coals.
            </p>
          </div>

          <div className="border border-foreground/30 bg-card p-4 rounded-xl space-y-2">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-900 flex items-center justify-center">
              <ShieldCheck size={18} />
            </div>
            <h4 className="font-bold text-sm">100% Halal &amp; Fresh</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Procured fresh daily with verified halal certificates and FSSAI hygiene.
            </p>
          </div>

          <div className="border border-foreground/30 bg-card p-4 rounded-xl space-y-2">
            <div className="w-9 h-9 rounded-lg bg-blue-500/20 text-blue-900 flex items-center justify-center">
              <Coffee size={18} />
            </div>
            <h4 className="font-bold text-sm">Rich Malai Chai</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Thick creamy rabdi milk decoction blended in traditional vintage glasses.
            </p>
          </div>

          <div className="border border-foreground/30 bg-card p-4 rounded-xl space-y-2">
            <div className="w-9 h-9 rounded-lg bg-purple-500/20 text-purple-900 flex items-center justify-center">
              <Truck size={18} />
            </div>
            <h4 className="font-bold text-sm">Insulated Hot Delivery</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Dispatched in heat-sealed packaging within 25–35 minutes.
            </p>
          </div>
        </div>
      </section>

      {/* Main Menu Section */}
      <section id="menu" className="mx-auto max-w-7xl px-5 sm:px-8 py-12 sm:py-16">
        <div className="flex flex-wrap items-end gap-6 justify-between border-b border-foreground/20 pb-6">
          <div>
            <p className="overline text-primary">The Nizam Catalogue</p>
            <h2 className="serif text-4xl sm:text-5xl font-extrabold tracking-tight mt-1">Explore Our Menu</h2>
            <p className="text-xs text-muted-foreground mt-1">
              Showing {shown.length} dishes · Choose from authentic Irani Chai, Tiffins, Biryani &amp; Sweets
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-72">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                data-testid="menu-search-input"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search biryani, chai, dosa..."
                className="w-full border border-foreground bg-card pl-9 pr-3 py-2.5 text-xs outline-none focus:ring-2 focus:ring-foreground rounded"
              />
            </div>
          </div>
        </div>

        {/* Veg / Non-Veg / Bestseller Filter Switcher */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setDietFilter("all")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded border transition ${dietFilter === "all"
                  ? "bg-foreground text-background border-foreground"
                  : "bg-card text-muted-foreground border-foreground/30 hover:border-foreground"
                }`}
            >
              All Items ({dietCounts.all})
            </button>

            <button
              onClick={() => setDietFilter("veg")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded border flex items-center gap-1.5 transition ${dietFilter === "veg"
                  ? "bg-emerald-700 text-white border-emerald-800"
                  : "bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100"
                }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
              Pure Veg ({dietCounts.veg})
            </button>

            <button
              onClick={() => setDietFilter("nonveg")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded border flex items-center gap-1.5 transition ${dietFilter === "nonveg"
                  ? "bg-red-700 text-white border-red-800"
                  : "bg-red-50 text-red-900 border-red-300 hover:bg-red-100"
                }`}
            >
              <span className="w-2 h-2 rounded-full bg-red-600 inline-block" />
              Non-Veg ({dietCounts.nonveg})
            </button>

            <button
              onClick={() => setDietFilter("bestseller")}
              className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded border flex items-center gap-1.5 transition ${dietFilter === "bestseller"
                  ? "bg-amber-600 text-white border-amber-700"
                  : "bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100"
                }`}
            >
              <Star size={12} className="fill-amber-500 text-amber-500" />
              Bestsellers
            </button>
          </div>

          <button
            onClick={() => setShowTerms(true)}
            className="text-[11px] font-bold text-primary hover:underline flex items-center gap-1"
          >
            <Info size={13} /> Delivery Terms (5km)
          </button>
        </div>

        {/* Category Filter Pills */}
        <div className="mt-4 flex gap-2 overflow-x-auto pb-2 scrollbar-none" data-testid="category-filters">
          {cats.map((c) => (
            <button
              key={c}
              data-testid={`category-${c.toLowerCase().replace(/\s+/g, "-")}`}
              onClick={() => setCat(c)}
              className={`border border-foreground px-4 py-2 text-xs uppercase tracking-wider font-bold whitespace-nowrap rounded transition-colors ${cat === c ? "bg-foreground text-background" : "bg-card hover:bg-muted text-muted-foreground"
                }`}
            >
              {c}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3" data-testid="menu-loading-skeleton">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="border border-foreground/30 bg-card animate-pulse flex flex-col rounded-xl overflow-hidden">
                <div className="aspect-[4/3] bg-muted/80 border-b border-foreground/20" />
                <div className="p-5 flex flex-col flex-1 space-y-3">
                  <div className="h-6 bg-muted rounded w-3/4" />
                  <div className="h-4 bg-muted/60 rounded w-full" />
                  <div className="h-4 bg-muted/60 rounded w-2/3" />
                  <div className="pt-4 flex justify-between items-center mt-auto">
                    <div className="h-6 bg-muted rounded w-20" />
                    <div className="h-9 bg-muted rounded w-16" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="mt-12 text-center p-8 border border-destructive bg-destructive/5 rounded-xl" data-testid="menu-error">
            <p className="text-sm text-destructive font-medium">{error}</p>
            <button
              onClick={() => fetchMenu(0)}
              className="mt-4 border border-foreground bg-primary text-primary-foreground px-6 py-2.5 text-xs font-semibold uppercase tracking-wider hover:opacity-90 rounded"
            >
              Retry Loading Menu
            </button>
          </div>
        ) : (
          <>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3" data-testid="menu-grid">
              {shown.map((i, idx) => {
                const hasPortions = Boolean(i.has_variants && i.variants && i.variants.length >= 2);
                const currentQty = qtyOf(i.id);
                const isCounterItem = Boolean(i.category === "Tea" || i.counter_only || i.order_type === "counter");
                return (
                  <article
                    key={i.id}
                    data-testid={`menu-item-${i.id}`}
                    className="border border-foreground/40 bg-card flex flex-col rounded-xl overflow-hidden hover:shadow-lg transition-all duration-200 rise"
                    style={{ animationDelay: `${Math.min(idx, 8) * 45}ms` }}
                  >
                    {/* Food Photo Card */}
                    <div className="aspect-[4/3] overflow-hidden border-b border-foreground/30 bg-muted relative">
                      {i.image_url ? (
                        <img
                          src={resolveImageUrl(i.image_url)}
                          alt={i.name}
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.style.display = "none";
                            const fallback = e.currentTarget.parentElement?.querySelector(".img-fallback");
                            if (fallback) fallback.style.display = "flex";
                          }}
                          className="h-full w-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      ) : null}

                      <div
                        className="img-fallback aspect-[4/3] w-full h-full border-b border-foreground/20 bg-muted items-center justify-center flex flex-col text-muted-foreground"
                        style={{ display: i.image_url ? "none" : "flex" }}
                      >
                        <span className="serif text-5xl text-foreground/20 font-black">{i.name ? i.name[0] : "☕"}</span>
                        <span className="text-[10px] uppercase font-bold tracking-wider mt-1">{i.category}</span>
                      </div>

                      {/* Veg / Non-Veg Indicator Badge */}
                      <div className="absolute top-3 left-3 bg-background/90 backdrop-blur px-2 py-1 rounded-md border border-foreground/30 flex items-center gap-1.5 shadow-sm">
                        <span
                          className={`w-2.5 h-2.5 rounded-full ${i.veg ? "bg-emerald-600" : "bg-red-600"
                            }`}
                        />
                        <span className="text-[10px] font-bold uppercase tracking-wider">
                          {i.veg ? "Veg" : "Non-Veg"}
                        </span>
                      </div>

                      {/* Live Counter Pill on Image */}
                      {isCounterItem ? (
                        <span className="absolute top-3 right-3 bg-amber-900/90 text-amber-200 border border-amber-500/40 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider backdrop-blur flex items-center gap-1 shadow">
                          <Coffee size={11} className="text-amber-400" />
                          <span>Live Counter</span>
                        </span>
                      ) : (
                        <span className="absolute top-3 right-3 bg-foreground/80 text-background px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider backdrop-blur">
                          {i.category}
                        </span>
                      )}
                    </div>

                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex items-start justify-between gap-3">
                        <h3 className="text-xl sm:text-2xl font-bold tracking-tight leading-tight">{i.name}</h3>
                      </div>
                      <p className="mt-2 text-xs text-muted-foreground leading-relaxed flex-1 line-clamp-2">
                        {i.description || `${i.name} prepared fresh with authentic Nizami ingredients.`}
                      </p>

                      <div className="mt-5 flex items-center justify-between pt-3 border-t border-foreground/10">
                        <div>
                          {hasPortions ? (
                            <div>
                              <div className="mono text-base font-black text-foreground">
                                ₹{i.variants[0].price} <span className="text-xs font-normal text-muted-foreground">/ ₹{i.variants[1].price}</span>
                              </div>
                              <span className="text-[10px] uppercase font-bold text-primary">
                                {i.variants[0].name} &amp; {i.variants[1].name}
                              </span>
                            </div>
                          ) : (
                            <span className="mono text-lg font-black text-foreground">
                              {i.price > 0 ? money(i.price) : "Contact for Price"}
                            </span>
                          )}
                        </div>

                        {activeTable && isCounterItem ? (
                          <button
                            data-testid={`counter-notice-${i.id}`}
                            onClick={() => setCounterNoticeItem(i)}
                            className="border border-amber-600 bg-amber-500/15 text-amber-950 px-3.5 py-2 text-xs font-bold uppercase tracking-wider hover:bg-amber-600 hover:text-white transition-colors flex items-center gap-1.5 rounded active:scale-95 shadow-sm"
                          >
                            <Coffee size={13} className="text-amber-700 group-hover:text-white" />
                            <span>Order at Counter</span>
                          </button>
                        ) : hasPortions ? (
                          <button
                            data-testid={`add-to-cart-${i.id}`}
                            onClick={() => setVariantModalItem(i)}
                            className="border border-foreground bg-primary text-primary-foreground px-4 py-2 text-xs font-bold uppercase tracking-wider hover:bg-foreground hover:text-background transition-colors flex items-center gap-1.5 rounded active:scale-95"
                          >
                            <span>Add</span>
                            <Plus size={13} />
                          </button>
                        ) : currentQty === 0 ? (
                          <button
                            data-testid={`add-to-cart-${i.id}`}
                            onClick={() => add(i)}
                            className="border border-foreground bg-primary text-primary-foreground px-5 py-2 text-xs uppercase font-bold tracking-widest hover:bg-foreground transition-colors rounded active:scale-95 shadow-sm"
                          >
                            Add
                          </button>
                        ) : (
                          <div className="flex items-center border-2 border-foreground rounded-lg bg-card shadow-sm">
                            <button
                              data-testid={`dec-${i.id}`}
                              onClick={() => setQty(i.id, currentQty - 1)}
                              className="px-2.5 py-1.5 hover:bg-muted transition text-foreground"
                            >
                              <Minus size={13} />
                            </button>
                            <span data-testid={`qty-${i.id}`} className="mono px-3 text-xs font-black text-foreground">
                              {currentQty}
                            </span>
                            <button
                              data-testid={`inc-${i.id}`}
                              onClick={() => add(i)}
                              className="px-2.5 py-1.5 hover:bg-muted transition text-foreground"
                            >
                              <Plus size={13} />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>

            {shown.length === 0 && (
              <div className="mt-12 text-center p-8 border border-foreground/30 bg-card rounded-xl" data-testid="menu-empty">
                <p className="text-base font-bold tracking-tight">No dishes found</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {q ? `No items match "${q}". Try clearing your search.` : "No items available under selected filters."}
                </p>
                <button
                  onClick={() => {
                    setQ("");
                    setCat("All");
                    setDietFilter("all");
                  }}
                  className="mt-4 border border-foreground bg-primary text-primary-foreground px-5 py-2 text-xs uppercase font-bold tracking-wider rounded"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </>
        )}

        {/* Pairing Suggestions Shelf */}
        {lines.length > 0 && cartPairings.length > 0 && (
          <div className="mt-12">
            <PairingShelf
              pairings={cartPairings}
              title="You will love pairing your order with"
              subtitle="Delicious snacks, accompaniments & beverages that complete your meal"
              onSelectVariantItem={(dish) => setVariantModalItem(dish)}
            />
          </div>
        )}
      </section>

      {/* Customer Reviews & Social Proof Wall */}
      <section className="border-t border-foreground/20 bg-card py-14 px-5 sm:px-8">
        <div className="mx-auto max-w-7xl space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <p className="overline text-primary">Loved by Hyderabad</p>
            <h3 className="serif text-3xl sm:text-4xl font-extrabold tracking-tight">What Food Lovers Say</h3>
            <p className="text-xs text-muted-foreground">Over 2,480+ authentic food lovers order every week</p>
          </div>

          <div className="grid sm:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t, idx) => (
              <div key={idx} className="border border-foreground/30 bg-background p-6 rounded-2xl hard-shadow space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center gap-1">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} size={14} className="fill-amber-500 text-amber-500" />
                    ))}
                  </div>
                  <p className="text-xs text-foreground/90 italic leading-relaxed">
                    "{t.text}"
                  </p>
                </div>
                <div className="pt-3 border-t border-foreground/15 flex items-center justify-between text-xs">
                  <div>
                    <h5 className="font-bold text-foreground">{t.name}</h5>
                    <p className="text-[10px] text-muted-foreground">{t.location}</p>
                  </div>
                  <span className="text-[10px] bg-primary/10 text-primary font-bold px-2 py-0.5 rounded">
                    {t.dish}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive FAQ Accordion */}
      <section className="border-t border-foreground/20 bg-muted/20 py-14 px-5 sm:px-8">
        <div className="mx-auto max-w-4xl space-y-6">
          <div className="text-center space-y-2">
            <p className="overline text-primary">Got Questions?</p>
            <h3 className="serif text-3xl sm:text-4xl font-extrabold tracking-tight">Frequently Asked Questions</h3>
            <p className="text-xs text-muted-foreground">Everything you need to know about ordering and delivery</p>
          </div>

          <div className="space-y-3 pt-4">
            {FAQS.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="border border-foreground/30 bg-card rounded-xl overflow-hidden transition"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base hover:bg-muted/40 transition"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? <ChevronUp size={18} className="shrink-0 text-primary" /> : <ChevronDown size={18} className="shrink-0 text-muted-foreground" />}
                  </button>
                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-5 pt-1 text-xs sm:text-sm text-muted-foreground leading-relaxed border-t border-foreground/10 bg-background/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Floating Bottom Cart Bar for Mobile */}
      {count > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-50 p-3 sm:hidden bg-background/90 backdrop-blur border-t border-foreground animate-slideUp">
          <Link
            to="/checkout"
            data-testid="sticky-checkout-bar"
            className="w-full border-2 border-foreground bg-foreground text-background py-3.5 px-5 flex items-center justify-between rounded-xl hard-shadow"
          >
            <div className="flex items-center gap-2.5">
              <ShoppingBag size={18} className="text-amber-400" />
              <span className="mono text-sm font-bold">
                {count} items · {money(subtotal)}
              </span>
            </div>
            <span className="text-xs uppercase font-bold tracking-widest text-amber-300">
              Checkout →
            </span>
          </Link>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-foreground bg-secondary text-secondary-foreground">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 py-14 grid gap-8 sm:grid-cols-4">
          <div className="sm:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <img src="/logo.png" alt="Logo" className="h-10 w-10 object-contain rounded-full border border-secondary-foreground/20" />
              <h3 className="serif text-2xl font-black tracking-tight">Hyderabadi Irani Food Court</h3>
            </div>
            <p className="text-xs text-secondary-foreground/75 leading-relaxed max-w-md">
              Plot no 38 Chandra Properties, Ayyappa Nagar Colony, Ghatkesar Road, 23-67, Rampally Main Rd, Rampally,
              Hyderabad, Secunderabad, Telangana 501302
            </p>
            <div className="space-y-1 text-xs text-secondary-foreground/90 mono pt-2">
              <div>Phone: <a href="tel:+918331807704" className="hover:underline font-bold">+91 8331807704</a></div>
              <div>Email: <a href="mailto:digitalfoxagency.care@gmail.com" className="hover:underline">digitalfoxagency.care@gmail.com</a></div>
              <div>GSTIN: <strong>36BLUPM3251R1Z6</strong> (Composition Scheme)</div>
              <div>FSSAI Lic. No: <strong>23625033000700</strong></div>
            </div>
          </div>

          <div className="text-sm">
            <p className="overline text-secondary-foreground/60 font-bold">Quick Links</p>
            <div className="mt-3 space-y-2">
              <Link to="/account" className="block text-xs underline underline-offset-4 hover:text-foreground">My Account &amp; Points</Link>
              <Link to="/track" className="block text-xs underline underline-offset-4 hover:text-foreground">Track Live Order</Link>
              <Link to="/contact" className="block text-xs underline underline-offset-4 hover:text-foreground">Store Location &amp; Dine-in</Link>
              <Link to="/login" className="block text-xs underline underline-offset-4 hover:text-foreground">Staff &amp; Admin Portal</Link>
            </div>
          </div>

          <div className="text-sm">
            <p className="overline text-secondary-foreground/60 font-bold">Policies &amp; Legal</p>
            <div className="mt-3 space-y-2">
              <Link to="/terms" className="block text-xs underline underline-offset-4 hover:text-foreground">Terms &amp; Conditions</Link>
              <Link to="/privacy" className="block text-xs underline underline-offset-4 hover:text-foreground">Privacy Policy</Link>
              <Link to="/refund-policy" className="block text-xs underline underline-offset-4 hover:text-foreground">Refund &amp; Cancellation</Link>
              <Link to="/shipping-policy" className="block text-xs underline underline-offset-4 hover:text-foreground">Shipping &amp; Delivery (5km)</Link>
            </div>
          </div>
        </div>

        <div className="border-t border-secondary-foreground/20 text-center py-4 text-xs font-bold uppercase tracking-widest text-secondary-foreground/60 flex flex-col sm:flex-row items-center justify-between max-w-7xl mx-auto px-5 gap-2">
          <span>© {new Date().getFullYear()} Hyderabadi Irani Food Court. All Rights Reserved.</span>
          <span>Authentic Nizami Taste · Crafted with Care</span>
        </div>
      </footer>

      {/* Customer Login / Register Modal */}
      <CustomerAuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => setAuthModalOpen(false)}
      />

      {/* Portion Selection Modal */}
      {variantModalItem && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-card border-2 border-foreground max-w-md w-full p-6 space-y-5 hard-shadow rounded-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-start justify-between border-b border-foreground/20 pb-3">
              <div className="flex items-center gap-3">
                {variantModalItem.image_url ? (
                  <img
                    src={variantModalItem.image_url}
                    alt={variantModalItem.name}
                    className="w-14 h-14 rounded-xl object-cover border border-foreground/30 shrink-0"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-xl bg-primary/10 text-primary border border-foreground/20 flex items-center justify-center font-bold text-lg">
                    {variantModalItem.name[0]}
                  </div>
                )}
                <div>
                  <h3 className="text-xl font-bold tracking-tight leading-tight">
                    {variantModalItem.name}
                  </h3>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mt-0.5">
                    {variantModalItem.category}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setVariantModalItem(null)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold border border-foreground/20 p-1.5 rounded hover:bg-muted"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Select Portion Size:
              </p>
              <div className="grid grid-cols-2 gap-3">
                {variantModalItem.variants?.map((v) => (
                  <button
                    key={v.name}
                    type="button"
                    onClick={() => {
                      addVariant(variantModalItem, v);
                      setVariantModalItem(null);
                    }}
                    className="border-2 border-foreground bg-primary hover:bg-foreground text-primary-foreground hover:text-background p-4 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95 shadow group"
                  >
                    <span className="text-sm font-black uppercase tracking-wider">
                      {v.name}
                    </span>
                    <span className="font-mono text-base font-bold">
                      ₹{v.price}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={() => setVariantModalItem(null)}
              className="w-full border border-foreground py-2.5 text-xs font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground rounded"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Live Tea & Snacks Counter Notice Modal */}
      {counterNoticeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md border-2 border-foreground bg-background p-6 hard-shadow space-y-4 rounded-2xl relative">
            <div className="flex justify-between items-start border-b border-foreground/15 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-amber-500/20 text-amber-900 flex items-center justify-center">
                  <Coffee size={18} />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-amber-700">Live Counter Service</p>
                  <h3 className="text-xl font-bold tracking-tight">{counterNoticeItem.name}</h3>
                </div>
              </div>
              <button
                onClick={() => setCounterNoticeItem(null)}
                className="border border-foreground/30 p-1 hover:bg-muted rounded"
              >
                <X size={16} />
              </button>
            </div>

            <div className="border border-amber-500/30 bg-amber-500/10 p-4 rounded-xl space-y-2 text-xs text-amber-950">
              <p className="font-bold flex items-center gap-1.5 text-amber-900">
                <span>☕</span> Please Approach the Live Tea Counter
              </p>
              <p className="leading-relaxed opacity-95">
                Our authentic Hyderabadi Irani Chai, Osmania Biscuits, and fresh bakery snacks are prepared live and served steaming hot directly at our <strong>Live Tea &amp; Snacks Counter</strong>.
              </p>
              <div className="pt-2 border-t border-amber-500/20 flex justify-between items-center text-[11px] font-mono">
                <span>Item Price:</span>
                <span className="font-bold text-sm text-foreground">₹{counterNoticeItem.price}</span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setCounterNoticeItem(null)}
                className="hard-shadow w-full border border-foreground bg-primary text-primary-foreground py-2.5 text-xs font-bold uppercase tracking-widest rounded hover:bg-foreground hover:text-background transition-colors"
              >
                Understood · Collect at Counter
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delivery Terms Modal */}
      {showTerms && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg border-2 border-foreground bg-background p-6 sm:p-8 hard-shadow space-y-5 rounded-2xl">
            <div className="flex justify-between items-start border-b border-foreground/15 pb-4">
              <div>
                <p className="overline text-primary">Hyderabadi Irani</p>
                <h3 className="text-2xl font-bold tracking-tight">Delivery Terms &amp; Charges</h3>
              </div>
              <button
                onClick={() => setShowTerms(false)}
                className="border border-foreground p-1.5 hover:bg-muted rounded"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-muted-foreground leading-relaxed">
                We deliver fresh hot biryani, chai, and food up to <b>5.0 km</b> from our Secunderabad store. Distance-based delivery charges apply:
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {DELIVERY_TERMS.map((t) => (
                  <div
                    key={t.label}
                    className={`p-3 border rounded text-center ${t.highlight
                        ? "border-emerald-600 bg-emerald-50 text-emerald-950 font-bold"
                        : "border-foreground/20 bg-muted/30"
                      }`}
                  >
                    <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{t.label}</div>
                    <div className="font-mono text-sm font-bold mt-1 text-primary">{t.charge}</div>
                  </div>
                ))}
              </div>

              <div className="p-3 border border-amber-600 bg-amber-50 text-amber-900 space-y-1 mt-4 rounded-xl">
                <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-[11px]">
                  <Clock size={14} className="text-amber-700" />
                  Late Night Delivery Session (10:00 PM – 6:00 AM)
                </div>
                <p className="text-[11px] leading-relaxed">
                  During late-night hours (10:00 PM to 6:00 AM), <b>only prepaid online orders (UPI, Cards, NetBanking)</b> are accepted. Cash on delivery is unavailable during the night session.
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-foreground/15 flex justify-end">
              <button
                onClick={() => setShowTerms(false)}
                className="hard-shadow border border-foreground bg-primary text-primary-foreground px-6 py-2.5 text-xs font-semibold uppercase tracking-widest rounded"
              >
                Understood &amp; Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
