import React, { useEffect, useState, useRef, useMemo, useCallback } from "react";
import { api, errMsg, money } from "@/lib/api";
import { toast } from "sonner";
import {
  Navigation,
  Phone,
  MessageSquare,
  Battery,
  BatteryCharging,
  Gauge,
  Clock,
  MapPin,
  RefreshCw,
  Search,
  Bike,
  Store,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Radio,
} from "lucide-react";
import { STORE_LOCATION, calculateDistanceKm } from "@/lib/deliveryTerms";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Custom Leaflet Icons
const storeIcon = L.divIcon({
  className: "custom-store-pin",
  html: `
    <div style="
      position: relative;
      transform: translate(-50%, -100%);
      display: flex;
      flex-direction: column;
      align-items: center;
    ">
      <div style="
        background: #78350f;
        color: #fef3c7;
        font-size: 11px;
        font-weight: bold;
        padding: 2px 8px;
        border-radius: 6px;
        white-space: nowrap;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        margin-bottom: 2px;
        border: 1px solid #f59e0b;
      ">🏪 Main Restaurant</div>
      <div style="
        width: 38px;
        height: 38px;
        background: linear-gradient(135deg, #d97706, #92400e);
        border: 3px solid #ffffff;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 16px rgba(180, 83, 9, 0.5);
      ">
        <span style="transform: rotate(45deg); font-size: 18px;">☕</span>
      </div>
    </div>
  `,
  iconSize: [40, 60],
  iconAnchor: [20, 60],
});

const createRiderIcon = (driver) => {
  const isDelivery = driver.status === "out_for_delivery";
  const bg = isDelivery ? "linear-gradient(135deg, #16a34a, #15803d)" : "linear-gradient(135deg, #2563eb, #1d4ed8)";
  const statusLabel = isDelivery ? "On Delivery" : "Online";

  return L.divIcon({
    className: "custom-rider-pin",
    html: `
      <div style="
        position: relative;
        transform: translate(-50%, -100%);
        display: flex;
        flex-direction: column;
        align-items: center;
      ">
        <div style="
          background: #0f172a;
          color: #f8fafc;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 7px;
          border-radius: 6px;
          white-space: nowrap;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          margin-bottom: 3px;
          border: 1px solid ${isDelivery ? "#22c55e" : "#3b82f6"};
          display: flex;
          align-items: center;
          gap: 4px;
        ">
          <span style="width: 6px; height: 6px; border-radius: 50%; background: ${isDelivery ? "#22c55e" : "#3b82f6"}; animation: pulse 1.5s infinite;"></span>
          ${driver.driver_name || "Delivery Partner"} (${statusLabel})
        </div>
        <div style="
          width: 42px;
          height: 42px;
          background: ${bg};
          border: 3px solid #ffffff;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 18px rgba(0, 0, 0, 0.4);
        ">
          <span style="font-size: 20px;">🛵</span>
        </div>
      </div>
    `,
    iconSize: [44, 70],
    iconAnchor: [22, 70],
  });
};

const createCustomerDropIcon = (orderNo) => {
  return L.divIcon({
    className: "custom-customer-pin",
    html: `
      <div style="
        position: relative;
        transform: translate(-50%, -100%);
        display: flex;
        flex-direction: column;
        align-items: center;
      ">
        <div style="
          background: #dc2626;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 4px;
          white-space: nowrap;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          margin-bottom: 2px;
        ">📍 Drop #${orderNo}</div>
        <div style="
          width: 32px;
          height: 32px;
          background: #dc2626;
          border: 2px solid #ffffff;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
        ">
          <span style="transform: rotate(45deg); font-size: 14px;">🏠</span>
        </div>
      </div>
    `,
    iconSize: [36, 54],
    iconAnchor: [18, 54],
  });
};

export default function LiveTracking() {
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedDriver, setSelectedDriver] = useState(null);

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef({});
  const routesRef = useRef({});

  // Fetch live drivers from backend
  const fetchLiveDrivers = useCallback(async () => {
    try {
      const res = await api.get("/admin/drivers/locations");
      if (res.data && Array.isArray(res.data.drivers)) {
        setDrivers(res.data.drivers);
        setLastUpdated(new Date());
      }
    } catch (e) {
      console.warn("Failed to fetch live driver locations:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  // Poll every 6 seconds
  useEffect(() => {
    fetchLiveDrivers();
    const interval = setInterval(fetchLiveDrivers, 6000);
    return () => clearInterval(interval);
  }, [fetchLiveDrivers]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [STORE_LOCATION.lat, STORE_LOCATION.lng],
      zoom: 14,
      zoomControl: true,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(map);

    // Restaurant marker
    L.marker([STORE_LOCATION.lat, STORE_LOCATION.lng], { icon: storeIcon })
      .addTo(map)
      .bindPopup("<b>Hyderabadi Irani Restaurant</b><br>Rampally, Secunderabad (Central Kitchen)");

    // 5.0 km Service Delivery Radius Geofence
    const deliveryCircle = L.circle([STORE_LOCATION.lat, STORE_LOCATION.lng], {
      radius: 5000,
      color: "#d97706",
      fillColor: "#f59e0b",
      fillOpacity: 0.14,
      weight: 2.5,
      dashArray: "6, 6",
    }).addTo(map);

    deliveryCircle.bindTooltip("🛡️ Official 5.0 KM Express Delivery Boundary", {
      permanent: false,
      direction: "top",
      className: "font-sans text-xs font-bold text-amber-900 bg-amber-100 border border-amber-400 rounded px-2 py-1 shadow",
    });

    // Fit map view to perfectly encompass the 5.0 KM delivery radius
    map.fitBounds(deliveryCircle.getBounds(), { padding: [25, 25] });

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update map markers when drivers change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear old markers & routes
    Object.values(markersRef.current).forEach((m) => m.remove());
    Object.values(routesRef.current).forEach((r) => r.remove());
    markersRef.current = {};
    routesRef.current = {};

    drivers.forEach((driver) => {
      if (driver.lat && driver.lng) {
        const marker = L.marker([driver.lat, driver.lng], {
          icon: createRiderIcon(driver),
        }).addTo(map);

        const isDelivery = driver.status === "out_for_delivery";
        const distToStore = calculateDistanceKm(
          STORE_LOCATION.lat,
          STORE_LOCATION.lng,
          driver.lat,
          driver.lng
        ).toFixed(1);

        let popupContent = `
          <div style="font-family: sans-serif; font-size: 12px; line-height: 1.5;">
            <b style="font-size: 13px; color: #1e293b;">${driver.driver_name || "Delivery Partner"}</b><br/>
            <span>📞 <a href="tel:${driver.driver_phone}">${driver.driver_phone}</a></span><br/>
            <span>⚡ Status: <b>${isDelivery ? "Out for Delivery" : "Online"}</b></span><br/>
            <span>🔋 Battery: ${driver.battery ? driver.battery + "%" : "N/A"}</span><br/>
            <span>🚀 Speed: ${driver.speed ? driver.speed + " km/h" : "Stationary"}</span><br/>
            <span>📍 ${distToStore} km from Store</span>
          </div>
        `;

        marker.bindPopup(popupContent);
        markersRef.current[`driver_${driver.driver_id}`] = marker;

        // Draw delivery routes to active customer orders
        if (driver.active_orders && driver.active_orders.length > 0) {
          driver.active_orders.forEach((order) => {
            if (order.lat && order.lng) {
              // Customer drop marker
              const dropMarker = L.marker([order.lat, order.lng], {
                icon: createCustomerDropIcon(order.order_no),
              }).addTo(map);

              dropMarker.bindPopup(`
                <div style="font-family: sans-serif; font-size: 12px;">
                  <b>Order #${order.order_no}</b><br/>
                  Customer: ${order.customer_name || "Customer"}<br/>
                  Phone: <a href="tel:${order.customer_phone}">${order.customer_phone}</a><br/>
                  Address: ${order.delivery_address || ""}<br/>
                  Total: ${money(order.total)}
                </div>
              `);
              markersRef.current[`drop_${order.id}`] = dropMarker;

              // Polyline from Driver to Customer Drop
              const routeLine = L.polyline(
                [
                  [driver.lat, driver.lng],
                  [order.lat, order.lng],
                ],
                {
                  color: "#16a34a",
                  weight: 4,
                  dashArray: "8, 8",
                  opacity: 0.85,
                }
              ).addTo(map);

              routesRef.current[`route_${order.id}`] = routeLine;
            }
          });
        }
      }
    });
  }, [drivers]);

  // Center map on a selected driver
  const focusDriver = (driver) => {
    setSelectedDriver(driver);
    if (mapInstanceRef.current && driver.lat && driver.lng) {
      mapInstanceRef.current.flyTo([driver.lat, driver.lng], 16, {
        animate: true,
        duration: 1.2,
      });
      const marker = markersRef.current[`driver_${driver.driver_id}`];
      if (marker) marker.openPopup();
    }
  };

  // Filtered drivers list
  const filteredDrivers = useMemo(() => {
    return drivers.filter((d) => {
      const matchSearch =
        (d.driver_name || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
        (d.driver_phone || "").includes(searchTerm);

      if (!matchSearch) return false;
      if (statusFilter === "all") return true;
      if (statusFilter === "delivery") return d.status === "out_for_delivery";
      if (statusFilter === "online") return d.status !== "out_for_delivery";
      return true;
    });
  }, [drivers, searchTerm, statusFilter]);

  const activeDeliveriesCount = useMemo(() => {
    return drivers.reduce((acc, d) => acc + (d.active_orders?.length || 0), 0);
  }, [drivers]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 flex flex-col h-[calc(100vh-65px)] lg:h-screen overflow-hidden">
      {/* Top Header & Metrics */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4 flex-shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
            <p className="text-xs font-bold uppercase tracking-wider text-emerald-600">
              Live Fleet Telemetry Radar
            </p>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2.5">
            <Navigation className="text-primary h-7 w-7" /> Live Delivery Tracking
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-4 bg-card border border-border px-4 py-2 rounded-xl text-xs shadow-sm">
            <div>
              <span className="text-muted-foreground block">Active Fleet</span>
              <b className="text-sm text-foreground">{drivers.length} Drivers</b>
            </div>
            <div className="w-[1px] h-6 bg-border"></div>
            <div>
              <span className="text-muted-foreground block">Live Deliveries</span>
              <b className="text-sm text-emerald-600 font-bold">{activeDeliveriesCount} Active</b>
            </div>
          </div>

          <button
            onClick={() => {
              setLoading(true);
              fetchLiveDrivers();
              toast.success("Radar telemetry refreshed");
            }}
            className="border border-border bg-card hover:bg-muted text-foreground px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center gap-2 shadow-sm active:scale-95 transition"
          >
            <RefreshCw size={14} className={loading ? "animate-spin text-primary" : ""} /> Refresh
          </button>
        </div>
      </div>

      {/* Main Grid: Map & Live Drivers Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1 min-h-0">
        {/* Map Container (2 Columns on large screens) */}
        <div className="lg:col-span-2 bg-card border border-border rounded-2xl overflow-hidden shadow-sm flex flex-col relative h-[50vh] lg:h-auto">
          <div
            ref={mapContainerRef}
            className="w-full h-full z-0"
            style={{ minHeight: "320px" }}
          />

          {/* Floating Map Controls & Geofence Badge */}
          <div className="absolute top-3 right-3 z-[400] flex items-center gap-2">
            <div className="bg-amber-900/90 backdrop-blur text-amber-200 px-3 py-2 rounded-xl text-xs font-bold shadow-lg border border-amber-600 flex items-center gap-1.5">
              <span>🛡️ 5.0 KM Delivery Range</span>
            </div>
            <button
              onClick={() => {
                if (mapInstanceRef.current) {
                  const bounds = L.latLng([STORE_LOCATION.lat, STORE_LOCATION.lng]).toBounds(10000);
                  mapInstanceRef.current.fitBounds(bounds, { padding: [25, 25] });
                }
              }}
              className="bg-white/95 backdrop-blur text-slate-800 p-2.5 rounded-xl shadow-lg border border-slate-200 hover:bg-white text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
              title="Reset View to 5.0 KM Service Area"
            >
              <Store size={15} className="text-amber-600" /> Center 5KM Area
            </button>
          </div>

          {/* Map Legend Overlay */}
          <div className="absolute bottom-3 left-3 z-[400] bg-slate-900/90 backdrop-blur text-white px-3.5 py-2 rounded-xl text-[11px] shadow-lg border border-slate-700 flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> 🏪 Restaurant
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> 🛵 On Delivery
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> 🛵 Online / Idle
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> 📍 Customer Drop
            </div>
          </div>
        </div>

        {/* Live Drivers Sidebar (1 Column) */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm flex flex-col h-full min-h-0">
          {/* Sidebar Search & Filter Bar */}
          <div className="p-3.5 border-b border-border bg-muted/30 space-y-2.5 flex-shrink-0">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 text-muted-foreground h-4 w-4" />
              <input
                type="text"
                placeholder="Search driver by name or phone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-background border border-border rounded-xl pl-9 pr-3 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>

            <div className="flex gap-1.5">
              {[
                { id: "all", label: `All (${drivers.length})` },
                { id: "delivery", label: `On Delivery (${drivers.filter((d) => d.status === "out_for_delivery").length})` },
                { id: "online", label: `Idle (${drivers.filter((d) => d.status !== "out_for_delivery").length})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className={`flex-1 py-1 px-2 rounded-lg text-[11px] font-semibold transition ${
                    statusFilter === tab.id
                      ? "bg-foreground text-background"
                      : "bg-background border border-border text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Drivers List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 divide-y divide-border/40">
            {filteredDrivers.length === 0 ? (
              <div className="text-center py-12 px-4">
                <Bike className="h-10 w-10 text-muted-foreground/40 mx-auto mb-2" />
                <p className="text-sm font-semibold text-foreground">No Delivery Partners Online</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Delivery partners will appear here once they log into the Hyderabadi Irani Delivery App.
                </p>
              </div>
            ) : (
              filteredDrivers.map((driver) => {
                const isDelivery = driver.status === "out_for_delivery";
                const isSelected = selectedDriver?.driver_id === driver.driver_id;
                const distToStore = driver.lat && driver.lng
                  ? calculateDistanceKm(STORE_LOCATION.lat, STORE_LOCATION.lng, driver.lat, driver.lng).toFixed(1)
                  : null;

                return (
                  <div
                    key={driver.driver_id}
                    onClick={() => focusDriver(driver)}
                    className={`pt-2.5 first:pt-0 p-3 rounded-xl border transition cursor-pointer ${
                      isSelected
                        ? "bg-primary/5 border-primary shadow-sm"
                        : "bg-background border-border hover:border-foreground/30 hover:bg-muted/30"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm shadow-sm flex-shrink-0 ${
                            isDelivery
                              ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                              : "bg-blue-100 text-blue-800 border border-blue-300"
                          }`}
                        >
                          🛵
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-bold text-foreground truncate">
                            {driver.driver_name || "Delivery Partner"}
                          </h4>
                          <p className="text-[11px] text-muted-foreground flex items-center gap-1.5 truncate">
                            <span>📞 {driver.driver_phone}</span>
                            {distToStore && <span>• {distToStore} km away</span>}
                          </p>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full flex-shrink-0 ${
                          isDelivery
                            ? "bg-emerald-500 text-white"
                            : "bg-blue-500 text-white"
                        }`}
                      >
                        {isDelivery ? "On Delivery" : "Online"}
                      </span>
                    </div>

                    {/* Telemetry Chips (Battery, Speed, Last Updated) */}
                    <div className="flex items-center gap-2 mt-2.5 pt-2 border-t border-border/50 text-[11px] text-muted-foreground flex-wrap">
                      <div className="flex items-center gap-1 bg-muted/60 px-2 py-0.5 rounded-md">
                        <Battery size={13} className={driver.battery && driver.battery < 20 ? "text-rose-500" : "text-emerald-500"} />
                        <span>{driver.battery != null ? `${driver.battery}%` : "N/A"}</span>
                      </div>

                      <div className="flex items-center gap-1 bg-muted/60 px-2 py-0.5 rounded-md">
                        <Gauge size={13} className="text-blue-500" />
                        <span>{driver.speed ? `${driver.speed} km/h` : "Stationary"}</span>
                      </div>

                      <div className="flex items-center gap-1 bg-muted/60 px-2 py-0.5 rounded-md ml-auto">
                        <Clock size={12} />
                        <span>
                          {driver.updated_at
                            ? new Date(driver.updated_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
                            : "Live"}
                        </span>
                      </div>
                    </div>

                    {/* Active Order Delivery Badge if on trip */}
                    {driver.active_orders && driver.active_orders.length > 0 && (
                      <div className="mt-2.5 bg-emerald-50/80 border border-emerald-200/80 rounded-lg p-2 text-xs">
                        <p className="font-bold text-emerald-950 flex items-center justify-between">
                          <span>📦 Active Order #{driver.active_orders[0].order_no}</span>
                          <span className="font-mono">{money(driver.active_orders[0].total)}</span>
                        </p>
                        <p className="text-[11px] text-emerald-800 truncate mt-0.5">
                          📍 {driver.active_orders[0].delivery_address || "Customer Address"}
                        </p>
                      </div>
                    )}

                    {/* Action Bar (Call, WhatsApp, Focus) */}
                    <div className="flex items-center gap-1.5 mt-2.5 pt-1.5">
                      <a
                        href={`tel:${driver.driver_phone}`}
                        onClick={(e) => e.stopPropagation()}
                        className="flex-1 border border-border bg-card hover:bg-muted text-foreground py-1 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
                      >
                        <Phone size={12} className="text-emerald-600" /> Call
                      </a>

                      <a
                        href={`https://api.whatsapp.com/send?phone=91${driver.driver_phone}&text=Hello%20${encodeURIComponent(driver.driver_name || "Partner")}%2C%20Hyderabadi%20Irani%20Admin%20here.`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="flex-1 border border-border bg-card hover:bg-muted text-foreground py-1 px-2 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
                      >
                        <MessageSquare size={12} className="text-emerald-600" /> WhatsApp
                      </a>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          focusDriver(driver);
                        }}
                        className="border border-foreground bg-primary text-primary-foreground py-1 px-2.5 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1 hover:opacity-90 active:scale-95 transition"
                      >
                        <MapPin size={12} /> Pin
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
