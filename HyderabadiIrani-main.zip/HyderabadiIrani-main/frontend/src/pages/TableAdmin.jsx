import { useState, useEffect } from "react";
import { api, errMsg } from "@/lib/api";
import { toast } from "sonner";
import { Grid, Printer, Download, RefreshCw, QrCode, Sparkles, ExternalLink, Check } from "lucide-react";

const DEFAULT_50_TABLES = Array.from({ length: 50 }, (_, i) => ({
  id: `table-t${i + 1}`,
  table_no: `T-${String(i + 1).padStart(2, "0")}`,
  status: "available",
  capacity: 4,
  active_order: null,
}));

export default function TableAdmin() {
  const [tables, setTables] = useState(DEFAULT_50_TABLES);
  const [loading, setLoading] = useState(false);
  const [selectedTable, setSelectedTable] = useState(null);
  const [downloadingBulk, setDownloadingBulk] = useState(false);

  const fetchTables = async () => {
    try {
      const { data } = await api.get("/tables");
      if (Array.isArray(data) && data.length > 0) {
        setTables(data);
      }
    } catch (e) {
      console.warn("Using default 50 tables layout:", e);
    }
  };

  useEffect(() => {
    fetchTables();
  }, []);

  const handleUpdateStatus = async (tableNo, newStatus) => {
    try {
      await api.put(`/tables/${tableNo}/status`, { status: newStatus });
      toast.success(`Table ${tableNo} marked as ${newStatus}`);
      setSelectedTable((prev) => (prev ? { ...prev, status: newStatus } : null));
      fetchTables();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const getTargetUrl = (tableNo) => {
    return `${window.location.origin}/?table=${tableNo}`;
  };

  const getQrUrl = (tableNo) => {
    const targetUrl = encodeURIComponent(getTargetUrl(tableNo));
    return `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${targetUrl}&margin=10`;
  };

  // Generate PNG Blob from Canvas for crisp download
  const createTableCardBlob = (tableNo) => {
    return new Promise((resolve, reject) => {
      const qrImgUrl = getQrUrl(tableNo);
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = 640;
        canvas.height = 820;
        const ctx = canvas.getContext("2d");

        // Card Background
        ctx.fillStyle = "#FFFFFF";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Outer Dark Border
        ctx.strokeStyle = "#1A1A1A";
        ctx.lineWidth = 12;
        ctx.strokeRect(12, 12, canvas.width - 24, canvas.height - 24);

        // Header Title
        ctx.fillStyle = "#D45D48";
        ctx.font = "bold 32px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("HYDERABADI IRANI", canvas.width / 2, 65);

        ctx.fillStyle = "#1A1A1A";
        ctx.font = "bold 18px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
        ctx.fillText("FOOD COURT • DINE-IN MENU", canvas.width / 2, 98);

        // Table Number Pill Box
        ctx.fillStyle = "#1A1A1A";
        ctx.fillRect(canvas.width / 2 - 110, 124, 220, 50);
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 28px monospace";
        ctx.fillText(tableNo, canvas.width / 2, 160);

        // Draw QR Code
        ctx.drawImage(img, 70, 194, 500, 500);

        // Subtext Instruction
        ctx.fillStyle = "#111111";
        ctx.font = "bold 19px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
        ctx.fillText("Scan QR to Order Directly from Table", canvas.width / 2, 722);

        // Separator
        ctx.strokeStyle = "#DDDDDD";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(50, 748);
        ctx.lineTo(canvas.width - 50, 748);
        ctx.stroke();

        // Footer Branding
        ctx.fillStyle = "#222222";
        ctx.font = "bold 15px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
        ctx.fillText("Powered by NovaSaaS", canvas.width / 2, 780);

        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject(new Error("Canvas export failed"));
        }, "image/png");
      };
      img.onerror = () => reject(new Error(`Failed to load QR for table ${tableNo}`));
      img.src = qrImgUrl;
    });
  };

  // Download Single QR Standee
  const downloadSingleQr = async (tableNo) => {
    try {
      toast.info(`Preparing QR Standee for ${tableNo}…`);
      const blob = await createTableCardBlob(tableNo);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.download = `Hyderabadi_Irani_Table_${tableNo}_QR.png`;
      link.href = url;
      link.click();
      URL.revokeObjectURL(url);
      toast.success(`Downloaded QR Standee for Table ${tableNo}! 🎉`);
    } catch (e) {
      toast.error(`Download failed: ${e.message}`);
    }
  };

  // Bulk Download All Active Tables
  const downloadAllQrsBulk = async () => {
    if (!tables.length) return toast.error("No tables found to download");
    setDownloadingBulk(true);
    toast.info(`Starting download for ${tables.length} table cards…`);

    try {
      for (let i = 0; i < tables.length; i++) {
        const t = tables[i];
        const blob = await createTableCardBlob(t.table_no);
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.download = `Table_${t.table_no}_QR.png`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
        // Small delay to prevent browser download throttling
        await new Promise((r) => setTimeout(r, 220));
      }
      toast.success(`Successfully downloaded all ${tables.length} table QR cards! ✨`);
    } catch (e) {
      toast.error(`Batch download interrupted: ${e.message}`);
    } finally {
      setDownloadingBulk(false);
    }
  };

  // Isolated Print for Single Standee Card
  const printSingleTableStandee = (tableNo) => {
    const qrUrl = getQrUrl(tableNo);
    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.right = "0";
    iframe.style.bottom = "0";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "0";
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Standee_Card_${tableNo}</title>
          <style>
            @page { size: portrait; margin: 10mm; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              display: flex;
              align-items: center;
              justify-content: center;
              min-height: 90vh;
              margin: 0;
              background: #fff;
            }
            .standee-card {
              border: 5px solid #000;
              padding: 24px;
              width: 320px;
              text-align: center;
              box-sizing: border-box;
            }
            .title { font-size: 22px; font-weight: 900; color: #D45D48; text-transform: uppercase; margin-bottom: 2px; }
            .subtitle { font-size: 11px; font-weight: bold; text-transform: uppercase; color: #555; margin-bottom: 12px; }
            .table-badge {
              background: #000;
              color: #fff;
              font-family: monospace;
              font-size: 24px;
              font-weight: 900;
              padding: 6px 16px;
              display: inline-block;
              margin-bottom: 14px;
              letter-spacing: 2px;
            }
            .qr-img { width: 220px; height: 220px; border: 2px solid #000; padding: 4px; }
            .instruction { font-size: 12px; font-weight: bold; margin-top: 14px; text-transform: uppercase; }
            .footer { border-top: 2px solid #000; margin-top: 16px; padding-top: 8px; font-size: 12px; font-weight: 900; }
          </style>
        </head>
        <body>
          <div class="standee-card">
            <div class="title">HYDERABADI IRANI</div>
            <div class="subtitle">Dine-In Table Menu</div>
            <div class="table-badge">${tableNo}</div>
            <div>
              <img src="${qrUrl}" class="qr-img" alt="QR" />
            </div>
            <div class="instruction">Scan QR to Order Directly from Table</div>
            <div class="footer">Powered by NovaSaaS</div>
          </div>
        </body>
      </html>
    `);
    doc.close();

    iframe.contentWindow.focus();
    setTimeout(() => {
      iframe.contentWindow.print();
      setTimeout(() => {
        if (iframe && iframe.parentNode) iframe.parentNode.removeChild(iframe);
      }, 1500);
    }, 400);
  };

  // Batch Print All Tables in Grid Sheet (4 per A4 page)
  const printAllStandeesGrid = () => {
    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.right = "0";
    iframe.style.bottom = "0";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "0";
    document.body.appendChild(iframe);

    const cardsHtml = tables
      .map(
        (t) => `
      <div class="standee-card">
        <div class="title">HYDERABADI IRANI</div>
        <div class="subtitle">Dine-In Table Menu</div>
        <div class="table-badge">${t.table_no}</div>
        <div>
          <img src="${getQrUrl(t.table_no)}" class="qr-img" alt="QR" />
        </div>
        <div class="instruction">Scan QR to Order Directly from Table</div>
        <div class="footer">Powered by NovaSaaS</div>
      </div>
    `
      )
      .join("");

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>All_50_Table_Standees</title>
          <style>
            @page { size: A4 portrait; margin: 8mm; }
            * { box-sizing: border-box; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              margin: 0;
              background: #fff;
            }
            .grid-container {
              display: grid;
              grid-template-columns: repeat(2, 1fr);
              gap: 16px;
            }
            .standee-card {
              border: 3px solid #000;
              padding: 14px;
              text-align: center;
              page-break-inside: avoid;
              break-inside: avoid;
              margin-bottom: 8px;
            }
            .title { font-size: 16px; font-weight: 900; color: #D45D48; text-transform: uppercase; margin-bottom: 2px; }
            .subtitle { font-size: 9px; font-weight: bold; text-transform: uppercase; color: #555; margin-bottom: 6px; }
            .table-badge {
              background: #000;
              color: #fff;
              font-family: monospace;
              font-size: 16px;
              font-weight: 900;
              padding: 3px 12px;
              display: inline-block;
              margin-bottom: 6px;
            }
            .qr-img { width: 140px; height: 140px; border: 1px solid #000; padding: 2px; }
            .instruction { font-size: 9.5px; font-weight: bold; margin-top: 6px; text-transform: uppercase; }
            .footer { border-top: 1px solid #000; margin-top: 6px; padding-top: 4px; font-size: 9px; font-weight: 900; }
          </style>
        </head>
        <body>
          <div class="grid-container">
            ${cardsHtml}
          </div>
        </body>
      </html>
    `);
    doc.close();

    iframe.contentWindow.focus();
    setTimeout(() => {
      iframe.contentWindow.print();
      setTimeout(() => {
        if (iframe && iframe.parentNode) iframe.parentNode.removeChild(iframe);
      }, 2000);
    }, 600);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 rise" data-testid="table-admin-page">
      {/* Screen UI */}
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-foreground/20 pb-5">
          <div>
            <span className="overline text-primary">Restaurant Layout & Automation</span>
            <h1 className="text-3xl font-semibold tracking-tight mt-1 flex items-center gap-2">
              <Grid className="text-primary" size={26} /> 50-Table Management & QR System
            </h1>
            <p className="text-xs text-muted-foreground mt-1">
              Live status for 50 tables, active bill tracking, & downloadable QR cards powered by <strong className="text-foreground">NovaSaaS</strong>.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={fetchTables}
              className="border border-foreground bg-background px-3 py-2 text-xs uppercase font-medium hover:bg-muted flex items-center gap-1.5"
            >
              <RefreshCw size={14} /> Refresh Status
            </button>
            <button
              onClick={downloadAllQrsBulk}
              disabled={downloadingBulk}
              data-testid="download-all-qrs-button"
              className="border border-foreground bg-card px-3.5 py-2 text-xs uppercase tracking-wider font-bold flex items-center gap-1.5 hover:bg-muted disabled:opacity-50"
            >
              <Download size={15} /> {downloadingBulk ? "Downloading QRs…" : "Download All 50 QRs (PNG)"}
            </button>
            <button
              onClick={printAllStandeesGrid}
              data-testid="print-all-qrs-button"
              className="hard-shadow bg-primary text-primary-foreground px-4 py-2 text-xs uppercase tracking-widest font-bold border border-foreground flex items-center gap-2 hover:opacity-90"
            >
              <Printer size={16} /> Batch Print All 50 Table Standees
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 p-3 border border-foreground bg-card text-xs font-semibold uppercase tracking-wider">
          <span className="text-muted-foreground">Status Legend:</span>
          <span className="flex items-center gap-1.5 text-emerald-700">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Available (Free)
          </span>
          <span className="flex items-center gap-1.5 text-amber-700">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span> Occupied (Active Order)
          </span>
          <span className="flex items-center gap-1.5 text-blue-700">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Reserved
          </span>
        </div>

        {/* 50 Tables Grid */}
        {loading ? (
          <div className="p-12 text-center text-sm text-muted-foreground overline">Loading 50 tables…</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-10 gap-3">
            {tables.map((t) => {
              const isOccupied = t.status === "occupied";
              const isReserved = t.status === "reserved";
              return (
                <div
                  key={t.table_no}
                  onClick={() => setSelectedTable(t)}
                  data-testid={`table-card-${t.table_no}`}
                  className={`border border-foreground p-3 cursor-pointer transition-all hover:scale-105 relative flex flex-col justify-between h-32 hard-shadow ${
                    isOccupied
                      ? "bg-amber-50 border-amber-600"
                      : isReserved
                      ? "bg-blue-50 border-blue-600"
                      : "bg-card hover:bg-muted/40"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="font-mono font-bold text-sm bg-foreground text-background px-1.5 py-0.5">
                      {t.table_no}
                    </span>
                    <button
                      type="button"
                      title="Download QR"
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadSingleQr(t.table_no);
                      }}
                      className="p-1 text-muted-foreground hover:text-primary hover:bg-background border border-transparent hover:border-foreground"
                    >
                      <Download size={14} />
                    </button>
                  </div>

                  <div className="my-1">
                    <span
                      className={`text-[9px] uppercase font-extrabold tracking-wider px-1.5 py-0.5 border block text-center ${
                        isOccupied
                          ? "bg-amber-500 text-white border-amber-600"
                          : isReserved
                          ? "bg-blue-500 text-white border-blue-600"
                          : "bg-emerald-100 text-emerald-800 border-emerald-300"
                      }`}
                    >
                      {t.status}
                    </span>
                  </div>

                  {isOccupied && t.active_order ? (
                    <div className="text-[10px] space-y-0.5 text-amber-950 font-medium">
                      <p className="truncate font-bold">{t.active_order.order_no}</p>
                      <p className="font-mono text-emerald-800 font-bold">₹{t.active_order.total}</p>
                    </div>
                  ) : (
                    <p className="text-[9px] text-muted-foreground text-center">Click for QR</p>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Footer Credit */}
        <div className="pt-6 border-t border-foreground/10 text-center text-xs text-muted-foreground font-medium">
          HYDERABADI IRANI Table Management Suite • <strong className="text-foreground">Powered by NovaSaaS</strong>
        </div>
      </div>

      {/* Modal: Single Table QR Standee Card Preview */}
      {selectedTable && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-background border-2 border-foreground max-w-sm w-full p-6 hard-shadow space-y-4 rise">
            <div className="flex justify-between items-center border-b border-foreground/20 pb-3">
              <h2 className="text-lg font-bold tracking-tight flex items-center gap-2">
                <QrCode size={18} className="text-primary" /> Table Standee QR Card
              </h2>
              <button
                onClick={() => setSelectedTable(null)}
                className="text-lg font-bold hover:bg-muted px-2 py-0.5 border border-foreground"
              >
                ✕
              </button>
            </div>

            {/* The Standee Card Preview */}
            <div className="border-4 border-foreground p-5 bg-card text-center space-y-3 hard-shadow">
              <div>
                <p className="text-lg font-black uppercase tracking-widest text-primary">HYDERABADI IRANI</p>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                  Dine-In Table Menu
                </p>
              </div>

              <div className="flex flex-col items-center">
                <div className="bg-foreground text-background px-4 py-1 font-mono font-extrabold text-2xl uppercase tracking-widest mb-2.5">
                  {selectedTable.table_no}
                </div>
                <img
                  src={getQrUrl(selectedTable.table_no)}
                  alt={`QR code for ${selectedTable.table_no}`}
                  className="w-44 h-44 border-2 border-foreground p-1 bg-white"
                />
                <p className="text-[10px] font-bold uppercase tracking-wider mt-2 text-foreground">
                  Scan QR to Order Directly from Table
                </p>
              </div>

              <div className="border-t-2 border-foreground pt-1.5">
                <p className="text-[11px] font-black uppercase tracking-widest text-foreground">
                  Powered by NovaSaaS
                </p>
              </div>
            </div>

            {/* Quick Status Toggle */}
            <div className="space-y-1.5 pt-1 border-t border-foreground/20">
              <label className="block text-[11px] font-bold uppercase tracking-wider">Update Table Status:</label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleUpdateStatus(selectedTable.table_no, "available")}
                  className={`text-[10px] uppercase font-bold py-1 border border-foreground ${
                    selectedTable.status === "available"
                      ? "bg-emerald-600 text-white"
                      : "bg-background hover:bg-muted"
                  }`}
                >
                  Available
                </button>
                <button
                  type="button"
                  onClick={() => handleUpdateStatus(selectedTable.table_no, "occupied")}
                  className={`text-[10px] uppercase font-bold py-1 border border-foreground ${
                    selectedTable.status === "occupied"
                      ? "bg-amber-600 text-white"
                      : "bg-background hover:bg-muted"
                  }`}
                >
                  Occupied
                </button>
                <button
                  type="button"
                  onClick={() => handleUpdateStatus(selectedTable.table_no, "reserved")}
                  className={`text-[10px] uppercase font-bold py-1 border border-foreground ${
                    selectedTable.status === "reserved"
                      ? "bg-blue-600 text-white"
                      : "bg-background hover:bg-muted"
                  }`}
                >
                  Reserved
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col gap-2">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => downloadSingleQr(selectedTable.table_no)}
                  className="flex-1 bg-background text-foreground hover:bg-muted py-2 text-xs font-bold uppercase tracking-wider border border-foreground hard-shadow flex items-center justify-center gap-1.5"
                >
                  <Download size={14} /> Download PNG
                </button>
                <button
                  type="button"
                  onClick={() => printSingleTableStandee(selectedTable.table_no)}
                  className="flex-1 bg-primary text-primary-foreground py-2 text-xs font-bold uppercase tracking-wider border border-foreground hard-shadow flex items-center justify-center gap-1.5 hover:opacity-90"
                >
                  <Printer size={14} /> Print Standee
                </button>
              </div>
              <a
                href={getTargetUrl(selectedTable.table_no)}
                target="_blank"
                rel="noreferrer"
                className="w-full text-center text-[11px] text-muted-foreground hover:text-foreground font-semibold flex items-center justify-center gap-1 py-1"
              >
                <ExternalLink size={12} /> Test Table Menu Link ({selectedTable.table_no})
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
