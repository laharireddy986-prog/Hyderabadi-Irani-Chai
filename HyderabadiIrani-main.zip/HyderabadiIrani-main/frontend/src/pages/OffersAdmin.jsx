import { useState, useEffect } from "react";
import { api, errMsg } from "@/lib/api";
import { toast } from "sonner";
import { Tag, Plus, Trash2, CheckCircle2, XCircle, Gift, Sparkles, Store, Monitor } from "lucide-react";

export default function OffersAdmin() {
  const [offers, setOffers] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  const [busy, setBusy] = useState(false);

  // Form State
  const [form, setForm] = useState({
    code: "",
    title: "",
    description: "",
    discount_type: "percent", // percent | fixed | freebie
    discount_value: 10,
    scope: "cart",            // cart | item | category
    target_ids: [],
    channel: "both",          // both | online | pos
    min_order: 200,
    max_discount: "",
    freebie_item_id: "",
    freebie_item_name: "",
    active: true,
  });

  const categories = Array.from(new Set(menuItems.map((m) => m.category))).filter(Boolean);

  const fetchOffersAndMenu = async () => {
    setLoading(true);
    try {
      const [resOffers, resMenu] = await Promise.all([
        api.get("/coupons"),
        api.get("/menu"),
      ]);
      setOffers(resOffers.data || []);
      setMenuItems(resMenu.data || []);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOffersAndMenu();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.code.trim()) {
      toast.error("Please enter an offer code");
      return;
    }

    setBusy(true);
    try {
      const payload = {
        ...form,
        code: form.code.toUpperCase().trim(),
        discount_value: parseFloat(form.discount_value) || 0,
        min_order: parseFloat(form.min_order) || 0,
        max_discount: form.max_discount ? parseFloat(form.max_discount) : null,
      };

      await api.post("/coupons", payload);
      toast.success(`Offer ${payload.code} created successfully!`);
      setOpenModal(false);
      resetForm();
      fetchOffersAndMenu();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const toggleStatus = async (offer) => {
    try {
      const updated = { ...offer, active: !offer.active };
      await api.put(`/coupons/${offer.id}`, updated);
      toast.success(`Offer ${offer.code} ${updated.active ? "activated" : "deactivated"}`);
      fetchOffersAndMenu();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const handleDelete = async (offerId, code) => {
    if (!window.confirm(`Are you sure you want to delete offer ${code}?`)) return;
    try {
      await api.delete(`/coupons/${offerId}`);
      toast.success(`Offer ${code} deleted`);
      fetchOffersAndMenu();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const resetForm = () => {
    setForm({
      code: "",
      title: "",
      description: "",
      discount_type: "percent",
      discount_value: 10,
      scope: "cart",
      target_ids: [],
      channel: "both",
      min_order: 200,
      max_discount: "",
      freebie_item_id: "",
      freebie_item_name: "",
      active: true,
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 rise" data-testid="offers-admin-page">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-foreground/20 pb-5">
        <div>
          <span className="overline text-primary">Marketing & Revenue</span>
          <h1 className="text-3xl font-semibold tracking-tight mt-1 flex items-center gap-2">
            <Sparkles className="text-primary" size={26} /> Offers & Discounts Engine
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Create Zomato-style offers: Item-wise, Category-wise, Channel-specific, & Freebies.
          </p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setOpenModal(true);
          }}
          data-testid="create-offer-button"
          className="hard-shadow bg-primary text-primary-foreground px-4 py-2.5 text-xs uppercase tracking-widest font-bold border border-foreground flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <Plus size={16} /> Create New Offer
        </button>
      </div>

      {/* Offers Cards Grid */}
      {loading ? (
        <div className="p-12 text-center text-sm text-muted-foreground overline">Loading offers…</div>
      ) : offers.length === 0 ? (
        <div className="p-12 text-center border border-dashed border-foreground/30 bg-muted/20 space-y-3">
          <Tag className="mx-auto text-muted-foreground" size={36} />
          <p className="font-semibold text-sm">No Offers Created Yet</p>
          <p className="text-xs text-muted-foreground">Click 'Create New Offer' to launch your first promotion.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {offers.map((offer) => {
            const isPercent = offer.discount_type === "percent";
            const isFreebie = offer.discount_type === "freebie";
            return (
              <div
                key={offer.id || offer.code}
                className={`border border-foreground bg-card p-5 relative flex flex-col justify-between space-y-4 hard-shadow ${
                  !offer.active ? "opacity-60" : ""
                }`}
                data-testid={`offer-card-${offer.code}`}
              >
                <div className="space-y-2">
                  <div className="flex justify-between items-start gap-2">
                    <span className="font-mono text-lg font-bold tracking-wider bg-secondary text-secondary-foreground px-2.5 py-1 border border-foreground">
                      {offer.code}
                    </span>
                    <button
                      onClick={() => toggleStatus(offer)}
                      className={`text-xs px-2 py-0.5 border border-foreground font-semibold flex items-center gap-1 ${
                        offer.active
                          ? "bg-green-100 text-green-800"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {offer.active ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                      {offer.active ? "ACTIVE" : "INACTIVE"}
                    </button>
                  </div>

                  <h3 className="font-semibold text-base tracking-tight">{offer.title || offer.code}</h3>
                  {offer.description && (
                    <p className="text-xs text-muted-foreground leading-relaxed">{offer.description}</p>
                  )}

                  {/* Badges */}
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {/* Discount Badge */}
                    <span className="bg-primary/10 text-primary text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border border-primary/30 flex items-center gap-1">
                      {isFreebie ? (
                        <>
                          <Gift size={11} /> Freebie Gift
                        </>
                      ) : isPercent ? (
                        `${offer.discount_value}% OFF`
                      ) : (
                        `₹${offer.discount_value} OFF`
                      )}
                    </span>

                    {/* Scope Badge */}
                    <span className="bg-muted text-foreground text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border border-foreground/30">
                      {offer.scope === "cart" && "Total Cart"}
                      {offer.scope === "category" && `Cat: ${offer.target_ids.join(", ")}`}
                      {offer.scope === "item" && `Specific Items (${offer.target_ids.length})`}
                    </span>

                    {/* Channel Badge */}
                    <span className="bg-secondary/10 text-secondary text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border border-secondary/30 flex items-center gap-1">
                      {offer.channel === "online" && <Monitor size={11} />}
                      {offer.channel === "pos" && <Store size={11} />}
                      {offer.channel.toUpperCase()}
                    </span>
                  </div>

                  <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t border-foreground/10">
                    {offer.min_order > 0 && <p>• Min order: ₹{offer.min_order}</p>}
                    {offer.max_discount && <p>• Max discount cap: ₹{offer.max_discount}</p>}
                    {isFreebie && (
                      <p className="text-primary font-medium">• Gift: {offer.freebie_item_name || "Free item"}</p>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-foreground/10 flex justify-end">
                  <button
                    onClick={() => handleDelete(offer.id, offer.code)}
                    className="text-xs text-destructive hover:bg-destructive/10 p-1.5 border border-destructive transition-colors flex items-center gap-1 font-medium"
                    title="Delete offer"
                  >
                    <Trash2 size={13} /> Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Create Offer */}
      {openModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-background border-2 border-foreground max-w-xl w-full p-6 hard-shadow space-y-5 max-h-[90vh] overflow-y-auto rise">
            <div className="flex justify-between items-center border-b border-foreground/20 pb-3">
              <h2 className="text-xl font-bold tracking-tight flex items-center gap-2">
                <Tag size={20} className="text-primary" /> Create New Zomato-Style Offer
              </h2>
              <button
                onClick={() => setOpenModal(false)}
                className="text-lg font-bold hover:bg-muted px-2 py-0.5 border border-foreground"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Coupon Code *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BIRYANI20"
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                    className="w-full border border-foreground p-2 text-sm outline-none font-mono uppercase focus:ring-2 focus:ring-foreground"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Offer Title</label>
                  <input
                    type="text"
                    placeholder="e.g. 20% Off Main Course"
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1">Description / Subtitle</label>
                <input
                  type="text"
                  placeholder="e.g. Get 20% off on all Main Course items on orders above ₹400"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground"
                />
              </div>

              {/* Scope & Channel */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Applicable Scope</label>
                  <select
                    value={form.scope}
                    onChange={(e) => setForm({ ...form, scope: e.target.value, target_ids: [] })}
                    className="w-full border border-foreground p-2 text-sm outline-none bg-background focus:ring-2 focus:ring-foreground"
                  >
                    <option value="cart">Total Catalogue / Cart</option>
                    <option value="category">Category-Wise</option>
                    <option value="item">Specific Menu Items</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Order Channel</label>
                  <select
                    value={form.channel}
                    onChange={(e) => setForm({ ...form, channel: e.target.value })}
                    className="w-full border border-foreground p-2 text-sm outline-none bg-background focus:ring-2 focus:ring-foreground"
                  >
                    <option value="both">Both (Online + POS)</option>
                    <option value="online">Online Storefront Only</option>
                    <option value="pos">In-Hotel POS Counter Only</option>
                  </select>
                </div>
              </div>

              {/* Target Selection based on Scope */}
              {form.scope === "category" && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Select Target Categories</label>
                  <div className="flex flex-wrap gap-2 p-2 border border-foreground bg-muted/20 max-h-32 overflow-y-auto">
                    {categories.map((cat) => {
                      const selected = form.target_ids.includes(cat);
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => {
                            const newTargets = selected
                              ? form.target_ids.filter((c) => c !== cat)
                              : [...form.target_ids, cat];
                            setForm({ ...form, target_ids: newTargets });
                          }}
                          className={`text-xs px-2.5 py-1 border border-foreground font-medium ${
                            selected ? "bg-primary text-primary-foreground" : "bg-background"
                          }`}
                        >
                          {cat} {selected && "✓"}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {form.scope === "item" && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Select Target Dishes</label>
                  <div className="flex flex-wrap gap-1.5 p-2 border border-foreground bg-muted/20 max-h-36 overflow-y-auto">
                    {menuItems.map((item) => {
                      const selected = form.target_ids.includes(item.id);
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            const newTargets = selected
                              ? form.target_ids.filter((i) => i !== item.id)
                              : [...form.target_ids, item.id];
                            setForm({ ...form, target_ids: newTargets });
                          }}
                          className={`text-xs px-2 py-0.5 border border-foreground ${
                            selected ? "bg-primary text-primary-foreground font-semibold" : "bg-background"
                          }`}
                        >
                          {item.name} {selected && "✓"}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Type, Value & Cap */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-1">Discount Type</label>
                  <select
                    value={form.discount_type}
                    onChange={(e) => setForm({ ...form, discount_type: e.target.value })}
                    className="w-full border border-foreground p-2 text-sm outline-none bg-background focus:ring-2 focus:ring-foreground"
                  >
                    <option value="percent">% Percentage Off</option>
                    <option value="fixed">₹ Flat Amount Off</option>
                    <option value="freebie">🎁 Freebie / Gift Item</option>
                  </select>
                </div>

                {form.discount_type !== "freebie" ? (
                  <>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider mb-1">
                        {form.discount_type === "percent" ? "Discount %" : "Discount Amount (₹)"}
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={form.discount_value}
                        onChange={(e) => setForm({ ...form, discount_value: e.target.value })}
                        className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider mb-1">Max Cap (₹)</label>
                      <input
                        type="number"
                        placeholder="Optional cap"
                        value={form.max_discount}
                        onChange={(e) => setForm({ ...form, max_discount: e.target.value })}
                        className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground"
                      />
                    </div>
                  </>
                ) : (
                  <div className="col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-wider mb-1">Select Free Gift Item</label>
                    <select
                      value={form.freebie_item_id}
                      onChange={(e) => {
                        const sel = menuItems.find((m) => m.id === e.target.value);
                        setForm({
                          ...form,
                          freebie_item_id: e.target.value,
                          freebie_item_name: sel ? sel.name : "",
                        });
                      }}
                      className="w-full border border-foreground p-2 text-sm outline-none bg-background focus:ring-2 focus:ring-foreground"
                    >
                      <option value="">Select a dish from menu…</option>
                      {menuItems.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} (₹{m.price})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1">Minimum Order Amount (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={form.min_order}
                  onChange={(e) => setForm({ ...form, min_order: e.target.value })}
                  className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground"
                />
              </div>

              <div className="pt-3 border-t border-foreground/20 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setOpenModal(false)}
                  className="px-4 py-2 border border-foreground text-xs uppercase tracking-wider hover:bg-muted font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={busy}
                  className="bg-primary text-primary-foreground px-5 py-2 border border-foreground text-xs uppercase tracking-widest font-bold hard-shadow hover:opacity-90"
                >
                  {busy ? "Saving…" : "Save Offer"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
