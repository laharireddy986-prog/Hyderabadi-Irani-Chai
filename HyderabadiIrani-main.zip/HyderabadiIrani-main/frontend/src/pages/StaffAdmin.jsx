import { useState, useEffect } from "react";
import { api, errMsg } from "@/lib/api";
import { toast } from "sonner";
import { Users, UserPlus, Shield, CheckCircle2, XCircle, Trash2, KeyRound } from "lucide-react";

export default function StaffAdmin() {
  const [staffList, setStaffList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  const [editingStaff, setEditingStaff] = useState(null);
  const [busy, setBusy] = useState(false);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "staff",
    active: true,
  });

  const fetchStaff = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/staff");
      setStaffList(data || []);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (editingStaff) {
        // Update
        const payload = {
          name: form.name,
          email: form.email,
          role: form.role,
          active: form.active,
        };
        if (form.password) payload.password = form.password;
        await api.put(`/staff/${editingStaff.id}`, payload);
        toast.success(`Staff member ${form.name} updated!`);
      } else {
        // Create
        if (!form.password) {
          toast.error("Password is required for new staff account");
          setBusy(false);
          return;
        }
        await api.post("/staff", form);
        toast.success(`New staff account ${form.name} created!`);
      }
      setOpenModal(false);
      resetForm();
      fetchStaff();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const toggleStatus = async (user) => {
    try {
      await api.put(`/staff/${user.id}`, { active: !user.active });
      toast.success(`User ${user.name} ${!user.active ? "activated" : "deactivated"}`);
      fetchStaff();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const handleDelete = async (user) => {
    if (!window.confirm(`Are you sure you want to delete staff account ${user.name}?`)) return;
    try {
      await api.delete(`/staff/${user.id}`);
      toast.success(`Staff member ${user.name} deleted`);
      fetchStaff();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  const openEdit = (user) => {
    setEditingStaff(user);
    setForm({
      name: user.name || "",
      email: user.email || "",
      password: "",
      role: user.role || "staff",
      active: user.active !== false,
    });
    setOpenModal(true);
  };

  const resetForm = () => {
    setEditingStaff(null);
    setForm({
      name: "",
      email: "",
      password: "",
      role: "staff",
      active: true,
    });
  };

  const roleBadges = {
    admin: { label: "ADMIN", bg: "bg-red-100 text-red-800 border-red-300" },
    staff: { label: "CASHIER / STAFF", bg: "bg-blue-100 text-blue-800 border-blue-300" },
    kitchen: { label: "KITCHEN CHEF", bg: "bg-amber-100 text-amber-800 border-amber-300" },
    delivery: { label: "DELIVERY DRIVER", bg: "bg-emerald-100 text-emerald-800 border-emerald-300" },
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 rise" data-testid="staff-admin-page">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-foreground/20 pb-5">
        <div>
          <span className="overline text-primary">Access & Governance</span>
          <h1 className="text-3xl font-semibold tracking-tight mt-1 flex items-center gap-2">
            <Users className="text-primary" size={26} /> Staff & Access Management
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Manage staff accounts, assign roles (Admin, Cashier, Kitchen, Driver), and reset credentials.
          </p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setOpenModal(true);
          }}
          data-testid="add-staff-button"
          className="hard-shadow bg-primary text-primary-foreground px-4 py-2.5 text-xs uppercase tracking-widest font-bold border border-foreground flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <UserPlus size={16} /> Add New Staff Member
        </button>
      </div>

      {/* Staff Directory Table */}
      {loading ? (
        <div className="p-12 text-center text-sm text-muted-foreground overline">Loading staff directory…</div>
      ) : staffList.length === 0 ? (
        <div className="p-12 text-center border border-dashed border-foreground/30 bg-muted/20">
          <Users className="mx-auto text-muted-foreground mb-2" size={36} />
          <p className="font-semibold text-sm">No Staff Members Found</p>
        </div>
      ) : (
        <div className="border border-foreground bg-card overflow-x-auto hard-shadow">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-foreground bg-secondary text-secondary-foreground text-xs uppercase tracking-wider">
                <th className="p-3.5">Name</th>
                <th className="p-3.5">Email / User ID</th>
                <th className="p-3.5">Role</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Created Date</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-foreground/10">
              {staffList.map((user) => {
                const badge = roleBadges[user.role] || roleBadges.staff;
                return (
                  <tr key={user.id} className="hover:bg-muted/30 transition-colors" data-testid={`staff-row-${user.email}`}>
                    <td className="p-3.5 font-semibold text-foreground flex items-center gap-2">
                      <Shield size={16} className="text-primary" /> {user.name}
                    </td>
                    <td className="p-3.5 font-mono text-xs text-foreground/80">{user.email}</td>
                    <td className="p-3.5">
                      <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border ${badge.bg}`}>
                        {badge.label}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <button
                        onClick={() => toggleStatus(user)}
                        className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border flex items-center gap-1 ${
                          user.active !== false
                            ? "bg-green-100 text-green-800 border-green-300"
                            : "bg-red-100 text-red-800 border-red-300"
                        }`}
                      >
                        {user.active !== false ? <CheckCircle2 size={11} /> : <XCircle size={11} />}
                        {user.active !== false ? "ACTIVE" : "INACTIVE"}
                      </button>
                    </td>
                    <td className="p-3.5 text-xs text-muted-foreground">
                      {user.created_at ? user.created_at.slice(0, 10) : "N/A"}
                    </td>
                    <td className="p-3.5 text-right space-x-2">
                      <button
                        onClick={() => openEdit(user)}
                        className="text-xs px-2.5 py-1 border border-foreground bg-background hover:bg-muted font-medium"
                      >
                        Edit / Reset Password
                      </button>
                      <button
                        onClick={() => handleDelete(user)}
                        className="text-xs px-2 py-1 border border-destructive text-destructive hover:bg-destructive/10"
                        title="Delete staff account"
                      >
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal: Create / Edit Staff */}
      {openModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-background border-2 border-foreground max-w-md w-full p-6 hard-shadow space-y-5 rise">
            <div className="flex justify-between items-center border-b border-foreground/20 pb-3">
              <h2 className="text-xl font-bold tracking-tight flex items-center gap-2">
                <UserPlus size={20} className="text-primary" />
                {editingStaff ? "Edit Staff Account" : "Add New Staff Member"}
              </h2>
              <button
                onClick={() => setOpenModal(false)}
                className="text-lg font-bold hover:bg-muted px-2 py-0.5 border border-foreground"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1">Email / User ID *</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. ramesh@hyderabadiirani.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1">
                  {editingStaff ? "New Password (Leave blank to keep existing)" : "Password *"}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required={!editingStaff}
                    placeholder={editingStaff ? "Enter new password if changing" : "Enter password"}
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    className="w-full border border-foreground p-2 text-sm outline-none focus:ring-2 focus:ring-foreground font-mono text-xs pr-8"
                  />
                  <KeyRound size={14} className="absolute right-2.5 top-3 text-muted-foreground" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-1">Assigned Role</label>
                <select
                  value={form.role}
                  onChange={(e) => setForm({ ...form, role: e.target.value })}
                  className="w-full border border-foreground p-2 text-sm outline-none bg-background focus:ring-2 focus:ring-foreground"
                >
                  <option value="admin">Admin (Full Control + Reports + Menu + Staff)</option>
                  <option value="staff">Cashier / Staff (POS Billing & Orders)</option>
                  <option value="kitchen">Kitchen Staff (KDS Display Only)</option>
                  <option value="delivery">Delivery Driver (Delivery Partner App Only)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-foreground/20 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setOpenModal(false)}
                  className="px-4 py-2 border border-foreground text-xs uppercase tracking-wider hover:bg-muted font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={busy}
                  className="bg-primary text-primary-foreground px-5 py-2 border border-foreground text-xs uppercase tracking-widest font-bold hard-shadow hover:opacity-90"
                >
                  {busy ? "Saving…" : editingStaff ? "Update Account" : "Create Staff"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
