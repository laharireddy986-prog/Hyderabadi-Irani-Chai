import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api, errMsg, money, API } from "@/lib/api";
import { ArrowLeft, Download, MapPin } from "lucide-react";

const DELIVERY_STEPS = ["placed", "preparing", "ready", "out_for_delivery", "completed"];
const DINEIN_STEPS = ["placed", "preparing", "ready", "completed"];

export default function TrackOrder() {
  const [params] = useSearchParams();
  const [orderNo, setOrderNo] = useState(params.get("order") || "");
  const [phone, setPhone] = useState(params.get("phone") || "");
  const [order, setOrder] = useState(null);
  const [error, setError] = useState("");

  const fetchOrder = async (no, ph, silent = false) => {
    if (!silent) setError("");
    try {
      const qParams = ph?.trim() ? { phone: ph.trim() } : {};
      const { data } = await api.get(`/public/orders/${no.trim()}`, { params: qParams });
      setOrder(data);
    } catch (e) {
      if (!silent) {
        setOrder(null);
        setError(errMsg(e));
      }
    }
  };

  useEffect(() => {
    if (params.get("order")) fetchOrder(params.get("order"), params.get("phone"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Real-time polling every 4s when an order is displayed
  useEffect(() => {
    if (!order?.order_no) return;
    const interval = setInterval(() => {
      fetchOrder(order.order_no, phone, true);
    }, 4000);
    return () => clearInterval(interval);
  }, [order?.order_no, phone]);

  const stepsList = order?.order_type === "delivery" ? DELIVERY_STEPS : DINEIN_STEPS;
  const activeIdx = order ? Math.max(stepsList.indexOf(order.status), 0) : -1;


  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-foreground">
        <div className="mx-auto max-w-3xl px-5 sm:px-8 py-5 flex items-center gap-4">
          <Link to="/" data-testid="track-back-link" className="flex items-center gap-2 overline hover:text-primary">
            <ArrowLeft size={15} /> Menu
          </Link>
          <span className="serif ml-auto text-xl tracking-tighter">Track Order</span>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-5 sm:px-8 py-14">
        <p className="overline text-primary">Live status</p>
        <h1 className="text-4xl sm:text-5xl font-semibold tracking-tighter mt-2">Where is my food?</h1>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchOrder(orderNo, phone);
          }}
          className="mt-8 flex flex-col sm:flex-row gap-3"
          data-testid="track-form"
        >
          <input
            data-testid="track-order-input"
            value={orderNo}
            onChange={(e) => setOrderNo(e.target.value)}
            placeholder="e.g. GH260610-0001"
            className="flex-1 border border-foreground bg-card px-4 py-3.5 text-sm mono outline-none focus:ring-2 focus:ring-foreground"
            required
          />
          <input
            data-testid="track-phone-input"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Phone number used for the order"
            className="flex-1 border border-foreground bg-card px-4 py-3.5 text-sm outline-none focus:ring-2 focus:ring-foreground"
            required
          />
          <button
            data-testid="track-submit-button"
            className="hard-shadow border border-foreground bg-primary text-primary-foreground px-8 py-3.5 text-xs uppercase tracking-widest"
          >
            Track
          </button>
        </form>

        {error && (
          <p data-testid="track-error" className="mt-6 border border-destructive bg-destructive/10 px-4 py-3 text-sm text-destructive">
            {error}
          </p>
        )}

        {order && (
          <div className="mt-10 border border-foreground bg-card p-6 sm:p-8 rise" data-testid="track-result">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="text-3xl font-semibold tracking-tighter mono">{order.order_no}</h2>
              <span data-testid="track-status" className="border border-foreground bg-secondary text-secondary-foreground px-3 py-1.5 overline">
                {order.status}
              </span>
            </div>

            <div className={`mt-8 grid gap-1 ${stepsList.length === 5 ? "grid-cols-5" : "grid-cols-4"}`}>
              {stepsList.map((s, i) => (
                <div key={s} className="text-center">
                  <div className={`h-1.5 ${i <= activeIdx ? "bg-primary" : "bg-muted"}`} />
                  <p className={`mt-2 text-[10px] uppercase tracking-widest ${i <= activeIdx ? "font-bold text-foreground" : "text-muted-foreground"}`}>
                    {s.replace(/_/g, " ")}
                  </p>
                </div>
              ))}
            </div>

            {/* Live Driver Tracking Card */}
            {(order.status === "out_for_delivery" || order.driver_name) && (
              <div className="mt-6 border border-emerald-600 bg-emerald-50 p-4 text-emerald-950 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="bg-emerald-600 text-white p-2.5 rounded-full">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider bg-emerald-200 text-emerald-800 px-2 py-0.5 rounded">
                      Out for Delivery
                    </span>
                    <h3 className="font-semibold text-base mt-0.5">{order.driver_name || "Hyderabadi Irani Delivery Partner"}</h3>
                    <p className="text-xs text-emerald-800">Your food is on the way!</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {order.driver_phone && (
                    <a
                      href={`tel:${order.driver_phone}`}
                      className="border border-emerald-800 bg-emerald-700 text-white px-3.5 py-2 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 hover:bg-emerald-800"
                    >
                      Call Driver
                    </a>
                  )}
                  {order.driver_lat && order.driver_lng && (
                    <a
                      href={`https://www.google.com/maps?q=${order.driver_lat},${order.driver_lng}`}
                      target="_blank"
                      rel="noreferrer"
                      className="border border-emerald-800 bg-white text-emerald-950 px-3.5 py-2 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 hover:bg-emerald-100"
                    >
                      Live Driver Map
                    </a>
                  )}
                </div>
              </div>
            )}

            <div className="mt-8 divide-y divide-foreground/15">
              {order.items.map((l) => (
                <div key={l.item_id} className="flex justify-between py-2.5 text-sm">
                  <span>{l.name} × {l.qty}</span>
                  <span className="mono">{money(l.price * l.qty)}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 border-t border-foreground pt-4 flex justify-between text-lg font-semibold mono">
              <span>Total</span>
              <span data-testid="track-total">{money(order.total)}</span>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                data-testid="track-invoice-link"
                href={`${API}/invoice/${order.order_no}?phone=${encodeURIComponent(phone)}`}
                className="inline-flex items-center gap-2 border border-foreground px-5 py-3 text-xs uppercase tracking-widest hover:bg-muted"
              >
                <Download size={14} /> Download invoice
              </a>
              {order.lat != null && order.lng != null && (
                <a
                  data-testid="track-map-link"
                  href={`https://www.google.com/maps?q=${order.lat},${order.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 border border-foreground bg-primary text-primary-foreground px-5 py-3 text-xs uppercase tracking-widest hover:opacity-90"
                >
                  <MapPin size={14} /> Open in Google Maps
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
