import { useEffect, useState, useMemo } from "react";
import { api, errMsg } from "@/lib/api";
import { toast } from "sonner";
import {
  Users,
  Search,
  Phone,
  MessageSquare,
  Award,
  ShoppingBag,
  Download,
  Sparkles,
  MapPin,
  RefreshCw,
  IndianRupee,
} from "lucide-react";

export default function CustomerAdmin() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all"); // all | registered | frequent | high_value
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/admin/customers");
      setCustomers(data);
    } catch (err) {
      toast.error(errMsg(err) || "Failed to load customer database");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const filtered = useMemo(() => {
    let list = customers;
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.phone.includes(q) ||
          (c.email && c.email.toLowerCase().includes(q))
      );
    }

    if (filter === "registered") {
      list = list.filter((c) => c.registered);
    } else if (filter === "frequent") {
      list = list.filter((c) => c.total_orders >= 3);
    } else if (filter === "high_value") {
      list = list.filter((c) => c.total_spend >= 1000);
    }

    return list;
  }, [customers, query, filter]);

  // Aggregate Stats
  const stats = useMemo(() => {
    const total = customers.length;
    const totalOrders = customers.reduce((acc, c) => acc + (c.total_orders || 0), 0);
    const totalRevenue = customers.reduce((acc, c) => acc + (c.total_spend || 0), 0);
    const avgSpend = total > 0 ? Math.round(totalRevenue / total) : 0;
    return { total, totalOrders, totalRevenue, avgSpend };
  }, [customers]);

  // Export Customer List as CSV
  const exportCsv = () => {
    if (!customers.length) return toast.error("No customer records to export");
    const headers = ["Customer Name", "Phone", "Email", "Account Type", "Total Orders", "Lifetime Spend (INR)", "Loyalty Points", "Favorite Item", "Last Order Date"];
    const rows = customers.map((c) => [
      `"${c.name}"`,
      `"${c.phone}"`,
      `"${c.email || ''}"`,
      c.registered ? "Registered" : "Walk-in Guest",
      c.total_orders,
      c.total_spend.toFixed(2),
      c.loyalty_points,
      `"${c.favorite_item || ''}"`,
      c.last_order_at ? `"${new Date(c.last_order_at).toLocaleDateString()}"` : '""',
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `hyderabadi_irani_customers_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Customer list exported to CSV!");
  };

  const openWhatsApp = (phone, name) => {
    const clean = phone.replace(/\D/g, "");
    const msg = encodeURIComponent(
      `Hello ${name || "valued customer"}! Greetings from *Hyderabadi Irani Food Court* ☕\nWe appreciate your support! Check out today's special Biryani & Irani Chai at https://hyderabadiirani.net`
    );
    window.open(`https://api.whatsapp.com/send?phone=91${clean}&text=${msg}`, "_blank");
  };

  return (
    <div className="p-5 sm:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-foreground/20 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="overline text-primary">CRM & Growth</span>
            <span className="bg-primary/10 text-primary text-[10px] uppercase font-bold px-2 py-0.5 rounded-full">
              Live Database
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-semibold tracking-tighter mt-1">Customer Database</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">
            Track customer order histories, lifetime value, loyalty points, and engage via WhatsApp.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchCustomers}
            disabled={loading}
            className="border border-foreground bg-card hover:bg-muted p-2.5 text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 transition"
            title="Refresh database"
          >
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
          <button
            onClick={exportCsv}
            className="hard-shadow border border-foreground bg-primary text-primary-foreground px-4 py-2.5 text-xs font-bold uppercase tracking-widest flex items-center gap-2 hover:opacity-90 transition"
          >
            <Download size={14} />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Metrics Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="border border-foreground bg-card p-4 sm:p-5 hard-shadow">
          <div className="flex items-center justify-between text-muted-foreground mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Customers</span>
            <Users size={16} className="text-primary" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold font-mono">{stats.total}</p>
          <p className="text-[10px] text-muted-foreground mt-1">Registered accounts + Counter guests</p>
        </div>

        <div className="border border-foreground bg-card p-4 sm:p-5 hard-shadow">
          <div className="flex items-center justify-between text-muted-foreground mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Orders</span>
            <ShoppingBag size={16} className="text-emerald-600" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-700">{stats.totalOrders}</p>
          <p className="text-[10px] text-muted-foreground mt-1">Lifetime customer order volume</p>
        </div>

        <div className="border border-foreground bg-card p-4 sm:p-5 hard-shadow">
          <div className="flex items-center justify-between text-muted-foreground mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Customer Revenue</span>
            <IndianRupee size={16} className="text-amber-600" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold font-mono text-amber-700">₹{stats.totalRevenue.toLocaleString("en-IN")}</p>
          <p className="text-[10px] text-muted-foreground mt-1">Total revenue generated by clients</p>
        </div>

        <div className="border border-foreground bg-card p-4 sm:p-5 hard-shadow">
          <div className="flex items-center justify-between text-muted-foreground mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Avg Customer Value</span>
            <Sparkles size={16} className="text-blue-600" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold font-mono text-blue-700">₹{stats.avgSpend.toLocaleString("en-IN")}</p>
          <p className="text-[10px] text-muted-foreground mt-1">Average lifetime revenue per guest</p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by customer name, mobile number, or email…"
            className="w-full border border-foreground bg-card pl-9 pr-4 py-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {[
            { id: "all", label: "All Customers" },
            { id: "registered", label: "Registered Accounts" },
            { id: "frequent", label: "Frequent Guests (3+ Orders)" },
            { id: "high_value", label: "High Spenders (₹1000+)" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`border border-foreground px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider transition ${
                filter === tab.id
                  ? "bg-foreground text-background"
                  : "bg-card hover:bg-muted text-foreground"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Data Table */}
      <div className="border border-foreground bg-card overflow-x-auto hard-shadow">
        {loading ? (
          <div className="p-12 text-center text-sm text-muted-foreground space-y-2">
            <RefreshCw size={24} className="animate-spin mx-auto text-primary" />
            <p>Loading customer records…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center text-sm text-muted-foreground">
            <Users size={32} className="mx-auto mb-3 opacity-40" />
            <p className="font-semibold text-foreground text-base">No customer records found</p>
            <p className="text-xs mt-1">Try refining your search query or placing orders with phone numbers in POS/Storefront.</p>
          </div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-foreground bg-muted/60 text-[11px] uppercase font-bold tracking-wider text-muted-foreground">
                <th className="py-3.5 px-4">Customer</th>
                <th className="py-3.5 px-4">Contact & WhatsApp</th>
                <th className="py-3.5 px-4 text-center">Orders</th>
                <th className="py-3.5 px-4">Total Spend</th>
                <th className="py-3.5 px-4">Loyalty Pts</th>
                <th className="py-3.5 px-4">Favorite Dish</th>
                <th className="py-3.5 px-4">Last Order</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-foreground/10">
              {filtered.map((c) => (
                <tr key={c.phone} className="hover:bg-muted/30 transition">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary border border-primary/20 flex items-center justify-center font-bold text-xs">
                        {c.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-semibold text-foreground text-[13px] flex items-center gap-1.5">
                          <span>{c.name}</span>
                          {c.registered && (
                            <span className="bg-emerald-100 text-emerald-800 text-[9px] uppercase font-bold px-1.5 py-0.2 rounded border border-emerald-300">
                              App User
                            </span>
                          )}
                        </div>
                        {c.email ? (
                          <span className="text-[11px] text-muted-foreground block">{c.email}</span>
                        ) : (
                          <span className="text-[10px] text-muted-foreground/60 italic">No email</span>
                        )}
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2 font-mono text-xs">
                      <span>+91 {c.phone}</span>
                      <button
                        onClick={() => openWhatsApp(c.phone, c.name)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white p-1 rounded transition"
                        title="Message on WhatsApp"
                      >
                        <MessageSquare size={12} />
                      </button>
                      <a
                        href={`tel:${c.phone}`}
                        className="border border-foreground/30 hover:bg-muted p-1 rounded text-muted-foreground hover:text-foreground transition"
                        title="Call Customer"
                      >
                        <Phone size={12} />
                      </a>
                    </div>
                  </td>

                  <td className="py-3 px-4 text-center">
                    <span className="inline-block bg-muted px-2 py-0.5 rounded font-mono font-bold">
                      {c.total_orders}
                    </span>
                  </td>

                  <td className="py-3 px-4">
                    <span className="font-mono font-bold text-foreground text-sm">
                      ₹{c.total_spend.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </span>
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1 text-amber-700 font-semibold font-mono">
                      <Award size={13} className="text-amber-500" />
                      <span>{c.loyalty_points}</span>
                    </div>
                  </td>

                  <td className="py-3 px-4">
                    <span className="text-muted-foreground font-medium truncate max-w-[140px] block">
                      {c.favorite_item || "—"}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-muted-foreground font-mono text-[11px]">
                    {c.last_order_at
                      ? new Date(c.last_order_at).toLocaleString("en-IN", {
                          day: "2-digit",
                          month: "short",
                          hour: "2-digit",
                          minute: "2-digit",
                        })
                      : "—"}
                  </td>

                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => setSelectedCustomer(c)}
                      className="border border-foreground px-2.5 py-1 text-[11px] uppercase font-bold tracking-wider hover:bg-foreground hover:text-background transition"
                    >
                      Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Customer Detail Drawer Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="border border-foreground bg-card p-6 sm:p-8 max-w-lg w-full hard-shadow space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between border-b border-foreground/20 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-lg font-bold">
                  {selectedCustomer.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-xl font-bold">{selectedCustomer.name}</h3>
                  <p className="text-xs text-muted-foreground font-mono">+91 {selectedCustomer.phone}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="text-muted-foreground hover:text-foreground text-sm font-bold border border-foreground/20 px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="border border-foreground/10 bg-muted/40 p-3 rounded">
                <span className="text-[10px] text-muted-foreground uppercase font-bold block">Lifetime Orders</span>
                <span className="text-lg font-bold font-mono text-emerald-700">{selectedCustomer.total_orders}</span>
              </div>
              <div className="border border-foreground/10 bg-muted/40 p-3 rounded">
                <span className="text-[10px] text-muted-foreground uppercase font-bold block">Total Spend</span>
                <span className="text-lg font-bold font-mono text-primary">₹{selectedCustomer.total_spend.toFixed(2)}</span>
              </div>
              <div className="border border-foreground/10 bg-muted/40 p-3 rounded">
                <span className="text-[10px] text-muted-foreground uppercase font-bold block">Loyalty Points</span>
                <span className="text-lg font-bold font-mono text-amber-600">{selectedCustomer.loyalty_points}</span>
              </div>
              <div className="border border-foreground/10 bg-muted/40 p-3 rounded">
                <span className="text-[10px] text-muted-foreground uppercase font-bold block">Favorite Dish</span>
                <span className="text-xs font-semibold text-foreground truncate block mt-1">{selectedCustomer.favorite_item || "—"}</span>
              </div>
            </div>

            {selectedCustomer.addresses && selectedCustomer.addresses.length > 0 && (
              <div className="border border-foreground/10 p-3 rounded space-y-1">
                <span className="text-[10px] text-muted-foreground uppercase font-bold flex items-center gap-1">
                  <MapPin size={12} /> Saved Addresses
                </span>
                {selectedCustomer.addresses.map((a, i) => (
                  <p key={i} className="text-xs text-foreground leading-snug">
                    {a.address} {a.flat_landmark ? `(${a.flat_landmark})` : ""}
                  </p>
                ))}
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => openWhatsApp(selectedCustomer.phone, selectedCustomer.name)}
                className="flex-1 hard-shadow bg-emerald-600 text-white py-3 text-xs uppercase tracking-widest font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 transition"
              >
                <MessageSquare size={14} /> Send WhatsApp Promo
              </button>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="border border-foreground px-4 py-3 text-xs uppercase tracking-widest font-semibold hover:bg-muted"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
