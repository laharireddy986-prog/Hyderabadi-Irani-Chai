import { useEffect, useState } from "react";
import { toast } from "sonner";
import { api, errMsg, money, openPdf } from "@/lib/api";
import GstMonthly from "@/components/GstMonthly";
import NotificationSound from "@/components/NotificationSound";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";

export default function Dashboard() {
  const [s, setS] = useState(null);
  const today = new Date().toISOString().slice(0, 10);
  const [day, setDay] = useState(today);
  const [report, setReport] = useState(null);
  const [busy, setBusy] = useState(false);

  const runReport = async (download) => {
    setBusy(true);
    try {
      if (download) {
        await openPdf(`/reports/day-end.pdf?date=${day}`, { download: `day-end-${day}.pdf` });
      } else {
        const { data } = await api.get("/reports/day-end", { params: { date: day } });
        setReport(data);
      }
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    api.get("/stats").then((r) => setS(r.data)).catch((e) => toast.error(errMsg(e)));
  }, []);

  if (!s) return <p className="p-8 overline" data-testid="dashboard-loading">Loading…</p>;

  const cards = [
    ["Today's revenue", money(s.today_revenue), "today-revenue"],
    ["Today's orders", s.today_orders, "today-orders"],
    ["Open orders", s.open_orders, "open-orders"],
    ["Avg order value", money(s.avg_order_value), "avg-order-value"],
    ["Lifetime revenue", money(s.total_revenue), "total-revenue"],
    ["Total orders", s.total_orders, "total-orders"],
  ];

  return (
    <div className="p-5 sm:p-8" data-testid="dashboard-page">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="overline text-primary">Overview</p>
          <h1 className="text-4xl font-semibold tracking-tighter mt-1">Dashboard</h1>
        </div>
        <NotificationSound />
      </div>

      <div className="mt-8 grid grid-cols-2 lg:grid-cols-3 border-t border-l border-foreground" data-testid="stats-grid">
        {cards.map(([label, value, id]) => (
          <div key={id} className="border-r border-b border-foreground bg-card p-5 sm:p-6">
            <p className="overline text-muted-foreground">{label}</p>
            <p data-testid={`stat-${id}`} className="mono text-2xl sm:text-3xl mt-2">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="border border-foreground bg-card p-5 sm:p-6">
          <h2 className="text-2xl font-semibold tracking-tighter">Revenue · last 7 days</h2>
          <div className="h-64 min-h-[256px] w-full mt-6" data-testid="revenue-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={s.revenue_by_day}>
                <CartesianGrid stroke="#1A1A1A" strokeOpacity={0.12} vertical={false} />
                <XAxis dataKey="day" tickFormatter={(d) => d.slice(5)} fontSize={11} stroke="#1A1A1A" />
                <YAxis fontSize={11} stroke="#1A1A1A" />
                <Tooltip formatter={(v) => money(v)} />
                <Bar dataKey="revenue" fill="#D45D48" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="border border-foreground bg-card p-5 sm:p-6">
          <h2 className="text-2xl font-semibold tracking-tighter">Best sellers</h2>
          <div className="mt-5 divide-y divide-foreground/15" data-testid="top-items-list">
            {s.top_items.length === 0 && <p className="text-sm text-muted-foreground">No sales yet.</p>}
            {s.top_items.map((t, i) => (
              <div key={t.name} className="flex items-center justify-between py-3">
                <span className="text-sm"><span className="mono text-muted-foreground mr-3">{String(i + 1).padStart(2, "0")}</span>{t.name}</span>
                <span className="mono text-sm">{t.qty}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-10 border border-foreground bg-card p-5 sm:p-6" data-testid="day-end-panel">
        <p className="overline text-primary">Closing the till</p>
        <h2 className="text-2xl font-semibold tracking-tighter mt-1">Day-End Report</h2>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed max-w-xl">
          Sales, GST collected and payment-mode split for any business date. Download it as a PDF for your accountant.
        </p>

        <div className="mt-5 flex flex-wrap gap-3 items-end">
          <div>
            <label className="block overline mb-1.5">Business date</label>
            <input
              data-testid="day-end-date-input"
              type="date"
              value={day}
              onChange={(e) => setDay(e.target.value)}
              className="border border-foreground bg-background px-3 py-2.5 text-sm mono outline-none focus:ring-2 focus:ring-foreground"
            />
          </div>
          <button
            data-testid="day-end-view-button"
            onClick={() => runReport(false)}
            disabled={busy}
            className="border border-foreground px-5 py-3 text-xs uppercase tracking-widest hover:bg-muted disabled:opacity-50"
          >
            View summary
          </button>
          <button
            data-testid="day-end-download-button"
            onClick={() => runReport(true)}
            disabled={busy}
            className="hard-shadow border border-foreground bg-primary text-primary-foreground px-5 py-3 text-xs uppercase tracking-widest disabled:opacity-50"
          >
            Download PDF
          </button>
          <button
            data-testid="day-end-csv-button"
            onClick={async () => {
              setBusy(true);
              try {
                const res = await api.get(`/reports/export/orders.csv?date=${day}`, { responseType: "blob" });
                const url = window.URL.createObjectURL(new Blob([res.data]));
                const link = document.createElement("a");
                link.href = url;
                link.setAttribute("download", `orders-${day}.csv`);
                document.body.appendChild(link);
                link.click();
                link.remove();
                toast.success(`Exported orders for ${day} (CSV)`);
              } catch (e) {
                toast.error(errMsg(e));
              } finally {
                setBusy(false);
              }
            }}
            disabled={busy}
            className="hard-shadow border border-foreground bg-emerald-700 text-white px-5 py-3 text-xs uppercase tracking-widest disabled:opacity-50 hover:bg-emerald-800 transition"
          >
            📊 Export CSV (Excel)
          </button>
        </div>

        {report && (
          <div className="mt-7 grid gap-6 lg:grid-cols-3" data-testid="day-end-summary">
            <div className="border border-foreground/20">
              {[
                ["Orders billed", report.orders, "orders"],
                ["Cancelled", report.cancelled, "cancelled"],
                ["Net sales", money(report.subtotal), "subtotal"],
                ["GST collected", money(report.tax), "tax"],
                ["Gross collection", money(report.total), "total"],
                ["Avg order value", money(report.avg_order_value), "aov"],
              ].map(([l, v, id]) => (
                <div key={id} className="flex justify-between px-4 py-2.5 border-b border-foreground/15 last:border-0 text-sm">
                  <span className="text-muted-foreground">{l}</span>
                  <span data-testid={`day-end-${id}`} className="mono">{v}</span>
                </div>
              ))}
            </div>
            <div>
              <p className="overline text-muted-foreground">By payment mode</p>
              <div className="mt-3 divide-y divide-foreground/15" data-testid="day-end-payments">
                {report.by_payment.length === 0 && <p className="text-sm text-muted-foreground">No sales.</p>}
                {report.by_payment.map((p) => (
                  <div key={p.mode} className="flex justify-between py-2.5 text-sm">
                    <span className="uppercase">{p.mode}</span>
                    <span className="mono">{money(p.amount)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <p className="overline text-muted-foreground">By channel</p>
              <div className="mt-3 divide-y divide-foreground/15" data-testid="day-end-channels">
                {report.by_source.length === 0 && <p className="text-sm text-muted-foreground">No sales.</p>}
                {report.by_source.map((p) => (
                  <div key={p.source} className="flex justify-between py-2.5 text-sm">
                    <span className="uppercase">{p.source}</span>
                    <span className="mono">{money(p.amount)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <GstMonthly />
    </div>
  );
}
