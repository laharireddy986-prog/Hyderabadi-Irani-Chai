import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  FileText,
  Shield,
  RotateCcw,
  Truck,
  Phone,
  Mail,
  MapPin,
  Clock,
  ArrowLeft,
  ChevronRight,
  Sparkles,
  ExternalLink,
} from "lucide-react";

export default function LegalPolicies() {
  const location = useLocation();
  const navigate = useNavigate();

  // Determine active tab from URL path
  const getTabFromPath = (path) => {
    if (path.includes("privacy")) return "privacy";
    if (path.includes("refund") || path.includes("cancellation")) return "refund";
    if (path.includes("shipping") || path.includes("delivery")) return "shipping";
    if (path.includes("contact")) return "contact";
    return "terms";
  };

  const [activeTab, setActiveTab] = useState(getTabFromPath(location.pathname));

  useEffect(() => {
    setActiveTab(getTabFromPath(location.pathname));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);

  const handleTabChange = (tabId, route) => {
    setActiveTab(tabId);
    navigate(route);
  };

  const tabs = [
    { id: "terms", label: "Terms & Conditions", icon: FileText, route: "/terms" },
    { id: "privacy", label: "Privacy Policy", icon: Shield, route: "/privacy" },
    { id: "refund", label: "Refund & Cancellation", icon: RotateCcw, route: "/refund-policy" },
    { id: "shipping", label: "Shipping & Delivery", icon: Truck, route: "/shipping-policy" },
    { id: "contact", label: "Contact Us", icon: Phone, route: "/contact" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col selection:bg-primary selection:text-primary-foreground">
      {/* Top Header */}
      <header className="sticky top-0 z-40 border-b border-foreground/10 bg-background/95 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 text-xs uppercase tracking-widest font-bold text-muted-foreground hover:text-foreground transition"
            >
              <ArrowLeft size={16} />
              <span>Back to Menu</span>
            </Link>
            <Link to="/" className="flex items-center gap-2.5 group">
              <img
                src="/logo.png"
                alt="Hyderabadi Irani Logo"
                className="h-9 w-9 object-contain rounded-full border border-amber-900/20"
              />
              <div className="flex flex-col">
                <span className="text-base sm:text-lg font-extrabold uppercase tracking-tight text-primary leading-none">
                  Hyderabadi Irani
                </span>
                <span className="text-[9px] uppercase font-bold tracking-widest text-muted-foreground">
                  Food Court
                </span>
              </div>
            </Link>
          </div>
          <div className="text-xs text-muted-foreground hidden md:flex items-center gap-3 mono">
            <span>GSTIN: 36BLUPM3251R1Z6</span>
            <span>•</span>
            <span>FSSAI: 23625033000700</span>
            <span>•</span>
            <span>Secunderabad, TS</span>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section className="bg-primary/5 border-b border-border py-8 sm:py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-widest text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                Legal & Compliance Centre
              </span>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mt-2 uppercase">
                {activeTab === "terms" && "Terms & Conditions"}
                {activeTab === "privacy" && "Privacy Policy"}
                {activeTab === "refund" && "Refund & Cancellation Policy"}
                {activeTab === "shipping" && "Shipping & Delivery Policy"}
                {activeTab === "contact" && "Contact Us & Grievances"}
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground mt-1.5">
                Official policies and operational guidelines of <b>Hyderabadi Irani</b> (hyderabadiirani.in).
              </p>
            </div>
            <div className="text-xs text-muted-foreground mono bg-background p-3 rounded-lg border border-border shrink-0">
              <div>Last Updated: August 2026</div>
              <div>Operational Status: Active & Verified</div>
            </div>
          </div>

          {/* Policy Navigation Tabs */}
          <div className="flex overflow-x-auto no-scrollbar gap-2 mt-8 pt-2 border-t border-border/50">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id, tab.route)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                    isActive
                      ? "bg-primary text-primary-foreground shadow-md"
                      : "bg-background border border-border text-foreground hover:bg-muted"
                  }`}
                >
                  <Icon size={14} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="max-w-4xl mx-auto px-4 py-8 sm:py-12 flex-1 w-full">
        {/* TAB 1: TERMS & CONDITIONS */}
        {activeTab === "terms" && (
          <article className="space-y-8 text-sm leading-relaxed">
            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground flex items-center gap-2 uppercase tracking-wide">
                <FileText size={18} className="text-primary" />
                1. Agreement to Terms
              </h2>
              <p className="text-muted-foreground">
                These Terms and Conditions constitute a legally binding agreement made between you, whether personally or on behalf of an entity (“you”) and <b>Hyderabadi Irani</b> (“Company”, “we”, “us”, or “our”), concerning your access to and use of the <b>https://hyderabadiirani.in</b> website as well as any related web applications, dine-in kiosk services, and online food ordering platforms.
              </p>
              <p className="text-muted-foreground">
                By accessing the website and placing an order (online delivery, takeaway, or dine-in), you agree that you have read, understood, and agree to be bound by all of these Terms and Conditions. If you do not agree with all of these terms, you are expressly prohibited from using the site and ordering services.
              </p>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                2. Restaurant Operations & Menu Pricing
              </h2>
              <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                <li>
                  <b>Pricing & Taxes:</b> All prices listed on our menu for food items, beverages, bakery goods, and Iranian specialties are listed in Indian Rupees (₹ INR) and are inclusive of applicable Goods and Services Tax (GST 5%), unless stated otherwise.
                </li>
                <li>
                  <b>Price Modifications:</b> We reserve the right to revise menu prices, introduce special deals, or adjust discounts at any time without prior notice.
                </li>
                <li>
                  <b>Item Availability:</b> All menu items are subject to real-time availability in our kitchen. In the event an ordered item becomes unavailable after placing an order, our staff will contact you immediately to offer a replacement or prompt full refund.
                </li>
              </ul>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                3. Customer Registration & Account Security
              </h2>
              <p className="text-muted-foreground">
                To place online delivery or dine-in orders, customers are required to register or sign in with their valid Indian mobile number and name. You agree to provide accurate and complete information and maintain the confidentiality of your account credentials. You are responsible for all activities and orders placed under your account.
              </p>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                4. Online Payments & Billing
              </h2>
              <p className="text-muted-foreground">
                We accept online payments via <b>Razorpay Payment Gateway</b> (supporting UPI, Google Pay, PhonePe, Paytm, Visa/Mastercard/RuPay Credit & Debit Cards, and Net Banking), as well as Cash on Delivery (COD) for eligible hours.
              </p>
              <ul className="list-disc pl-5 space-y-2 text-muted-foreground mt-2">
                <li>
                  <b>Prepaid Night Policy:</b> Orders placed between <b>10:00 PM and 6:00 AM IST</b> must be prepaid online. Cash on Delivery is disabled during late night hours.
                </li>
                <li>
                  <b>Digital Receipts:</b> An electronic invoice and KOT (Kitchen Order Ticket) branded with <i>"Powered by NovaSaaS"</i> is generated for every order and accessible via your account or tracking page.
                </li>
              </ul>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                5. Limitation of Liability & Food Allergies
              </h2>
              <p className="text-muted-foreground">
                Our food is freshly prepared following stringent hygiene and food safety standards. However, our kitchen processes dairy, nuts, wheat, gluten, and various spices. Customers with specific food allergies must mention their requirements in order notes or confirm with restaurant staff before placing orders.
              </p>
            </section>
          </article>
        )}

        {/* TAB 2: PRIVACY POLICY */}
        {activeTab === "privacy" && (
          <article className="space-y-8 text-sm leading-relaxed">
            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground flex items-center gap-2 uppercase tracking-wide">
                <Shield size={18} className="text-primary" />
                1. Privacy Commitment
              </h2>
              <p className="text-muted-foreground">
                At <b>Hyderabadi Irani</b> (accessible from <b>hyderabadiirani.in</b>), accessible via our web and mobile applications, one of our main priorities is the privacy of our visitors and customers. This Privacy Policy document contains types of information that is collected and recorded by Hyderabadi Irani and how we use it.
              </p>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                2. Information We Collect
              </h2>
              <div className="space-y-3 text-muted-foreground">
                <p>When you register, place an order, or browse our menu, we may collect the following information:</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 bg-background rounded-lg border border-border">
                    <b className="text-foreground block mb-1">Contact Information:</b>
                    Full name, 10-digit mobile number, email address (optional for receipts).
                  </div>
                  <div className="p-3 bg-background rounded-lg border border-border">
                    <b className="text-foreground block mb-1">Delivery & Location Data:</b>
                    GPS latitude/longitude coordinates, house number, landmark, street, and colony name.
                  </div>
                  <div className="p-3 bg-background rounded-lg border border-border">
                    <b className="text-foreground block mb-1">Order & Transaction History:</b>
                    Items ordered, order timestamp, payment method, Razorpay payment ID, and loyalty points.
                  </div>
                  <div className="p-3 bg-background rounded-lg border border-border">
                    <b className="text-foreground block mb-1">Technical Device Data:</b>
                    Browser type, operating system, IP address, and session cookies for seamless login.
                  </div>
                </div>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                3. How We Use Your Information
              </h2>
              <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                <li>To process, fulfill, and deliver your food orders accurately within our 5.0 km radius.</li>
                <li>To send live order tracking updates and SMS/WhatsApp notifications regarding order status.</li>
                <li>To credit and manage customer loyalty reward points on qualifying orders.</li>
                <li>To process refunds and resolve customer service queries through our helpline.</li>
                <li>To prevent fraudulent transactions and maintain high system security.</li>
              </ul>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                4. Payment Gateway & Third-Party Security
              </h2>
              <p className="text-muted-foreground">
                We do NOT store or capture sensitive payment card numbers, CVVs, or Net Banking credentials on our servers. All digital transactions are securely processed through <b>Razorpay Software Private Limited</b>, an RBI-authorized, PCI-DSS Level 1 compliant payment gateway using 256-bit TLS encryption.
              </p>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                5. Data Protection & Customer Rights
              </h2>
              <p className="text-muted-foreground">
                We never sell, rent, or trade your personal data with third-party advertising companies. You have the right to request access to your saved delivery addresses, review past order invoices, or delete your account by contacting our support team at <b>hyderabadiirani1@gmail.com</b>.
              </p>
            </section>
          </article>
        )}

        {/* TAB 3: REFUND & CANCELLATION POLICY */}
        {activeTab === "refund" && (
          <article className="space-y-8 text-sm leading-relaxed">
            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground flex items-center gap-2 uppercase tracking-wide">
                <RotateCcw size={18} className="text-primary" />
                1. Order Cancellation Policy
              </h2>
              <p className="text-muted-foreground">
                Because food items are prepared fresh to order immediately upon confirmation, our cancellation policy is designed to ensure minimal food wastage while accommodating genuine customer requests:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                <li>
                  <b>Before Kitchen Starts Preparation:</b> You may request an order cancellation within <b>60 seconds</b> of placing the order by immediately contacting the store hotline at <b>+91 8331807704</b>. If approved, a 100% refund will be issued.
                </li>
                <li>
                  <b>After Food Preparation Begins:</b> Once the kitchen has initiated cooking or baking, orders cannot be cancelled or modified, and no refund can be processed.
                </li>
                <li>
                  <b>Cancellation by Restaurant:</b> In rare situations where an item is sold out, extreme weather prevents delivery, or the address is beyond our 5.0 km delivery limit, Hyderabadi Irani reserves the right to cancel the order and issue a 100% full refund immediately.
                </li>
              </ul>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                2. Eligibility for Refunds
              </h2>
              <div className="space-y-3 text-muted-foreground">
                <p>Customers are eligible for a replacement or full/partial refund under the following conditions:</p>
                <div className="space-y-2">
                  <div className="p-3 bg-background rounded-lg border border-border flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span><b>Wrong Item Delivered:</b> If you received a completely different dish than ordered.</span>
                  </div>
                  <div className="p-3 bg-background rounded-lg border border-border flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span><b>Missing Items:</b> If any paid item was omitted from your sealed delivery package.</span>
                  </div>
                  <div className="p-3 bg-background rounded-lg border border-border flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span><b>Packaging Defect / Spillage:</b> Food damaged during transit rendering it unconsumable (photographic proof required within 15 minutes of delivery).</span>
                  </div>
                </div>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                3. Refund Processing Timeline
              </h2>
              <div className="p-4 bg-primary/5 rounded-lg border border-primary/20 space-y-2">
                <div className="font-bold text-foreground">Razorpay Payment Gateway Refunds:</div>
                <p className="text-muted-foreground text-xs">
                  Once a refund is approved by our management, the transaction is reversed via Razorpay to the customer's original source account (UPI ID, Debit/Credit Card, or Net Banking account).
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-xs">
                  <div className="bg-background p-2.5 rounded border border-border">
                    <b>UPI / Wallets:</b> Reversal credited within <b>24 to 48 Hours</b>.
                  </div>
                  <div className="bg-background p-2.5 rounded border border-border">
                    <b>Debit / Credit Cards & Net Banking:</b> Reversal reflected within <b>5 to 7 Working Days</b> as per banking clearing cycles.
                  </div>
                </div>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                4. How to Request a Refund or Report an Issue
              </h2>
              <p className="text-muted-foreground">
                To report an order dispute or claim a refund, please contact our store manager immediately with your <b>Order Number</b>:
              </p>
              <div className="flex flex-wrap gap-3 pt-1">
                <a
                  href="tel:+918331807704"
                  className="px-4 py-2 bg-primary text-primary-foreground text-xs font-bold uppercase rounded-lg flex items-center gap-2"
                >
                  <Phone size={14} /> Call Support: +91 8331807704
                </a>
                <a
                  href="mailto:hyderabadiirani1@gmail.com"
                  className="px-4 py-2 bg-secondary text-secondary-foreground text-xs font-bold uppercase rounded-lg flex items-center gap-2 border border-border"
                >
                  <Mail size={14} /> Email: hyderabadiirani1@gmail.com
                </a>
              </div>
            </section>
          </article>
        )}

        {/* TAB 4: SHIPPING & DELIVERY POLICY */}
        {activeTab === "shipping" && (
          <article className="space-y-8 text-sm leading-relaxed">
            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground flex items-center gap-2 uppercase tracking-wide">
                <Truck size={18} className="text-primary" />
                1. Delivery Radius & Service Coverage
              </h2>
              <p className="text-muted-foreground">
                Hyderabadi Irani provides fast, fresh food delivery strictly within a <b>5.0 Kilometer radius</b> from our main kitchen located at <i>Plot no 38 Chandra Properties, Ayyappa Nagar Colony, Ghatkesar Road, 23-67, Rampally Main Rd, Rampally, Secunderabad, Telangana 501302</i>.
              </p>
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-800 text-xs">
                <b>Coverage Areas:</b> Rampally, Ghatkesar Road, Ayyappa Nagar, ECIL surroundings, Cherlapally nearby colonies, and adjacent residential areas within 5 km.
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                2. Delivery Charges & Free Delivery Tier
              </h2>
              <p className="text-muted-foreground">
                Delivery charges are calculated based on accurate GPS aerial distance from our kitchen:
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border border-border mt-2 rounded-lg overflow-hidden">
                  <thead className="bg-muted text-foreground font-bold uppercase">
                    <tr>
                      <th className="p-3 border-b border-border">Distance Range</th>
                      <th className="p-3 border-b border-border">Delivery Fee</th>
                      <th className="p-3 border-b border-border">Special Offer</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border text-muted-foreground">
                    <tr>
                      <td className="p-3 font-medium">0.0 km to 2.0 km</td>
                      <td className="p-3 font-bold text-foreground">₹20</td>
                      <td className="p-3 text-emerald-600 font-bold">FREE on orders &gt; ₹499</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium">2.0 km to 3.0 km</td>
                      <td className="p-3 font-bold text-foreground">₹30</td>
                      <td className="p-3 text-emerald-600 font-bold">FREE on orders &gt; ₹499</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium">3.0 km to 4.0 km</td>
                      <td className="p-3 font-bold text-foreground">₹40</td>
                      <td className="p-3 text-emerald-600 font-bold">FREE on orders &gt; ₹499</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium">4.0 km to 5.0 km</td>
                      <td className="p-3 font-bold text-foreground">₹50</td>
                      <td className="p-3 text-emerald-600 font-bold">FREE on orders &gt; ₹499</td>
                    </tr>
                    <tr className="bg-destructive/5 text-destructive font-semibold">
                      <td className="p-3">Above 5.0 km</td>
                      <td className="p-3" colSpan={2}>Out of delivery zone (Takeaway / Dine-in available)</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                3. Estimated Delivery Time
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 bg-background border border-border rounded-lg space-y-1">
                  <div className="font-bold text-foreground flex items-center gap-1.5">
                    <Clock size={14} className="text-primary" /> Regular Hours Delivery
                  </div>
                  <p className="text-muted-foreground">Standard preparation & delivery time is <b>30 to 45 minutes</b> depending on distance and live traffic conditions.</p>
                </div>
                <div className="p-3.5 bg-background border border-border rounded-lg space-y-1">
                  <div className="font-bold text-foreground flex items-center gap-1.5">
                    <Sparkles size={14} className="text-amber-600" /> Peak & Monsoon Hours
                  </div>
                  <p className="text-muted-foreground">During festival peaks or adverse weather, deliveries may take <b>45 to 60 minutes</b>. Our team prioritizes rider safety.</p>
                </div>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                4. Ordering for Someone Else & Address Accuracy
              </h2>
              <p className="text-muted-foreground">
                Customers can order for family, friends, or office colleagues by pinning the destination on our interactive Google Map on checkout or entering the exact landmark. Please ensure a functioning contact phone number is provided to facilitate delivery handover.
              </p>
            </section>
          </article>
        )}

        {/* TAB 5: CONTACT US & GRIEVANCE REDRESSAL */}
        {activeTab === "contact" && (
          <article className="space-y-8 text-sm leading-relaxed">
            <section className="bg-card p-6 rounded-xl border border-border space-y-4">
              <h2 className="text-lg font-bold text-foreground flex items-center gap-2 uppercase tracking-wide">
                <Phone size={18} className="text-primary" />
                Contact Information & Store Address
              </h2>
              <p className="text-muted-foreground">
                We are committed to providing the authentic taste of Hyderabad with highest quality service. For orders, table reservations, catering, or grievances, reach out to us:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-4 bg-background rounded-xl border border-border space-y-2">
                  <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase">
                    <MapPin size={16} /> Main Kitchen & Dine-in Address
                  </div>
                  <p className="text-xs text-muted-foreground leading-normal">
                    <b>Hyderabadi Irani Restaurant</b><br />
                    Plot no 38 Chandra Properties, Ayyappa Nagar Colony,<br />
                    Ghatkesar Road, 23-67, Rampally Main Rd,<br />
                    Rampally, Hyderabad, Secunderabad, Telangana 501302
                  </p>
                  <a
                    href="https://maps.google.com/?q=17.4617,78.6506"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-primary underline mt-1"
                  >
                    <span>View on Google Maps</span>
                    <ExternalLink size={12} />
                  </a>
                </div>

                <div className="p-4 bg-background rounded-xl border border-border space-y-3">
                  <div>
                    <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase mb-1">
                      <Phone size={15} /> Helpline Number
                    </div>
                    <div className="space-y-1 text-xs">
                      <div><a href="tel:+918331807704" className="hover:underline font-bold text-foreground">+91 8331807704</a> (Order Support & Manager)</div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 text-primary font-bold text-xs uppercase mb-1">
                      <Mail size={15} /> Support Email
                    </div>
                    <a href="mailto:hyderabadiirani1@gmail.com" className="text-xs hover:underline text-foreground">
                      hyderabadiirani1@gmail.com
                    </a>
                  </div>
                </div>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                Kitchen Working Hours
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-background border border-border rounded-lg flex items-center justify-between">
                  <span className="font-semibold text-foreground">Monday – Sunday</span>
                  <span className="text-primary font-bold">6:00 AM – 4:00 AM IST</span>
                </div>
                <div className="p-3 bg-background border border-border rounded-lg flex items-center justify-between">
                  <span className="font-semibold text-foreground">Late Night Kitchen</span>
                  <span className="text-amber-600 font-bold">10:00 PM – 4:00 AM (Prepaid)</span>
                </div>
              </div>
            </section>

            <section className="bg-card p-6 rounded-xl border border-border space-y-3">
              <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
                Grievance Redressal Officer
              </h2>
              <p className="text-xs text-muted-foreground">
                In accordance with the Information Technology Act 2000 and Consumer Protection (E-Commerce) Rules 2020, the name and contact details of the Grievance Officer are provided below:
              </p>
              <div className="p-3.5 bg-muted rounded-lg text-xs space-y-1 mono text-muted-foreground">
                <div><b>Officer:</b> Store Operations Manager</div>
                <div><b>Entity:</b> Hyderabadi Irani Food Court (Powered by NovaSaaS)</div>
                <div><b>Email:</b> hyderabadiirani1@gmail.com</div>
                <div><b>Phone:</b> +91 8331807704</div>
                <div><b>Address:</b> Plot no 38 Chandra Properties, Ayyappa Nagar Colony, Ghatkesar Road, Rampally, Secunderabad, Telangana 501302</div>
              </div>
            </section>
          </article>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-6 mt-12 text-center text-xs text-muted-foreground">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            © {new Date().getFullYear()} <b>Hyderabadi Irani</b>. All rights reserved. Powered by NovaSaaS.
          </div>
          <div className="flex flex-wrap gap-4 text-[11px] font-semibold uppercase tracking-wider">
            <Link to="/terms" className="hover:text-foreground">Terms</Link>
            <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
            <Link to="/refund-policy" className="hover:text-foreground">Refunds</Link>
            <Link to="/shipping-policy" className="hover:text-foreground">Delivery</Link>
            <Link to="/contact" className="hover:text-foreground">Contact</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
