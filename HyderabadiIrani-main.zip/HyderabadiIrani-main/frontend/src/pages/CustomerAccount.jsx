import React, { useEffect, useState } from "react";
import { useCustomerAuth } from "@/context/CustomerAuthContext";
import { useCart } from "@/context/CartContext";
import { useNavigate, Link } from "react-router-dom";
import {
  User,
  Phone,
  Mail,
  MapPin,
  Clock,
  Award,
  ChevronRight,
  LogOut,
  ShoppingBag,
  ArrowLeft,
  RefreshCw,
  Plus,
  Trash2,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
} from "lucide-react";
import { money } from "@/lib/api";
import { toast } from "sonner";
import CustomerAuthModal from "@/components/CustomerAuthModal";
import CustomerAddressSelector from "@/components/CustomerAddressSelector";

export default function CustomerAccount() {
  const { customer, isCustomerLoggedIn, loading, logout, getCustomerOrders, updateProfile } =
    useCustomerAuth();
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState(false);

  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (customer) {
      setEditName(customer.name || "");
      setEditEmail(customer.email || "");
      fetchOrders();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer]);

  const fetchOrders = async () => {
    setOrdersLoading(true);
    const res = await getCustomerOrders();
    setOrdersLoading(false);
    if (res.ok) {
      setOrders(res.orders || []);
    }
  };

  const handleUpdateProfileSubmit = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    const res = await updateProfile({ name: editName, email: editEmail });
    setSavingProfile(false);
    if (res.ok) {
      toast.success("Profile details updated successfully! ✨");
      setEditingProfile(false);
    } else {
      toast.error(res.error || "Failed to update profile");
    }
  };

  const handleReorder = (order) => {
    if (!order.items || order.items.length === 0) return;
    order.items.forEach((it) => {
      addToCart({
        id: it.item_id,
        name: it.name,
        price: it.price,
        veg: true,
      }, it.qty);
    });
    toast.success(`Added ${order.items.length} items to your cart! 🛒`);
    navigate("/checkout");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-stone-950 text-stone-100 flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!isCustomerLoggedIn) {
    return (
      <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col justify-center items-center px-4 py-12">
        <div className="max-w-md w-full text-center bg-stone-900 border border-amber-900/40 rounded-3xl p-8 shadow-2xl">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto mb-4 text-amber-400">
            <User className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold font-serif text-amber-100 mb-2">Customer Account</h1>
          <p className="text-stone-400 text-sm mb-6">
            Sign in with your mobile number to view past orders, track live deliveries, and manage saved addresses.
          </p>
          <div className="space-y-3">
            <button
              onClick={() => setAuthModalOpen(true)}
              className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold rounded-2xl shadow-lg transition"
            >
              Sign In or Register
            </button>
            <Link
              to="/"
              className="block w-full py-3 bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold rounded-2xl text-sm transition"
            >
              Back to Menu
            </Link>
          </div>
        </div>

        <CustomerAuthModal
          isOpen={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          onSuccess={() => {
            setAuthModalOpen(false);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 pb-16 selection:bg-amber-500 selection:text-white">
      {/* Header Bar */}
      <header className="sticky top-0 z-30 bg-stone-900/90 backdrop-blur-md border-b border-stone-800 px-4 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-2 text-stone-400 hover:text-amber-400 text-sm font-semibold transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Order Food</span>
          </Link>
          <h1 className="text-base font-bold font-serif text-amber-100 flex items-center gap-2">
            <span>My Account</span>
          </h1>
          <button
            onClick={() => {
              logout();
              toast.info("Signed out successfully");
              navigate("/");
            }}
            className="text-stone-400 hover:text-red-400 text-xs font-semibold flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-red-950/30 transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6 space-y-6">
        {/* Customer Profile & Loyalty Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Profile Card */}
          <div className="md:col-span-2 bg-gradient-to-br from-stone-900 via-stone-900 to-stone-950 border border-amber-900/40 rounded-3xl p-6 relative overflow-hidden shadow-xl">
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white font-bold text-xl shadow-lg">
                  {customer.name ? customer.name.charAt(0).toUpperCase() : "C"}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-amber-100 flex items-center gap-2">
                    {customer.name}
                    <ShieldCheck className="w-4 h-4 text-emerald-400" title="Verified Customer" />
                  </h2>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-stone-400 mt-1">
                    <span className="flex items-center gap-1">
                      <Phone className="w-3 h-3 text-amber-400" />
                      +91 {customer.phone}
                    </span>
                    {customer.email && (
                      <span className="flex items-center gap-1">
                        <Mail className="w-3 h-3 text-amber-400" />
                        {customer.email}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setEditingProfile(!editingProfile)}
                className="text-xs font-semibold px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 transition"
              >
                {editingProfile ? "Cancel Edit" : "Edit Profile"}
              </button>
            </div>

            {/* Profile Edit Drawer */}
            {editingProfile && (
              <form onSubmit={handleUpdateProfileSubmit} className="mt-6 pt-4 border-t border-stone-800 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-400 mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full p-2.5 bg-stone-950 border border-stone-800 rounded-xl text-xs text-stone-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-400 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      className="w-full p-2.5 bg-stone-950 border border-stone-800 rounded-xl text-xs text-stone-100"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="submit"
                    disabled={savingProfile}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50"
                  >
                    {savingProfile ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Loyalty Points Card */}
          <div className="bg-gradient-to-br from-amber-950/60 to-stone-900 border border-amber-800/40 rounded-3xl p-6 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center justify-between text-amber-400 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Loyalty Rewards</span>
                <Award className="w-5 h-5" />
              </div>
              <div className="text-3xl font-black text-amber-200 mt-1">
                {customer.loyalty_points || 0}{" "}
                <span className="text-sm font-normal text-amber-400/80">Pts</span>
              </div>
              <p className="text-xs text-stone-400 mt-2 leading-relaxed">
                Earn 1 Point for every ₹100 spent. Redeem points for instant discounts on future orders!
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-amber-900/40 text-[11px] text-amber-300/90 font-medium">
              ✨ Free delivery unlocked on orders above ₹499
            </div>
          </div>
        </div>

        {/* Saved Addresses Section */}
        <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-xl">
          <CustomerAddressSelector selectedAddress={null} onSelectAddress={() => {}} />
        </div>

        {/* Past Orders Section */}
        <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-amber-100 font-serif flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-amber-400" />
              <span>Past Orders & Deliveries</span>
            </h3>
            <button
              onClick={fetchOrders}
              className="text-stone-400 hover:text-amber-400 p-1.5 rounded-lg hover:bg-stone-800 transition"
              title="Refresh Orders"
            >
              <RefreshCw className={`w-4 h-4 ${ordersLoading ? "animate-spin" : ""}`} />
            </button>
          </div>

          {ordersLoading ? (
            <div className="py-12 flex justify-center">
              <div className="w-6 h-6 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
            </div>
          ) : orders.length === 0 ? (
            <div className="py-10 text-center text-stone-400">
              <ShoppingBag className="w-10 h-10 mx-auto text-stone-600 mb-2" />
              <p className="text-sm">No orders placed yet.</p>
              <Link
                to="/"
                className="mt-3 inline-block px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow-md transition"
              >
                Browse Menu & Order
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((ord) => {
                const dateStr = new Date(ord.created_at).toLocaleString("en-IN", {
                  dateStyle: "medium",
                  timeStyle: "short",
                });

                const isDelivered = ord.status === "completed" || ord.status === "delivered";

                return (
                  <div
                    key={ord.id || ord.order_no}
                    className="p-4 rounded-2xl bg-stone-950/80 border border-stone-800 hover:border-amber-900/60 transition space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-amber-200 text-sm">#{ord.order_no}</span>
                          <span
                            className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                              isDelivered
                                ? "bg-emerald-950 text-emerald-400 border border-emerald-800/60"
                                : "bg-amber-950 text-amber-300 border border-amber-800/60 animate-pulse"
                            }`}
                          >
                            {ord.status || "Processing"}
                          </span>
                          <span className="text-[11px] capitalize text-stone-400">
                            ({ord.order_type || "delivery"})
                          </span>
                        </div>
                        <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" />
                          {dateStr}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-bold text-stone-100 text-base">{money(ord.total)}</div>
                        <span className="text-[10px] text-stone-400">
                          {ord.payment_mode === "prepaid" ? "💳 Online Paid" : "💵 Cash on Delivery"}
                        </span>
                      </div>
                    </div>

                    {/* Items List */}
                    <div className="bg-stone-900/60 p-3 rounded-xl border border-stone-800/60">
                      <div className="text-xs text-stone-300 space-y-1">
                        {ord.items?.map((it, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>
                              {it.qty}x {it.name}
                            </span>
                            <span className="text-stone-400">{money(it.price * it.qty)}</span>
                          </div>
                        ))}
                      </div>

                      {ord.address && (
                        <div className="mt-2 pt-2 border-t border-stone-800 text-[11px] text-stone-400 flex items-start gap-1">
                          <MapPin className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                          <span className="line-clamp-1">{ord.address}</span>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-1">
                      <Link
                        to={`/track?order_no=${ord.order_no}&phone=${ord.phone}`}
                        className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Live Status
                      </Link>

                      <button
                        onClick={() => handleReorder(ord)}
                        className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition"
                      >
                        Order Again
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
