import { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { api, errMsg, money } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import {
  Truck,
  Phone,
  Navigation,
  CheckCircle2,
  Clock,
  MapPin,
  RefreshCw,
  LogOut,
  ChevronRight,
  ShieldCheck,
} from "lucide-react";

export default function DeliveryApp() {
  const [orders, setOrders] = useState([]);
  const [tab, setTab] = useState("pickup"); // 'pickup' | 'active' | 'history'
  const [busy, setBusy] = useState(false);
  const [gpsActive, setGpsActive] = useState(false);
  const { user, logout } = useAuth();

  const loadOrders = useCallback(async () => {
    try {
      const { data } = await api.get("/delivery/orders");
      setOrders(data);
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, []);

  useEffect(() => {
    loadOrders();
    const interval = setInterval(loadOrders, 8000);
    return () => clearInterval(interval);
  }, [loadOrders]);

  // Live GPS tracking broadcaster for active deliveries
  useEffect(() => {
    if (!gpsActive || !navigator.geolocation) return;

    const activeOrder = orders.find(
      (o) => o.driver_id === user?.id && o.status === "out_for_delivery"
    );
    if (!activeOrder) return;

    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        try {
          await api.put(`/delivery/orders/${activeOrder.id}/location`, {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        } catch {
          // Silent GPS broadcast
        }
      },
      (err) => console.warn("GPS error:", err),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [gpsActive, orders, user]);

  const handleAccept = async (orderId) => {
    setBusy(true);
    try {
      await api.put(`/delivery/orders/${orderId}/accept`);
      toast.success("Order accepted! Navigating to customer address...");
      setTab("active");
      setGpsActive(true);
      loadOrders();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const handleMarkDelivered = async (orderId) => {
    setBusy(true);
    try {
      await api.put(`/delivery/orders/${orderId}/delivered`);
      toast.success("Order marked as Delivered & Payment Collected!");
      loadOrders();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const pickupOrders = orders.filter((o) => o.status === "ready" && !o.driver_id);
  const activeOrders = orders.filter(
    (o) => o.driver_id === user?.id && o.status === "out_for_delivery"
  );
  const historyOrders = orders.filter(
    (o) => o.driver_id === user?.id && o.status === "completed"
  );

  const currentList =
    tab === "pickup" ? pickupOrders : tab === "active" ? activeOrders : historyOrders;

  return (
    <div className="min-h-screen bg-background text-foreground max-w-md mx-auto border-x border-foreground pb-20">
      {/* Mobile App Header */}
      <header className="bg-primary text-primary-foreground p-4 sticky top-0 z-30 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Truck size={22} />
            <div>
              <h1 className="font-semibold text-lg leading-tight">Delivery Express</h1>
              <p className="text-[11px] opacity-80">{user?.name || "Delivery Partner"}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setGpsActive((g) => !g)}
              className={`px-2 py-1 text-[10px] uppercase tracking-wider font-bold rounded flex items-center gap-1 ${
                gpsActive ? "bg-emerald-500 text-white animate-pulse" : "bg-black/20 text-white"
              }`}
            >
              <Navigation size={10} />
              {gpsActive ? "GPS ON" : "GPS OFF"}
            </button>

            <button
              onClick={logout}
              className="p-1.5 hover:bg-black/20 text-primary-foreground"
              title="Logout"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>

        {/* Status Tab Bar */}
        <div className="grid grid-cols-3 gap-1 mt-3 bg-black/20 p-1">
          <button
            onClick={() => setTab("pickup")}
            className={`py-1.5 text-[11px] uppercase tracking-wider font-semibold text-center transition-colors ${
              tab === "pickup" ? "bg-background text-foreground shadow" : "text-primary-foreground opacity-80"
            }`}
          >
            Pickup ({pickupOrders.length})
          </button>
          <button
            onClick={() => setTab("active")}
            className={`py-1.5 text-[11px] uppercase tracking-wider font-semibold text-center transition-colors ${
              tab === "active" ? "bg-background text-foreground shadow" : "text-primary-foreground opacity-80"
            }`}
          >
            Active ({activeOrders.length})
          </button>
          <button
            onClick={() => setTab("history")}
            className={`py-1.5 text-[11px] uppercase tracking-wider font-semibold text-center transition-colors ${
              tab === "history" ? "bg-background text-foreground shadow" : "text-primary-foreground opacity-80"
            }`}
          >
            History ({historyOrders.length})
          </button>
        </div>
      </header>

      {/* Main Orders List */}
      <main className="p-4 space-y-4">
        {currentList.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-foreground/30 p-6 bg-card">
            <Truck size={36} className="mx-auto text-muted-foreground mb-2 opacity-50" />
            <p className="font-semibold text-sm">No orders in this tab</p>
            <p className="text-xs text-muted-foreground mt-1">
              {tab === "pickup"
                ? "New ready orders from kitchen will appear here."
                : tab === "active"
                ? "Accept an order from the Pickup tab to start delivery."
                : "Completed deliveries history will be listed here."}
            </p>
            <button
              onClick={loadOrders}
              className="mt-4 inline-flex items-center gap-1.5 border border-foreground bg-background px-3 py-1.5 text-xs font-semibold uppercase tracking-wider"
            >
              <RefreshCw size={12} /> Refresh Queue
            </button>
          </div>
        ) : (
          currentList.map((o) => {
            const mapsUrl =
              o.lat && o.lng
                ? `https://www.google.com/maps/dir/?api=1&destination=${o.lat},${o.lng}`
                : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(o.address)}`;

            return (
              <article key={o.id} className="border border-foreground bg-card p-4 shadow-sm space-y-3">
                {/* Header info */}
                <div className="flex items-center justify-between border-b border-foreground/15 pb-2">
                  <div>
                    <span className="mono text-base font-bold">{o.order_no}</span>
                    <p className="text-[10px] text-muted-foreground uppercase">
                      {new Date(o.created_at).toLocaleTimeString("en-IN")} · {o.payment_mode.toUpperCase()}
                    </p>
                  </div>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border ${
                      o.status === "completed"
                        ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                        : o.status === "out_for_delivery"
                        ? "bg-amber-100 text-amber-900 border-amber-300"
                        : "bg-blue-100 text-blue-900 border-blue-300"
                    }`}
                  >
                    {o.status.replace(/_/g, " ")}
                  </span>
                </div>

                {/* Customer Details */}
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-sm">{o.customer_name}</span>
                    {o.phone && (
                      <a
                        href={`tel:${o.phone}`}
                        className="inline-flex items-center gap-1 border border-foreground bg-emerald-600 text-white px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider"
                      >
                        <Phone size={12} /> Call
                      </a>
                    )}
                  </div>
                  <p className="text-muted-foreground flex items-start gap-1">
                    <MapPin size={13} className="shrink-0 mt-0.5 text-primary" />
                    <span>{o.address || "Address provided at checkout"}</span>
                  </p>
                  {o.notes && <p className="italic text-[11px] text-amber-800 bg-amber-50 p-1.5 border border-amber-200">Note: {o.notes}</p>}
                </div>

                {/* Item List Summary */}
                <div className="border-t border-b border-foreground/15 py-2 text-xs space-y-1">
                  <p className="overline text-muted-foreground">Items ({o.items?.length || 0})</p>
                  {o.items?.map((item, idx) => (
                    <div key={idx} className="flex justify-between">
                      <span>{item.qty}× {item.name}</span>
                      <span className="mono">{money(item.qty * item.price)}</span>
                    </div>
                  ))}
                </div>

                {/* Collection Amount */}
                <div className="flex justify-between items-center text-xs font-semibold pt-1">
                  <span>Collection Amount:</span>
                  <span className="mono text-sm font-bold text-primary">{money(o.total)}</span>
                </div>

                {/* Action Controls */}
                <div className="space-y-2 pt-2">
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full border border-foreground bg-background text-foreground py-2.5 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-muted"
                  >
                    <Navigation size={14} className="text-primary" /> Open Navigation Map
                  </a>

                  {tab === "pickup" && (
                    <button
                      onClick={() => handleAccept(o.id)}
                      disabled={busy}
                      className="w-full border border-foreground bg-primary text-primary-foreground py-3 text-xs font-bold uppercase tracking-widest hard-shadow disabled:opacity-50"
                    >
                      Accept & Start Delivery
                    </button>
                  )}

                  {tab === "active" && (
                    <button
                      onClick={() => handleMarkDelivered(o.id)}
                      disabled={busy}
                      className="w-full border border-foreground bg-emerald-600 text-white py-3 text-xs font-bold uppercase tracking-widest hard-shadow flex items-center justify-center gap-1.5 hover:bg-emerald-700 disabled:opacity-50"
                    >
                      <CheckCircle2 size={15} /> Mark Order Delivered
                    </button>
                  )}
                </div>
              </article>
            );
          })
        )}
      </main>

      {/* Navigation link to Terminal */}
      <footer className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-card border-t border-foreground p-3 text-center text-xs">
        <Link to="/admin/pos" className="text-primary font-semibold hover:underline">
          Return to Admin / POS Terminal
        </Link>
      </footer>
    </div>
  );
}
