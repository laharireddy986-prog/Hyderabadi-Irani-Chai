import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { api, errMsg } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { ArrowLeft, ChefHat, Clock, Volume2, VolumeX } from "lucide-react";

const COLUMNS = [
  { key: "placed", label: "New", next: "preparing", nextLabel: "Start cooking" },
  { key: "preparing", label: "Cooking", next: "ready", nextLabel: "Mark ready" },
  { key: "ready", label: "Ready to serve", next: "completed", nextLabel: "Served" },
];

const minsAgo = (iso) => Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000));

import { playNotificationSound, notificationSound } from "@/lib/notificationSound";

export default function Kitchen() {
  const [orders, setOrders] = useState([]);
  const [tick, setTick] = useState(0);
  const [moving, setMoving] = useState(null);
  const [stationFilter, setStationFilter] = useState("all");
  const [muted, setMuted] = useState(() => localStorage.getItem("gh_kitchen_muted") === "1");
  const seenRef = useRef(null);
  const mutedRef = useRef(muted);
  const { user } = useAuth();

  useEffect(() => {
    mutedRef.current = muted;
    localStorage.setItem("gh_kitchen_muted", muted ? "1" : "0");
  }, [muted]);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get("/kitchen/queue");
      const ids = new Set(data.map((o) => o.id));
      if (seenRef.current) {
        const fresh = data.filter((o) => o.status === "placed" && !seenRef.current.has(o.id));
        if (fresh.length && !mutedRef.current) {
          playNotificationSound(5000); // Loud 5-second notification alarm
          toast.success(`🚨 ${fresh.length} NEW ORDER(S) RECEIVED!`);
        }
      }
      seenRef.current = ids;
      setOrders(data);
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, []);

  useEffect(() => {
    load();
    const poll = setInterval(() => {
      if (document.visibilityState === "visible") load();
    }, 7000);
    const clock = setInterval(() => setTick((t) => t + 1), 30000);
    return () => {
      clearInterval(poll);
      clearInterval(clock);
    };
  }, [load]);

  const move = async (o, status) => {
    if (moving === o.id) return;
    setMoving(o.id);
    setOrders((p) => p.filter((x) => x.id !== o.id));
    try {
      await api.put(`/orders/${o.id}/status`, { status });
      load();
    } catch (e) {
      toast.error(errMsg(e));
      load();
    } finally {
      setMoving(null);
    }
  };

  const getFilteredItems = (itemsList) => {
    if (stationFilter === "all") return itemsList;
    return itemsList.filter((i) => (i.station || "kitchen") === stationFilter);
  };

  return (
    <div className="min-h-screen bg-secondary text-secondary-foreground" data-testid="kitchen-screen">
      <header className="border-b border-secondary-foreground/25 px-5 sm:px-8 py-4 flex flex-wrap items-center gap-4">
        <ChefHat size={22} />
        <h1 className="serif text-3xl tracking-tighter">Kitchen Display</h1>

        {/* Station Filter Selector */}
        <div className="flex border border-secondary-foreground/40 text-xs font-semibold uppercase tracking-wider">
          {["all", "kitchen", "beverage", "bakery"].map((st) => (
            <button
              key={st}
              onClick={() => setStationFilter(st)}
              className={`px-3 py-1 transition-colors ${stationFilter === st ? "bg-secondary-foreground text-secondary" : "hover:bg-secondary-foreground/10"}`}
            >
              {st === "all" ? "All Stations" : st}
            </button>
          ))}
        </div>

        <span data-testid="kitchen-live-count" className="border border-secondary-foreground/40 px-3 py-1 overline">
          {orders.length} live
        </span>
        <span className="overline text-secondary-foreground/60 hidden sm:inline">auto-refreshing</span>
        <div className="ml-auto flex items-center gap-4">
          <button
            data-testid="kitchen-sound-toggle"
            onClick={() => {
              if (muted) playNotificationSound(5000);
              setMuted((m) => !m);
            }}
            title={muted ? "Sound alerts are MUTED (Click to activate 5s alert)" : "Sound alerts are ON (5-second alarm)"}
            className="flex items-center gap-2 border border-secondary-foreground/40 px-3 py-2 overline hover:bg-secondary-foreground/10"
          >
            {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            <span data-testid="kitchen-sound-state" className="hidden sm:inline">
              {muted ? "Muted" : "Alerts ON (5s)"}
            </span>
          </button>
          <span className="overline text-secondary-foreground/60 hidden sm:inline">{user?.name}</span>
          <Link to="/admin/pos" data-testid="kitchen-exit-link" className="flex items-center gap-2 border border-secondary-foreground/40 px-4 py-2 overline hover:bg-secondary-foreground/10">
            <ArrowLeft size={14} /> Terminal
          </Link>
        </div>
      </header>

      <div className="grid gap-0 lg:grid-cols-3 border-t border-secondary-foreground/20" data-testid="kitchen-columns">
        {COLUMNS.map((col) => {
          const list = orders.filter((o) => o.status === col.key);
          return (
            <section key={col.key} data-testid={`kitchen-col-${col.key}`} className="border-b lg:border-b-0 lg:border-r border-secondary-foreground/20 p-4 sm:p-5 min-h-[60vh]">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-semibold tracking-tighter">{col.label}</h2>
                <span data-testid={`kitchen-count-${col.key}`} className="mono text-sm text-secondary-foreground/60">{list.length}</span>
              </div>

              <div className="mt-4 space-y-3">
                {list.length === 0 && (
                  <p data-testid={`kitchen-empty-${col.key}`} className="text-sm text-secondary-foreground/50">
                    Nothing here.
                  </p>
                )}
                {list.map((o) => {
                  const late = minsAgo(o.created_at) >= 15;
                  return (
                    <article
                      key={o.id}
                      data-testid={`kitchen-ticket-${o.order_no}`}
                      className={`border bg-background text-foreground p-4 rise ${late ? "border-primary border-2" : "border-foreground"}`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="mono text-base font-semibold">{o.order_no}</p>
                        <span className={`mono text-xs flex items-center gap-1 ${late ? "text-primary font-semibold" : "text-muted-foreground"}`} data-testid={`kitchen-age-${o.order_no}`}>
                          <Clock size={12} /> {minsAgo(o.created_at)}m
                        </span>
                      </div>
                      <p className="overline mt-1 text-muted-foreground">
                        {o.order_type}{o.table_no ? ` · Table ${o.table_no}` : ""} · {o.source}
                      </p>

                      <div className="mt-3 space-y-1.5">
                        {getFilteredItems(o.items).map((l) => (
                          <div key={l.item_id} className="text-base leading-snug">
                            <div className="flex justify-between items-start">
                              <span>
                                <span className="mono font-semibold mr-2">{l.qty}×</span>
                                {l.name}
                              </span>
                              <span className="text-[9px] uppercase opacity-60 border px-1">{l.station || "kitchen"}</span>
                            </div>
                            {l.notes && (
                              <p className="text-xs text-amber-600 font-semibold italic pl-6 mt-0.5">
                                👉 Note: {l.notes}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>

                      {o.notes && (
                        <p className="mt-3 border-l-2 border-primary pl-2 text-xs italic">{o.notes}</p>
                      )}

                      {/* Action Buttons based on order stage and order type */}
                      {col.key === "ready" && o.order_type === "delivery" ? (
                        <div className="mt-4 space-y-2">
                          <div className="border border-emerald-600/30 bg-emerald-50 text-emerald-950 p-2.5 rounded text-xs space-y-1">
                            <div className="flex items-center justify-between font-bold">
                              <span>🛵 Delivery Ready</span>
                              {o.driver_name ? (
                                <span className="bg-emerald-200 text-emerald-900 px-1.5 py-0.5 rounded text-[10px]">
                                  Rider: {o.driver_name}
                                </span>
                              ) : (
                                <span className="text-amber-700 font-normal">Waiting for Rider</span>
                              )}
                            </div>
                            {o.address && <p className="text-[11px] text-emerald-800 line-clamp-1">📍 {o.address}</p>}
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <button
                              data-testid={`kitchen-dispatch-${o.order_no}`}
                              onClick={() => move(o, "out_for_delivery")}
                              disabled={moving === o.id}
                              className="border border-foreground bg-primary text-primary-foreground py-2 text-[10px] font-bold uppercase tracking-wider hover:bg-foreground transition-colors disabled:opacity-50"
                              title="Hand over food packet to delivery partner"
                            >
                              Dispatch / Rider
                            </button>
                            <button
                              data-testid={`kitchen-served-${o.order_no}`}
                              onClick={() => move(o, "completed")}
                              disabled={moving === o.id}
                              className="border border-foreground bg-secondary text-secondary-foreground py-2 text-[10px] font-bold uppercase tracking-wider hover:bg-foreground hover:text-background transition-colors disabled:opacity-50"
                            >
                              Mark Delivered
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          data-testid={`kitchen-advance-${o.order_no}`}
                          onClick={() => move(o, col.next)}
                          disabled={moving === o.id}
                          className="mt-4 w-full border border-foreground bg-primary text-primary-foreground py-2.5 text-[11px] uppercase tracking-widest hover:bg-foreground transition-colors disabled:opacity-50"
                        >
                          {col.key === "ready" && (o.order_type === "dinein" || o.order_type === "dine-in")
                            ? `Serve to Table ${o.table_no || ""}`
                            : col.key === "ready" && o.order_type === "takeaway"
                            ? "Handover to Customer"
                            : col.nextLabel}
                        </button>
                      )}
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
      <span className="hidden">{tick}</span>
    </div>
  );
}
