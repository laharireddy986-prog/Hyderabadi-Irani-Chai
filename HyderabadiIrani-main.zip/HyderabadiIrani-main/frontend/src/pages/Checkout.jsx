import { useEffect, useState, useRef, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api, errMsg, money, API } from "@/lib/api";
import { useCart } from "@/context/CartContext";
import { useCustomerAuth } from "@/context/CustomerAuthContext";
import CustomerAuthModal from "@/components/CustomerAuthModal";
import CustomerAddressSelector from "@/components/CustomerAddressSelector";
import {
  Minus,
  Plus,
  Trash2,
  ArrowLeft,
  Download,
  MapPin,
  AlertCircle,
  Navigation,
  Sparkles,
  Clock,
  Info,
  User,
  LogIn,
  ShieldCheck,
  Coffee,
} from "lucide-react";
import { useJsApiLoader, GoogleMap, MarkerF, CircleF, Autocomplete } from "@react-google-maps/api";
import {
  STORE_LOCATION,
  MAX_DELIVERY_DISTANCE_KM,
  FREE_DELIVERY_THRESHOLD,
  calculateDistanceKm,
  calculateDeliveryFee,
  isNightSession,
  DELIVERY_TERMS,
} from "@/lib/deliveryTerms";
import { getCartPairings } from "@/lib/pairings";
import PairingShelf from "@/components/PairingShelf";

const GOOGLE_MAPS_KEY = process.env.REACT_APP_GOOGLE_MAPS_KEY || "";
const MAP_LIBRARIES = ["places"];

function loadRazorpayScript() {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function Checkout() {
  const { lines, setQty, subtotal, clear } = useCart();
  const { customer, isCustomerLoggedIn } = useCustomerAuth();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [form, setForm] = useState({
    customer_name: "",
    phone: "",
    address: "",
    notes: "",
    lat: null,
    lng: null,
  });
  const [markerPos, setMarkerPos] = useState(STORE_LOCATION);
  const isNight = isNightSession();
  const isDineIn = Boolean(sessionStorage.getItem("table_no"));
  // In-house (dine-in) bookings placed via the app/website must be prepaid
  // online — cash is only available when a staff member takes the order at
  // the counter through POS. Enforced server-side too (see backend/server.py).
  const [payMode, setPayMode] = useState(isNight || isDineIn ? "razorpay" : "cod");
  const [rzpEnabled, setRzpEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [locating, setLocating] = useState(false);
  const [placed, setPlaced] = useState(null);
  const [couponCode, setCouponCode] = useState("");
  const [couponInfo, setCouponInfo] = useState(null);
  const [availableOffers, setAvailableOffers] = useState([]);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const navigate = useNavigate();

  const [storeStatus, setStoreStatus] = useState({ is_online_open: true, notice: "" });
  const [menuItems, setMenuItems] = useState([]);

  // Preload Razorpay checkout script, store status & menu items in background
  useEffect(() => {
    loadRazorpayScript();
    api.get("/store/status")
      .then((r) => {
        if (r.data) setStoreStatus(r.data);
      })
      .catch(() => {});
    api.get("/menu", { params: { only_available: true } })
      .then((r) => {
        if (r.data) setMenuItems(r.data);
      })
      .catch(() => {});
  }, []);

  const cartPairings = useMemo(() => {
    return getCartPairings(lines, menuItems, 6);
  }, [lines, menuItems]);

  // Pre-fill customer details if logged in
  useEffect(() => {
    if (customer) {
      setForm((prev) => ({
        ...prev,
        customer_name: prev.customer_name || customer.name || "",
        phone: prev.phone || customer.phone || "",
      }));
      // Auto-select default address if no address is set yet
      if (!form.address && customer.addresses && customer.addresses.length > 0) {
        const defAddr = customer.addresses.find((a) => a.is_default) || customer.addresses[0];
        if (defAddr) {
          handleSelectSavedAddress(defAddr);
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customer]);

  const handleSelectSavedAddress = (addr) => {
    if (!addr) return;
    const fullText = addr.address + (addr.flat_landmark ? ` (Landmark: ${addr.flat_landmark})` : "");
    setForm((prev) => ({
      ...prev,
      address: fullText,
      lat: addr.lat || prev.lat,
      lng: addr.lng || prev.lng,
    }));
    if (addr.lat && addr.lng) {
      setMarkerPos({ lat: addr.lat, lng: addr.lng });
    }
    toast.success(`Selected delivery address: ${addr.label || "Saved Address"} 🏠`);
  };

  useEffect(() => {
    const fetchOffers = async () => {
      try {
        const { data } = await api.get("/coupons");
        const onlineOffers = (data || []).filter(
          (o) => o.active && (o.channel === "online" || o.channel === "both")
        );
        setAvailableOffers(onlineOffers);
      } catch (e) {
        /* silent */
      }
    };
    const fetchPaymentConfig = async () => {
      try {
        const { data } = await api.get("/payments/config");
        if (data?.razorpay_enabled) {
          setRzpEnabled(true);
          if (isNight || isDineIn) {
            setPayMode("razorpay");
          }
        }
      } catch (e) {
        /* silent */
      }
    };
    fetchOffers();
    fetchPaymentConfig();
  }, [isNight, isDineIn]);

  const handleApplyCoupon = async (codeToApply) => {
    const code = (codeToApply || couponCode).toUpperCase().trim();
    if (!code) return toast.error("Enter a coupon code");
    if (!subtotal) return toast.error("Your cart is empty");
    try {
      const { data } = await api.get(`/coupons/validate?code=${code}&subtotal=${subtotal}&channel=online`);
      setCouponCode(code);
      setCouponInfo(data);
      if (data.discount_type === "freebie") {
        toast.success(`Offer ${data.code} applied! Free Gift: ${data.freebie_item_name}`);
      } else {
        toast.success(`Coupon ${data.code} applied! Saved ${money(data.discount_amount)}`);
      }
    } catch (e) {
      toast.error(errMsg(e));
      setCouponInfo(null);
    }
  };

  const discountAmount = couponInfo ? couponInfo.discount_amount : 0;
  const distanceKm =
    form.lat && form.lng
      ? calculateDistanceKm(STORE_LOCATION.lat, STORE_LOCATION.lng, form.lat, form.lng)
      : 0;
  const isOutOfBounds = form.lat && form.lng && distanceKm > MAX_DELIVERY_DISTANCE_KM;

  // Delivery Fee Calculation based on distance & order total
  const deliveryCalc = calculateDeliveryFee(distanceKm, subtotal);
  const deliveryFee = isDineIn ? 0 : deliveryCalc.fee;

  const total = Math.max(0, subtotal - discountAmount + deliveryFee);
  const taxableSubtotal = Math.round((total / 1.05) * 100) / 100;
  const tax = Math.round((total - taxableSubtotal) * 100) / 100;
  const autocompleteRef = useRef(null);

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: GOOGLE_MAPS_KEY,
    libraries: MAP_LIBRARIES,
  });

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onPlaceChanged = () => {
    if (autocompleteRef.current) {
      const place = autocompleteRef.current.getPlace();
      if (place && place.geometry && place.geometry.location) {
        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();
        const formattedAddress = place.formatted_address || place.name || "";
        setForm((prev) => ({ ...prev, address: formattedAddress, lat, lng }));
        setMarkerPos({ lat, lng });
      }
    }
  };

  const geocodeAndSet = (lat, lng, actionLabel = "Location updated!") => {
    setMarkerPos({ lat, lng });
    setForm((prev) => ({ ...prev, lat, lng }));

    if (window.google && window.google.maps && window.google.maps.Geocoder) {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === "OK" && results && results[0]) {
          setForm((prev) => ({ ...prev, address: results[0].formatted_address }));
          toast.success(actionLabel);
        }
      });
    }
  };

  const onMarkerDragEnd = (e) => {
    if (e && e.latLng) {
      const lat = e.latLng.lat();
      const lng = e.latLng.lng();
      geocodeAndSet(lat, lng, "Marker pinned to new delivery spot!");
    }
  };

  const onMapClick = (e) => {
    if (e && e.latLng) {
      const lat = e.latLng.lat();
      const lng = e.latLng.lng();
      geocodeAndSet(lat, lng, "Delivery pin placed on map!");
    }
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      return toast.error("Geolocation is not supported by your browser");
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setMarkerPos({ lat, lng });
        setForm((prev) => ({ ...prev, lat, lng }));

        if (window.google && window.google.maps && window.google.maps.Geocoder) {
          const geocoder = new window.google.maps.Geocoder();
          geocoder.geocode({ location: { lat, lng } }, (results, status) => {
            setLocating(false);
            if (status === "OK" && results && results[0]) {
              setForm((prev) => ({ ...prev, address: results[0].formatted_address }));
              toast.success("Located your current address!");
            } else {
              toast.success("Marker updated to your GPS location!");
            }
          });
        } else {
          setLocating(false);
          toast.success("Marker updated to your GPS location!");
        }
      },
      (error) => {
        setLocating(false);
        if (error.code === error.PERMISSION_DENIED) {
          toast.error("Location permission denied. Please search or pick on map.");
        } else {
          toast.error("Could not retrieve your location. Please search or pick on map.");
        }
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const payOnline = async (order) => {
    const ok = await loadRazorpayScript();
    if (!ok) throw new Error("Could not load the payment window");
    const { data: rp } = await api.post("/payments/razorpay/order", { order_no: order.order_no });
    await new Promise((resolve, reject) => {
      const rzp = new window.Razorpay({
        key: rp.key_id,
        amount: rp.amount,
        currency: rp.currency,
        order_id: rp.razorpay_order_id,
        name: "Hyderabadi Irani",
        description: `Order ${order.order_no}`,
        prefill: { name: form.customer_name, contact: form.phone },
        theme: { color: "#D45D48" },
        handler: async (res) => {
          try {
            await api.post("/payments/razorpay/verify", {
              order_no: order.order_no,
              razorpay_order_id: res.razorpay_order_id,
              razorpay_payment_id: res.razorpay_payment_id,
              razorpay_signature: res.razorpay_signature,
            });
            resolve();
          } catch (err) {
            reject(err);
          }
        },
        modal: { ondismiss: () => reject(new Error("Payment cancelled")) },
      });
      rzp.open();
    });
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!lines.length) return toast.error("Your cart is empty");

    if (!isCustomerLoggedIn) {
      setAuthModalOpen(true);
      return toast.error("Please Sign In or Register with your phone number to place your order.");
    }

    if (!isDineIn && isOutOfBounds) {
      return toast.error(
        `We deliver up to ${MAX_DELIVERY_DISTANCE_KM} km from our Secunderabad store. Your address is ${distanceKm} km away.`
      );
    }
    if (isNight && payMode === "cod") {
      return toast.error(
        "Late Night orders (10:00 PM to 6:00 AM) must be prepaid online. Cash on delivery is disabled."
      );
    }
    if (isDineIn && payMode === "cod") {
      return toast.error(
        "Dine-in bookings must be prepaid online. Cash is only available when ordering at the counter."
      );
    }

    setBusy(true);
    try {
      const activeTableNo = sessionStorage.getItem("table_no");
      const orderType = activeTableNo ? "dine-in" : "delivery";
      const { data } = await api.post("/public/orders", {
        ...form,
        order_type: orderType,
        table_no: activeTableNo || "",
        payment_mode: payMode,
        discount_code: couponInfo?.code || "",
        discount: discountAmount,
        delivery_fee: deliveryFee,
        distance_km: distanceKm,
        // lines[].item_id is the cart LINE key (e.g. "<id>_half" for a
        // portion variant so both sizes of a dish can be separate lines),
        // not the real menu item id — send base_item_id (falls back to
        // item_id for plain, non-variant lines) so the backend can look the
        // item up. See mobile-customer-app/src/components/CartModal.jsx for
        // the same fix on the mobile side.
        items: lines.map((l) => ({ ...l, item_id: l.base_item_id || l.item_id })),
      });
      if (payMode === "razorpay") {
        await payOnline(data);
        toast.success("Payment received successfully!");
      }
      setPlaced({ ...data, payment_mode: payMode, delivery_fee: deliveryFee });
      clear();
    } catch (e2) {
      toast.error(errMsg(e2));
    } finally {
      setBusy(false);
    }
  };

  if (placed)
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-background">
        <div className="w-full max-w-lg border border-foreground bg-card p-8 sm:p-12 rise" data-testid="order-success">
          <p className="overline text-primary">Order confirmed</p>
          <h1 className="text-4xl font-semibold tracking-tighter mt-2">Thank you, {placed.customer_name}!</h1>
          <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
            {placed.payment_mode === "razorpay"
              ? "Payment confirmed. Your order is being prepared by our kitchen."
              : "Your order is with our kitchen. Pay cash on delivery."}
          </p>
          <div className="mt-8 border border-foreground/20 bg-muted p-5 mono text-sm">
            <div className="flex justify-between">
              <span>Order No.</span>
              <span data-testid="success-order-no" className="font-semibold">{placed.order_no}</span>
            </div>
            {placed.delivery_fee > 0 && (
              <div className="flex justify-between mt-2">
                <span>Delivery Charge</span>
                <span>{money(placed.delivery_fee)}</span>
              </div>
            )}
            <div className="flex justify-between mt-2">
              <span>{placed.payment_mode === "razorpay" ? "Amount paid" : "Total payable"}</span>
              <span data-testid="success-total" className="font-bold text-primary">{money(placed.total)}</span>
            </div>
            <div className="flex justify-between mt-2">
              <span>Payment</span>
              <span data-testid="success-payment-mode">
                {placed.payment_mode === "razorpay" ? "PAID ONLINE" : "CASH ON DELIVERY"}
              </span>
            </div>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              data-testid="download-invoice-link"
              href={`${API}/invoice/${placed.order_no}?phone=${encodeURIComponent(placed.phone)}`}
              className="hard-shadow border border-foreground bg-primary text-primary-foreground px-6 py-3 text-xs uppercase tracking-widest flex items-center gap-2"
            >
              <Download size={14} /> Invoice PDF
            </a>
            <button
              data-testid="track-my-order-button"
              onClick={() => navigate(`/track?order=${placed.order_no}&phone=${encodeURIComponent(placed.phone)}`)}
              className="border border-foreground px-6 py-3 text-xs uppercase tracking-widest hover:bg-muted"
            >
              Track order
            </button>
          </div>
          <Link to="/" className="block mt-8 text-xs underline underline-offset-4">← Back to menu</Link>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <div className="border-b border-foreground">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-4 flex items-center justify-between">
          <Link to="/" data-testid="back-to-menu-link" className="flex items-center gap-2 overline hover:text-primary">
            <ArrowLeft size={15} /> Menu
          </Link>
          <Link to="/" className="flex items-center gap-2.5">
            <img src="/logo.png" alt="Logo" className="h-8 w-8 object-contain rounded-full border border-foreground/20" />
            <span className="serif text-xl sm:text-2xl font-bold tracking-tight text-primary">Hyderabadi Irani</span>
          </Link>
          <span className="serif text-sm sm:text-base tracking-tighter text-muted-foreground hidden sm:block">Checkout & Delivery</span>
        </div>
      </div>

      {lines.length === 0 ? (
        <div className="mx-auto max-w-2xl px-5 sm:px-8 py-20 text-center">
          <div className="border border-foreground bg-card p-10 sm:p-14 hard-shadow">
            <p className="overline text-primary">Your Cart is Empty</p>
            <h1 className="text-4xl font-semibold tracking-tighter mt-2">No items added yet</h1>
            <p className="mt-4 text-sm text-muted-foreground max-w-md mx-auto leading-relaxed">
              Explore our authentic Hyderabadi Biryani, freshly brewed Irani Chai, and snacks.
            </p>
            <Link
              to="/"
              data-testid="cart-empty-browse-btn"
              className="hard-shadow mt-8 inline-flex items-center justify-center gap-2 border border-foreground bg-primary text-primary-foreground px-8 py-3.5 text-xs font-semibold uppercase tracking-widest hover:opacity-90 transition-opacity"
            >
              <ArrowLeft size={14} /> Browse Menu & Add Dishes
            </Link>
          </div>
        </div>
      ) : (
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-12 grid gap-10 lg:grid-cols-[1.1fr_0.9fr] overflow-x-hidden">
          <div className="min-w-0">
            <div className="flex justify-between items-center">
              <h1 className="text-4xl font-semibold tracking-tighter">Your Cart</h1>
              {sessionStorage.getItem("table_no") && (
                <span className="bg-primary text-primary-foreground px-3 py-1 text-xs uppercase font-extrabold tracking-widest border border-foreground hard-shadow">
                  🍽️ Table {sessionStorage.getItem("table_no")} (Dine-in)
                </span>
              )}
            </div>

            {/* Live Counter Note for Table Dine-In */}
            {isDineIn && lines.some((l) => l.category === "Tea" || l.counter_only) && (
              <div className="mt-4 p-3.5 border border-amber-600/40 bg-amber-500/10 rounded-xl flex items-center gap-3 text-xs text-amber-950">
                <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0 text-amber-900">
                  <Coffee size={16} />
                </div>
                <div>
                  <p className="font-bold text-amber-900">Live Counter Item Included</p>
                  <p className="opacity-90">
                    Hot Irani Chai &amp; bakery snacks are freshly served directly at our <strong>Live Tea Counter</strong>. Please collect them at the counter!
                  </p>
                </div>
              </div>
            )}

            {/* Free Delivery Progress Notification */}
            {!isDineIn && (
              <div className="mt-4 p-3.5 border border-foreground bg-card flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Sparkles size={16} className="text-amber-500 shrink-0" />
                  <div>
                    {subtotal >= FREE_DELIVERY_THRESHOLD ? (
                      <span className="font-semibold text-emerald-700">
                        🎉 FREE DELIVERY UNLOCKED! (Orders above ₹{FREE_DELIVERY_THRESHOLD})
                      </span>
                    ) : (
                      <span>
                        Add <b>{money(FREE_DELIVERY_THRESHOLD - subtotal)}</b> more to get <b>FREE DELIVERY</b>!
                      </span>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowTermsModal(!showTermsModal)}
                  className="underline text-[11px] uppercase tracking-wider text-muted-foreground hover:text-foreground shrink-0"
                >
                  Rates & Policy
                </button>
              </div>
            )}

            {/* Collapsible Delivery Terms Card */}
            {showTermsModal && !isDineIn && (
              <div className="mt-3 p-4 border border-foreground bg-muted/40 text-xs space-y-2.5 animate-fadeIn">
                <div className="flex justify-between items-center font-bold uppercase tracking-wider border-b border-foreground/10 pb-2">
                  <span className="flex items-center gap-1.5"><Info size={14} /> Hyderabadi Irani Delivery Terms</span>
                  <button onClick={() => setShowTermsModal(false)} className="text-muted-foreground hover:text-foreground">✕</button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  {DELIVERY_TERMS.map((t) => (
                    <div key={t.label} className={`p-2 border text-center ${t.highlight ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold' : 'border-foreground/20 bg-background'}`}>
                      <div className="text-[10px] text-muted-foreground">{t.label}</div>
                      <div className="font-mono font-bold mt-0.5">{t.charge}</div>
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed pt-1">
                  🌙 <b>Late Night Policy (10:00 PM – 6:00 AM):</b> Only prepaid orders (UPI / Cards / NetBanking) accepted during night hours. Cash on delivery is unavailable. Maximum delivery radius: 5.0 km from Secunderabad store.
                </p>
              </div>
            )}

            <div className="mt-6 border border-foreground bg-card divide-y divide-foreground/15" data-testid="cart-lines">
              {lines.map((l) => (
                <div key={l.item_id} className="p-3 sm:p-4 flex items-center gap-1.5 sm:gap-4 flex-wrap" data-testid={`cart-line-${l.item_id}`}>
                  <div className="flex-1 min-w-[110px]">
                    <p className="font-medium truncate">{l.name}</p>
                    <p className="mono text-xs text-muted-foreground mt-1">{money(l.price)} each</p>
                  </div>
                  <div className="flex items-center border border-foreground flex-shrink-0">
                    <button onClick={() => setQty(l.item_id, l.qty - 1)} data-testid={`cart-dec-${l.item_id}`} className="px-2 py-1.5 sm:px-2.5 sm:py-2 hover:bg-muted">
                      <Minus size={13} />
                    </button>
                    <span className="mono px-2 sm:px-3 text-sm">{l.qty}</span>
                    <button onClick={() => setQty(l.item_id, l.qty + 1)} data-testid={`cart-inc-${l.item_id}`} className="px-2 py-1.5 sm:px-2.5 sm:py-2 hover:bg-muted">
                      <Plus size={13} />
                    </button>
                  </div>
                  <span className="mono w-14 sm:w-24 text-right text-xs sm:text-sm flex-shrink-0">{money(l.price * l.qty)}</span>
                  <button onClick={() => setQty(l.item_id, 0)} data-testid={`cart-remove-${l.item_id}`} className="text-muted-foreground hover:text-destructive flex-shrink-0">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </div>

            {/* Pairing Suggestions before checkout */}
            {cartPairings.length > 0 && (
              <PairingShelf
                pairings={cartPairings}
                title="Complete your meal with"
                subtitle="Add popular accompaniments & pairings before ordering"
              />
            )}
          </div>

          <form onSubmit={submit} className="border border-foreground bg-card p-6 sm:p-8 h-fit" data-testid="checkout-form">
            <p className="overline text-primary">Delivery details</p>
            <h2 className="text-3xl font-semibold tracking-tighter mt-2">Checkout</h2>

            {/* Customer Auth / Loyalty Banner */}
            {isCustomerLoggedIn ? (
              <div className="mt-4 p-3.5 border border-amber-500/40 bg-amber-500/10 rounded-xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold">
                    {customer.name?.charAt(0).toUpperCase() || "C"}
                  </div>
                  <div>
                    <div className="font-bold text-foreground flex items-center gap-1">
                      <span>Ordering as {customer.name}</span>
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    </div>
                    <div className="text-muted-foreground text-[11px]">
                      +91 {customer.phone} • {customer.loyalty_points || 0} Loyalty Pts
                    </div>
                  </div>
                </div>
                <Link to="/account" className="underline font-semibold text-primary text-[11px] uppercase tracking-wider">
                  My Account
                </Link>
              </div>
            ) : (
              <div className="mt-4 p-3.5 border border-dashed border-primary/50 bg-primary/5 rounded-xl flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-primary shrink-0 animate-pulse" />
                  <div>
                    <span className="font-semibold text-foreground">Have an account?</span>
                    <p className="text-[11px] text-muted-foreground">Sign in to use saved addresses & earn loyalty points</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setAuthModalOpen(true)}
                  className="px-3 py-1.5 bg-primary text-primary-foreground text-xs font-bold rounded-lg uppercase tracking-wider shrink-0 hover:opacity-90 transition"
                >
                  Sign In
                </button>
              </div>
            )}

            {[
              ["customer_name", "Full name", true],
              ["phone", "Phone number (10 Digits)", true],
            ].map(([k, label, req]) => (
              <div key={k}>
                <label htmlFor={`checkout-${k}`} className="block overline mt-6 mb-2">{label}</label>
                <input
                  id={`checkout-${k}`}
                  name={k}
                  data-testid={`checkout-${k}-input`}
                  value={form[k]}
                  onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                  className="w-full border border-foreground bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-foreground"
                  required={req}
                />
              </div>
            ))}

            {/* Saved Address Selector for Logged-In Customers */}
            {!isDineIn && isCustomerLoggedIn && (
              <div className="mt-6">
                <CustomerAddressSelector
                  selectedAddress={{ address: form.address, lat: form.lat, lng: form.lng }}
                  onSelectAddress={handleSelectSavedAddress}
                />
              </div>
            )}

            {!isDineIn && isLoaded ? (
              <div>
                <label className="block overline mt-6 mb-2">Pin delivery address on map (Up to 5 km)</label>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <Autocomplete
                      onLoad={(auto) => (autocompleteRef.current = auto)}
                      onPlaceChanged={onPlaceChanged}
                      className="flex-1"
                    >
                      <input
                        type="text"
                        placeholder="Search landmark, street, colony…"
                        className="w-full border border-foreground bg-background px-4 py-2.5 text-sm outline-none"
                      />
                    </Autocomplete>
                    <button
                      type="button"
                      onClick={handleLocateMe}
                      disabled={locating}
                      className="border border-foreground bg-background px-3 py-2.5 text-xs uppercase tracking-wider hover:bg-muted flex items-center gap-1.5 shrink-0"
                    >
                      <Navigation size={13} className={locating ? "animate-spin" : ""} />
                      {locating ? "Locating…" : "GPS Pick"}
                    </button>
                  </div>

                  <div className="border border-foreground overflow-hidden rounded-md relative">
                    <GoogleMap
                      mapContainerStyle={{ height: "170px", width: "100%", cursor: "crosshair" }}
                      center={markerPos}
                      zoom={14}
                      onClick={onMapClick}
                      options={{
                        disableDefaultUI: false,
                        zoomControl: true,
                        mapTypeControl: false,
                        streetViewControl: false,
                        fullscreenControl: false,
                      }}
                    >
                      <CircleF
                        center={STORE_LOCATION}
                        options={{
                          radius: 5000,
                          fillColor: "#D45D48",
                          fillOpacity: 0.08,
                          strokeColor: "#D45D48",
                          strokeOpacity: 0.6,
                        }}
                      />
                      <MarkerF
                        position={STORE_LOCATION}
                        title="Hyderabadi Irani Restaurant"
                        icon={{ url: "https://maps.google.com/mapfiles/ms/icons/restaurant.png" }}
                      />
                      <MarkerF
                        position={markerPos}
                        draggable={true}
                        onDragEnd={onMarkerDragEnd}
                        title="Your Delivery Location (Drag or tap anywhere to reposition)"
                      />
                    </GoogleMap>
                  </div>

                  <div className="flex flex-col gap-1 px-1">
                    <div className="flex items-center justify-between text-xs mono">
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <MapPin size={12} /> Distance: <b>{distanceKm} km</b>
                      </span>
                      <span className={isOutOfBounds ? "text-destructive font-bold" : "text-emerald-700 font-medium"}>
                        {isOutOfBounds ? `Outside 5 km Zone (${distanceKm} km)` : "Within 5 km Zone ✓"}
                      </span>
                    </div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                      <span>📍</span>
                      <span>Ordering for someone else? Tap anywhere on the map or drag the pin to set the exact delivery spot.</span>
                    </p>
                  </div>
                </div>
              </div>
            ) : null}

            <div>
              <label htmlFor="checkout-address" className="block overline mt-6 mb-2">Delivery address</label>
              <textarea
                id="checkout-address"
                name="address"
                data-testid="checkout-address-input"
                rows={3}
                value={form.address}
                onChange={set("address")}
                className="w-full border border-foreground bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-foreground"
                placeholder="House/Flat No., Building Name, Colony, Street…"
                required
              />
            </div>

            {isOutOfBounds && !isDineIn && (
              <p data-testid="delivery-out-of-bounds-warning" className="mt-2 text-xs text-destructive flex items-center gap-1.5 font-medium">
                <AlertCircle size={13} />
                Selected location is {distanceKm} km away. We currently deliver up to {MAX_DELIVERY_DISTANCE_KM} km from Secunderabad.
              </p>
            )}

            <div>
              <label htmlFor="checkout-notes" className="block overline mt-6 mb-2">Landmark / Cooking instructions (optional)</label>
              <input
                id="checkout-notes"
                name="notes"
                data-testid="checkout-notes-input"
                value={form.notes}
                onChange={set("notes")}
                placeholder="e.g. Near clock tower, extra spicy biryani…"
                className="w-full border border-foreground bg-background px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-foreground"
              />
            </div>

            {/* Night Prepayment Warning */}
            {isNight && (
              <div className="mt-6 p-3.5 border-2 border-amber-600 bg-amber-50 text-amber-900 text-xs space-y-1">
                <div className="flex items-center gap-2 font-bold uppercase tracking-wider">
                  <Clock size={15} className="text-amber-700" />
                  Late Night Session (10:00 PM – 6:00 AM)
                </div>
                <p className="leading-relaxed">
                  To ensure smooth late-night delivery, <b>only prepaid online orders (UPI / Card / NetBanking)</b> are accepted during this window. Cash on delivery is unavailable.
                </p>
              </div>
            )}

            {/* Dine-in Prepayment Notice */}
            {isDineIn && (
              <div className="mt-6 p-3.5 border-2 border-amber-600 bg-amber-50 text-amber-900 text-xs space-y-1">
                <div className="flex items-center gap-2 font-bold uppercase tracking-wider">
                  <Clock size={15} className="text-amber-700" />
                  In-House Booking
                </div>
                <p className="leading-relaxed">
                  Table bookings placed here are <b>prepaid online (UPI / Card / NetBanking) only</b>. To pay by cash, please order directly at the counter.
                </p>
              </div>
            )}

            <label className="block overline mt-8 mb-2">Payment method</label>
            <div className="grid grid-cols-2 gap-2" data-testid="payment-mode-selector">
              <button
                type="button"
                data-testid="pay-cod-button"
                onClick={() => {
                  if (isNight) {
                    toast.error("Cash on delivery is unavailable between 10:00 PM and 6:00 AM. Please choose Card/UPI.");
                    return;
                  }
                  if (isDineIn) {
                    toast.error("Dine-in bookings must be prepaid online. Please choose Card/UPI.");
                    return;
                  }
                  setPayMode("cod");
                }}
                disabled={isNight || isDineIn}
                className={`border border-foreground px-3 py-3 text-[11px] uppercase tracking-widest ${
                  isNight || isDineIn ? "opacity-40 cursor-not-allowed bg-muted" : payMode === "cod" ? "bg-foreground text-background" : "bg-background hover:bg-muted"
                }`}
              >
                Cash on delivery {(isNight || isDineIn) && "(Closed)"}
              </button>
              <button
                type="button"
                data-testid="pay-online-button"
                onClick={() => rzpEnabled && setPayMode("razorpay")}
                disabled={!rzpEnabled}
                title={rzpEnabled ? "" : "Online payment gateway is loading"}
                className={`border border-foreground px-3 py-3 text-[11px] uppercase tracking-widest disabled:opacity-40 ${
                  payMode === "razorpay" ? "bg-foreground text-background" : "bg-background hover:bg-muted"
                }`}
              >
                Online (UPI / Card)
              </button>
            </div>

            {/* Coupons Section */}
            <div className="mt-6 border border-foreground p-3.5 bg-muted/30 space-y-3">
              <div className="flex justify-between items-center">
                <label className="block text-xs font-semibold uppercase tracking-wider">Apply Promo / Coupon Code</label>
                {availableOffers.length > 0 && (
                  <span className="text-[10px] bg-primary text-primary-foreground px-1.5 py-0.5 uppercase font-bold tracking-wider">
                    {availableOffers.length} Offers Available
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <input
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Try IRANI10, FLAT50..."
                  className="flex-1 border border-foreground bg-background px-3 py-2 text-xs uppercase outline-none font-mono"
                />
                <button
                  type="button"
                  onClick={() => handleApplyCoupon()}
                  className="border border-foreground bg-foreground text-background px-4 py-2 text-xs font-semibold uppercase tracking-wider hover:opacity-90"
                >
                  Apply
                </button>
              </div>
              {couponInfo && (
                <div className="p-2 border border-emerald-500 bg-emerald-50 text-xs text-emerald-800 font-medium flex justify-between items-center">
                  <span>
                    ✓ <strong>{couponInfo.code}</strong> applied!{" "}
                    {couponInfo.discount_type === "freebie"
                      ? `Free Gift: ${couponInfo.freebie_item_name}`
                      : `Saved ${money(couponInfo.discount_amount)}`}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setCouponInfo(null);
                      setCouponCode("");
                    }}
                    className="text-xs font-bold underline"
                  >
                    Remove
                  </button>
                </div>
              )}

              {availableOffers.length > 0 && (
                <div className="pt-2 space-y-2 border-t border-foreground/10">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-muted-foreground block">
                    Available Offers:
                  </span>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {availableOffers.map((offer) => {
                      const isApplied = couponInfo?.code === offer.code;
                      return (
                        <div
                          key={offer.code}
                          className={`p-2.5 border text-xs flex justify-between items-center gap-2 ${
                            isApplied ? "border-emerald-600 bg-emerald-50/50" : "border-foreground/30 bg-background hover:border-foreground"
                          }`}
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-primary uppercase">{offer.code}</span>
                              <span className="text-[9px] bg-muted px-1.5 py-0.2 border border-foreground/20 font-bold uppercase">
                                {offer.discount_type === "freebie"
                                  ? "Free Gift"
                                  : offer.discount_type === "percent"
                                  ? `${offer.discount_value}% OFF`
                                  : `₹${offer.discount_value} OFF`}
                              </span>
                            </div>
                            <p className="font-medium text-foreground">{offer.title || offer.code}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleApplyCoupon(offer.code)}
                            className={`px-3 py-1 text-[10px] uppercase font-bold tracking-wider border border-foreground ${
                              isApplied ? "bg-emerald-600 text-white" : "bg-primary text-primary-foreground hover:opacity-90"
                            }`}
                          >
                            {isApplied ? "Applied ✓" : "Apply"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Bill Summary */}
            <div className="mt-6 border-t border-foreground pt-5 mono text-sm space-y-2">
              <div className="flex justify-between">
                <span>Subtotal (Incl. GST)</span>
                <span data-testid="checkout-subtotal">{money(subtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Discount ({couponInfo?.code || "Promo"})</span>
                  <span>-{money(discountAmount)}</span>
                </div>
              )}
              {!isDineIn && (
                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1">
                    Delivery Charge ({distanceKm > 0 ? `${distanceKm} km` : "Standard"})
                  </span>
                  {deliveryCalc.isFree ? (
                    <span className="text-emerald-700 font-bold">FREE (Above ₹499 🎉)</span>
                  ) : (
                    <span>{money(deliveryFee)}</span>
                  )}
                </div>
              )}
              <div className="flex justify-between text-lg font-semibold pt-2 border-t border-foreground/20">
                <span>Total Payable</span>
                <span data-testid="checkout-total" className="text-primary">{money(total)}</span>
              </div>
            </div>

            {!storeStatus.is_online_open && !isDineIn ? (
              <div className="mt-7 border-2 border-red-600 bg-red-50 p-4 text-center rounded">
                <p className="font-bold text-red-900 text-sm">⚠️ Online Ordering is Currently Paused</p>
                <p className="text-xs text-red-700 mt-1">
                  We are not taking online delivery orders right now. Please visit our restaurant for Dine-in & Counter Takeaway!
                </p>
              </div>
            ) : (
              <button
                data-testid="place-order-button"
                disabled={busy || !lines.length || (isOutOfBounds && !isDineIn)}
                className="hard-shadow mt-7 w-full border border-foreground bg-primary text-primary-foreground py-4 text-xs uppercase tracking-widest disabled:opacity-50 font-bold"
              >
                {busy
                  ? "Processing…"
                  : !isCustomerLoggedIn
                  ? `Sign In / Register to ${payMode === "razorpay" ? `Pay ${money(total)}` : "Place Order"}`
                  : payMode === "razorpay"
                  ? `Pay ${money(total)} online`
                  : "Place order (COD)"}
              </button>
            )}

            <div className="mt-4 text-center text-[11px] text-muted-foreground leading-relaxed">
              By placing your order, you agree to Hyderabadi Irani's{" "}
              <Link to="/terms" target="_blank" className="underline hover:text-foreground">Terms & Conditions</Link>,{" "}
              <Link to="/privacy" target="_blank" className="underline hover:text-foreground">Privacy Policy</Link>,{" "}
              <Link to="/refund-policy" target="_blank" className="underline hover:text-foreground">Refund Policy</Link> &{" "}
              <Link to="/shipping-policy" target="_blank" className="underline hover:text-foreground">Shipping Policy</Link>.
            </div>
          </form>
        </div>
      )}

      {/* Customer Login / Registration Modal */}
      <CustomerAuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(c) => {
          setForm((prev) => ({
            ...prev,
            customer_name: c.name || prev.customer_name,
            phone: c.phone || prev.phone,
          }));
          setAuthModalOpen(false);
        }}
      />
    </div>
  );
}
