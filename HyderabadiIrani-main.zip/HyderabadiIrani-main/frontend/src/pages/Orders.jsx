import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { api, errMsg, money, API, openPdf } from "@/lib/api";
import { RefreshCw, Download, ChefHat, MapPin, Navigation } from "lucide-react";
import NotificationSound from "@/components/NotificationSound";
import { playNotificationSound } from "@/lib/notificationSound";

const FLOW = { placed: "preparing", preparing: "ready", ready: "completed", out_for_delivery: "completed" };
const FILTERS = ["all", "placed", "preparing", "ready", "out_for_delivery", "completed", "cancelled"];

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const seenRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get("/orders", { params: filter === "all" ? {} : { status: filter } });
      if (seenRef.current) {
        const fresh = data.filter((o) => o.status === "placed" && !seenRef.current.has(o.id));
        if (fresh.length) {
          playNotificationSound(5000); // Loud 5-second notification alarm
          toast.success(`🚨 ${fresh.length} NEW ORDER(S) RECEIVED!`);
        }
      }
      seenRef.current = new Set(data.map((o) => o.id));
      setOrders(data);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    load();
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, [load]);

  const advance = async (o, status) => {
    try {
      await api.put(`/orders/${o.id}/status`, { status });
      toast.success(`${o.order_no} → ${status}`);
      load();
    } catch (e) {
      toast.error(errMsg(e));
    }
  };

  return (
    <div className="p-5 sm:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="overline text-primary">Kitchen & billing queue</p>
          <h1 className="text-4xl font-semibold tracking-tighter mt-1">Orders</h1>
        </div>
        <div className="flex items-center gap-3">
          <NotificationSound compact={true} />
          <button data-testid="orders-refresh-button" onClick={load} className="border border-foreground px-4 py-2.5 text-xs uppercase tracking-widest hover:bg-muted flex items-center gap-2">
            <RefreshCw size={14} /> Refresh
          </button>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-1.5" data-testid="orders-filters">
        {FILTERS.map((f) => (
          <button
            key={f}
            data-testid={`orders-filter-${f}`}
            onClick={() => setFilter(f)}
            className={`border border-foreground px-4 py-2 text-[11px] uppercase tracking-widest ${filter === f ? "bg-foreground text-background" : "bg-card hover:bg-muted"}`}
          >
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="mt-10 overline">Loading…</p>
      ) : orders.length === 0 ? (
        <p data-testid="orders-empty" className="mt-10 text-sm text-muted-foreground">No orders in this view yet.</p>
      ) : (
        <div className="mt-8 grid gap-0 sm:grid-cols-2 xl:grid-cols-3 border-t border-l border-foreground" data-testid="orders-grid">
          {orders.map((o) => (
            <article key={o.id} data-testid={`order-card-${o.order_no}`} className="border-r border-b border-foreground bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="mono text-lg font-semibold">{o.order_no}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {new Date(o.created_at).toLocaleString("en-IN")}
                  </p>
                </div>
                <span data-testid={`order-status-${o.order_no}`} className={`border border-foreground px-2 py-1 text-[10px] uppercase tracking-widest ${o.status === "completed" ? "bg-secondary text-secondary-foreground" : o.status === "cancelled" ? "bg-muted" : "bg-primary text-primary-foreground"}`}>
                  {o.status}
                </span>
              </div>

              <p className="mt-3 text-sm">
                {o.customer_name} · <span className="text-muted-foreground">{o.order_type}{o.table_no ? ` · T${o.table_no}` : ""} · {o.source}</span>
              </p>

              {/* Payment collection status — the customer_name line above
                  shows "source" (web/app/POS), which is easy to mistake for
                  the payment method. This is the actual money-collection
                  signal staff need: cash orders must be collected on
                  delivery/at the counter, online orders that aren't yet
                  paid still need following up. */}
              {(() => {
                const isOnlinePay = o.payment_mode === "razorpay" || o.payment_mode === "online";
                const label = !isOnlinePay
                  ? "💰 Collect Cash"
                  : o.paid
                  ? "✅ Paid Online"
                  : "⚠️ Payment Pending";
                const cls = !isOnlinePay
                  ? "bg-amber-100 text-amber-900 border-amber-400"
                  : o.paid
                  ? "bg-emerald-100 text-emerald-900 border-emerald-400"
                  : "bg-red-100 text-red-900 border-red-400";
                return (
                  <span
                    data-testid={`order-payment-${o.order_no}`}
                    className={`mt-2 inline-block border px-2 py-1 text-[10px] font-bold uppercase tracking-widest ${cls}`}
                  >
                    {label}
                  </span>
                );
              })()}

              <div className="mt-3 border-t border-foreground/15 pt-3 space-y-1.5">
                {o.items.map((l) => (
                  <div key={l.item_id} className="text-xs">
                    <div className="flex justify-between">
                      <span>{l.name} × {l.qty}</span>
                      <span className="mono">{money(l.price * l.qty)}</span>
                    </div>
                    {l.notes && (
                      <p className="text-[11px] text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 mt-0.5 font-medium">
                        👉 {l.notes}
                      </p>
                    )}
                  </div>
                ))}
                {o.notes && (
                  <div className="text-xs italic text-amber-900 bg-amber-50/80 p-2 border-l-2 border-primary mt-2">
                    Note: {o.notes}
                  </div>
                )}
              </div>

              <p className="mt-3 mono text-base font-semibold" data-testid={`order-total-${o.order_no}`}>{money(o.total)}</p>

              <div className="mt-4 flex flex-wrap gap-2">
                {o.order_type === "delivery" && o.status === "ready" ? (
                  <>
                    <button
                      data-testid={`order-dispatch-${o.order_no}`}
                      onClick={() => advance(o, "out_for_delivery")}
                      className="border border-foreground bg-primary text-primary-foreground px-3 py-2 text-[11px] font-bold uppercase tracking-widest hover:opacity-90"
                    >
                      Dispatch Rider
                    </button>
                    <button
                      data-testid={`order-complete-${o.order_no}`}
                      onClick={() => advance(o, "completed")}
                      className="border border-foreground bg-secondary text-secondary-foreground px-3 py-2 text-[11px] uppercase tracking-widest hover:bg-foreground hover:text-background"
                    >
                      Mark Delivered
                    </button>
                  </>
                ) : FLOW[o.status] ? (
                  <button
                    data-testid={`order-advance-${o.order_no}`}
                    onClick={() => advance(o, FLOW[o.status])}
                    className="border border-foreground bg-secondary text-secondary-foreground px-3 py-2 text-[11px] uppercase tracking-widest hover:bg-foreground hover:text-background"
                  >
                    Mark {FLOW[o.status] === "completed" && (o.order_type === "dinein" || o.order_type === "dine-in") ? "Served" : FLOW[o.status]}
                  </button>
                ) : null}
                <button
                  data-testid={`order-kot-${o.order_no}`}
                  onClick={() => openPdf(`/kot/${o.order_no}`).catch(() => toast.error("Could not open the kitchen ticket"))}
                  className="border border-foreground px-3 py-2 text-[11px] uppercase tracking-widest hover:bg-muted flex items-center gap-1.5"
                >
                  <ChefHat size={12} /> KOT
                </button>
                <a data-testid={`order-invoice-${o.order_no}`} href={`${API}/invoice/${o.order_no}`} className="border border-foreground px-3 py-2 text-[11px] uppercase tracking-widest hover:bg-muted flex items-center gap-1.5">
                  <Download size={12} /> Invoice
                </a>
                {o.order_type === "delivery" && (
                  <Link
                    to="/admin/live-tracking"
                    className="border border-emerald-600 bg-emerald-50 text-emerald-800 px-3 py-2 text-[11px] font-bold uppercase tracking-widest hover:bg-emerald-100 flex items-center gap-1.5"
                  >
                    <Navigation size={12} className="text-emerald-600 animate-pulse" /> Live Radar
                  </Link>
                )}
                {o.lat != null && o.lng != null && (
                  <a
                    data-testid={`order-map-${o.order_no}`}
                    href={`https://www.google.com/maps?q=${o.lat},${o.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="border border-foreground bg-primary text-primary-foreground px-3 py-2 text-[11px] uppercase tracking-widest hover:opacity-90 flex items-center gap-1.5"
                  >
                    <MapPin size={12} /> Maps
                  </a>
                )}
                {o.status !== "completed" && o.status !== "cancelled" && (
                  <button data-testid={`order-cancel-${o.order_no}`} onClick={() => advance(o, "cancelled")} className="border border-foreground px-3 py-2 text-[11px] uppercase tracking-widest hover:bg-destructive hover:text-destructive-foreground">
                    Cancel
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
