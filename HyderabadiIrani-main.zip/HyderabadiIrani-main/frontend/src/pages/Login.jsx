
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Loader2 } from "lucide-react";


export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const { user, login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      if (user.role === "delivery") {
        navigate("/delivery", { replace: true });
      } else {
        navigate("/admin/pos", { replace: true });
      }
    }
  }, [user, navigate]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await login(email, password);
    setBusy(false);
    if (res.ok) {
      if (res.user?.role === "delivery") {
        navigate("/delivery");
      } else {
        navigate("/admin/pos");
      }
    } else {
      setError(res.error);
    }
  };


  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="relative hidden lg:block grain overflow-hidden border-r border-foreground">
        <img
          src="https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?crop=entropy&cs=srgb&fm=jpg&q=85&w=1400"
          alt="Hotel restaurant"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 h-full flex flex-col justify-end p-14 text-white">
          <p className="overline text-white/70">Staff Terminal</p>
          <h1 className="text-6xl font-light tracking-tighter leading-none mt-3">
            Hyderabadi
            <br />
            Irani
          </h1>
          <p className="mt-6 max-w-sm text-sm text-white/80 leading-relaxed">
            Billing, kitchen orders, delivery express & online site — one unified portal.
          </p>
        </div>
      </div>

      <div className="flex items-center justify-center p-8 sm:p-16">
        <form onSubmit={submit} className="w-full max-w-sm rise" data-testid="login-form">
          <div className="flex items-center gap-3 mb-4">
            <img src="/logo.png" alt="Logo" className="h-12 w-12 object-contain rounded-full border border-foreground/20" />
            <div>
              <span className="serif text-2xl font-bold tracking-tight text-primary block leading-none">Hyderabadi Irani</span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Food Court</span>
            </div>
          </div>
          <h2 className="text-3xl font-semibold tracking-tighter">Staff & Driver Login</h2>
          <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
            Enter your authorized email and password to open POS billing or Delivery Partner Express.
          </p>

          <label htmlFor="login-email" className="block overline mt-6 mb-2">Email</label>
          <input
            id="login-email"
            name="email"
            data-testid="login-email-input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-foreground bg-card px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-foreground"
            required
          />

          <label htmlFor="login-password" className="block overline mt-6 mb-2">Password</label>
          <input
            id="login-password"
            name="password"
            data-testid="login-password-input"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-foreground bg-card px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-foreground"
            required
          />

          {error && (
            <p data-testid="login-error" className="mt-5 border border-destructive bg-destructive/10 px-4 py-3 text-sm text-destructive">
              {error}
            </p>
          )}

          <button
            data-testid="login-submit-button"
            disabled={busy}
            className="hard-shadow mt-8 w-full bg-primary text-primary-foreground py-3.5 text-sm uppercase tracking-widest font-medium border border-foreground disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {busy && <Loader2 size={15} className="animate-spin" />} Sign In
          </button>

          <a href="/" data-testid="back-to-site-link" className="block mt-6 text-xs underline underline-offset-4">
            ← Back to the ordering website
          </a>
        </form>
      </div>
    </div>
  );
}
