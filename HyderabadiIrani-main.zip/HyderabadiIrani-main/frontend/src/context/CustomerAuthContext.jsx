import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api, errMsg } from "@/lib/api";

const CustomerAuthCtx = createContext(null);
export const useCustomerAuth = () => useContext(CustomerAuthCtx);

export function CustomerAuthProvider({ children }) {
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore customer session if token exists
  useEffect(() => {
    let cancelled = false;
    const restoreCustomer = async () => {
      const token = localStorage.getItem("gh_customer_token");
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const { data } = await api.get("/customer/profile");
        if (!cancelled) {
          setCustomer(data);
        }
      } catch (e) {
        console.warn("[CustomerAuth] Session restore failed, clearing token.");
        localStorage.removeItem("gh_customer_token");
        if (!cancelled) {
          setCustomer(null);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    restoreCustomer();
    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(async (identifier, password) => {
    try {
      const { data } = await api.post("/customer/login", { identifier, password });
      if (data.access_token) {
        localStorage.setItem("gh_customer_token", data.access_token);
      }
      setCustomer(data.customer);
      return { ok: true, customer: data.customer };
    } catch (e) {
      return { ok: false, error: errMsg(e) };
    }
  }, []);

  const register = useCallback(async ({ name, phone, password, email }) => {
    try {
      const { data } = await api.post("/customer/register", { name, phone, password, email });
      if (data.access_token) {
        localStorage.setItem("gh_customer_token", data.access_token);
      }
      setCustomer(data.customer);
      return { ok: true, customer: data.customer };
    } catch (e) {
      return { ok: false, error: errMsg(e) };
    }
  }, []);

  const resetPassword = useCallback(async ({ phone, newPassword, name }) => {
    try {
      const { data } = await api.post("/customer/reset-password", {
        phone,
        new_password: newPassword,
        name: name || "",
      });
      if (data.access_token) {
        localStorage.setItem("gh_customer_token", data.access_token);
      }
      setCustomer(data.customer);
      return { ok: true, customer: data.customer };
    } catch (e) {
      return { ok: false, error: errMsg(e) };
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("gh_customer_token");
    setCustomer(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    try {
      const { data } = await api.get("/customer/profile");
      setCustomer(data);
      return data;
    } catch (e) {
      console.warn("Failed to refresh customer profile", e);
      return null;
    }
  }, []);

  const addAddress = useCallback(async (addressData) => {
    try {
      const { data } = await api.post("/customer/addresses", addressData);
      setCustomer((prev) => (prev ? { ...prev, addresses: data } : prev));
      return { ok: true, addresses: data };
    } catch (e) {
      return { ok: false, error: errMsg(e) };
    }
  }, []);

  const deleteAddress = useCallback(async (addressId) => {
    try {
      const { data } = await api.delete(`/customer/addresses/${addressId}`);
      setCustomer((prev) => (prev ? { ...prev, addresses: data } : prev));
      return { ok: true, addresses: data };
    } catch (e) {
      return { ok: false, error: errMsg(e) };
    }
  }, []);

  const updateProfile = useCallback(async ({ name, email }) => {
    try {
      const { data } = await api.put("/customer/profile", { name, email });
      setCustomer(data);
      return { ok: true, customer: data };
    } catch (e) {
      return { ok: false, error: errMsg(e) };
    }
  }, []);

  const getCustomerOrders = useCallback(async () => {
    try {
      const { data } = await api.get("/customer/orders");
      return { ok: true, orders: data };
    } catch (e) {
      return { ok: false, error: errMsg(e), orders: [] };
    }
  }, []);

  const value = useMemo(
    () => ({
      customer,
      isCustomerLoggedIn: Boolean(customer),
      loading,
      login,
      register,
      resetPassword,
      logout,
      refreshProfile,
      addAddress,
      deleteAddress,
      updateProfile,
      getCustomerOrders,
    }),
    [customer, loading, login, register, resetPassword, logout, refreshProfile, addAddress, deleteAddress, updateProfile, getCustomerOrders]
  );

  return <CustomerAuthCtx.Provider value={value}>{children}</CustomerAuthCtx.Provider>;
}
