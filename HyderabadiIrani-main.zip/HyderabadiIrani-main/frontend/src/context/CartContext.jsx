import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

const CartCtx = createContext(null);
export const useCart = () => useContext(CartCtx);

export function CartProvider({ children }) {
  const [lines, setLines] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("gh_cart") || "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("gh_cart", JSON.stringify(lines));
  }, [lines]);

  const add = useCallback((item) => {
    setLines((p) => {
      const found = p.find((l) => l.item_id === item.id);
      if (found) return p.map((l) => (l.item_id === item.id ? { ...l, qty: l.qty + 1 } : l));
      return [...p, { item_id: item.id, name: item.name, price: item.price, qty: 1, station: item.station || "kitchen" }];
    });
  }, []);

  const addVariant = useCallback((item, variant) => {
    const lineId = `${item.id}_${variant.name.toLowerCase()}`;
    const lineName = `${item.name} (${variant.name})`;
    setLines((p) => {
      const found = p.find((l) => l.item_id === lineId);
      if (found) return p.map((l) => (l.item_id === lineId ? { ...l, qty: l.qty + 1 } : l));
      return [
        ...p,
        {
          item_id: lineId,
          base_item_id: item.id,
          name: lineName,
          variant: variant.name,
          price: Number(variant.price),
          qty: 1,
          station: item.station || "kitchen",
        },
      ];
    });
  }, []);

  const setQty = useCallback((id, qty) => {
    setLines((p) => (qty <= 0 ? p.filter((l) => l.item_id !== id) : p.map((l) => (l.item_id === id ? { ...l, qty } : l))));
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const value = useMemo(() => {
    const subtotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
    const count = lines.reduce((s, l) => s + l.qty, 0);
    return { lines, add, addVariant, setQty, clear, subtotal, count };
  }, [lines, add, addVariant, setQty, clear]);

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
