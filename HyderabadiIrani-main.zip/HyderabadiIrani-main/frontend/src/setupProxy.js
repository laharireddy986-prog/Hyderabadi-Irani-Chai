const { createProxyMiddleware } = require("http-proxy-middleware");

module.exports = function (app) {
  const rawTarget = process.env.REACT_APP_API_URL || process.env.REACT_APP_BACKEND_URL || "http://localhost:8000";
  const cleanTarget = rawTarget.split(/\s+|%20/)[0].trim().replace(/^["'(\[]+|["')\]]+$/g, "").replace(/\/+$/, "");

  app.use(
    ["/api", "/uploads"],
    createProxyMiddleware({
      target: cleanTarget,
      changeOrigin: true,
      secure: false,
    })
  );
};
