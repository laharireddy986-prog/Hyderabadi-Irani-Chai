import React, { useState } from "react";
import { useCustomerAuth } from "@/context/CustomerAuthContext";
import { X, Lock, Phone, User, Mail, Sparkles, LogIn, UserPlus, AlertCircle, Eye, EyeOff, KeyRound } from "lucide-react";
import { toast } from "sonner";

export default function CustomerAuthModal({ isOpen, onClose, onSuccess, initialTab = "login" }) {
  const { login, register, resetPassword } = useCustomerAuth();
  const [tab, setTab] = useState(initialTab); // "login" | "register" | "forgot"
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  // Form states
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  if (!isOpen) return null;

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!phone.trim()) {
      setError("Please enter your mobile number or email");
      return;
    }
    if (!password) {
      setError("Please enter your password");
      return;
    }

    setLoading(true);
    const res = await login(phone.trim(), password);
    setLoading(false);

    if (res.ok) {
      toast.success(`Welcome back, ${res.customer.name || "Customer"}! 🎉`);
      if (onSuccess) onSuccess(res.customer);
      if (onClose) onClose();
    } else {
      setError(res.error || "Invalid mobile number or password");
    }
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    setError("");
    const cleanPhone = phone.replace(/\D/g, "").slice(-10);
    if (!name.trim()) {
      setError("Please enter your full name");
      return;
    }
    if (cleanPhone.length < 10) {
      setError("Please enter a valid 10-digit mobile number");
      return;
    }
    if (password.length < 4) {
      setError("Password must be at least 4 characters");
      return;
    }

    setLoading(true);
    const res = await register({
      name: name.trim(),
      phone: cleanPhone,
      password,
      email: email.trim(),
    });
    setLoading(false);

    if (res.ok) {
      toast.success(`Account ready! Welcome to Hyderabadi Irani Chai, ${res.customer.name}! ✨`);
      if (onSuccess) onSuccess(res.customer);
      if (onClose) onClose();
    } else {
      setError(res.error || "Registration failed. Please check your details.");
    }
  };

  const handleResetSubmit = async (e) => {
    e.preventDefault();
    setError("");
    const cleanPhone = phone.replace(/\D/g, "").slice(-10);
    if (cleanPhone.length < 10) {
      setError("Please enter your valid 10-digit mobile number");
      return;
    }
    if (password.length < 4) {
      setError("Password must be at least 4 characters");
      return;
    }

    setLoading(true);
    const res = await resetPassword({
      phone: cleanPhone,
      newPassword: password,
      name: name.trim() || undefined,
    });
    setLoading(false);

    if (res.ok) {
      toast.success(`Password updated & signed in! Welcome, ${res.customer.name || "Customer"}! ✨`);
      if (onSuccess) onSuccess(res.customer);
      if (onClose) onClose();
    } else {
      setError(res.error || "Failed to reset password. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div
        className="relative w-full max-w-md bg-stone-900 border border-amber-900/40 rounded-3xl p-6 md:p-8 shadow-2xl text-stone-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Glow Accent */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-orange-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-stone-400 hover:text-white hover:bg-stone-800 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Branding */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-stone-900 border border-amber-600/30 p-1 shadow-lg mb-3">
            <img src="/logo.png" alt="Logo" className="w-full h-full object-contain rounded-full" />
          </div>
          <h2 className="text-2xl font-bold font-serif text-amber-100">Hyderabadi Irani Food Court</h2>
          <p className="text-xs text-stone-400 mt-1">
            {tab === "login"
              ? "Sign in to access saved delivery addresses & loyalty rewards"
              : tab === "register"
              ? "Create an account for 1-click ordering & rewards"
              : "Set a new password to sign in immediately"}
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex bg-stone-950/80 p-1 rounded-2xl border border-stone-800 mb-6">
          <button
            type="button"
            onClick={() => {
              setTab("login");
              setError("");
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-xl transition ${
              tab === "login"
                ? "bg-amber-600 text-white shadow-md"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setTab("register");
              setError("");
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-xl transition ${
              tab === "register"
                ? "bg-amber-600 text-white shadow-md"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            Register
          </button>
          <button
            type="button"
            onClick={() => {
              setTab("forgot");
              setError("");
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-xl transition ${
              tab === "forgot"
                ? "bg-amber-600 text-white shadow-md"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-800/60 text-red-200 text-xs flex flex-col gap-1.5 animate-shake">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{error}</span>
            </div>
            {tab === "login" && (
              <button
                type="button"
                onClick={() => {
                  setTab("forgot");
                  setError("");
                }}
                className="text-left text-amber-400 hover:underline font-semibold text-[11px] pl-6"
              >
                Need to reset your password? Click here →
              </button>
            )}
          </div>
        )}

        {/* Sign In Form */}
        {tab === "login" ? (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                Mobile Number or Email
              </label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-3.5 w-4 h-4 text-stone-500" />
                <input
                  type="text"
                  required
                  placeholder="e.g. 9701463241 or email@domain.com"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-semibold text-stone-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setTab("forgot");
                    setError("");
                  }}
                  className="text-[11px] text-amber-400 hover:underline font-medium"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-stone-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-3 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-stone-500 hover:text-stone-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 mt-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg hover:shadow-amber-500/25 transition duration-200 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  Sign In
                </>
              )}
            </button>

            <p className="text-center text-xs text-stone-400 mt-3">
              Don't have an account yet?{" "}
              <button
                type="button"
                onClick={() => {
                  setTab("register");
                  setError("");
                }}
                className="text-amber-400 hover:underline font-semibold"
              >
                Create one in 10 seconds
              </button>
            </p>
          </form>
        ) : tab === "register" ? (
          /* Register Form */
          <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Your Full Name <span className="text-amber-500">*</span>
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-3 w-4 h-4 text-stone-500" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Mobile Number <span className="text-amber-500">*</span>
              </label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-3 w-4 h-4 text-stone-500" />
                <input
                  type="tel"
                  required
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Email Address <span className="text-stone-500 text-[10px]">(Optional)</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3 w-4 h-4 text-stone-500" />
                <input
                  type="email"
                  placeholder="rahul@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Create Password <span className="text-amber-500">*</span>
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3 w-4 h-4 text-stone-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="At least 4 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-stone-500 hover:text-stone-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 mt-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg hover:shadow-amber-500/25 transition duration-200 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  Create Customer Account
                </>
              )}
            </button>

            <p className="text-center text-xs text-stone-400 mt-2">
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => {
                  setTab("login");
                  setError("");
                }}
                className="text-amber-400 hover:underline font-semibold"
              >
                Sign in here
              </button>
            </p>
          </form>
        ) : (
          /* Reset Password Form */
          <form onSubmit={handleResetSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Your Mobile Number <span className="text-amber-500">*</span>
              </label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-3 w-4 h-4 text-stone-500" />
                <input
                  type="tel"
                  required
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                New Password <span className="text-amber-500">*</span>
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3 w-4 h-4 text-stone-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="Set your new password (min 4 chars)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-stone-100 placeholder-stone-600 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-stone-500 hover:text-stone-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 mt-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl shadow-lg hover:shadow-amber-500/25 transition duration-200 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  Reset Password & Sign In
                </>
              )}
            </button>

            <p className="text-center text-xs text-stone-400 mt-2">
              Remember your password?{" "}
              <button
                type="button"
                onClick={() => {
                  setTab("login");
                  setError("");
                }}
                className="text-amber-400 hover:underline font-semibold"
              >
                Sign in directly
              </button>
            </p>
          </form>
        )}
      </div>
    </div>
  );
}

