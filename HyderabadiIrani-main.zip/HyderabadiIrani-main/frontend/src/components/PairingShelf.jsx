import { Plus, Minus, Sparkles, Leaf } from "lucide-react";
import { money } from "@/lib/api";
import { useCart } from "@/context/CartContext";

export default function PairingShelf({
  pairings = [],
  title = "You will love pairing it with",
  subtitle = "Frequently ordered together with your selection",
  onSelectVariantItem,
}) {
  const { add, setQty, lines } = useCart();

  if (!pairings || pairings.length === 0) return null;

  const qtyOf = (id) => lines.find((l) => l.item_id === id)?.qty || 0;

  return (
    <div className="border border-foreground bg-card p-4 sm:p-5 my-6 rise shadow-xs">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-foreground/10 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-amber-500 shrink-0" />
          <div>
            <h4 className="font-bold text-sm sm:text-base uppercase tracking-wider text-foreground leading-none">
              {title}
            </h4>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-0.5 leading-none">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        <span className="text-[10px] font-extrabold uppercase bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded">
          Chef Recommends
        </span>
      </div>

      {/* Horizontal Cards Scroll Strip */}
      <div className="flex gap-4 overflow-x-auto pb-2 pt-1 no-scrollbar -mx-1 px-1">
        {pairings.map((dish) => {
          const hasPortions = Boolean(
            dish.has_variants && dish.variants && dish.variants.length >= 2
          );
          const currentQty = qtyOf(dish.id);
          const displayPrice = hasPortions
            ? dish.variants[0].price
            : dish.price;

          return (
            <div
              key={dish.id}
              className="w-44 sm:w-48 shrink-0 border border-foreground/30 bg-background hover:border-foreground transition-all p-3 flex flex-col justify-between rounded-md group"
            >
              {/* Photo Thumbnail */}
              <div className="relative aspect-[4/3] rounded overflow-hidden bg-muted mb-2.5 border border-foreground/20">
                {dish.image_url ? (
                  <img
                    src={dish.image_url}
                    alt={dish.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground font-bold text-sm">
                    {dish.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                {dish.veg && (
                  <span className="absolute top-1.5 left-1.5 bg-background/90 p-0.5 rounded border border-emerald-600 shadow-xs">
                    <Leaf size={10} className="text-emerald-600" />
                  </span>
                )}
              </div>

              {/* Title & Info */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h5 className="font-semibold text-xs text-foreground line-clamp-2 leading-tight">
                    {dish.name}
                  </h5>
                  <span className="text-[10px] uppercase font-bold text-muted-foreground mt-0.5 block">
                    {dish.category}
                  </span>
                </div>

                {/* Price & Action */}
                <div className="mt-3 pt-2 border-t border-foreground/10 flex items-center justify-between gap-1">
                  <div>
                    <span className="mono font-bold text-xs sm:text-sm text-foreground">
                      ₹{displayPrice}
                    </span>
                    {hasPortions && (
                      <span className="text-[9px] text-muted-foreground block uppercase font-mono">
                        {dish.variants[0].name}
                      </span>
                    )}
                  </div>

                  {hasPortions ? (
                    <button
                      type="button"
                      onClick={() =>
                        onSelectVariantItem ? onSelectVariantItem(dish) : add(dish)
                      }
                      className="border border-foreground bg-primary text-primary-foreground hover:bg-foreground hover:text-background px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded transition"
                    >
                      + Add
                    </button>
                  ) : currentQty === 0 ? (
                    <button
                      type="button"
                      onClick={() => add(dish)}
                      className="border border-foreground bg-primary text-primary-foreground hover:bg-foreground hover:text-background px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded transition"
                    >
                      + Add
                    </button>
                  ) : (
                    <div className="flex items-center border border-foreground rounded bg-background">
                      <button
                        type="button"
                        onClick={() => setQty(dish.id, currentQty - 1)}
                        className="px-1.5 py-0.5 hover:bg-muted text-xs"
                      >
                        <Minus size={11} />
                      </button>
                      <span className="mono px-1.5 text-xs font-bold font-mono">
                        {currentQty}
                      </span>
                      <button
                        type="button"
                        onClick={() => add(dish)}
                        className="px-1.5 py-0.5 hover:bg-muted text-xs"
                      >
                        <Plus size={11} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
