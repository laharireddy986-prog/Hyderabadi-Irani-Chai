import React, { useState } from "react";
import { useCustomerAuth } from "@/context/CustomerAuthContext";
import { MapPin, Home, Building2, Plus, Check, Trash2, Crosshair, Sparkles } from "lucide-react";
import { toast } from "sonner";

export default function CustomerAddressSelector({ selectedAddress, onSelectAddress }) {
  const { customer, addAddress, deleteAddress } = useCustomerAuth();
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(false);

  // New Address Form State
  const [label, setLabel] = useState("Home");
  const [addressText, setAddressText] = useState("");
  const [flatLandmark, setFlatLandmark] = useState("");
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);
  const [isDefault, setIsDefault] = useState(false);
  const [locating, setLocating] = useState(false);

  const addresses = customer?.addresses || [];

  const handleGetCurrentLocation = () => {
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const latitude = pos.coords.latitude;
        const longitude = pos.coords.longitude;
        setLat(latitude);
        setLng(longitude);

        // Reverse geocoding via OpenStreetMap Nominatim
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`
          );
          const data = await res.json();
          if (data && data.display_name) {
            setAddressText(data.display_name);
            toast.success("Location detected via GPS! 📍");
          }
        } catch {
          toast.info("GPS coordinates pinned.");
        } finally {
          setLocating(false);
        }
      },
      (err) => {
        setLocating(false);
        toast.error("Could not fetch location. Please enter manually.");
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleSaveNewAddress = async (e) => {
    e.preventDefault();
    if (!addressText.trim()) {
      toast.error("Please enter a street or building address");
      return;
    }

    setLoading(true);
    const res = await addAddress({
      label,
      address: addressText.trim(),
      flat_landmark: flatLandmark.trim(),
      lat: lat || undefined,
      lng: lng || undefined,
      is_default: isDefault || addresses.length === 0,
    });
    setLoading(false);

    if (res.ok) {
      toast.success("Address saved to your profile! 🏠");
      const newlyAdded = res.addresses[res.addresses.length - 1];
      if (newlyAdded && onSelectAddress) {
        onSelectAddress(newlyAdded);
      }
      setShowAddForm(false);
      setAddressText("");
      setFlatLandmark("");
    } else {
      toast.error(res.error || "Failed to save address");
    }
  };

  const handleDelete = async (e, addrId) => {
    e.stopPropagation();
    if (!window.confirm("Remove this address from saved list?")) return;
    const res = await deleteAddress(addrId);
    if (res.ok) {
      toast.success("Address removed");
    } else {
      toast.error("Failed to delete address");
    }
  };

  const getIcon = (lbl) => {
    const l = (lbl || "").toLowerCase();
    if (l === "home") return <Home className="w-4 h-4 text-amber-400 shrink-0" />;
    if (l === "work" || l === "office") return <Building2 className="w-4 h-4 text-sky-400 shrink-0" />;
    return <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />;
  };

  if (!customer) return null;

  return (
    <div className="space-y-3 mb-4">
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold text-amber-200 uppercase tracking-wider flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          Saved Delivery Addresses ({addresses.length})
        </label>
        <button
          type="button"
          onClick={() => setShowAddForm(!showAddForm)}
          className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 transition"
        >
          <Plus className="w-3.5 h-3.5" />
          {showAddForm ? "Cancel" : "Add New Address"}
        </button>
      </div>

      {/* Address Cards Grid */}
      {addresses.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {addresses.map((addr) => {
            const isSelected =
              selectedAddress?.id === addr.id ||
              (selectedAddress?.address && selectedAddress.address === addr.address);

            return (
              <div
                key={addr.id}
                onClick={() => onSelectAddress(addr)}
                className={`relative group cursor-pointer p-3 rounded-2xl border transition-all text-left flex flex-col justify-between ${
                  isSelected
                    ? "bg-amber-950/40 border-amber-500 shadow-md shadow-amber-950/50"
                    : "bg-stone-900/60 border-stone-800 hover:border-stone-700 hover:bg-stone-800/40"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-stone-950/80 border border-stone-800 text-stone-200">
                      {getIcon(addr.label)}
                      {addr.label || "Saved Address"}
                    </span>
                    {addr.is_default && (
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 font-semibold px-2 py-0.5 rounded-full">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-medium text-stone-200 line-clamp-2 leading-relaxed">
                    {addr.address}
                  </p>
                  {addr.flat_landmark && (
                    <p className="text-[11px] text-stone-400 mt-1 line-clamp-1">
                      Landmark: {addr.flat_landmark}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between mt-3 pt-2 border-t border-stone-800/50">
                  <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-400">
                    {isSelected ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-amber-400" />
                        Selected for Delivery
                      </>
                    ) : (
                      <span className="text-stone-400 group-hover:text-stone-200">Tap to Deliver Here</span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={(e) => handleDelete(e, addr.id)}
                    className="p-1 rounded-lg text-stone-500 hover:text-red-400 hover:bg-red-950/40 transition"
                    title="Delete address"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        !showAddForm && (
          <div className="p-4 rounded-2xl bg-stone-950/50 border border-stone-800/80 text-center">
            <p className="text-xs text-stone-400">No saved addresses yet.</p>
            <button
              type="button"
              onClick={() => setShowAddForm(true)}
              className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-400 bg-amber-950/30 border border-amber-800/40 rounded-xl hover:bg-amber-900/40 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Delivery Address
            </button>
          </div>
        )
      )}

      {/* Add New Address Drawer / Form */}
      {showAddForm && (
        <form
          onSubmit={handleSaveNewAddress}
          className="p-4 rounded-2xl bg-stone-950 border border-amber-800/40 space-y-3 animate-in fade-in"
        >
          <div className="flex items-center justify-between mb-1">
            <h4 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> Add New Delivery Address
            </h4>
            <div className="flex gap-1">
              {["Home", "Work", "Other"].map((lbl) => (
                <button
                  key={lbl}
                  type="button"
                  onClick={() => setLabel(lbl)}
                  className={`px-2.5 py-1 text-xs rounded-lg font-semibold transition ${
                    label === lbl
                      ? "bg-amber-600 text-white"
                      : "bg-stone-800 text-stone-400 hover:text-stone-200"
                  }`}
                >
                  {lbl}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-semibold text-stone-400">Street / Area Address</label>
              <button
                type="button"
                onClick={handleGetCurrentLocation}
                disabled={locating}
                className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 disabled:opacity-50"
              >
                <Crosshair className={`w-3 h-3 ${locating ? "animate-spin" : ""}`} />
                {locating ? "Locating..." : "Use Current GPS"}
              </button>
            </div>
            <textarea
              required
              rows={2}
              placeholder="e.g. Flat 302, Green Meadows, Rampally X Road, Secunderabad"
              value={addressText}
              onChange={(e) => setAddressText(e.target.value)}
              className="w-full p-2.5 bg-stone-900 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-600 text-xs focus:outline-none focus:border-amber-500 transition"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-stone-400 mb-1">
              Landmark / House No. (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Near HP Petrol Pump"
              value={flatLandmark}
              onChange={(e) => setFlatLandmark(e.target.value)}
              className="w-full p-2.5 bg-stone-900 border border-stone-700 rounded-xl text-stone-100 placeholder-stone-600 text-xs focus:outline-none focus:border-amber-500 transition"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 text-xs text-stone-400 cursor-pointer">
              <input
                type="checkbox"
                checked={isDefault}
                onChange={(e) => setIsDefault(e.target.checked)}
                className="rounded border-stone-700 text-amber-500 focus:ring-amber-500 bg-stone-900"
              />
              Set as default address
            </label>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 text-xs text-stone-400 hover:text-stone-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50"
              >
                {loading ? "Saving..." : "Save Address"}
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
