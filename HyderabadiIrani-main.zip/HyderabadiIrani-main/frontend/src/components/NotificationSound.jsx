import { useState, useEffect } from "react";
import { Volume2, VolumeX, BellRing, Play } from "lucide-react";
import { notificationSound } from "@/lib/notificationSound";

/**
 * Reusable NotificationSound Component
 * Can be embedded in Dashboard, Kitchen Screen, POS, or Table Booking management.
 * Plays loud notification alert for exactly 5 seconds on new order / booking trigger.
 */
export default function NotificationSound({
  trigger = null,
  duration = 5000,
  label = "Order Alert Sound",
  compact = false,
}) {
  const [muted, setMuted] = useState(() => {
    return localStorage.getItem("gh_sound_alerts_muted") === "true";
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [unlocked, setUnlocked] = useState(false);

  useEffect(() => {
    localStorage.setItem("gh_sound_alerts_muted", String(muted));
  }, [muted]);

  // When external trigger changes (e.g. new order ID), play for 5s
  useEffect(() => {
    if (trigger && !muted) {
      handlePlay(duration);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trigger]);

  const handlePlay = (timeMs = 5000) => {
    notificationSound.unlockAudio();
    setUnlocked(true);
    if (muted) return;

    setIsPlaying(true);
    notificationSound.play(timeMs);

    setTimeout(() => {
      setIsPlaying(false);
    }, timeMs);
  };

  const handleStop = () => {
    notificationSound.stop();
    setIsPlaying(false);
  };

  const toggleMute = () => {
    if (isPlaying) handleStop();
    setMuted((prev) => !prev);
  };

  if (compact) {
    return (
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={toggleMute}
          title={muted ? "Sound alerts are MUTED" : "Sound alerts are ACTIVE"}
          className={`p-1.5 border border-foreground text-xs uppercase font-semibold flex items-center gap-1 transition-colors ${
            muted
              ? "bg-muted text-muted-foreground"
              : isPlaying
              ? "bg-primary text-primary-foreground animate-pulse"
              : "bg-emerald-50 text-emerald-800 border-emerald-500"
          }`}
        >
          {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          <span className="hidden sm:inline">{muted ? "Muted" : isPlaying ? "Alerting (5s)..." : "Sound ON"}</span>
        </button>

        {!muted && (
          <button
            type="button"
            onClick={() => handlePlay(5000)}
            title="Test 5-second loud alarm"
            className="p-1.5 border border-foreground bg-card hover:bg-muted text-xs flex items-center gap-1"
          >
            <Play size={12} className="text-primary" />
            <span className="hidden md:inline text-[10px] uppercase font-bold">Test (5s)</span>
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="border border-foreground bg-card p-3 flex flex-wrap items-center justify-between gap-3 text-xs shadow-sm">
      <div className="flex items-center gap-2">
        <div
          className={`w-7 h-7 rounded flex items-center justify-center ${
            isPlaying
              ? "bg-primary text-primary-foreground animate-bounce"
              : muted
              ? "bg-muted text-muted-foreground"
              : "bg-emerald-100 text-emerald-800"
          }`}
        >
          {isPlaying ? <BellRing size={16} /> : muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </div>
        <div>
          <p className="font-bold tracking-tight">{label}</p>
          <p className="text-[10px] text-muted-foreground">
            {muted
              ? "Audio alerts disabled"
              : isPlaying
              ? "🚨 Ringing 5-second loud alarm..."
              : "Plays loud 5-second alarm on new online orders & table bookings"}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => handlePlay(5000)}
          disabled={muted}
          className="border border-foreground bg-background px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider hover:bg-muted disabled:opacity-40 flex items-center gap-1.5"
        >
          <Play size={12} className="text-primary" /> Test Alarm (5s)
        </button>

        <button
          type="button"
          onClick={toggleMute}
          className={`border border-foreground px-3 py-1 text-[11px] font-bold uppercase tracking-wider ${
            muted ? "bg-foreground text-background" : "bg-muted hover:bg-muted/80 text-foreground"
          }`}
        >
          {muted ? "Unmute Sound" : "Mute Sound"}
        </button>
      </div>
    </div>
  );
}
