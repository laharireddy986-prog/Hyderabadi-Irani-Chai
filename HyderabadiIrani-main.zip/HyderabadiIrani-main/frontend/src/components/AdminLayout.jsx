import { Link, useLocation, useNavigate } from "react-router-dom";
import { useMemo } from "react";
import { useAuth } from "@/context/AuthContext";
import { LayoutDashboard, Receipt, ScrollText, UtensilsCrossed, LogOut, Store, ChefHat, Tag, Users, Grid, UserCheck, ShieldCheck, Navigation } from "lucide-react";

const links = [
  { to: "/admin/pos", label: "Billing / POS", icon: Receipt, testid: "nav-pos" },
  { to: "/admin/orders", label: "Orders", icon: ScrollText, testid: "nav-orders" },
  { to: "/admin/live-tracking", label: "Live Delivery Radar", icon: Navigation, testid: "nav-live-tracking" },
  { to: "/kitchen", label: "Kitchen Screen", icon: ChefHat, testid: "nav-kitchen" },
  { to: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard, adminOnly: true, testid: "nav-dashboard" },
  { to: "/admin/customers", label: "Customer CRM", icon: UserCheck, adminOnly: true, testid: "nav-customers" },
  { to: "/admin/tables", label: "Table QR System", icon: Grid, adminOnly: true, testid: "nav-tables" },
  { to: "/admin/menu", label: "Menu", icon: UtensilsCrossed, adminOnly: true, testid: "nav-menu" },
  { to: "/admin/offers", label: "Offers Engine", icon: Tag, adminOnly: true, testid: "nav-offers" },
  { to: "/admin/staff", label: "Staff Management", icon: ShieldCheck, adminOnly: true, testid: "nav-staff" },
];

export const AdminLayout = ({ children }) => {
  const { user, logout } = useAuth();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const visibleLinks = useMemo(
    () => links.filter((l) => !l.adminOnly || user?.role === "admin"),
    [user?.role]
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-background">
      <aside className="lg:w-64 border-b lg:border-b-0 lg:border-r border-foreground bg-secondary text-secondary-foreground flex lg:flex-col">
        <div className="p-5 lg:border-b border-foreground/20 flex-1 lg:flex-none flex items-center gap-3">
          <img
            src="/logo.png"
            alt="Hyderabadi Irani Logo"
            className="h-10 w-10 object-contain rounded-full border border-secondary-foreground/20"
          />
          <div>
            <span className="serif text-xl font-bold tracking-tight text-primary block leading-none">
              Hyderabadi Irani
            </span>
            <span className="text-[10px] uppercase font-bold tracking-widest text-secondary-foreground/70">
              Food Court • Suite
            </span>
          </div>
        </div>
        <nav className="hidden lg:flex flex-col p-3 gap-1">
          {visibleLinks.map(({ to, label, icon: Icon, testid }) => (
              <Link
                key={to}
                to={to}
                data-testid={testid}
                className={`flex items-center gap-3 px-4 py-3 text-sm transition-colors ${
                  pathname === to
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-secondary-foreground/10"
                }`}
              >
                <Icon size={17} /> {label}
              </Link>
            ))}
          <a
            href="/"
            data-testid="nav-storefront"
            className="flex items-center gap-3 px-4 py-3 text-sm hover:bg-secondary-foreground/10"
          >
            <Store size={17} /> View Website
          </a>
        </nav>
        <div className="lg:mt-auto p-4 lg:border-t border-foreground/20 space-y-2">
          <div className="flex items-center gap-3">
            <div className="hidden lg:block">
              <p className="text-sm font-medium">{user?.name}</p>
              <p className="overline text-secondary-foreground/60">{user?.role}</p>
            </div>
            <button
              data-testid="logout-button"
              onClick={async () => {
                await logout();
                navigate("/login");
              }}
              className="lg:ml-auto p-2 border border-secondary-foreground/40 hover:bg-primary hover:border-primary transition-colors"
              title="Log out"
            >
              <LogOut size={16} />
            </button>
          </div>
          <div className="hidden lg:block text-[10px] text-secondary-foreground/50 text-center uppercase tracking-widest pt-1 border-t border-secondary-foreground/10 font-bold">
            Powered by NovaSaaS
          </div>
        </div>
      </aside>

      <div className="lg:hidden flex overflow-x-auto border-b border-foreground bg-muted">
        {visibleLinks.map(({ to, label, testid }) => (
            <Link
              key={to}
              to={to}
              data-testid={`${testid}-mobile`}
              className={`px-4 py-3 text-xs whitespace-nowrap border-r border-foreground ${
                pathname === to ? "bg-primary text-primary-foreground" : ""
              }`}
            >
              {label}
            </Link>
          ))}
      </div>

      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
};

export default AdminLayout;
