import { useState } from "react";
import { toast } from "sonner";
import { api, errMsg, money, openPdf } from "@/lib/api";

export const GstMonthly = () => {
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);

  const run = async (download) => {
    setBusy(true);
    try {
      if (download) {
        await openPdf(`/reports/gst-monthly.pdf?month=${month}`, { download: `gst-${month}.pdf` });
      } else {
        const res = await api.get("/reports/gst-monthly", { params: { month } });
        setData(res.data);
      }
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-10 border border-foreground bg-card p-5 sm:p-6" data-testid="gst-monthly-panel">
      <p className="overline text-primary">For the accountant</p>
      <h2 className="text-2xl font-semibold tracking-tighter mt-1">Monthly GST Statement</h2>
      <p className="mt-2 text-sm text-muted-foreground leading-relaxed max-w-xl">
        Taxable value, GST payable and gross collection for the whole month, with a day-wise table you can hand over as-is.
      </p>

      <div className="mt-5 flex flex-wrap gap-3 items-end">
        <div>
          <label className="block overline mb-1.5">Month</label>
          <input
            data-testid="gst-month-input"
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className="border border-foreground bg-background px-3 py-2.5 text-sm mono outline-none focus:ring-2 focus:ring-foreground"
          />
        </div>
        <button
          data-testid="gst-view-button"
          onClick={() => run(false)}
          disabled={busy}
          className="border border-foreground px-5 py-3 text-xs uppercase tracking-widest hover:bg-muted disabled:opacity-50"
        >
          View statement
        </button>
        <button
          data-testid="gst-download-button"
          onClick={() => run(true)}
          disabled={busy}
          className="hard-shadow border border-foreground bg-secondary text-secondary-foreground px-5 py-3 text-xs uppercase tracking-widest disabled:opacity-50"
        >
          Download PDF
        </button>
      </div>

      {data && (
        <div className="mt-7" data-testid="gst-summary">
          <div className="grid grid-cols-2 lg:grid-cols-4 border-t border-l border-foreground">
            {[
              ["Orders billed", data.orders, "orders"],
              ["Taxable value", money(data.subtotal), "subtotal"],
              [`GST payable (${Math.round(data.gst_rate * 100)}%)`, money(data.tax), "tax"],
              ["Gross collection", money(data.total), "total"],
            ].map(([l, v, id]) => (
              <div key={id} className="border-r border-b border-foreground p-4">
                <p className="overline text-muted-foreground">{l}</p>
                <p data-testid={`gst-${id}`} className="mono text-xl mt-2">{v}</p>
              </div>
            ))}
          </div>

          <div className="mt-6 overflow-x-auto border border-foreground">
            <table className="w-full text-sm border-collapse" data-testid="gst-day-table">
              <thead>
                <tr className="bg-muted text-left">
                  {["Date", "Orders", "Taxable", "GST", "Gross"].map((h) => (
                    <th key={h} className="border-b border-foreground px-4 py-2.5 overline whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.days.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-4 py-4 text-sm text-muted-foreground" data-testid="gst-no-data">
                      No sales recorded in this month.
                    </td>
                  </tr>
                )}
                {data.days.map((r) => (
                  <tr key={r.day} data-testid={`gst-row-${r.day}`} className="border-b border-foreground/15">
                    <td className="px-4 py-2.5 mono whitespace-nowrap">{r.day}</td>
                    <td className="px-4 py-2.5 mono">{r.orders}</td>
                    <td className="px-4 py-2.5 mono">{money(r.subtotal)}</td>
                    <td className="px-4 py-2.5 mono">{money(r.tax)}</td>
                    <td className="px-4 py-2.5 mono">{money(r.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default GstMonthly;
