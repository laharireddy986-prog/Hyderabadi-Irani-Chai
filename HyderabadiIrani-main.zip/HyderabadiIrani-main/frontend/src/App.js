import "@/App.css";
import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { CustomerAuthProvider } from "@/context/CustomerAuthContext";
import { CartProvider } from "@/context/CartContext";
import Storefront from "@/pages/Storefront";
import Checkout from "@/pages/Checkout";
import TrackOrder from "@/pages/TrackOrder";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Pos from "@/pages/Pos";
import Orders from "@/pages/Orders";
import MenuAdmin from "@/pages/MenuAdmin";
import OffersAdmin from "@/pages/OffersAdmin";
import StaffAdmin from "@/pages/StaffAdmin";
import CustomerAdmin from "@/pages/CustomerAdmin";
import TableAdmin from "@/pages/TableAdmin";
import Kitchen from "@/pages/Kitchen";
import DeliveryApp from "@/pages/DeliveryApp";
import LiveTracking from "@/pages/LiveTracking";
import CustomerAccount from "@/pages/CustomerAccount";
import LegalPolicies from "@/pages/LegalPolicies";
import AdminLayout from "@/components/AdminLayout";
import { initSyncEngine } from "@/lib/syncEngine";

function Protected({ children, adminOnly, bare }) {
  const { user, loading } = useAuth();
  if (loading)
    return (
      <div className="min-h-screen flex items-center justify-center overline" data-testid="auth-loading">
        Loading…
      </div>
    );
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === "delivery" && !bare) {
    return <Navigate to="/delivery" replace />;
  }
  if (user.role !== "delivery" && bare && window.location.pathname === "/delivery") {
    return <Navigate to="/admin/pos" replace />;
  }
  if (adminOnly && user.role !== "admin") return <Navigate to="/admin/pos" replace />;
  if (bare) return children;
  return <AdminLayout>{children}</AdminLayout>;
}

export default function App() {
  useEffect(() => {
    initSyncEngine();
  }, []);

  return (
    <AuthProvider>
      <CustomerAuthProvider>
        <CartProvider>
          <BrowserRouter>
            <Toaster position="top-right" />
            <Routes>
              <Route path="/" element={<Storefront />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/track" element={<TrackOrder />} />
              <Route path="/account" element={<CustomerAccount />} />
              <Route path="/terms" element={<LegalPolicies />} />
              <Route path="/terms-and-conditions" element={<LegalPolicies />} />
              <Route path="/privacy" element={<LegalPolicies />} />
              <Route path="/privacy-policy" element={<LegalPolicies />} />
              <Route path="/refund-policy" element={<LegalPolicies />} />
              <Route path="/cancellation-policy" element={<LegalPolicies />} />
              <Route path="/shipping-policy" element={<LegalPolicies />} />
              <Route path="/delivery-policy" element={<LegalPolicies />} />
              <Route path="/contact" element={<LegalPolicies />} />
              <Route path="/contact-us" element={<LegalPolicies />} />
              <Route path="/login" element={<Login />} />
              <Route path="/delivery" element={<Protected bare><DeliveryApp /></Protected>} />
              <Route path="/admin" element={<Navigate to="/admin/pos" replace />} />
              <Route path="/admin/pos" element={<Protected><Pos /></Protected>} />
              <Route path="/admin/orders" element={<Protected><Orders /></Protected>} />
              <Route path="/admin/live-tracking" element={<Protected><LiveTracking /></Protected>} />
              <Route path="/admin/dashboard" element={<Protected adminOnly><Dashboard /></Protected>} />
              <Route path="/admin/customers" element={<Protected adminOnly><CustomerAdmin /></Protected>} />
              <Route path="/admin/menu" element={<Protected adminOnly><MenuAdmin /></Protected>} />
              <Route path="/admin/offers" element={<Protected adminOnly><OffersAdmin /></Protected>} />
              <Route path="/admin/staff" element={<Protected adminOnly><StaffAdmin /></Protected>} />
              <Route path="/admin/tables" element={<Protected adminOnly><TableAdmin /></Protected>} />
              <Route path="/kitchen" element={<Protected bare><Kitchen /></Protected>} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </CartProvider>
      </CustomerAuthProvider>
    </AuthProvider>
  );
}

